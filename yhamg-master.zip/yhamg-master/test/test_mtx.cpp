/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <iostream>
#include <yhamg.h>

using namespace YHAMG;

static void SetInitialGuess(const ParMultiVector& X)
{
	int m = X.local.nvec;
	for (int j = 0; j < m; ++j)
		X(j).FillRandom();
}

int main(int argc, char* argv[])
{
	MPI_Init(&argc, &argv);

	int solver_type = 0;
	int pre_type = 0;
	int bsize = 1;
	char* in_file = 0;
	char* x0_file = 0;
	char* rhs_file = 0;
	char* out_file = 0;
	int m = 4;

	int arg_index = 1;

	while (arg_index < argc)
	{
		if (strcmp(argv[arg_index], "-in") == 0)
			in_file = argv[++arg_index];
		else if (strcmp(argv[arg_index], "-rhs") == 0)
			rhs_file = argv[++arg_index];
		else if (strcmp(argv[arg_index], "-x0") == 0)
			x0_file = argv[++arg_index];
		else if (strcmp(argv[arg_index], "-out") == 0)
			out_file = argv[++arg_index];
		else if (strcmp(argv[arg_index], "-bsize") == 0)
			bsize = atoi(argv[++arg_index]);
		else if (strcmp(argv[arg_index], "-pre") == 0)
			pre_type = atoi(argv[++arg_index]);
		else if (strcmp(argv[arg_index], "-solver") == 0)
			solver_type = atoi(argv[++arg_index]);
		else if (strcmp(argv[arg_index], "-m") == 0)
			m = atoi(argv[++arg_index]);
		++arg_index;
	}

	int    max_levels = 20;
	int    coarse_size = 8;
	double strength_threshold = 0.25;
	int    aggressive_levels = 1;
	int    coarsen_type = 1; // 0: HMIS, 1: PMIS
	int    interp_type = 1;  // 0: Long-Range Interpolation, 1: Smoothed Aggregation
	int    interp_min_elements = 4;
	int    interp_max_elements = 6;
	double truncation_factor = 0.01;
	double sparsification_threshold = 0.0;
	int    cycle_type = 0; // 0: V-Cycle, 1: W-Cycle, 2: F-Cycle
	int    pre_sweeps = 1;
	int    post_sweeps = 1;
	int    coarse_sweeps = 1;
	int    smooth_type = 2; // 0: Jacobi, 1: SOR, 2: ILU, 3: Chebyshev

	double jacobi_factor = 0.75;

	int    sor_type = 2; // 0: Forward, 1: Backword, 2: Symmetric
	double sor_factor = 1.0;

	int    ilu_maxfil = 0;
	double ilu_droptol = 0.01;

	int    chebyshev_order = 3;
	double chebyshev_eigen_ratio = 0.3;

	int    gmres_restart = 20;
	int    max_iters = 500;
	double tolerance = 1.0e-08;

	bool   print_stats = 1;

	if (!in_file)
		return -1;

	int comm_rank;
	MPI_Comm_rank(MPI_COMM_WORLD, &comm_rank);

	if (comm_rank == 0)
	{
		MPI_Comm comm = MPI_COMM_SELF;

		int iter;
		double relres;
		double setup_time;
		double solve_time;

		char line[1024];
		char banner[64];
		char mtx[64]; 
		char crd[64];
		char data_type[64];
		char storage_scheme[64];
		
		FILE* fin = fopen(in_file, "r");

		fgets(line, 1024, fin);
		sscanf(line, "%s %s %s %s %s", banner, mtx, crd, data_type, storage_scheme);

		char* p;
		p = data_type;
		do *p = tolower(*p); 
		while (*(++p) != '\0');

		p = storage_scheme;
		do *p = tolower(*p); 
		while (*(++p) != '\0');

		do fgets(line, 1024, fin);
		while (line[0] == '%');

		if (strcmp(data_type, "real") == 0)
		{
			ParOperator* A = 0;
			ParOperator* P = 0;

			if (strcmp(storage_scheme, "general") == 0)
			{
				int n, m, nz;
				sscanf(line, "%d %d %d", &n, &m, &nz);

				int* Ai = new int[nz];
				int* Aj = new int[nz];
				double* Av = new double[nz];

				for (int j = 0; j < nz; ++j)
				{
					fscanf(fin, "%d %d %lg\n", &Ai[j], &Aj[j], &Av[j]);
					--Ai[j];
					--Aj[j];
				}

				fclose(fin);

				if (bsize > 1)
				{
					A = new ParBSRMatrix(bsize, ParCSRMatrix(COOMatrix(n, m, nz, Ai, Aj, Av, 0)));
					((ParBSRMatrix*)A)->SetupHalo();
				}
				else
				{
					A = new ParCSRMatrix(COOMatrix(n, m, nz, Ai, Aj, Av, 0));
					((ParCSRMatrix*)A)->SetupHalo();
				}
			}
			else if (strcmp(storage_scheme, "symmetric") == 0)
			{
				int n, m, nz, _nz;
				sscanf(line, "%d %d %d", &n, &m, &_nz);

				int* Ai = new int[_nz * 2];
				int* Aj = new int[_nz * 2];
				double* Av = new double[_nz * 2];
				
				nz = 0;
				for (int j = 0; j < _nz; ++j)
				{
					fscanf(fin, "%d %d %lg\n", &Ai[nz], &Aj[nz], &Av[nz]);
					--Ai[nz];
					--Aj[nz];
					if (Ai[nz] != Aj[nz])
					{
						Ai[nz + 1] = Aj[nz];
						Aj[nz + 1] = Ai[nz];
						Av[nz + 1] = Av[nz];
						++nz;
					}
					++nz;
				}

				fclose(fin);

				if (bsize > 1)
				{
					A = new ParBSRMatrix(bsize, ParCSRMatrix(COOMatrix(n, m, nz, Ai, Aj, Av, 0)));
					((ParBSRMatrix*)A)->SetupHalo();
				}
				else
				{
					A = new ParCSRMatrix(COOMatrix(n, m, nz, Ai, Aj, Av, 0));
					((ParCSRMatrix*)A)->SetupHalo();
				}
			}

			if (bsize > 1)
			{
				std::cout << "\n# Test Problem\n";
				std::cout << "--------------------------------------------------\n";
				std::cout << "Input File: \"" << in_file << "\"\n";
				std::cout << "RelaxationType & Structure: " << data_type << " " << storage_scheme << "\n";
				std::cout << "Rows: " << ((ParBSRMatrix*)A)->local.size[0] << ", Nz: " << ((ParBSRMatrix*)A)->local.rowptr[((ParBSRMatrix*)A)->local.size[0]] << "\n";
				std::cout << "Bsize: " << ((ParBSRMatrix*)A)->local.bsize << "\n";
			}
			else
			{
				std::cout << "\n# Test Problem\n";
				std::cout << "--------------------------------------------------\n";
				std::cout << "Input File: \"" << in_file << "\"\n";
				std::cout << "RelaxationType & Structure: " << data_type << " " << storage_scheme << "\n";
				std::cout << "Rows: " << ((ParCSRMatrix*)A)->local.size[0] << ", Nz: " << ((ParCSRMatrix*)A)->local.rowptr[((ParCSRMatrix*)A)->local.size[0]] << "\n";
			}

			if (pre_type >= 0 && pre_type < 5)
			{
				MPI_Barrier(comm);
				setup_time = -MPI_Wtime();

				if (pre_type == 3)
				{
					std::cout << "\n# Chebyshev Setup Phase\n";
					std::cout  << "--------------------------------------------------\n";

					P = new ParOperatorChebyshev(chebyshev_order, chebyshev_eigen_ratio, *A);
				}
				else if (bsize == 1)
				{

					if (pre_type == 0)
					{
						std::cout << "\n# Jacobi Setup Phase\n";
						std::cout << "--------------------------------------------------\n";
						P = new ParCSRPrecondJacobi;
					}
					else if (pre_type == 1)
					{
						std::cout << "\n# SOR Setup Phase\n";
						std::cout  << "--------------------------------------------------\n";
						P = new ParCSRPrecondSOR(sor_type, sor_factor);
					}
					else if (pre_type == 2)
					{
						std::cout << "\n# ILU Setup Phase\n";
						std::cout  << "--------------------------------------------------\n";
						P = new ParCSRPrecondILU0;
					}
					else if (pre_type == 4)
					{
						std::cout << "\n# AMG Setup Phase\n";
						std::cout  << "--------------------------------------------------\n";
						P = new ParCSRPrecondAMG();
						((ParCSRPrecondAMG*)P)->MaxLevels = max_levels;
						((ParCSRPrecondAMG*)P)->CoarseSize = coarse_size;
						((ParCSRPrecondAMG*)P)->StrengthThreshold = strength_threshold;
						((ParCSRPrecondAMG*)P)->AggressiveLevels = aggressive_levels;
						((ParCSRPrecondAMG*)P)->CoarsenType = coarsen_type;
						((ParCSRPrecondAMG*)P)->InterpType = interp_type;
						((ParCSRPrecondAMG*)P)->InterpMinElements = interp_min_elements;
						((ParCSRPrecondAMG*)P)->InterpMaxElements = interp_max_elements;
						((ParCSRPrecondAMG*)P)->TruncationFactor = truncation_factor;
						((ParCSRPrecondAMG*)P)->SparsificationThreshold = sparsification_threshold;
						((ParCSRPrecondAMG*)P)->CycleType = cycle_type;
						((ParCSRPrecondAMG*)P)->PreSweeps = pre_sweeps;
						((ParCSRPrecondAMG*)P)->PostSweeps = post_sweeps;
						((ParCSRPrecondAMG*)P)->CoarseSweeps = coarse_sweeps;
						((ParCSRPrecondAMG*)P)->SmoothType = smooth_type;
						((ParCSRPrecondAMG*)P)->JacobiFactor = jacobi_factor;
						((ParCSRPrecondAMG*)P)->SORType = sor_type;
						((ParCSRPrecondAMG*)P)->SORFactor = sor_factor;
						((ParCSRPrecondAMG*)P)->ILUMaxFillins = ilu_maxfil;
						((ParCSRPrecondAMG*)P)->ILUDropTolerance = ilu_droptol;
						((ParCSRPrecondAMG*)P)->ChebyshevEigenRatio = chebyshev_eigen_ratio;
						((ParCSRPrecondAMG*)P)->PrintStats = print_stats;
					}

					if (P) ((ParCSRPrecond*)P)->Setup(*(ParCSRMatrix*)A);
				}
				else
				{
					if (pre_type == 0)
					{
						std::cout << "\n# Jacobi Setup Phase\n";
						std::cout  << "--------------------------------------------------\n";
						P = new ParBSRPrecondJacobi;
					}
					else if (pre_type == 1)
					{
						std::cout << "\n# SOR Setup Phase\n";
						std::cout  << "--------------------------------------------------\n";
						P = new ParBSRPrecondSOR(sor_type, sor_factor);
					}
					else if (pre_type == 2)
					{
						std::cout << "\n# ILU Setup Phase\n";
						std::cout  << "--------------------------------------------------\n";
						P = new ParBSRPrecondILU0;
					}
					else if (pre_type == 4)
					{
						std::cout << "\n# AMG Setup Phase\n";
						std::cout  << "--------------------------------------------------\n";
						P = new ParBSRPrecondAMG();
						((ParBSRPrecondAMG*)P)->MaxLevels = max_levels;
						((ParBSRPrecondAMG*)P)->CoarseSize = coarse_size;
						((ParBSRPrecondAMG*)P)->StrengthThreshold = strength_threshold;
						((ParBSRPrecondAMG*)P)->AggressiveLevels = aggressive_levels;
						((ParBSRPrecondAMG*)P)->CoarsenType = coarsen_type;
						((ParBSRPrecondAMG*)P)->InterpType = interp_type;
						((ParBSRPrecondAMG*)P)->InterpMinElements = interp_min_elements;
						((ParBSRPrecondAMG*)P)->InterpMaxElements = interp_max_elements;
						((ParBSRPrecondAMG*)P)->TruncationFactor = truncation_factor;
						((ParBSRPrecondAMG*)P)->SparsificationThreshold = sparsification_threshold;
						((ParBSRPrecondAMG*)P)->CycleType = cycle_type;
						((ParBSRPrecondAMG*)P)->PreSweeps = pre_sweeps;
						((ParBSRPrecondAMG*)P)->PostSweeps = post_sweeps;
						((ParBSRPrecondAMG*)P)->CoarseSweeps = coarse_sweeps;
						((ParBSRPrecondAMG*)P)->SmoothType = smooth_type;
						((ParBSRPrecondAMG*)P)->JacobiFactor = jacobi_factor;
						((ParBSRPrecondAMG*)P)->SORType = sor_type;
						((ParBSRPrecondAMG*)P)->SORFactor = sor_factor;
						((ParBSRPrecondAMG*)P)->ILUMaxFillins = ilu_maxfil;
						((ParBSRPrecondAMG*)P)->ILUDropTolerance = ilu_droptol;
						((ParBSRPrecondAMG*)P)->ChebyshevEigenRatio = chebyshev_eigen_ratio;
						((ParBSRPrecondAMG*)P)->PrintStats = print_stats;
					}

					if (P) ((ParBSRPrecond*)P)->Setup(*(ParBSRMatrix*)A);
				}

				MPI_Barrier(comm);
				setup_time += MPI_Wtime();

				std::cout << "Setup Time: " << setup_time << "\n";
			}

			if(solver_type == 3)
			{
				int iter;
				Vector Lambda, Res;
				Lambda.Resize(m);
				Res.Resize(m);

				ParMultiVector X(comm);
				X.Allocate(m, A->OutSize());
				SetInitialGuess(X);

				solve_time = -MPI_Wtime();
				std::cout << "\n# LOBPCG Solve Phase\n";
				std::cout << "--------------------------------------------------\n";

				if (P) ParEigenSolverLOBPCG(max_iters, tolerance, print_stats)(*A, *P, X, Lambda, iter, Res);
				else ParEigenSolverLOBPCG(max_iters, tolerance, print_stats)(*A, X, Lambda, iter, Res);
	
				solve_time += MPI_Wtime();
				std::cout << "Solve Time: " << solve_time << "\n";
				std::cout << "Time/Iteration: " << solve_time / iter << "\n";

				std::cout << "\n";
				for (int j = 0; j < m; ++j)
					std::cout <<"LAMBDA #" << j + 1 << " = "<< Lambda.values[j] << "\n";

				if (out_file)
				{
					int n = X.local.size;
					double* Xv = X.local.values;

					FILE* fout = fopen(out_file, "w");

					fprintf(fout, "%s\n", "%%MatrixMarket matrix array real general");
					fprintf(fout, "%d %d\n", n, m);

					for (int i = 0; i < n; ++i)
					{
						for (int j = 0; j < m; ++j)
						{
							fprintf(fout, "%20.16g ", Xv[i + j * n]);
						}
						fprintf(fout, "\n");
					}

					fclose(fout);
				}
			}
			else
			{
				ParVector x(comm);
				ParVector b(comm);

				if (!rhs_file)
				{
					b.Resize(A->OutSize());
					b.Fill(1.0);
				}
				else
				{
					FILE* frhs = fopen(rhs_file, "r");

					do fgets(line, 1024, frhs);
					while (line[0] == '%');

					int n, m;
					sscanf(line, "%d %d", &n, &m);

					double* bv = new double[n];
					for (int i = 0; i < n; ++i)
						fscanf(frhs, "%lg\n", &bv[i]);

					fclose(frhs);

					b = ParVector(comm, n, bv, 0);
				}
				
				if (!x0_file)
				{
					x.Resize(A->InSize());
					x.Fill(0.0);
				}
				else
				{
					FILE* fx0 = fopen(x0_file, "r");

					do fgets(line, 1024, fx0);
					while (line[0] == '%');

					int n, m;
					sscanf(line, "%d %d", &n, &m);

					double* xv = new double[n];
					for (int i = 0; i < n; ++i)
						fscanf(fx0, "%lg\n", &xv[i]);

					fclose(fx0);

					x = ParVector(comm, n, xv, 0);
				}

				if (solver_type == 0)
				{
					solve_time = -MPI_Wtime();
					std::cout << "\n# CG Solve Phase\n";
					std::cout << "--------------------------------------------------\n";

					if (P) ParSolverCG(max_iters, tolerance, print_stats)(*A, *P, b, x, iter, relres);
					else ParSolverCG(max_iters, tolerance, print_stats)(*A, b, x, iter, relres);

					solve_time += MPI_Wtime();
					std::cout << "Solve Time: " << solve_time << "\n";
					std::cout << "Time/Iteration: " << solve_time / iter << "\n";
				}
				else if (solver_type == 1)
				{
					solve_time = -MPI_Wtime();
					std::cout << "\n# GMRES Solve Phase\n";
					std::cout << "--------------------------------------------------\n";

					if (P) ParSolverGMRES(gmres_restart, max_iters, tolerance, print_stats)(*A, *P, b, x, iter, relres);
					else ParSolverGMRES(gmres_restart, max_iters, tolerance, print_stats)(*A, b, x, iter, relres);

					solve_time += MPI_Wtime();
					std::cout << "Solve Time: " << solve_time << "\n";
					std::cout << "Time/Iteration: " << solve_time / iter << "\n";
				}
				else if (solver_type == 2)
				{
					solve_time = -MPI_Wtime();
					std::cout << "\n# BiCGStab Solve Phase\n";
					std::cout << "--------------------------------------------------\n";

					if (P) ParSolverBCGS(max_iters, tolerance, print_stats)(*A, *P, b, x, iter, relres);
					else ParSolverBCGS(max_iters, tolerance, print_stats)(*A, b, x, iter, relres);

					solve_time += MPI_Wtime();
					std::cout << "Solve Time: " << solve_time << "\n";
					std::cout << "Time/Iteration: " << solve_time / iter << "\n";		
				}

				if (out_file)
				{
					int n = x.local.size;
					double* xv = x.local.values;

					FILE* fout = fopen(out_file, "w");

					fprintf(fout, "%s\n", "%%MatrixMarket matrix array real general");
					fprintf(fout, "%d %d\n", n, 1);

					for (int i = 0; i < n; ++i)
						fprintf(fout, "%20.16g\n", xv[i]);

					fclose(fout);
				}
			}

			if (A) delete A;
			if (P) delete P;
		}
		else if (strcmp(data_type, "complex") == 0)
		{
			ParComplexOperator* A = 0;
			ParComplexOperator* P = 0;
			
			if (strcmp(storage_scheme, "general") == 0)
			{
				int n, m, nz;
				sscanf(line, "%d %d %d", &n, &m, &nz);

				int* Ai = new int[nz];
				int* Aj = new int[nz];
				zomplex* Av = new zomplex[nz];

				for (int j = 0; j < nz; ++j)
				{
					double re, im;
					fscanf(fin, "%d %d %lg %lg\n", &Ai[j], &Aj[j], &re, &im);
					Av[j] = zomplex(re, im);
					--Ai[j];
					--Aj[j];
				}

				fclose(fin);

				A = new ParComplexCSRMatrix(ComplexCOOMatrix(n, m, nz, Ai, Aj, Av, 0));
			}
			else if (strcmp(storage_scheme, "hermitian") == 0)
			{
				int n, m, nz, _nz;
				sscanf(line, "%d %d %d", &n, &m, &_nz);

				int* Ai = new int[_nz * 2];
				int* Aj = new int[_nz * 2];
				zomplex* Av = new zomplex[_nz * 2];

				nz = 0;
				for (int j = 0; j < _nz; ++j)
				{
					double re, im;
					fscanf(fin, "%d %d %lg %lg\n", &Ai[nz], &Aj[nz], &re, &im);
					Av[nz] = zomplex(re, im);
					--Ai[nz];
					--Aj[nz];
					if (Ai[nz] != Aj[nz])
					{
						Ai[nz + 1] = Aj[nz];
						Aj[nz + 1] = Ai[nz];
						Av[nz + 1] = zconj(Av[nz]);
						++nz;
					}
					++nz;
				}

				fclose(fin);

				A = new ParComplexCSRMatrix(ComplexCOOMatrix(n, m, nz, Ai, Aj, Av, 0));
			}
			else if (strcmp(storage_scheme, "symmetric") == 0)
			{
				int n, m, nz, _nz;
				sscanf(line, "%d %d %d", &n, &m, &_nz);

				int* Ai = new int[_nz * 2];
				int* Aj = new int[_nz * 2];
				zomplex* Av = new zomplex[_nz * 2];

				nz = 0;
				for (int j = 0; j < _nz; ++j)
				{
					double re, im;
					fscanf(fin, "%d %d %lg %lg\n", &Ai[nz], &Aj[nz], &re, &im);
					Av[nz] = zomplex(re, im);
					--Ai[nz];
					--Aj[nz];
					if (Ai[nz] != Aj[nz])
					{
						Ai[nz + 1] = Aj[nz];
						Aj[nz + 1] = Ai[nz];
						Av[nz + 1] = Av[nz];
						++nz;
					}
					++nz;
				}

				fclose(fin);

				A = new ParComplexCSRMatrix(ComplexCOOMatrix(n, m, nz, Ai, Aj, Av, 0));
			}

			std::cout << "\n# Test Problem\n";
			std::cout << "--------------------------------------------------\n";
			std::cout << "Input File: \"" << in_file << "\"\n";
			std::cout << "Type & Structure: " << data_type << " " << storage_scheme << "\n";
			std::cout << "Rows: " << ((ParComplexCSRMatrix*)A)->local.size[0] << ", nz: " << ((ParComplexCSRMatrix*)A)->local.rowptr[((ParComplexCSRMatrix*)A)->local.size[0]] << "\n";

			((ParComplexCSRMatrix*)A)->SetupHalo();


			setup_time = -MPI_Wtime();

			if (pre_type == 0)
			{
				std::cout << "\n# Jacobi Setup Phase\n";
				std::cout << "--------------------------------------------------\n";
				P = new ParComplexCSRPrecondJacobi;
			}
			else if (pre_type == 1)
			{
				std::cout << "\n# SOR Setup Phase\n";
				std::cout << "--------------------------------------------------\n";
				P = new ParComplexCSRPrecondSOR(sor_type, sor_factor);
			}
			else if (pre_type == 2)
			{
				std::cout << "\n# ILU Setup Phase\n";
				std::cout << "--------------------------------------------------\n";
				P = new ParComplexCSRPrecondILU0;
			}

			setup_time += MPI_Wtime();

			std::cout << "Setup Time: " << setup_time << "\n";

			ParComplexVector x(comm);
			ParComplexVector b(comm);

			if (!rhs_file)
			{
				b.Resize(A->OutSize());
				b.Fill(1.0);
			}
			else
			{
				char line[1024];
				char banner[64];
				char mtx[64]; 
				char arr[64];
				char data_type[64];
				char storage_scheme[64];

				FILE* frhs = fopen(rhs_file, "r");

				fgets(line, 1024, frhs);
				sscanf(line, "%s %s %s %s %s", banner, mtx, arr, data_type, storage_scheme);

				char* p;
				p = data_type;
				do *p = tolower(*p); 
				while (*(++p) != '\0');

				do fgets(line, 1024, frhs);
				while (line[0] == '%');

				if (strcmp(data_type, "real") == 0)
				{
					int n, m;
					sscanf(line, "%d %d", &n, &m);

					zomplex* bv = new zomplex[n];
					for (int i = 0; i < n; ++i)
					{
						double re;
						fscanf(frhs, "%lg\n", &re);
						bv[i] = zomplex(re);
					}

					fclose(frhs);

					b = ParComplexVector(comm, n, bv, 0);
				}
				else if (strcmp(data_type, "complex") == 0)
				{
					int n, m;
					sscanf(line, "%d %d", &n, &m);

					zomplex* bv = new zomplex[n];
					for (int i = 0; i < n; ++i)
					{
						double re, im;
						fscanf(frhs, "%lg %lg\n", &re, &im);
						bv[i] = zomplex(re, im);
					}

					fclose(frhs);

					b = ParComplexVector(comm, n, bv, 0);
				}
			}

			if (!x0_file)
			{
				x.Resize(A->InSize());
				x.Fill(0.0);
			}
			else
			{
				char line[1024];
				char banner[64];
				char mtx[64]; 
				char arr[64];
				char data_type[64];
				char storage_scheme[64];

				FILE* fx0 = fopen(x0_file, "r");

				fgets(line, 1024, fx0);
				sscanf(line, "%s %s %s %s %s", banner, mtx, arr, data_type, storage_scheme);

				char* p;
				p = data_type;
				do *p = tolower(*p); 
				while (*(++p) != '\0');

				do fgets(line, 1024, fx0);
				while (line[0] == '%');

				if (strcmp(data_type, "real") == 0)
				{
					int n, m;
					sscanf(line, "%d %d", &n, &m);

					zomplex* xv = new zomplex[n];
					for (int i = 0; i < n; ++i)
					{
						double re;
						fscanf(fx0, "%lg\n", &re);
						xv[i] = zomplex(re);
					}

					fclose(fx0);

					x = ParComplexVector(comm, n, xv, 0);
				}
				else if (strcmp(data_type, "complex") == 0)
				{
					int n, m;
					sscanf(line, "%d %d", &n, &m);

					zomplex* xv = new zomplex[n];
					for (int i = 0; i < n; ++i)
					{
						double re, im;
						fscanf(fx0, "%lg %lg\n", &re, &im);
						xv[i] = zomplex(re, im);
					}

					fclose(fx0);

					x = ParComplexVector(comm, n, xv, 0);
				}
			}

			if (solver_type == 0)
			{
				solve_time = -MPI_Wtime();
				std::cout << "\n# CG Solve Phase\n";
				std::cout << "--------------------------------------------------\n";

				if (P) ParComplexSolverCG(max_iters, tolerance, print_stats)(*A, *P, b, x, iter, relres);
				else ParComplexSolverCG(max_iters, tolerance, print_stats)(*A, b, x, iter, relres);

				solve_time += MPI_Wtime();
				std::cout << "Solve Time: " << solve_time << "\n";
				std::cout << "Time/Iteration: " << solve_time / iter << "\n";
			}
			else if (solver_type == 1)
			{
				solve_time = -MPI_Wtime();
				std::cout << "\n# GMRES Solve Phase\n";
				std::cout << "--------------------------------------------------\n";

				if (P) ParComplexSolverGMRES(gmres_restart, max_iters, tolerance, print_stats)(*A, *P, b, x, iter, relres);
				else ParComplexSolverGMRES(gmres_restart, max_iters, tolerance, print_stats)(*A, b, x, iter, relres);

				solve_time += MPI_Wtime();
				std::cout << "Solve Time: " << solve_time << "\n";
				std::cout << "Time/Iteration: " << solve_time / iter << "\n";
			}
			else if (solver_type == 2)
			{
				solve_time = -MPI_Wtime();
				std::cout << "\n# BiCGStab Solve Phase\n";
				std::cout << "--------------------------------------------------\n";

				if (P) ParComplexSolverBCGS(max_iters, tolerance, print_stats)(*A, *P, b, x, iter, relres);
				else ParComplexSolverBCGS(max_iters, tolerance, print_stats)(*A, b, x, iter, relres);

				solve_time += MPI_Wtime();
				std::cout << "Solve Time: " << solve_time << "\n";
				std::cout << "Time/Iteration: " << solve_time / iter << "\n";
			}

			if (out_file)
			{
				int n = x.local.size;
				zomplex* xv = x.local.values;

				FILE* fout = fopen(out_file, "w");

				fprintf(fout, "%s\n", "%%MatrixMarket matrix array complex general");
				fprintf(fout, "%d %d\n", n, 1);

				for (int i = 0; i < n; ++i)
				{
					double re = zreal(xv[i]);
					double im = zimag(xv[i]);
					fprintf(fout, "%20.16g %20.16g\n", re, im);
				}

				fclose(fout);
			}

			if (A) delete A;
			if (P) delete P;
		}
	}

	MPI_Finalize();

	return 0;
}
