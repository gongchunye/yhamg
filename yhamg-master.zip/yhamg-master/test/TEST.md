## YHAMG - TEST
### Running
- test_solver
```
mpirun -n 8 ./test_solver -laplace -n 64 64 64 -P 2 2 2 -pre 4
```
- test_eigen
```
mpirun -n 8 ./test_eigen -laplace -n 32 32 32 -P 2 2 2 -m 4 -pre 2
```
- test_mtx
```
./test_mtx -in thermal1.mtx -rhs thermal1_b.mtx -out thermal1_x.mtx -pre 4 -solver 1
```
### Options
- Laplace
```
-laplace         3D Laplace problem on a cube(default)
-27pt            3D Laplace problem with 27-point stencil
-n <nx ny nz>    local domain size
-b <bx by bz>    nonzero block size
-P <Px Py Pz>    MPI process size
```
- Solver
```
-pre <ID>        preconditioner ID
                 0(default): Jacobi
                 1: SOR
                 2: ILU(0)
				 3: Chebyshev
                 4: AMG

-solver <ID>     solver ID
                 0(default): CG
                 1: GMRES(10)
                 2: BiCGStab
```
- EigenSolver
```
-m <m>           number of eigenvalues to solve

-pre <ID>        preconditioner ID
                 0(default): Jacobi
                 1: SOR
                 2: ILU(0)
				 3: Chebyshev
                 4: AMG

-solver <ID>     solver ID
                 0(default): LOBPCG
```
- MTX - IO
```
-in  <filename>  input matrix file
-rhs <filename>  input rhs vector
-x0  <filename>  initial guess
-out <filename>  output solution
-bsize  <bsize>  nonzero block size
```