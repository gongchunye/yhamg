/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef COOMatrix_H
#define COOMatrix_H

#include "Operator.hpp"

namespace YHAMG
{

struct COOMatrix : public Operator
{
	int ref;
	int size[2];
	int nnz;
	
	int* rowind;
	int* colind;
	double* values;

	COOMatrix();
	COOMatrix(int n, int m, int nnz, int* rowind, int* colind, double* values, int ref);
	COOMatrix(const COOMatrix& A);
	COOMatrix(COOMatrix&& A);
	~COOMatrix();
	COOMatrix& operator=(const COOMatrix& A);
	COOMatrix& operator=(COOMatrix&& A);
	
	void Free();
	void Refer(const COOMatrix& A);
	int InSize() const;
	int OutSize() const;
	void Apply(const Vector& x, const Vector& y) const;
};

void COORead(const char* filename, COOMatrix& A);
void COOWrite(const char* filename, const COOMatrix& A);

}

#endif