/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef ParSolverGMRES_H
#define ParSolverGMRES_H

#include "ParSolver.hpp"

namespace YHAMG
{

class ParSolverGMRES : public ParSolver
{
public:
	int    Restart;
	int    MaxIters;
	double Tolerance;
	int    PrintStats;

	using ParSolver::operator();
	ParSolverGMRES(int restart = 10, int max_iters = 500, double tolerance = 1.0e-08, int print_stats = 0);
	void operator()(const ParOperator& A, const ParOperator& P, const ParVector& b, const ParVector& x, int& iter, double& relres) const;
};

}

#endif