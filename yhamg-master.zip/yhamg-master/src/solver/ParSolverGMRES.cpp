/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <cmath>
#include <iostream>
#include "ParSolverGMRES.hpp"

namespace YHAMG
{

ParSolverGMRES::ParSolverGMRES(int restart, int max_iters, double tolerance, int print_stats)
	: Restart(restart),
	MaxIters(max_iters),
	Tolerance(tolerance),
	PrintStats(print_stats)
{
}

#define ABS(x) ((x) > 0 ? (x) : -(x))
#define H(i, j) (H[(i) + (((j) + 1) * (j) / 2)])

static inline void GeneratePlaneRotation(double dx, double dy, double& cs, double& sn)
{
	if (dy == 0.0)
	{
		cs = 1.0;
		sn = 0.0;
	}
	else if (ABS(dy) > ABS(dx))
	{
		double temp = dx / dy;
		sn = 1.0 / sqrt(1.0 + temp * temp);
		cs = temp * sn;
	}
	else
	{
		double temp = dy / dx;
		cs = 1.0 / sqrt(1.0 + temp * temp);
		sn = temp * cs;
	}
}

static inline void ApplyPlaneRotation(double& dx, double& dy, double cs, double sn)
{
	double temp = cs * dx + sn * dy;
	dy = -sn * dx + cs * dy;
	dx = temp;
}

static inline void SolveUpperTriangular(int m, const double* H, double* y)
{
	for (int i = m - 1; i >= 0; --i)
	{
		y[i] /= H(i, i);
		for (int j = i - 1; j >= 0; --j)
			y[j] -= H(j, i) * y[i];
	}
}

void ParSolverGMRES::operator()(const ParOperator& A, const ParOperator& P, const ParVector& b, const ParVector& x, int& iter, double& relres) const
{
	MPI_Comm comm = A.comm;

	int comm_rank;
	MPI_Comm_rank(comm, &comm_rank);

	int m = Restart;
	int n = A.OutSize();

	double normb, res;
	double* cs = new double[m];
	double* sn = new double[m];
	double* y = new double[m + 1];
	double* H = new double[(m + 1) * m / 2 + 1];
	ParVector w(comm), z(comm);
	ParVector* v = new ParVector[m + 1];

	for (int k = 0; k <= m; ++k)
	{
		v[k].comm = comm;
		v[k].Resize(n);
	}

	w.Resize(n);
	z.Resize(n);

	if (PrintStats && comm_rank == 0)
	{
		std::cout << "Iter\tResidual\n";
		std::cout << "--------------------------------------------------\n";
	}

	iter = 0;

	normb = sqrt(ParVecDot(b, b));

	while (1)
	{
		A.Apply(x, v[0]);
		ParVecAXPBY(1.0, b, -1.0, v[0]);
		
		res = sqrt(ParVecDot(v[0], v[0]));

		if (iter == 0 && PrintStats && comm_rank == 0)
			std::cout << iter << "\t" << res << "\n";

		if (res / normb <= Tolerance || iter == MaxIters) break;

		v[0].Scale(1.0 / res);

		for (int i = 0; i <= m; ++i)
			y[i] = 0.0;

		y[0] = res;

		int k = 0;

		while (1)
		{
			P.Apply(v[k], z);

			A.Apply(z, v[k + 1]);

			for (int i = 0; i <= k; ++i)
			{
				H(i, k) = ParVecDot(v[i], v[k + 1]);
				v[k + 1].AddScaled(-H(i, k), v[i]);
			}

			H(k + 1, k) = sqrt(ParVecDot(v[k + 1], v[k + 1]));

			v[k + 1].Scale(1.0 / H(k + 1, k));

			for (int i = 0; i < k; ++i)
				ApplyPlaneRotation(H(i, k), H(i + 1, k), cs[i], sn[i]);

			GeneratePlaneRotation(H(k, k), H(k + 1, k), cs[k], sn[k]);
			ApplyPlaneRotation(H(k, k), H(k + 1, k), cs[k], sn[k]);
			ApplyPlaneRotation(y[k], y[k + 1], cs[k], sn[k]);

			res = ABS(y[k + 1]);

			++k;
			++iter;

			if (comm_rank == 0 && PrintStats)
				std::cout << iter << "\t" << res << "\n";

			if (res / normb <= Tolerance || k == m || iter == MaxIters) break;
		}

		SolveUpperTriangular(k, H, y);

		w.Fill(0.0);

		int i = 0;
		for ( ; i + 1 < k; i += 2)
			w.Add2Scaled(y[i], v[i], y[i + 1], v[i + 1]);
		if (i + 1 == k) w.AddScaled(y[i], v[i]);

		P.Apply(w, z);

		x.AddScaled(1.0, z);

		if (res / normb <= Tolerance || iter == MaxIters) break;
	}

	relres = res / normb;

	if (PrintStats && comm_rank == 0)
	{
		std::cout << "--------------------------------------------------\n";
		std::cout << "Iterations: " << iter << "\n";
		std::cout << "Final Relative Residual: " << relres << "\n";
	}

	delete[] v;
	delete[] y;
	delete[] cs;
	delete[] sn;
	delete[] H;
}

}