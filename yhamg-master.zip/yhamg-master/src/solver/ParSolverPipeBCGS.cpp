/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <cmath>
#include <iostream>
#include "ParSolverPipeBCGS.hpp"

namespace YHAMG
{

ParSolverPipeBCGS::ParSolverPipeBCGS(int max_iters, double tolerance, int print_stats)
	: MaxIters(max_iters),
	Tolerance(tolerance),
	PrintStats(print_stats)
{
}

#define PBCGS_RR_STEPS         100
#define APPLYDOT(x, y, result) ApplyDot(x, y, result, buf, dst, cnt)
#define BEGINREDUCTION()       BeginReduction(buf, cnt, comm, &request)
#define ENDREDUCTION()         EndReduction(buf, dst, cnt, &request, &status)

static inline void ApplyDot(const ParVector& x, const ParVector& y, double& result, double* buf, double **dst, int &cnt)
{
	buf[cnt] = VecDot(x.local, y.local);
	dst[cnt++] = &result;
}

static inline void BeginReduction(double* buf, int cnt, MPI_Comm comm, MPI_Request* request)
{
	MPI_Iallreduce(MPI_IN_PLACE, buf, cnt, MPI_DOUBLE, MPI_SUM, comm, request);
}

static inline void EndReduction(const double* buf, double** dst, int &cnt, MPI_Request* request, MPI_Status* status)
{
	MPI_Wait(request, status);
	for (int i = 0; i < cnt; ++i)
		*dst[i] = buf[i];
	cnt = 0;
}

void ParSolverPipeBCGS::operator()(const ParOperator& A, const ParOperator& P, const ParVector& b, const ParVector& x, int& iter, double& relres) const
{
	MPI_Comm comm = A.comm;

	int comm_rank;
	MPI_Comm_rank(comm, &comm_rank);

	MPI_Request request;
	MPI_Status status;
	double buf[5];
	double* dst[5];
	int cnt = 0;

	int n = A.OutSize();

	double normb, res, alpha, beta, omega, rho, rho1, yr, yy, r0y, r0s, r0z;
	ParVector r(comm), r0(comm), r1(comm), s(comm), s1(comm), t(comm), p1(comm), v(comm), y(comm), y1(comm), z(comm), z1(comm);

	r.Resize(n);
	r0.Resize(n);
	r1.Resize(n);
	s.Resize(n);
	s1.Resize(n);
	t.Resize(n);
	p1.Resize(n);
	v.Resize(n);
	y.Resize(n);
	y1.Resize(n);
	z.Resize(n);
	z1.Resize(n);

	if (PrintStats && comm_rank == 0)
	{
		std::cout << "Iter\tResidual\n";
		std::cout << "--------------------------------------------------\n";
	}

	iter = 0;

	APPLYDOT(b, b, normb);

	BEGINREDUCTION();

	A.Apply(x, r);
	ParVecAXPBY(1.0, b, -1.0, r);

	r0.Copy(r);

	P.Apply(r, r1);

	A.Apply(r1, y);

	ENDREDUCTION();

	normb = sqrt(normb);

	while (1)
	{
		APPLYDOT(r0, r, rho);
		APPLYDOT(r0, y, r0y);

		if (iter > 0)
		{
			APPLYDOT(r0, s, r0s);
			APPLYDOT(r0, z, r0z);
			APPLYDOT(r, r, res);
		}

		BEGINREDUCTION();

		P.Apply(y, y1);
		A.Apply(y1, t);

		ENDREDUCTION();

		if (iter == 0) res = rho;

		res = sqrt(res);

		if (PrintStats && comm_rank == 0)
			std::cout << iter << "\t" << res << "\n";

		if (res / normb <= Tolerance || iter == MaxIters) break;

		if (iter == 0)
		{
			alpha = rho / r0y;

			p1.Copy(r1);
			s.Copy(y);
			s1.Copy(y1);
			z.Copy(t);
		}
		else
		{
			beta = (alpha / omega) * (rho / rho1);
			alpha = rho / (r0y + beta * r0s - beta * omega * r0z);

			ParVecAXPBYPCZ(1.0, r1, -beta * omega, s1, beta, p1);
			ParVecAXPBYPCZ(1.0, y, -beta * omega, z, beta, s);
			ParVecAXPBYPCZ(1.0, y1, -beta * omega, z1, beta, s1);
			ParVecAXPBYPCZ(1.0, t, -beta * omega, v, beta, z);
		}

		r.AddScaled(-alpha, s);
		r1.AddScaled(-alpha, s1);
		y.AddScaled(-alpha, z);

		APPLYDOT(y, r, yr);
		APPLYDOT(y, y, yy);

		BEGINREDUCTION();

		P.Apply(z, z1);
		A.Apply(z1, v);

		ENDREDUCTION();

		omega = yr / yy;

		x.Add2Scaled(alpha, p1, omega, r1);

		r.AddScaled(-omega, y);
		r1.Add2Scaled(-omega, y1, omega * alpha, z1);
		y.Add2Scaled(-omega, t, omega * alpha, v);

		rho1 = rho;

		++iter;
		
		if (iter % PBCGS_RR_STEPS == 0)
		{
			A.Apply(x, r);
			ParVecAXPBY(1.0, b, -1.0, r);
			P.Apply(r, r1);
			A.Apply(r1, y);
			A.Apply(p1, s);
			P.Apply(s, s1);
			A.Apply(s1, z);
		}
	}

	relres = res / normb;

	if (PrintStats && comm_rank == 0)
	{
		std::cout << "--------------------------------------------------\n";
		std::cout << "Iterations: " << iter << "\n";
		std::cout << "Final Relative Residual: " << relres << "\n";
	}
}

}