/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef ParMultiVector_H
#define ParMultiVector_H

#include "MultiVector.hpp"
#include "ParVector.hpp"

namespace YHAMG
{

struct ParMultiVector
{
	MPI_Comm comm;
	MultiVector local;

	ParMultiVector(MPI_Comm comm = MPI_COMM_SELF);
	ParMultiVector(MPI_Comm comm, int nvec, int local_size);
	ParMultiVector(MPI_Comm comm, int nvec, int local_size, double* local_values, int local_ref);
	ParMultiVector(const MultiVector& X);
	ParMultiVector(const ParMultiVector& X);
	ParMultiVector(ParMultiVector&& X);
	ParMultiVector& operator=(const ParMultiVector& X);
	ParMultiVector& operator=(ParMultiVector&& X);

	void Free();
	void Allocate(int m, int n);
	void Refer(const ParMultiVector& X);
	const ParVector operator()(int j) const;
};

}

#endif