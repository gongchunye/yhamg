/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <stdio.h>
#include "random.hpp"
#include "blas.hpp"
#include "Vector.hpp"

namespace YHAMG
{

Vector::Vector()
	: ref(0),
	size(0),
	values(0)
{
}

Vector::Vector(int _n)
	: ref(0),
	size(_n),
	values(new double[_n])
{
}

Vector::Vector(int _n, double* _values, int _ref)
	: ref(_ref),
	size(_n),
	values(_values)
{
}

Vector::Vector(const Vector& x)
	: ref(0),
	size(x.size),
	values(new double[x.size])
{
	blas_dcopy(size, x.values, values);
}

Vector::Vector(Vector&& x)
	: ref(x.ref),
	size(x.size),
	values(x.values)
{
	x.ref = 1;
}

Vector::~Vector()
{
	if (!ref && values)
		delete[] values;
}

Vector& Vector::operator=(double a)
{
	blas_dfill(size, a, values);
	return *this;
}

Vector& Vector::operator=(const Vector& x)
{
	Resize(x.size);
	blas_dcopy(size, x.values, values);
	return *this;
}

Vector& Vector::operator=(Vector&& x)
{
	if (!ref && values)
		delete[] values;
	ref = x.ref;
	size = x.size;
	values = x.values;
	x.ref = 1;
	return *this;
}

double& Vector::operator[](int i) const
{
	return values[i];
}

void Vector::Free()
{
	if (!ref && values)
		delete[] values;
	size = 0;
	values = 0;
	ref = 0;
}

void Vector::Resize(int n)
{
	if (!ref && values)
		delete[] values;
	size = n;
	values = new double[n];
	ref = 0;
}

void Vector::Fill(double a) const
{
	blas_dfill(size, a, values);
}

void Vector::FillRandom() const
{
	for (int i = 0; i < size; ++i)
		values[i] = (double)(random() & 4294967295U) / 4294967295U;
}

void Vector::Copy(const Vector& x) const
{
	blas_dcopy(size, x.values, values);
}

void Vector::Scale(double a) const
{
	blas_dscal(size, a, values);
}

void Vector::AddScaled(double a, const Vector& x) const
{
	double* xv = x.values;
	blas_daxpy(size, a, xv, values);
}

void Vector::Add2Scaled(double a, const Vector& x, double b, const Vector& y) const
{
	double* xv = x.values;
	double* yv = y.values;
	blas_daxpbypz(size, a, xv, b, yv, values);
}

void Vector::Refer(const Vector& x)
{
	if (!ref && values)
		delete[] values;
	size = x.size;
	values = x.values;
	ref = 1;
}

void VecRead(const char* filename, Vector& x)
{
	FILE* f = fopen(filename, "r");

	int n;

	fscanf(f, "%d\n", &n);

	double* xv = new double[n];

	for (int i = 0; i < n; ++i)
		fscanf(f, "%lg\n", &xv[i]);

	fclose(f);

	x.Free();
	x.size = n;
	x.values = xv;
}

void VecWrite(const char* filename, const Vector& x)
{
	int n = x.size;
	double* xv = x.values;

	FILE* f = fopen(filename, "w");

	fprintf(f, "%d\n", n);

	for (int i = 0; i < n; ++i)
		fprintf(f, "%20.16g\n", xv[i]);

	fclose(f);
}

void VecAXPBY(double alpha, const Vector& x, double beta, const Vector& y)
{
	int n = y.size;
	double* xv = x.values;
	double* yv = y.values;

	blas_daxpby(n, alpha, xv, beta, yv);
}

void VecAXPBYPCZ(double alpha, const Vector& x, double beta, const Vector& y, double gamma, const Vector& z)
{
	int n = z.size;
	double* xv = x.values;
	double* yv = y.values;
	double* zv = z.values;

	blas_daxpbypcz(n, alpha, xv, beta, yv, gamma, zv);
}

double VecDot(const Vector& x, const Vector& y)
{
	int n = x.size;
	double* xv = x.values;
	double* yv = y.values;

	return blas_ddot(n, xv, yv);
}

void VecElemMul(const Vector& x, const Vector& y)
{
	int n = x.size;
	double* xv = x.values;
	double* yv = y.values;
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
	for (int i = 0; i < n; ++i)
		yv[i] *= xv[i];
}

void VecRecip(const Vector& x)
{
	int n = x.size;
	double* xv = x.values;
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
	for (int i = 0; i < n; ++i)
		xv[i] = 1.0 / xv[i];
}

}