/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "ParMultiVector.hpp"

namespace YHAMG
{

ParMultiVector::ParMultiVector(MPI_Comm _comm)
	: comm(_comm)
{
}

ParMultiVector::ParMultiVector(MPI_Comm _comm, int _num_vectors, int local_size)
	: comm(_comm),
	local(_num_vectors, local_size)
{
}

ParMultiVector::ParMultiVector(MPI_Comm _comm, int _num_vectors, int local_size, double* local_values, int local_ref)
	: comm(_comm),
	local(_num_vectors, local_size, local_values, local_ref)
{
}

ParMultiVector::ParMultiVector(const MultiVector& X)
	: comm(MPI_COMM_SELF),
	local(X)
{
}

ParMultiVector::ParMultiVector(const ParMultiVector& X)
	: comm(X.comm),
	local(X.local)
{
}

ParMultiVector::ParMultiVector(ParMultiVector&& X)
	: comm(X.comm),
	local(X.local.nvec, X.local.size, X.local.values, X.local.ref)
{
	X.local.ref = 1;
}

ParMultiVector& ParMultiVector::operator=(const ParMultiVector& X)
{
	comm = X.comm;
	local = X.local;
	return *this;
}

ParMultiVector& ParMultiVector::operator=(ParMultiVector&& X)
{
	Free();

	comm = X.comm;
	local.ref = X.local.ref;
	local.nvec = X.local.nvec;
	local.size = X.local.size;
	local.values = X.local.values;

	X.local.ref = 1;

	return *this;
}

void ParMultiVector::Free()
{
	local.Free();
}

void ParMultiVector::Allocate(int m, int n)
{
	local.Allocate(m, n);
}

void ParMultiVector::Refer(const ParMultiVector& X)
{
	comm = X.comm;
	local.Refer(X.local);
}

const ParVector ParMultiVector::operator()(int j) const
{
	return ParVector(comm, local.size, local.values + j * local.size, 1);
}

}