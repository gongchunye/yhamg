/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef Vector_H
#define Vector_H

namespace YHAMG
{

struct Vector
{
	int ref;
	int size;
	double* values;

	Vector();
	Vector(int n);
	Vector(int n, double* values, int ref);
	Vector(const Vector& x);
	Vector(Vector&& x); 
	~Vector();
	Vector& operator=(double a);
	Vector& operator=(const Vector& x);
	Vector& operator=(Vector&& x);
	double& operator[](int i) const;

	void Free();
	void Resize(int n);
	void Fill(double a) const;
	void FillRandom() const;
	void Copy(const Vector& x) const;
	void Scale(double a) const;
	void AddScaled(double a, const Vector& x) const;
	void Add2Scaled(double a, const Vector& x, double b, const Vector& y) const;
	void Refer(const Vector& x);
};

void VecRead(const char* filename, Vector& x);
void VecWrite(const char* filename, const Vector& x);
void VecAXPBY(double alpha, const Vector& x, double beta, const Vector& y);
void VecAXPBYPCZ(double alpha, const Vector& x, double beta, const Vector& y, double gamma, const Vector& z);
double VecDot(const Vector& x, const Vector& y);
void VecElemMul(const Vector& x, const Vector& y);
void VecRecip(const Vector& x);

}

#endif