/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "ParVector.hpp"

namespace YHAMG
{

ParVector::ParVector(MPI_Comm _comm)
	: comm(_comm)
{
}

ParVector::ParVector(MPI_Comm _comm, int local_size)
	: comm(_comm),
	local(local_size)
{
}

ParVector::ParVector(MPI_Comm _comm, int local_size, double* local_values, int local_ref)
	: comm(_comm),
	local(local_size, local_values, local_ref)
{
}

ParVector::ParVector(const Vector& x)
	: comm(MPI_COMM_SELF),
	local(x)
{
}

ParVector::ParVector(const ParVector& x)
	: comm(x.comm),
	local(x.local)
{
}

ParVector::ParVector(ParVector&& x)
	: comm(x.comm),
	local(x.local.size, x.local.values, x.local.ref)
{
	x.local.ref = 1;
}

ParVector& ParVector::operator=(double a)
{
	local = a;
	return *this;
}

ParVector& ParVector::operator=(const ParVector& x)
{
	comm = x.comm;
	local = x.local;
	return *this;
}

ParVector& ParVector::operator=(ParVector&& x)
{
	Free();
	comm = x.comm;
	local.ref = x.local.ref;
	local.size = x.local.size;
	local.values = x.local.values;
	x.local.ref = 1;
	return *this;
}

double& ParVector::operator[](int i) const
{
	return local.values[i];
}

void ParVector::Free()
{
	local.Free();
}

void ParVector::Resize(int n)
{
	local.Resize(n);
}

void ParVector::Refer(const ParVector& x)
{
	comm = x.comm;
	local.Refer(x.local);
}

void ParVector::Fill(double a) const
{
	local.Fill(a);
}


void ParVector::FillRandom() const
{
	local.FillRandom();
}

void ParVector::Copy(const ParVector& x) const
{
	local.Copy(x.local);
}

void ParVector::Scale(double a) const
{
	local.Scale(a);
}

void ParVector::AddScaled(double a, const ParVector& x) const
{
	local.AddScaled(a, x.local);
}

void ParVector::Add2Scaled(double a, const ParVector& x, double b, const ParVector& y) const
{
	local.Add2Scaled(a, x.local, b, y.local);
}

void ParVecAXPBY(double alpha, const ParVector& x, double beta, const ParVector& y)
{
	VecAXPBY(alpha, x.local, beta, y.local);
}

void ParVecAXPBYPCZ(double alpha, const ParVector& x, double beta, const ParVector& y, double gamma, const ParVector& z)
{
	VecAXPBYPCZ(alpha, x.local, beta, y.local, gamma, z.local);
}

double ParVecDot(const ParVector& x, const ParVector& y)
{
	double result = VecDot(x.local, y.local);
	MPI_Allreduce(MPI_IN_PLACE, &result, 1, MPI_DOUBLE, MPI_SUM, x.comm);
	return result;
}

void ParVecElemMul(const ParVector& x, const ParVector& y)
{
	VecElemMul(x.local, y.local);
}

void ParVecRecip(const ParVector& x)
{
	VecRecip(x.local);
}

}