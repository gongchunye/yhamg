/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef ParVector_H
#define ParVector_H

#include <mpi.h>
#include "Vector.hpp"

namespace YHAMG
{

struct ParVector
{
	MPI_Comm comm;
	Vector local;

	ParVector(MPI_Comm comm = MPI_COMM_SELF);
	ParVector(MPI_Comm comm, int local_size);
	ParVector(MPI_Comm comm, int local_size, double* local_values, int local_ref);
	ParVector(const Vector& x);
	ParVector(const ParVector& x);
	ParVector(ParVector&& x);
	ParVector& operator=(double a);
	ParVector& operator=(const ParVector& x);
	ParVector& operator=(ParVector&& x);
	double& operator[](int i) const;

	void Free();
	void Resize(int n);
	void Refer(const ParVector& x);
	void Fill(double a) const;
	void FillRandom() const;
	void Copy(const ParVector& x) const;
	void Scale(double a) const;
	void AddScaled(double a, const ParVector& x) const;
	void Add2Scaled(double a, const ParVector& x, double b, const ParVector& y) const;
};

void ParVecAXPBY(double alpha, const ParVector& x, double beta, const ParVector& y);
void ParVecAXPBYPCZ(double alpha, const ParVector& x, double beta, const ParVector& y, double gamma, const ParVector& z);
double ParVecDot(const ParVector& x, const ParVector& y);
void ParVecElemMul(const ParVector& x, const ParVector& y);
void ParVecRecip(const ParVector& x);

}

#endif