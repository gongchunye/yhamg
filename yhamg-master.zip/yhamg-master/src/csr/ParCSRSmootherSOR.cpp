/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <iostream>
#include "ParCSRSmootherSOR.hpp"

#ifdef YHAMG_USE_OPENMP
#include <omp.h>
#endif

namespace YHAMG
{

#define SPBLAS(Y, Op, i, Ap, Ai, Av, X) \
	for (int spblas_index = Ap[i]; spblas_index < Ap[i + 1]; ++spblas_index) \
		Y Op ## = Av[spblas_index] * X[Ai[spblas_index]];

#define SPBLAS_R(Y, Op, i, Ap, Ai, Av, X) \
	for (int spblas_index = Ap[i + 1] - 1; spblas_index >= Ap[i]; --spblas_index) \
		Y Op ## = Av[spblas_index] * X[Ai[spblas_index]];

#define MPI_TAG 500

ParCSRSmootherSORLocal::ParCSRSmootherSORLocal(int relaxation_type, double relaxation_factor)
	: nthd(0),
	RelaxationType(relaxation_type),
	RelaxationFactor(relaxation_factor)
{
}

void ParCSRSmootherSORLocal::Setup(const ParCSRMatrix& A, int REUSE)
{
	int n = A.local.size[0];
	int* Ap = A.local.rowptr;
	int* Ai = A.local.colind;
	double* Av = A.local.values;

	if (!REUSE)
	{
		D_recip.Resize(n);
		nthd = 1;
#ifdef USE_ONED_PARTITION
		nthd = omp_get_max_threads();
#endif
		z.comm = A.comm;
		z.Resize(n);
	}

	double* Drcpv = D_recip.values;
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
	for (int i = 0; i < n; ++i)
	{
		for (int j = Ap[i]; j < Ap[i + 1]; ++j)
		{
			if (Ai[j] == i)
			{
				Drcpv[i] = 1.0 / Av[j];
				break;
			}
		}
	}
}

void ParCSRSmootherSORLocal::Post(const ParCSRMatrix& A, const ParVector& b, const ParVector& x, int step) const
{
	int n = A.local.size[0];

	int* local_rowptr = A.local.rowptr;
	int* local_colind = A.local.colind;
	double* local_values = A.local.values;
	int* exter_rowptr = A.exter.rowptr;
	int* exter_colind = A.exter.colind;
	double* exter_values = A.exter.values;

	double* Dv_recip = D_recip.values;
	double* xv_local = x.local.values;
	double* bv_local = b.local.values;
	double* zv_local = z.local.values;
	
	double* xv_recv = A.recvx.values;
	
	double omega = RelaxationFactor;

	A.ExchangeHalo(x);

	if (nthd == 1)
	{
		for (int k = 0; k < step; ++k)
		{
			if (RelaxationType == 0 || (RelaxationType == 2 && !((step - k) & 1)))
			{
				for (int i = 0; i < n; ++i)
				{
					double temp = bv_local[i];
					SPBLAS(temp, -, i, local_rowptr, local_colind, local_values, xv_local)
					SPBLAS(temp, -, i, exter_rowptr, exter_colind, exter_values, xv_recv)
					xv_local[i] += omega * Dv_recip[i] * temp;
				}
			}
			else if (RelaxationType == 1 || (RelaxationType == 2 && (step - k) & 1))
			{
				for (int i = n - 1; i >= 0; --i)
				{
					double temp = bv_local[i];
					SPBLAS_R(temp, -, i, local_rowptr, local_colind, local_values, xv_local)
					SPBLAS_R(temp, -, i, exter_rowptr, exter_colind, exter_values, xv_recv)
					xv_local[i] += omega * Dv_recip[i] * temp;
				}
			}
		}
	}
	else
	{
		z.Copy(x);
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		for (int t = 0; t < nthd; ++t)
		{
			int begin = n * t / nthd;
			int end = n * (t + 1) / nthd;
			
			for (int k = 0; k < step; ++k)
			{
				if (RelaxationType == 0 || (RelaxationType == 2 && !((step - k) & 1)))
				{
					for (int i = begin; i < end; ++i)
					{
						double temp = bv_local[i];
						for (int j = local_rowptr[i]; j < local_rowptr[i + 1]; ++j)
						{
							int jcol = local_colind[j];
							double jval = local_values[j];

							if (jcol < begin || jcol >= end)
								temp -= jval * zv_local[jcol];
							else
								temp -= jval * xv_local[jcol];
						}
						SPBLAS(temp, -, i, exter_rowptr, exter_colind, exter_values, xv_recv)
						xv_local[i] += omega * Dv_recip[i] * temp;
					}
				}
				else if (RelaxationType == 1 || (RelaxationType == 2 && (step - k) & 1))
				{
					for (int i = end - 1; i >= begin; --i)
					{
						double temp = bv_local[i];
						for (int j = local_rowptr[i + 1] - 1; j >= local_rowptr[i]; --j)
						{
							int jcol = local_colind[j];
							double jval = local_values[j];

							if (jcol < begin || jcol >= end)
								temp -= jval * zv_local[jcol];
							else
								temp -= jval * xv_local[jcol];
						}
						SPBLAS_R(temp, -, i, exter_rowptr, exter_colind, exter_values, xv_recv)
						xv_local[i] += omega * Dv_recip[i] * temp;
					}
				}
			}
		}
	}
}

void ParCSRSmootherSORLocal::operator()(const ParCSRMatrix& A, const ParVector& b, const ParVector& x, int step, bool x0zero) const
{
	int n = A.local.size[0];

	int* local_rowptr = A.local.rowptr;
	int* local_colind = A.local.colind;
	double* local_values = A.local.values;
	int* exter_rowptr = A.exter.rowptr;
	int* exter_colind = A.exter.colind;
	double* exter_values = A.exter.values;

	double* Dv_recip = D_recip.values;
	double* xv_local = x.local.values;
	double* bv_local = b.local.values;
	double* zv_local = z.local.values;
	
	double* xv_recv = A.recvx.values;

	double omega = RelaxationFactor;

	if (!x0zero)
	{
		A.ExchangeHalo(x);

		if (nthd == 1)
		{
			for (int k = 0; k < step; ++k)
			{
				if (RelaxationType == 0 || (RelaxationType == 2 && !(k & 1)))
				{
					for (int i = 0; i < n; ++i)
					{
						double temp = bv_local[i];
						SPBLAS(temp, -, i, local_rowptr, local_colind, local_values, xv_local)
						SPBLAS(temp, -, i, exter_rowptr, exter_colind, exter_values, xv_recv)
						xv_local[i] += omega * Dv_recip[i] * temp;
					}
				}
				else if (RelaxationType == 1 || (RelaxationType == 2 && k & 1))
				{
					for (int i = n - 1; i >= 0; --i)
					{
						double temp = bv_local[i];
						SPBLAS_R(temp, -, i, local_rowptr, local_colind, local_values, xv_local)
						SPBLAS_R(temp, -, i, exter_rowptr, exter_colind, exter_values, xv_recv)
						xv_local[i] += omega * Dv_recip[i] * temp;
					}
				}
			}
		}
		else
		{
			z.Copy(x);
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			for (int t = 0; t < nthd; ++t)
			{
				int begin = n * t / nthd;
				int end = n * (t + 1) / nthd;

				for (int k = 0; k < step; ++k)
				{
					if (RelaxationType == 0 || (RelaxationType == 2 && !(k & 1)))
					{
						for (int i = begin; i < end; ++i)
						{
							double temp = bv_local[i];
							for (int j = local_rowptr[i]; j < local_rowptr[i + 1]; ++j)
							{
								int jcol = local_colind[j];
								double jval = local_values[j];

								if (jcol < begin || jcol >= end)
									temp -= jval * zv_local[jcol];
								else
									temp -= jval * xv_local[jcol];
							}
							SPBLAS(temp, -, i, exter_rowptr, exter_colind, exter_values, xv_recv)
							xv_local[i] += omega * Dv_recip[i] * temp;
						}
					}
					else if (RelaxationType == 1 || (RelaxationType == 2 && k & 1))
					{
						for (int i = end - 1; i >= begin; --i)
						{
							double temp = bv_local[i];
							for (int j = local_rowptr[i + 1] - 1; j >= local_rowptr[i]; --j)
							{
								int jcol = local_colind[j];
								double jval = local_values[j];

								if (jcol < begin || jcol >= end)
									temp -= jval * zv_local[jcol];
								else
									temp -= jval * xv_local[jcol];
							}
							SPBLAS_R(temp, -, i, exter_rowptr, exter_colind, exter_values, xv_recv)
							xv_local[i] += omega * Dv_recip[i] * temp;
						}
					}
				}
			}
		}
	}
	else
	{
		if (nthd == 1)
		{
			for (int k = 0; k < step; ++k)
			{
				if (RelaxationType == 0 || (RelaxationType == 2 && !(k & 1)))
				{
					for (int i = 0; i < n; ++i)
					{
						double temp = bv_local[i];
						SPBLAS(temp, -, i, local_rowptr, local_colind, local_values, xv_local)
						xv_local[i] += omega * Dv_recip[i] * temp;
					}
				}
				else if (RelaxationType == 1 || (RelaxationType == 2 && k & 1))
				{
					for (int i = n - 1; i >= 0; --i)
					{
						double temp = bv_local[i];
						SPBLAS_R(temp, -, i, local_rowptr, local_colind, local_values, xv_local)
						xv_local[i] += omega * Dv_recip[i] * temp;
					}
				}
			}
		}
		else
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			for (int t = 0; t < nthd; ++t)
			{
				int begin = n * t / nthd;
				int end = n * (t + 1) / nthd;

				for (int k = 0; k < step; ++k)
				{
					if (RelaxationType == 0 || (RelaxationType == 2 && !(k & 1)))
					{
						for (int i = begin; i < end; ++i)
						{
							double temp = bv_local[i];
							for (int j = local_rowptr[i]; j < local_rowptr[i + 1]; ++j)
								if (local_colind[j] >= begin && local_colind[j] < end)
									temp -= local_values[j] * xv_local[local_colind[j]];
							xv_local[i] += omega * Dv_recip[i] * temp;
						}
					}
					else if (RelaxationType == 1 || (RelaxationType == 2 && k & 1))
					{
						for (int i = end - 1; i >= begin; --i)
						{
							double temp = bv_local[i];
							for (int j = local_rowptr[i + 1] - 1; j >= local_rowptr[i]; --j)
								if (local_colind[j] >= begin && local_colind[j] < end)
									temp -= local_values[j] * xv_local[local_colind[j]];
							xv_local[i] += omega * Dv_recip[i] * temp;
						}
					}
				}
			}
		}
	}
}

ParCSRSmootherSOR::ParCSRSmootherSOR(int relaxation_type, double relaxation_factor)
	: nthd(0),
	RelaxationType(relaxation_type),
	RelaxationFactor(relaxation_factor)
{
}

void ParCSRSmootherSOR::Setup(const ParCSRMatrix& A, int REUSE)
{
	int n = A.local.size[0];
	int* Ap = A.local.rowptr;
	int* Ai = A.local.colind;
	double* Av = A.local.values;

	if (!REUSE)
	{
		D_recip.Resize(n);
		nthd = 1;
#ifdef USE_ONED_PARTITION
		nthd = omp_get_max_threads();
#endif
		z.comm = A.comm;
		z.Resize(n);
	}

	double* Drcpv = D_recip.values;
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
	for (int i = 0; i < n; ++i)
	{
		for (int j = Ap[i]; j < Ap[i + 1]; ++j)
		{
			if (Ai[j] == i)
			{
				Drcpv[i] = 1.0 / Av[j];
				break;
			}
		}
	}
}

void ParCSRSmootherSOR::Post(const ParCSRMatrix& A, const ParVector& b, const ParVector& x, int step) const
{
	int n = A.local.size[0];

	int* local_rowptr = A.local.rowptr;
	int* local_colind = A.local.colind;
	double* local_values = A.local.values;
	int* exter_rowptr = A.exter.rowptr;
	int* exter_colind = A.exter.colind;
	double* exter_values = A.exter.values;

	double* Dv_recip = D_recip.values;
	double* xv_local = x.local.values;
	double* bv_local = b.local.values;
	double* zv_local = z.local.values;
	
	double* xv_recv = A.recvx.values;
	
	double omega = RelaxationFactor;

	if (nthd == 1)
	{
		for (int k = 0; k < step; ++k)
		{
			A.ExchangeHalo(x);

			if (RelaxationType == 0 || (RelaxationType == 2 && !(step - k & 1)))
			{
				for (int i = 0; i < n; ++i)
				{
					double temp = bv_local[i];
					SPBLAS(temp, -, i, local_rowptr, local_colind, local_values, xv_local)
					SPBLAS(temp, -, i, exter_rowptr, exter_colind, exter_values, xv_recv)
					xv_local[i] += omega * Dv_recip[i] * temp;
				}
			}
			else if (RelaxationType == 1 || (RelaxationType == 2 && step - k & 1))
			{
				for (int i = n - 1; i >= 0; --i)
				{
					double temp = bv_local[i];
					SPBLAS_R(temp, -, i, local_rowptr, local_colind, local_values, xv_local)
					SPBLAS_R(temp, -, i, exter_rowptr, exter_colind, exter_values, xv_recv)
					xv_local[i] += omega * Dv_recip[i] * temp;
				}
			}
		}
	}
	else
	{
		for (int k = 0; k < step; ++k)
		{
			A.ExchangeHalo(x);
			z.Copy(x);
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			for (int t = 0; t < nthd; ++t)
			{
				int begin = n * t / nthd;
				int end = n * (t + 1) / nthd;

				if (RelaxationType == 0 || (RelaxationType == 2 && !(step - k & 1)))
				{
					for (int i = begin; i < end; ++i)
					{
						double temp = bv_local[i];
						for (int j = local_rowptr[i]; j < local_rowptr[i + 1]; ++j)
						{
							int jcol = local_colind[j];
							double jval = local_values[j];

							if (jcol < begin || jcol >= end)
								temp -= jval * zv_local[jcol];
							else
								temp -= jval * xv_local[jcol];
						}
						SPBLAS(temp, -, i, exter_rowptr, exter_colind, exter_values, xv_recv)
						xv_local[i] += omega * Dv_recip[i] * temp;
					}
				}
				else if (RelaxationType == 1 || (RelaxationType == 2 && step - k & 1))
				{
					for (int i = end - 1; i >= begin; --i)
					{
						double temp = bv_local[i];
						for (int j = local_rowptr[i + 1] - 1; j >= local_rowptr[i]; --j)
						{
							int jcol = local_colind[j];
							double jval = local_values[j];

							if (jcol < begin || jcol >= end)
								temp -= jval * zv_local[jcol];
							else
								temp -= jval * xv_local[jcol];
						}
						SPBLAS_R(temp, -, i, exter_rowptr, exter_colind, exter_values, xv_recv)
						xv_local[i] += omega * Dv_recip[i] * temp;
					}
				}
			}
		}
	}
}

void ParCSRSmootherSOR::operator()(const ParCSRMatrix& A, const ParVector& b, const ParVector& x, int step, bool x0zero) const
{
	int n = A.local.size[0];

	int* local_rowptr = A.local.rowptr;
	int* local_colind = A.local.colind;
	double* local_values = A.local.values;
	int* exter_rowptr = A.exter.rowptr;
	int* exter_colind = A.exter.colind;
	double* exter_values = A.exter.values;

	double* Dv_recip = D_recip.values;
	double* xv_local = x.local.values;
	double* bv_local = b.local.values;
	double* zv_local = z.local.values;
	
	double* xv_recv = A.recvx.values;

	double omega = RelaxationFactor;

	if (nthd == 1)
	{
		for (int k = 0; k < step; ++k)
		{
			if (k > 0 || !x0zero)
			{
				A.ExchangeHalo(x);

				if (RelaxationType == 0 || (RelaxationType == 2 && !(k & 1)))
				{
					for (int i = 0; i < n; ++i)
					{
						double temp = bv_local[i];
						SPBLAS(temp, -, i, local_rowptr, local_colind, local_values, xv_local)
						SPBLAS(temp, -, i, exter_rowptr, exter_colind, exter_values, xv_recv)
						xv_local[i] += omega * Dv_recip[i] * temp;
					}
				}
				else if (RelaxationType == 1 || (RelaxationType == 2 && k & 1))
				{
					for (int i = n - 1; i >= 0; --i)
					{
						double temp = bv_local[i];
						SPBLAS_R(temp, -, i, local_rowptr, local_colind, local_values, xv_local)
						SPBLAS_R(temp, -, i, exter_rowptr, exter_colind, exter_values, xv_recv)
						xv_local[i] += omega * Dv_recip[i] * temp;
					}
				}
			}
			else
			{
				if (RelaxationType == 0 || (RelaxationType == 2 && !(k & 1)))
				{
					for (int i = 0; i < n; ++i)
					{
						double temp = bv_local[i];
						SPBLAS(temp, -, i, local_rowptr, local_colind, local_values, xv_local)
						xv_local[i] += omega * Dv_recip[i] * temp;
					}
				}
				else if (RelaxationType == 1 || (RelaxationType == 2 && k & 1))
				{
					for (int i = n - 1; i >= 0; --i)
					{
						double temp = bv_local[i];
						SPBLAS_R(temp, -, i, local_rowptr, local_colind, local_values, xv_local)
						xv_local[i] += omega * Dv_recip[i] * temp;
					}
				}
			}
		}
	}
	else
	{
		for (int k = 0; k < step; ++k)
		{
			if (k > 0 || !x0zero)
			{
				A.ExchangeHalo(x);
				z.Copy(x);
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				for (int t = 0; t < nthd; ++t)
				{
					int begin = n * t / nthd;
					int end = n * (t + 1) / nthd;

					if (RelaxationType == 0 || (RelaxationType == 2 && !(k & 1)))
					{
						for (int i = begin; i < end; ++i)
						{
							double temp = bv_local[i];
							for (int j = local_rowptr[i]; j < local_rowptr[i + 1]; ++j)
							{
								int jcol = local_colind[j];
								double jval = local_values[j];

								if (jcol < begin || jcol >= end)
									temp -= jval * zv_local[jcol];
								else
									temp -= jval * xv_local[jcol];
							}
							SPBLAS(temp, -, i, exter_rowptr, exter_colind, exter_values, xv_recv)
							xv_local[i] += omega * Dv_recip[i] * temp;
						}
					}
					else if (RelaxationType == 1 || (RelaxationType == 2 && k & 1))
					{
						for (int i = end - 1; i >= begin; --i)
						{
							double temp = bv_local[i];
							for (int j = local_rowptr[i + 1] - 1; j >= local_rowptr[i]; --j)
							{
								int jcol = local_colind[j];
								double jval = local_values[j];

								if (jcol < begin || jcol >= end)
									temp -= jval * zv_local[jcol];
								else
									temp -= jval * xv_local[jcol];
							}
							SPBLAS_R(temp, -, i, exter_rowptr, exter_colind, exter_values, xv_recv)
							xv_local[i] += omega * Dv_recip[i] * temp;
						}
					}
				}
			}
			else
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				for (int t = 0; t < nthd; ++t)
				{
					int begin = n * t / nthd;
					int end = n * (t + 1) / nthd;

					if (RelaxationType == 0 || (RelaxationType == 2 && !(k & 1)))
					{
						for (int i = begin; i < end; ++i)
						{
							double temp = bv_local[i];
							for (int j = local_rowptr[i]; j < local_rowptr[i + 1]; ++j)
								if (local_colind[j] >= begin && local_colind[j] < end)
									temp -= local_values[j] * xv_local[local_colind[j]];
							xv_local[i] += omega * Dv_recip[i] * temp;
						}
					}
					else if (RelaxationType == 1 || (RelaxationType == 2 && k & 1))
					{
						for (int i = end - 1; i >= begin; --i)
						{
							double temp = bv_local[i];
							for (int j = local_rowptr[i + 1] - 1; j >= local_rowptr[i]; --j)
								if (local_colind[j] >= begin && local_colind[j] < end)
									temp -= local_values[j] * xv_local[local_colind[j]];
							xv_local[i] += omega * Dv_recip[i] * temp;
						}
					}
				}
			}
		}
	}
}

ParCSRSmootherSORXLocal::ParCSRSmootherSORXLocal(int relaxation_type, double relaxation_factor)
	: nthd(0),
	RelaxationType(relaxation_type),
	RelaxationFactor(relaxation_factor)
{
}

void ParCSRSmootherSORXLocal::Setup(const ParCSRMatrix& A, int REUSE)
{
	int n = A.local.size[0];
	int* Ap = A.local.rowptr;
	int* Ai = A.local.colind;
	double* Av = A.local.values;
	
	if (!REUSE)
	{
		z.comm = A.comm;
		w.comm = A.comm;
		z.Resize(n);
		w.Resize(n);

		D.Resize(n);
		D_recip.Resize(n);

		nthd = 1;
#ifdef USE_ONED_PARTITION
		nthd = omp_get_max_threads();
#endif

		double* Dv = D.values;
		double* Drcpv = D_recip.values;

		int* Lp = new int[n + 1];
		int* Up = new int[n + 1];
		int* Ep = new int[n + 1];

		Lp[0] = 0;
		Up[0] = 0;
		Ep[0] = 0;
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		for (int t = 0; t < nthd; ++t)
		{
			int begin = t * n / nthd;
			int end = (t + 1) * n / nthd;

			for (int i = begin; i < end; ++i)
			{
				int cntl = 0;
				int cntu = 0;
				int cnte = 0;

				for (int j = Ap[i]; j < Ap[i + 1]; ++j)
				{
					int jcol = Ai[j];

					if (jcol >= begin && jcol < i) 
						++cntl;
					else if (jcol < end && jcol > i)
						++cntu;
					else if (jcol != i)
						++cnte;
				}

				Lp[i + 1] = cntl;
				Up[i + 1] = cntu;
				Ep[i + 1] = cnte;
			}
		}

		for (int i = 0; i < n;++i)
			Lp[i + 1] += Lp[i];
		for (int i = 0; i < n;++i)
			Up[i + 1] += Up[i];
		for (int i = 0; i < n;++i)
			Ep[i + 1] += Ep[i];

		int* Li = new int[Lp[n]];
		double* Lv = new double[Lp[n]];
		int* Ui = new int[Up[n]];
		double* Uv = new double[Up[n]];
		int* Ei = new int[Ep[n]];
		double* Ev = new double[Ep[n]];

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		for (int t = 0; t < nthd; ++t)
		{
			int begin = t * n / nthd;
			int end = (t + 1) * n / nthd;

			for (int i = begin; i < end; ++i)
			{
				for (int j = Ap[i], k = Lp[i], r = Up[i], s = Ep[i]; j < Ap[i + 1]; ++j)
				{
					int jcol = Ai[j];
					double jval = Av[j];

					if (jcol >= begin && jcol < i) 
					{
						Li[k] = jcol;
						Lv[k++] = jval;
					}
					else if (jcol < end && jcol > i)
					{
						Ui[r] = jcol;
						Uv[r++] = jval;
					}
					else if (jcol == i)
					{
						Dv[i] = jval;
						Drcpv[i] = 1.0 / jval;
					}
					else
					{
						Ei[s] = jcol;
						Ev[s++] = jval;
					}
				}
			}
		}

		L.size[0] = n;
		L.size[1] = n;
		L.rowptr = Lp;
		L.colind = Li;
		L.values = Lv;
		U.size[0] = n;
		U.size[1] = n;
		U.rowptr = Up;
		U.colind = Ui;
		U.values = Uv;
		E.size[0] = n;
		E.size[1] = n;
		E.rowptr = Ep;
		E.colind = Ei;
		E.values = Ev;
	}
	else
	{
		int* Lp = L.rowptr;
		int* Li = L.colind;
		double* Lv = L.values;
		int* Up = U.rowptr;
		int* Ui = U.colind;
		double* Uv = U.values;
		int* Ep = E.rowptr;
		int* Ei = E.colind;
		double* Ev = E.values;
		double* Dv = D.values;
		double* Drcpv = D_recip.values;
		
		int* w = new int[n];

		for (int i = 0; i < n; ++i)
			w[i] = -1;

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		for (int t = 0; t < nthd; ++t)
		{
			int begin = t * n / nthd;
			int end = (t + 1) * n / nthd;

			for (int i = begin; i < end; ++i)
			{
				int j0 = Ap[i];

				for (int j = Ap[i]; j < Ap[i + 1]; ++j)
					w[Ai[j]] = j;

				if (w[i] >= j0)
				{
					Dv[i] = Av[w[i]];
					Drcpv[i] = 1.0 / Av[w[i]];
				}

				for (int j = Lp[i]; j < Lp[i + 1]; ++j)
					if (w[Li[j]] >= j0) Lv[j] = Av[w[Li[j]]];
				for (int j = Up[i]; j < Up[i + 1]; ++j)
					if (w[Ui[j]] >= j0) Uv[j] = Av[w[Ui[j]]];
				for (int j = Ep[i]; j < Ep[i + 1]; ++j)
					if (w[Ei[j]] >= j0) Ev[j] = Av[w[Ei[j]]];
			}
		}
		
		delete[] w;	
	}
}

void ParCSRSmootherSORXLocal::Pre_and_Resid(const ParCSRMatrix& A, const ParVector& b, const ParVector& x, const ParVector& r, int step, bool x0zero) const
{
	int n = A.local.size[0];

	double* Dv = D.values;
	double* Drcpv = D_recip.values;
	int* Lp = L.rowptr;
	int* Li = L.colind;
	double* Lv = L.values;
	int* Up = U.rowptr;
	int* Ui = U.colind;
	double* Uv = U.values;
	int* Ep = E.rowptr;
	int* Ei = E.colind;
	double* Ev = E.values;
	int* Extp = A.exter.rowptr;
	int* Exti = A.exter.colind;
	double* Extv = A.exter.values;
	double* bv = b.local.values;
	double* zv = z.local.values;
	double* rv = r.local.values;
	double* wv = w.local.values;
	double* xv = x.local.values;
	double* recvxv = A.recvx.values;

	double omega = RelaxationFactor;
	double theta = (1 - omega) / omega;

	if (!x0zero)
	{
		A.ExchangeHalo(x);

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		for (int i = 0; i < n; ++i)
		{
			double temp = bv[i];
			SPBLAS(temp, -, i, Extp, Exti, Extv, recvxv)
			SPBLAS(temp, -, i, Ep, Ei, Ev, xv)
			wv[i] = temp;
		}
	}
	else
		w.Copy(b);

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
	for (int t = 0; t < nthd; ++t)
	{
		int begin = t * n / nthd;
		int end = (t + 1) * n / nthd;

		if (RelaxationType == 0)
		{
			for (int k = 0; k < step; ++k)
			{
				if (!x0zero || k > 0)
				{
					for (int i = begin; i < end; ++i)
					{
						double temp = wv[i] + theta * Dv[i] * xv[i];
						SPBLAS(temp, -, i, Up, Ui, Uv, xv)
						zv[i] = temp;
					}
				}
				else
				{
					for (int i = begin; i < end; ++i)
						zv[i] = wv[i];
				}

				for (int i = begin; i < end; ++i)
				{
					double temp = zv[i];
					SPBLAS(temp, -, i, Lp, Li, Lv, xv)
					xv[i] = temp * Drcpv[i] * omega;
				}
			}

			for (int i = begin; i < end; ++i)
			{
				double temp = zv[i] - theta * Dv[i] * xv[i];
				SPBLAS(temp, +, i, Up, Ui, Uv, xv)
				rv[i] = temp;
			}
		}
		else if (RelaxationType == 1)
		{
			for (int k = 0; k < step; ++k)
			{
				if (!x0zero || k > 0)
				{
					for (int i = begin; i < end; ++i)
					{
						double temp = wv[i] + theta * Dv[i] * xv[i];
						SPBLAS(temp, -, i, Lp, Li, Lv, xv)
						zv[i] = temp;
					}
				}
				else
				{
					for (int i = begin; i < end; ++i)
						zv[i] = wv[i];
				}

				for (int i = end - 1; i >= begin; --i)
				{
					double temp = zv[i];
					SPBLAS_R(temp, -, i, Up, Ui, Uv, xv)
					xv[i] = temp * Drcpv[i] * omega;
				}
			}

			for (int i = begin; i < end; ++i)
			{
				double temp = zv[i] - theta * Dv[i] * xv[i];
				SPBLAS(temp, +, i, Lp, Li, Lv, xv)
				rv[i] = temp;
			}
		}
		else if (RelaxationType == 2)
		{
			int k = 0;

			if (!x0zero)
			{
				for (int i = begin; i < end; ++i)
				{
					double temp = theta * Dv[i] * xv[i];
					SPBLAS(temp, -, i, Up, Ui, Uv, xv)
					zv[i] = temp;
				}
			}
			else
			{
				for (int i = begin; i < end; ++i)
					zv[i] = 0.0;
			}

			while (1)
			{
				if (++k >= step)
				{
					for (int i = begin; i < end; ++i)
					{
						double temp = wv[i] + zv[i];
						SPBLAS(temp, -, i, Lp, Li, Lv, xv)
						xv[i] = temp * Drcpv[i] * omega;
					}

					for (int i = begin; i < end; ++i)
					{
						double temp = wv[i] + zv[i] - theta * Dv[i] * xv[i];
						SPBLAS(temp, +, i, Up, Ui, Uv, xv)
						rv[i] = temp;
					}

					break;
				}
				else
				{
					for (int i = begin; i < end; ++i)
					{
						double temp = wv[i] + zv[i];
						SPBLAS(temp, -, i, Lp, Li, Lv, xv)
						xv[i] = temp * Drcpv[i] * omega;
						zv[i] = temp * (2 - omega) - zv[i]; 
					}
				}
				
				if (++k >= step)
				{
					for (int i = end - 1; i >= begin; --i)
					{
						double temp = zv[i];
						SPBLAS_R(temp, -, i, Up, Ui, Uv, xv)
						xv[i] = temp * Drcpv[i] * omega;
					}

					for (int i = begin; i < end; ++i)
					{
						double temp = zv[i] - theta * Dv[i] * xv[i];
						SPBLAS(temp, +, i, Lp, Li, Lv, xv)
						rv[i] = temp;
					}

					break;
				}
				else
				{
					for (int i = end - 1; i >= begin; --i)
					{
						double temp = zv[i];
						SPBLAS_R(temp, -, i, Up, Ui, Uv, xv)
						xv[i] = temp * Drcpv[i] * omega;
						zv[i] = temp * (2 - omega) - zv[i]; 
					}
				}
			}
		}
	}

	A.ExchangeHalo(x);

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
	for (int i = 0; i < n; ++i)
	{
		double temp = bv[i] - rv[i];
		SPBLAS(temp, -, i, Ep, Ei, Ev, xv)
		SPBLAS(temp, -, i, Extp, Exti, Extv, recvxv)
		rv[i] = temp;
	}
}

void ParCSRSmootherSORXLocal::Post(const ParCSRMatrix& A, const ParVector& b, const ParVector& x, int step) const
{
	int n = A.local.size[0];

	double* Dv = D.values;
	double* Drcpv = D_recip.values;
	int* Lp = L.rowptr;
	int* Li = L.colind;
	double* Lv = L.values;
	int* Up = U.rowptr;
	int* Ui = U.colind;
	double* Uv = U.values;
	int* Ep = E.rowptr;
	int* Ei = E.colind;
	double* Ev = E.values;
	int* Extp = A.exter.rowptr;
	int* Exti = A.exter.colind;
	double* Extv = A.exter.values;
	double* bv = b.local.values;
	double* zv = z.local.values;
	double* wv = w.local.values;
	double* xv = x.local.values;
	double* recvxv = A.recvx.values;

	double omega = RelaxationFactor;
	double theta = (1 - omega) / omega;

	A.ExchangeHalo(x);

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
	for (int i = 0; i < n; ++i)
	{
		double temp = bv[i];
		SPBLAS(temp, -, i, Extp, Exti, Extv, recvxv)
		SPBLAS(temp, -, i, Ep, Ei, Ev, xv)
		wv[i] = temp;
	}

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
	for (int t = 0; t < nthd; ++t)
	{
		int begin = t * n / nthd;
		int end = (t + 1) * n / nthd;

		if (RelaxationType == 0)
		{
			for (int k = 0; k < step; ++k)
			{
				for (int i = begin; i < end; ++i)
				{
					double temp = wv[i] + theta * Dv[i] * xv[i];
					SPBLAS(temp, -, i, Up, Ui, Uv, xv)
					zv[i] = temp;
				}
				
				for (int i = begin; i < end; ++i)
				{
					double temp = zv[i];
					SPBLAS(temp, -, i, Lp, Li, Lv, xv)
					xv[i] = temp * Drcpv[i] * omega;
				}
			}
		}
		else if (RelaxationType == 1)
		{
			for (int k = 0; k < step; ++k)
			{
				for (int i = begin; i < end; ++i)
				{
					double temp = wv[i] + theta * Dv[i] * xv[i];
					SPBLAS(temp, -, i, Lp, Li, Lv, xv)
					zv[i] = temp;
				}

				for (int i = end - 1; i >= begin; --i)
				{
					double temp = zv[i];
					SPBLAS_R(temp, -, i, Up, Ui, Uv, xv)
					xv[i] = temp * Drcpv[i] * omega;
				}
			}
		}
		else if (RelaxationType == 2)
		{
			int k = 0;

			if (!(step & 1))
			{
				for (int i = begin; i < end; ++i)
				{
					double temp = theta * Dv[i] * xv[i];
					SPBLAS(temp, -, i, Up, Ui, Uv, xv)
					zv[i] = temp;
				}
			}
			else
			{
				for (int i = begin; i < end; ++i)
				{
					double temp = wv[i] + theta * Dv[i] * xv[i];
					SPBLAS(temp, -, i, Lp, Li, Lv, xv)
					zv[i] = temp;
				}
			}

			while (1)
			{
				if (!(step - k & 1))
				{
					++k;
					for (int i = begin; i < end; ++i)
					{
						double temp = wv[i] + zv[i];
						SPBLAS(temp, -, i, Lp, Li, Lv, xv)
						xv[i] = temp * Drcpv[i] * omega;
						zv[i] = temp * (2 - omega) - zv[i]; 
					}
				}

				if (++k >= step)
				{
					for (int i = end - 1; i >= begin; --i)
					{
						double temp = zv[i];
						SPBLAS_R(temp, -, i, Up, Ui, Uv, xv)
						xv[i] = temp * Drcpv[i] * omega;
					}

					break;
				}
				else
				{
					for (int i = end - 1; i >= begin; --i)
					{
						double temp = zv[i];
						SPBLAS_R(temp, -, i, Up, Ui, Uv, xv)
						xv[i] = temp * Drcpv[i] * omega;
						zv[i] = temp * (2 - omega) - zv[i]; 
					}
				}
			}
		}
	}
}

void ParCSRSmootherSORXLocal::operator()(const ParCSRMatrix& A, const ParVector& b, const ParVector& x, int step, bool x0zero) const
{
	int n = A.local.size[0];

	double* Dv = D.values;
	double* Drcpv = D_recip.values;
	int* Lp = L.rowptr;
	int* Li = L.colind;
	double* Lv = L.values;
	int* Up = U.rowptr;
	int* Ui = U.colind;
	double* Uv = U.values;
	int* Ep = E.rowptr;
	int* Ei = E.colind;
	double* Ev = E.values;
	int* Extp = A.exter.rowptr;
	int* Exti = A.exter.colind;
	double* Extv = A.exter.values;
	double* bv = b.local.values;
	double* zv = z.local.values;
	double* wv = w.local.values;
	double* xv = x.local.values;
	double* recvxv = A.recvx.values;

	double omega = RelaxationFactor;
	double theta = (1 - omega) / omega;

	if (!x0zero)
	{
		A.ExchangeHalo(x);

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		for (int i = 0; i < n; ++i)
		{
			double temp = bv[i];
			SPBLAS(temp, -, i, Extp, Exti, Extv, recvxv)
			SPBLAS(temp, -, i, Ep, Ei, Ev, xv)
			wv[i] = temp;
		}
	}
	else
		w.Copy(b);

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
	for (int t = 0; t < nthd; ++t)
	{
		int begin = t * n / nthd;
		int end = (t + 1) * n / nthd;

		if (RelaxationType == 0)
		{
			for (int k = 0; k < step; ++k)
			{
				if (!x0zero || k > 0)
				{
					for (int i = begin; i < end; ++i)
					{
						double temp = wv[i] + theta * Dv[i] * xv[i];
						SPBLAS(temp, -, i, Up, Ui, Uv, xv)
						zv[i] = temp;
					}
				}
				else
				{
					for (int i = begin; i < end; ++i)
						zv[i] = wv[i];
				}
				
				for (int i = begin; i < end; ++i)
				{
					double temp = zv[i];
					SPBLAS(temp, -, i, Lp, Li, Lv, xv)
					xv[i] = temp * Drcpv[i] * omega;
				}
			}
		}
		else if (RelaxationType == 1)
		{
			for (int k = 0; k < step; ++k)
			{
				if (!x0zero || k > 0)
				{
					for (int i = begin; i < end; ++i)
					{
						double temp = wv[i] + theta * Dv[i] * xv[i];
						SPBLAS(temp, -, i, Lp, Li, Lv, xv)
						zv[i] = temp;
					}
				}
				else
				{
					for (int i = begin; i < end; ++i)
						zv[i] = wv[i];
				}

				for (int i = end - 1; i >= begin; --i)
				{
					double temp = zv[i];
					SPBLAS_R(temp, -, i, Up, Ui, Uv, xv)
					xv[i] = temp * Drcpv[i] * omega;
				}
			}
		}
		else if (RelaxationType == 2)
		{
			int k = 0;

			if (!x0zero)
			{
				for (int i = begin; i < end; ++i)
				{
					double temp = theta * Dv[i] * xv[i];
					SPBLAS(temp, -, i, Up, Ui, Uv, xv)
					zv[i] = temp;
				}
			}
			else
			{
				for (int i = begin; i < end; ++i)
					zv[i] = 0.0;
			}

			while (1)
			{
				if (++k >= step)
				{
					for (int i = begin; i < end; ++i)
					{
						double temp = wv[i] + zv[i];
						SPBLAS(temp, -, i, Lp, Li, Lv, xv)
						xv[i] = temp * Drcpv[i] * omega;
					}

					break;
				}
				else
				{
					for (int i = begin; i < end; ++i)
					{
						double temp = wv[i] + zv[i];
						SPBLAS(temp, -, i, Lp, Li, Lv, xv)
						xv[i] = temp * Drcpv[i] * omega;
						zv[i] = temp * (2 - omega) - zv[i]; 
					}
				}
				
				if (++k >= step)
				{
					for (int i = end - 1; i >= begin; --i)
					{
						double temp = zv[i];
						SPBLAS_R(temp, -, i, Up, Ui, Uv, xv)
						xv[i] = temp * Drcpv[i] * omega;
					}

					break;
				}
				else
				{
					for (int i = end - 1; i >= begin; --i)
					{
						double temp = zv[i];
						SPBLAS_R(temp, -, i, Up, Ui, Uv, xv)
						xv[i] = temp * Drcpv[i] * omega;
						zv[i] = temp * (2 - omega) - zv[i]; 
					}
				}
			}
		}
	}
}

ParCSRSmootherSORX::ParCSRSmootherSORX(int relaxation_type, double relaxation_factor)
	: nthd(0),
	RelaxationType(relaxation_type),
	RelaxationFactor(relaxation_factor)
{
}

void ParCSRSmootherSORX::Setup(const ParCSRMatrix& A, int REUSE)
{
	int n = A.local.size[0];
	int* Ap = A.local.rowptr;
	int* Ai = A.local.colind;
	double* Av = A.local.values;
	
	if (!REUSE)
	{
		z.comm = A.comm;
		w.comm = A.comm;
		z.Resize(n);
		w.Resize(n);

		D.Resize(n);
		D_recip.Resize(n);

		nthd = 1;
#ifdef USE_ONED_PARTITION
		nthd = omp_get_max_threads();
#endif

		double* Dv = D.values;
		double* Drcpv = D_recip.values;

		int* Lp = new int[n + 1];
		int* Up = new int[n + 1];
		int* Ep = new int[n + 1];

		Lp[0] = 0;
		Up[0] = 0;
		Ep[0] = 0;
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		for (int t = 0; t < nthd; ++t)
		{
			int begin = t * n / nthd;
			int end = (t + 1) * n / nthd;

			for (int i = begin; i < end; ++i)
			{
				int cntl = 0;
				int cntu = 0;
				int cnte = 0;

				for (int j = Ap[i]; j < Ap[i + 1]; ++j)
				{
					int jcol = Ai[j];

					if (jcol >= begin && jcol < i) 
						++cntl;
					else if (jcol < end && jcol > i)
						++cntu;
					else if (jcol != i)
						++cnte;
				}

				Lp[i + 1] = cntl;
				Up[i + 1] = cntu;
				Ep[i + 1] = cnte;
			}
		}

		for (int i = 0; i < n;++i)
			Lp[i + 1] += Lp[i];
		for (int i = 0; i < n;++i)
			Up[i + 1] += Up[i];
		for (int i = 0; i < n;++i)
			Ep[i + 1] += Ep[i];

		int* Li = new int[Lp[n]];
		double* Lv = new double[Lp[n]];
		int* Ui = new int[Up[n]];
		double* Uv = new double[Up[n]];
		int* Ei = new int[Ep[n]];
		double* Ev = new double[Ep[n]];

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		for (int t = 0; t < nthd; ++t)
		{
			int begin = t * n / nthd;
			int end = (t + 1) * n / nthd;

			for (int i = begin; i < end; ++i)
			{
				for (int j = Ap[i], k = Lp[i], r = Up[i], s = Ep[i]; j < Ap[i + 1]; ++j)
				{
					int jcol = Ai[j];
					double jval = Av[j];

					if (jcol >= begin && jcol < i) 
					{
						Li[k] = jcol;
						Lv[k++] = jval;
					}
					else if (jcol < end && jcol > i)
					{
						Ui[r] = jcol;
						Uv[r++] = jval;
					}
					else if (jcol == i)
					{
						Dv[i] = jval;
						Drcpv[i] = 1.0 / jval;
					}
					else
					{
						Ei[s] = jcol;
						Ev[s++] = jval;
					}
				}
			}
		}

		L.size[0] = n;
		L.size[1] = n;
		L.rowptr = Lp;
		L.colind = Li;
		L.values = Lv;
		U.size[0] = n;
		U.size[1] = n;
		U.rowptr = Up;
		U.colind = Ui;
		U.values = Uv;
		E.size[0] = n;
		E.size[1] = n;
		E.rowptr = Ep;
		E.colind = Ei;
		E.values = Ev;
	}
	else
	{
		int* Lp = L.rowptr;
		int* Li = L.colind;
		double* Lv = L.values;
		int* Up = U.rowptr;
		int* Ui = U.colind;
		double* Uv = U.values;
		int* Ep = E.rowptr;
		int* Ei = E.colind;
		double* Ev = E.values;
		double* Dv = D.values;
		double* Drcpv = D_recip.values;
		
		int* w = new int[n];

		for (int i = 0; i < n; ++i)
			w[i] = -1;

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		for (int t = 0; t < nthd; ++t)
		{
			int begin = t * n / nthd;
			int end = (t + 1) * n / nthd;

			for (int i = begin; i < end; ++i)
			{
				int j0 = Ap[i];

				for (int j = Ap[i]; j < Ap[i + 1]; ++j)
					w[Ai[j]] = j;

				if (w[i] >= j0)
				{
					Dv[i] = Av[w[i]];
					Drcpv[i] = 1.0 / Av[w[i]];
				}

				for (int j = Lp[i]; j < Lp[i + 1]; ++j)
					if (w[Li[j]] >= j0) Lv[j] = Av[w[Li[j]]];
				for (int j = Up[i]; j < Up[i + 1]; ++j)
					if (w[Ui[j]] >= j0) Uv[j] = Av[w[Ui[j]]];
				for (int j = Ep[i]; j < Ep[i + 1]; ++j)
					if (w[Ei[j]] >= j0) Ev[j] = Av[w[Ei[j]]];
			}
		}
		
		delete[] w;	
	}
}

void ParCSRSmootherSORX::Pre_and_Resid(const ParCSRMatrix& A, const ParVector& b, const ParVector& x, const ParVector& r, int step, bool x0zero) const
{
	int n = A.local.size[0];

	double* Dv = D.values;
	double* Drcpv = D_recip.values;
	int* Lp = L.rowptr;
	int* Li = L.colind;
	double* Lv = L.values;
	int* Up = U.rowptr;
	int* Ui = U.colind;
	double* Uv = U.values;
	int* Ep = E.rowptr;
	int* Ei = E.colind;
	double* Ev = E.values;
	int* Extp = A.exter.rowptr;
	int* Exti = A.exter.colind;
	double* Extv = A.exter.values;
	double* bv = b.local.values;
	double* rv = r.local.values;
	double* zv = z.local.values;
	double* xv = x.local.values;
	double* recvxv = A.recvx.values;

	double omega = RelaxationFactor;
	double theta = (1 - omega) / omega;

	if (RelaxationType == 0)
	{
		for (int k = 0; k < step; ++k)
		{
			if (!x0zero || k > 0)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
				for (int i = 0; i < n; ++i)
				{
					double temp = theta * Dv[i] * xv[i];
					SPBLAS(temp, -, i, Up, Ui, Uv, xv)
					zv[i] = temp;
				}
				A.ExchangeHalo(x);
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
				for (int i = 0; i < n; ++i)
				{
					double temp = zv[i];
					SPBLAS(temp, -, i, Extp, Exti, Extv, recvxv)
					SPBLAS(temp, -, i, Ep, Ei, Ev, xv)
					zv[i] = temp;
				}
			}
			else
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				for (int i = 0; i < n; ++i)
					zv[i] = 0.0;
			}
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			for (int t = 0; t < nthd; ++t)
			{
				int begin = t * n / nthd;
				int end = (t + 1) * n / nthd;				
				for (int i = begin; i < end; ++i)
				{
					double temp = bv[i] + zv[i];
					SPBLAS(temp, -, i, Lp, Li, Lv, xv)
					xv[i] = temp * Drcpv[i] * omega;
				}
			}
		}

		A.ExchangeHalo(x);
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		for (int i = 0; i < n; ++i)
		{
			double temp = theta * Dv[i] * xv[i] - zv[i];
			SPBLAS(temp, -, i, Extp, Exti, Extv, recvxv)
			SPBLAS(temp, -, i, Ep, Ei, Ev, xv)
			SPBLAS(temp, -, i, Up, Ui, Uv, xv)
			rv[i] = temp;
		}
	}
	else if (RelaxationType == 1)
	{
		for (int k = 0; k < step; ++k)
		{
			if (!x0zero || k > 0)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
				for (int i = 0; i < n; ++i)
				{
					double temp = theta * Dv[i] * xv[i];
					SPBLAS(temp, -, i, Lp, Li, Lv, xv)
					zv[i] = temp;
				}
				A.ExchangeHalo(x);
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
				for (int i = 0; i < n; ++i)
				{
					double temp = zv[i];
					SPBLAS(temp, -, i, Extp, Exti, Extv, recvxv)
					SPBLAS(temp, -, i, Ep, Ei, Ev, xv)
					zv[i] = temp;
				}
			}
			else
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				for (int i = 0; i < n; ++i)
					zv[i] = 0.0;
			}

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			for (int t = 0; t < nthd; ++t)
			{
				int begin = t * n / nthd;
				int end = (t + 1) * n / nthd;		
				for (int i = end - 1; i >= begin; --i)
				{
					double temp = bv[i] + zv[i];
					SPBLAS_R(temp, -, i, Up, Ui, Uv, xv)
					xv[i] = temp * Drcpv[i] * omega;
				}
			}
		}

		A.ExchangeHalo(x);
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		for (int i = 0; i < n; ++i)
		{
			double temp = theta * Dv[i] * xv[i] - zv[i];
			SPBLAS(temp, -, i, Extp, Exti, Extv, recvxv)
			SPBLAS(temp, -, i, Ep, Ei, Ev, xv)
			SPBLAS(temp, -, i, Lp, Li, Lv, xv)
			rv[i] = temp;
		}
	}
	else if (RelaxationType == 2)
	{
		int k = 0;

		if (!x0zero)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				double temp = theta * Dv[i] * xv[i];
				SPBLAS(temp, -, i, Up, Ui, Uv, xv)
				zv[i] = temp;
			}

			A.ExchangeHalo(x);
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				double temp = zv[i];
				SPBLAS(temp, -, i, Extp, Exti, Extv, recvxv)
				SPBLAS(temp, -, i, Ep, Ei, Ev, xv)
				zv[i] = temp;
			}
		}
		else
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			for (int i = 0; i < n; ++i)
				zv[i] = 0.0;
		}

		while (1)
		{
			if (++k >= step)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				for (int t = 0; t < nthd; ++t)
				{
					int begin = t * n / nthd;
					int end = (t + 1) * n / nthd;
					for (int i = begin; i < end; ++i)
					{
						double temp = bv[i] + zv[i];
						SPBLAS(temp, -, i, Lp, Li, Lv, xv)
						xv[i] = temp * Drcpv[i] * omega;
					}
				}

				A.ExchangeHalo(x);
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
				for (int i = 0; i < n; ++i)
				{
					double temp = theta * Dv[i] * xv[i] - zv[i];
					SPBLAS(temp, -, i, Extp, Exti, Extv, recvxv)
					SPBLAS(temp, -, i, Ep, Ei, Ev, xv)
					SPBLAS(temp, -, i, Up, Ui, Uv, xv)
					rv[i] = temp;
				}

				break;
			}
			else
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				for (int t = 0; t < nthd; ++t)
				{
					int begin = t * n / nthd;
					int end = (t + 1) * n / nthd;
					for (int i = begin; i < end; ++i)
					{
						double temp = bv[i] + zv[i];
						SPBLAS(temp, -, i, Lp, Li, Lv, xv)
						xv[i] = temp * Drcpv[i] * omega;
						zv[i] = temp * (2 - omega) - zv[i]; 
					}
				}

				A.ExchangeHalo(x);
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
				for (int i = 0; i < n; ++i)
				{
					double temp = zv[i];
					SPBLAS(temp, -, i, Extp, Exti, Extv, recvxv)
					SPBLAS(temp, -, i, Ep, Ei, Ev, xv)
					zv[i] = temp;
				}
			}
			
			if (++k >= step)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				for (int t = 0; t < nthd; ++t)
				{
					int begin = t * n / nthd;
					int end = (t + 1) * n / nthd;
					for (int i = end - 1; i >= begin; --i)
					{
						double temp = zv[i];
						SPBLAS_R(temp, -, i, Up, Ui, Uv, xv)
						xv[i] = temp * Drcpv[i] * omega;
					}
				}

				A.ExchangeHalo(x);
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
				for (int i = 0; i < n; ++i)
				{
					double temp = bv[i] + theta * Dv[i] * xv[i] - zv[i];
					SPBLAS(temp, -, i, Extp, Exti, Extv, recvxv)
					SPBLAS(temp, -, i, Ep, Ei, Ev, xv)
					SPBLAS(temp, -, i, Lp, Li, Lv, xv)
					rv[i] = temp;
				}

				break;
			}
			else
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				for (int t = 0; t < nthd; ++t)
				{
					int begin = t * n / nthd;
					int end = (t + 1) * n / nthd;
					for (int i = end - 1; i >= begin; --i)
					{
						double temp = zv[i];
						SPBLAS_R(temp, -, i, Up, Ui, Uv, xv)
						xv[i] = temp * Drcpv[i] * omega;
						zv[i] = temp * (2 - omega) - zv[i]; 
					}
				}

				A.ExchangeHalo(x);
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
				for (int i = 0; i < n; ++i)
				{
					double temp = zv[i];
					SPBLAS(temp, -, i, Extp, Exti, Extv, recvxv)
					SPBLAS(temp, -, i, Ep, Ei, Ev, xv)
					zv[i] = temp;
				}
			}
		}
	}
}

void ParCSRSmootherSORX::Post(const ParCSRMatrix& A, const ParVector& b, const ParVector& x, int step) const
{
	int n = A.local.size[0];

	double* Dv = D.values;
	double* Drcpv = D_recip.values;
	int* Lp = L.rowptr;
	int* Li = L.colind;
	double* Lv = L.values;
	int* Up = U.rowptr;
	int* Ui = U.colind;
	double* Uv = U.values;
	int* Ep = E.rowptr;
	int* Ei = E.colind;
	double* Ev = E.values;
	int* Extp = A.exter.rowptr;
	int* Exti = A.exter.colind;
	double* Extv = A.exter.values;
	double* bv = b.local.values;
	double* zv = z.local.values;
	double* xv = x.local.values;
	double* recvxv = A.recvx.values;

	double omega = RelaxationFactor;
	double theta = (1 - omega) / omega;

	if (RelaxationType == 0)
	{
		for (int k = 0; k < step; ++k)
		{
			A.ExchangeHalo(x);
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				double temp = bv[i] + theta * Dv[i] * xv[i];
				SPBLAS(temp, -, i, Extp, Exti, Extv, recvxv)
				SPBLAS(temp, -, i, Ep, Ei, Ev, xv)
				SPBLAS(temp, -, i, Up, Ui, Uv, xv)
				zv[i] = temp;
			}

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			for (int t = 0; t < nthd; ++t)
			{
				int begin = t * n / nthd;
				int end = (t + 1) * n / nthd;				
				for (int i = begin; i < end; ++i)
				{
					double temp = zv[i];
					SPBLAS(temp, -, i, Lp, Li, Lv, xv)
					xv[i] = temp * Drcpv[i] * omega;
				}
			}
		}
	}
	else if (RelaxationType == 1)
	{
		for (int k = 0; k < step; ++k)
		{
			A.ExchangeHalo(x);
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				double temp = bv[i] + theta * Dv[i] * xv[i];
				SPBLAS(temp, -, i, Extp, Exti, Extv, recvxv)
				SPBLAS(temp, -, i, Ep, Ei, Ev, xv)
				SPBLAS(temp, -, i, Lp, Li, Lv, xv)
				zv[i] = temp;
			}

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			for (int t = 0; t < nthd; ++t)
			{
				int begin = t * n / nthd;
				int end = (t + 1) * n / nthd;		
				for (int i = end - 1; i >= begin; --i)
				{
					double temp = zv[i];
					SPBLAS_R(temp, -, i, Up, Ui, Uv, xv)
					xv[i] = temp * Drcpv[i] * omega;
				}
			}
		}
	}
	else if (RelaxationType == 2)
	{
		int k = 0;

		if (!(step & 1))
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				double temp = theta * Dv[i] * xv[i];
				SPBLAS(temp, -, i, Up, Ui, Uv, xv)
				zv[i] = temp;
			}
		}
		else
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				double temp = bv[i] + theta * Dv[i] * xv[i];
				SPBLAS(temp, -, i, Lp, Li, Lv, xv)
				zv[i] = temp;
			}
		}

		A.ExchangeHalo(x);
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		for (int i = 0; i < n; ++i)
		{
			double temp = zv[i];
			SPBLAS(temp, -, i, Extp, Exti, Extv, recvxv)
			SPBLAS(temp, -, i, Ep, Ei, Ev, xv)
			zv[i] = temp;
		}

		while (1)
		{
			if (!(step - k & 1))
			{
				++k;
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				for (int t = 0; t < nthd; ++t)
				{
					int begin = t * n / nthd;
					int end = (t + 1) * n / nthd;
					for (int i = begin; i < end; ++i)
					{
						double temp = bv[i] + zv[i];
						SPBLAS(temp, -, i, Lp, Li, Lv, xv)
						xv[i] = temp * Drcpv[i] * omega;
						zv[i] = temp * (2 - omega) - zv[i]; 
					}
				}
				
				A.ExchangeHalo(x);
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
				for (int i = 0; i < n; ++i)
				{
					double temp = zv[i];
					SPBLAS(temp, -, i, Extp, Exti, Extv, recvxv)
					SPBLAS(temp, -, i, Ep, Ei, Ev, xv)
					zv[i] = temp;
				}
			}

			if (++k >= step)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				for (int t = 0; t < nthd; ++t)
				{
					int begin = t * n / nthd;
					int end = (t + 1) * n / nthd;
					for (int i = end - 1; i >= begin; --i)
					{
						double temp = zv[i];
						SPBLAS_R(temp, -, i, Up, Ui, Uv, xv)
						xv[i] = temp * Drcpv[i] * omega;
					}
				}

				break;
			}
			else
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				for (int t = 0; t < nthd; ++t)
				{
					int begin = t * n / nthd;
					int end = (t + 1) * n / nthd;
					for (int i = end - 1; i >= begin; --i)
					{
						double temp = zv[i];
						SPBLAS_R(temp, -, i, Up, Ui, Uv, xv)
						xv[i] = temp * Drcpv[i] * omega;
						zv[i] = temp * (2 - omega) - zv[i]; 
					}
				}
				
				A.ExchangeHalo(x);
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
				for (int i = 0; i < n; ++i)
				{
					double temp = zv[i];
					SPBLAS(temp, -, i, Extp, Exti, Extv, recvxv)
					SPBLAS(temp, -, i, Ep, Ei, Ev, xv)
					zv[i] = temp;
				}
			}
		}
	}
}

void ParCSRSmootherSORX::operator()(const ParCSRMatrix& A, const ParVector& b, const ParVector& x, int step, bool x0zero) const
{
	int n = A.local.size[0];

	double* Dv = D.values;
	double* Drcpv = D_recip.values;
	int* Lp = L.rowptr;
	int* Li = L.colind;
	double* Lv = L.values;
	int* Up = U.rowptr;
	int* Ui = U.colind;
	double* Uv = U.values;
	int* Ep = E.rowptr;
	int* Ei = E.colind;
	double* Ev = E.values;
	int* Extp = A.exter.rowptr;
	int* Exti = A.exter.colind;
	double* Extv = A.exter.values;
	double* bv = b.local.values;
	double* zv = z.local.values;
	double* xv = x.local.values;
	double* recvxv = A.recvx.values;

	double omega = RelaxationFactor;
	double theta = (1 - omega) / omega;

	if (RelaxationType == 0)
	{
		for (int k = 0; k < step; ++k)
		{
			if (!x0zero || k > 0)
			{
				A.ExchangeHalo(x);
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
				for (int i = 0; i < n; ++i)
				{
					double temp = bv[i] + theta * Dv[i] * xv[i];
					SPBLAS(temp, -, i, Extp, Exti, Extv, recvxv)
					SPBLAS(temp, -, i, Ep, Ei, Ev, xv)
					SPBLAS(temp, -, i, Up, Ui, Uv, xv)
					zv[i] = temp;
				}
			}
			else
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				for (int i = 0; i < n; ++i)
					zv[i] = bv[i];
			}
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			for (int t = 0; t < nthd; ++t)
			{
				int begin = t * n / nthd;
				int end = (t + 1) * n / nthd;				
				for (int i = begin; i < end; ++i)
				{
					double temp = zv[i];
					SPBLAS(temp, -, i, Lp, Li, Lv, xv)
					xv[i] = temp * Drcpv[i] * omega;
				}
			}
		}
	}
	else if (RelaxationType == 1)
	{
		for (int k = 0; k < step; ++k)
		{
			if (!x0zero || k > 0)
			{
				A.ExchangeHalo(x);
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
				for (int i = 0; i < n; ++i)
				{
					double temp = bv[i] + theta * Dv[i] * xv[i];
					SPBLAS(temp, -, i, Extp, Exti, Extv, recvxv)
					SPBLAS(temp, -, i, Ep, Ei, Ev, xv)
					SPBLAS(temp, -, i, Lp, Li, Lv, xv)
					zv[i] = temp;
				}
			}
			else
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				for (int i = 0; i < n; ++i)
					zv[i] = bv[i];
			}

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			for (int t = 0; t < nthd; ++t)
			{
				int begin = t * n / nthd;
				int end = (t + 1) * n / nthd;		
				for (int i = end - 1; i >= begin; --i)
				{
					double temp = zv[i];
					SPBLAS_R(temp, -, i, Up, Ui, Uv, xv)
					xv[i] = temp * Drcpv[i] * omega;
				}
			}
		}
	}
	else if (RelaxationType == 2)
	{
		int k = 0;

		if (!x0zero)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				double temp = theta * Dv[i] * xv[i];
				SPBLAS(temp, -, i, Up, Ui, Uv, xv)
				zv[i] = temp;
			}

			A.ExchangeHalo(x);
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				double temp = zv[i];
				SPBLAS(temp, -, i, Extp, Exti, Extv, recvxv)
				SPBLAS(temp, -, i, Ep, Ei, Ev, xv)
				zv[i] = temp;
			}
		}
		else
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			for (int i = 0; i < n; ++i)
				zv[i] = 0.0;
		}

		while (1)
		{
			if (++k >= step)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				for (int t = 0; t < nthd; ++t)
				{
					int begin = t * n / nthd;
					int end = (t + 1) * n / nthd;
					for (int i = begin; i < end; ++i)
					{
						double temp = bv[i] + zv[i];
						SPBLAS(temp, -, i, Lp, Li, Lv, xv)
						xv[i] = temp * Drcpv[i] * omega;
					}
				}

				break;
			}
			else
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				for (int t = 0; t < nthd; ++t)
				{
					int begin = t * n / nthd;
					int end = (t + 1) * n / nthd;
					for (int i = begin; i < end; ++i)
					{
						double temp = bv[i] + zv[i];
						SPBLAS(temp, -, i, Lp, Li, Lv, xv)
						xv[i] = temp * Drcpv[i] * omega;
						zv[i] = temp * (2 - omega) - zv[i]; 
					}
				}

				A.ExchangeHalo(x);
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
				for (int i = 0; i < n; ++i)
				{
					double temp = zv[i];
					SPBLAS(temp, -, i, Extp, Exti, Extv, recvxv)
					SPBLAS(temp, -, i, Ep, Ei, Ev, xv)
					zv[i] = temp;
				}
			}
			
			if (++k >= step)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				for (int t = 0; t < nthd; ++t)
				{
					int begin = t * n / nthd;
					int end = (t + 1) * n / nthd;
					for (int i = end - 1; i >= begin; --i)
					{
						double temp = zv[i];
						SPBLAS_R(temp, -, i, Up, Ui, Uv, xv)
						xv[i] = temp * Drcpv[i] * omega;
					}
				}

				break;
			}
			else
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				for (int t = 0; t < nthd; ++t)
				{
					int begin = t * n / nthd;
					int end = (t + 1) * n / nthd;
					for (int i = end - 1; i >= begin; --i)
					{
						double temp = zv[i];
						SPBLAS_R(temp, -, i, Up, Ui, Uv, xv)
						xv[i] = temp * Drcpv[i] * omega;
						zv[i] = temp * (2 - omega) - zv[i]; 
					}
				}

				A.ExchangeHalo(x);
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
				for (int i = 0; i < n; ++i)
				{
					double temp = zv[i];
					SPBLAS(temp, -, i, Extp, Exti, Extv, recvxv)
					SPBLAS(temp, -, i, Ep, Ei, Ev, xv)
					zv[i] = temp;
				}
			}
		}
	}
}

}