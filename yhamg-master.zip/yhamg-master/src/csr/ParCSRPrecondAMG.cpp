/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <iostream>
#include "ParCSRSmootherJacobi.hpp"
#include "ParCSRSmootherSOR.hpp"
#include "ParCSRSmootherILU.hpp"
#include "ParCSRSmootherChebyshev.hpp"
#include "ParCSRPrecondAMG.hpp"
#include "RugeStuben.hpp"

namespace YHAMG
{

class ParCSRPrecondAMG::Smoother
{
private:
	ParCSRSmoother* _;

public:
	Smoother()
	: _(0)
	{
	}

	~Smoother()
	{
		if (_) delete _;
	}

	void SetupJacobi(const ParCSRMatrix& A, double RelaxationFactor)
	{
		if (_) delete _;
#ifdef KERNEL_FUSION
#ifdef LOCAL_SMOOTH
		_ = new ParCSRSmootherJacobiXLocal(RelaxationFactor);
#else
		_ = new ParCSRSmootherJacobiX(RelaxationFactor);
#endif
#else
		_ = new ParCSRSmootherJacobi(RelaxationFactor);
#endif
		_->Setup(A, 0);
	}

	void SetupSOR(const ParCSRMatrix& A, int RelaxationType, double RelaxationFactor)
	{
		if (_) delete _;
#ifdef KERNEL_FUSION
#ifdef LOCAL_SMOOTH
		_ = new ParCSRSmootherSORXLocal(RelaxationType, RelaxationFactor);
#else
		_ = new ParCSRSmootherSORX(RelaxationType, RelaxationFactor);
#endif
#else
#ifdef LOCAL_SMOOTH
		_ = new ParCSRSmootherSORLocal(RelaxationType, RelaxationFactor);
#else
		_ = new ParCSRSmootherSOR(RelaxationType, RelaxationFactor);
#endif
#endif
		_->Setup(A, 0);
	}

	void SetupILU(const ParCSRMatrix& A, int MaxFillins, double DropTolerance)
	{
		if (_) delete _;
		_ = new ParCSRSmootherILU(MaxFillins, DropTolerance);
		_->Setup(A, 0);
	}

	void SetupChebyshev(const ParCSRMatrix& A, double EigenRatio)
	{
		if (_) delete _;
#ifdef KERNEL_FUSION
#ifdef LOCAL_SMOOTH
		_ = new ParCSRSmootherChebyshevXLocal(EigenRatio);
#else
		_ = new ParCSRSmootherChebyshevX(EigenRatio);
#endif
#else
		_ = new ParCSRSmootherChebyshev(EigenRatio);
#endif
		_->Setup(A, 0);
	}

	void SetupReuse(const ParCSRMatrix& A)
	{
		_->Setup(A, 1);
	}

	void Pre(const ParCSRMatrix& A, const ParVector& b, const ParVector& x, int step, bool x0zero = 0) const
	{
		_->Pre(A, b, x, step, x0zero);
	}

	void Pre_and_Resid(const ParCSRMatrix& A, const ParVector& b, const ParVector& x, const ParVector& r, int step, bool x0zero = 0) const
	{
		_->Pre_and_Resid(A, b, x, r, step, x0zero);
	}

	void Post(const ParCSRMatrix& A, const ParVector& b, const ParVector& x, int step) const
	{
		_->Post(A, b, x, step);
	}

	void Coarse(const ParCSRMatrix& A, const ParVector& b, const ParVector& x, int step, bool x0zero = 0) const
	{
		_->Pre(A, b, x, step, x0zero);
	}
};

void ParCSRPrecondAMG::Strength(const ParCSRMatrix& A, bool* locstg, bool* extstg) const
{
	double threshold = StrengthThreshold;
	RugeStuben::Strength(A, locstg, extstg, threshold);
}

void ParCSRPrecondAMG::Coarsening(const ParCSRMatrix& A, const bool* locstg, const bool* extstg, int* cfmap, int AGGRESSIVE) const
{
	if (AGGRESSIVE)
	{
		if (CoarsenType == 0)
			RugeStuben::AggressiveHMISCoarsening(A, locstg, extstg, cfmap);
		else if (CoarsenType == 1)
			RugeStuben::AggressivePMISCoarsening(A, locstg, extstg, cfmap);
	}
	else
	{
		if (CoarsenType == 0)
			RugeStuben::HMISCoarsening(A, locstg, extstg, cfmap);
		else if (CoarsenType == 1)
			RugeStuben::PMISCoarsening(A, locstg, extstg, cfmap);
	}
}

void ParCSRPrecondAMG::Interpolation(const ParCSRMatrix& A, const bool* locstg, const bool* extstg, int* cfmap, ParCSRMatrix& P, int AGGRESSIVE) const
{
	if (InterpType == 0)
	{
		int min_elements = InterpMinElements;
		int max_elements = InterpMaxElements;
		double truncation_factor = TruncationFactor;
		if (AGGRESSIVE)
			RugeStuben::AggressiveLongRangeInterpolation(A, locstg, extstg, cfmap, P, min_elements, max_elements, truncation_factor);
		else
			RugeStuben::LongRangeInterpolation(A, locstg, extstg, cfmap, P, min_elements, max_elements, truncation_factor);
	}
	else if (InterpType == 1)
	{
		if (AGGRESSIVE)
			RugeStuben::AggressiveSmoothedAggregation(A, locstg, extstg, cfmap, P);
		else
			RugeStuben::SmoothedAggregation(A, locstg, extstg, cfmap, P);
	}
}

void ParCSRPrecondAMG::RAP(const ParCSRMatrix& R, const ParCSRMatrix& A, const ParCSRMatrix& P, ParCSRMatrix& C) const
{
	ParCSRMatrix Z;
	ParCSRMatMul(A, P, Z);
	ParCSRMatMul(R, Z, C);
}

void ParCSRPrecondAMG::Sparsification(const ParCSRMatrix& A, ParCSRMatrix& B) const
{
	double threshold = SparsificationThreshold;
	RugeStuben::Sparsification(A, B, threshold);
}

void ParCSRPrecondAMG::SetupSmoother(const ParCSRMatrix& A, Smoother& S, int REUSE) const
{
	if (!REUSE)
	{
		if (SmoothType == 0)
			S.SetupJacobi(A, JacobiFactor);
		else if (SmoothType == 1)
			S.SetupSOR(A, SORType, SORFactor);
		else if (SmoothType == 2)
			S.SetupILU(A, ILUMaxFillins, ILUDropTolerance);
		else if (SmoothType == 3)
			S.SetupChebyshev(A, ChebyshevEigenRatio);
	}
	else
		S.SetupReuse(A);
}

void ParCSRPrecondAMG::PreSmooth(int level, const ParVector& b, const ParVector& x, bool x0zero) const
{
	S[level].Pre(A[level], b, x, PreSweeps, x0zero);
}

void ParCSRPrecondAMG::PreSmooth_Restriction(int level, const ParVector& b, const ParVector& x, const ParVector& g, bool x0zero) const
{
	S[level].Pre_and_Resid(A[level], b, x, r[level], PreSweeps, x0zero);
	ParCSRMatVec(1.0, R[level], r[level], 0.0, g);
}

void ParCSRPrecondAMG::PostSmooth(int level, const ParVector& b, const ParVector& x) const
{
	S[level].Post(A[level], b, x, PostSweeps);
}

void ParCSRPrecondAMG::CoarseSmooth(int level, const ParVector& b, const ParVector& x, bool x0zero) const
{
	S[level].Coarse(A[level], b, x, CoarseSweeps, x0zero);
}

void ParCSRPrecondAMG::Restriction(int level, const ParVector& b, const ParVector& x, const ParVector& g) const
{
	r[level].Copy(b);
	ParCSRMatVec(-1.0, A[level], x, 1.0, r[level]);
	ParCSRMatVec(1.0, R[level], r[level], 0.0, g);
}

void ParCSRPrecondAMG::Prolongation(int level, const ParVector& e, const ParVector& x) const
{
	ParCSRMatVec(1.0, P[level], e, 1.0, x);
}

void ParCSRPrecondAMG::V_Cycle(int level, const ParVector& b, const ParVector& x, bool x0zero) const
{
	if (level == nlev - 1)
		CoarseSmooth(level, b, x, x0zero);
	else
	{
		PreSmooth_Restriction(level, b, x, g[level], x0zero);

		e[level].Fill(0.0);

		V_Cycle(level + 1, g[level], e[level], 1);

		Prolongation(level, e[level], x);

		PostSmooth(level, b, x);
	}
}

void ParCSRPrecondAMG::W_Cycle(int level, const ParVector& b, const ParVector& x, bool x0zero) const
{
	if (level == nlev - 1)
		CoarseSmooth(level, b, x, x0zero);
	else
	{
		PreSmooth_Restriction(level, b, x, g[level], x0zero);

		e[level].Fill(0.0);

		W_Cycle(level + 1, g[level], e[level], 1);
		W_Cycle(level + 1, g[level], e[level]);

		Prolongation(level, e[level], x);

		PostSmooth(level, b, x);
	}
}

void ParCSRPrecondAMG::F_Cycle(int level, const ParVector& b, const ParVector& x) const
{
	if (level == nlev - 1)
	{
		x.Fill(0.0);
		CoarseSmooth(level, b, x, 1);
	}
	else
	{
		ParCSRMatVec(1.0, R[level], b, 0.0, g[level]);

		F_Cycle(level + 1, g[level], e[level]);

		ParCSRMatVec(1.0, P[level], e[level], 0.0, x);

		V_Cycle(level, b, x);
	}
}

ParCSRPrecondAMG::ParCSRPrecondAMG(
	int    max_levels,
	int    coarse_size,
	double strength_threshold,
	int    aggressive_levels,
	int    coarsen_type, 
	int    interp_type, 
	int    interp_min_elements,
	int    interp_max_elements,
	double truncation_factor,
	double sparsification_threshold,
	int    cycle_type,
	int    pre_sweeps,
	int    post_sweeps,
	int    coarse_sweeps,
	int    smooth_type,
	int    print_stats)
	: nlev(0),
	A(0),
	P(0),
	R(0),
	S(0),
	r(0),
	e(0),
	g(0),
	MaxLevels(max_levels),
	CoarseSize(coarse_size),
	StrengthThreshold(strength_threshold),
	AggressiveLevels(aggressive_levels),
	CoarsenType(coarsen_type),
	InterpType(interp_type),
	InterpMinElements(interp_min_elements),
	InterpMaxElements(interp_max_elements),
	TruncationFactor(truncation_factor),
	SparsificationThreshold(sparsification_threshold),
	CycleType(cycle_type),
	PreSweeps(pre_sweeps),
	PostSweeps(post_sweeps),
	CoarseSweeps(coarse_sweeps),
	SmoothType(smooth_type),
	JacobiFactor(0.75),
	SORType(2),
	SORFactor(1.0),
	ILUMaxFillins(0),
	ILUDropTolerance(0.01),
	ChebyshevEigenRatio(0.3),
	PrintStats(print_stats)
{
}

ParCSRPrecondAMG::~ParCSRPrecondAMG()
{
	if (A) delete[] A;
	if (P) delete[] P;
	if (R) delete[] R;
	if (S) delete[] S;
	if (r) delete[] r;
	if (e) delete[] e;
	if (g) delete[] g;
}

void ParCSRPrecondAMG::Free()
{
	if (A) delete[] A;
	if (P) delete[] P;
	if (R) delete[] R;
	if (S) delete[] S;
	if (r) delete[] r;
	if (e) delete[] e;
	if (g) delete[] g;
	nlev = 0;
	A = 0;
	P = 0;
	R = 0;
	S = 0;
	r = 0;
	e = 0;
	g = 0;
}

void ParCSRPrecondAMG::Setup(const ParCSRMatrix& _A, int REUSE)
{
	if (!REUSE)
	{
		Free();

		MPI_Comm comm = _A.comm;

		int comm_rank;
		MPI_Comm_rank(comm, &comm_rank);

		A = new ParCSRMatrix[MaxLevels];
		P = new ParCSRMatrix[MaxLevels - 1];
		R = new ParCSRMatrix[MaxLevels - 1];
		r = new ParVector[MaxLevels];
		e = new ParVector[MaxLevels - 1];
		g = new ParVector[MaxLevels - 1];
		S = new Smoother[MaxLevels];

		long global_size0[2];
		double grid_complexity = 0.0;
		double operator_complexity = 0.0;

		if (PrintStats && comm_rank == 0)
		{
			std::cout << "Multigrid Hierarchy:\n";
			std::cout << "Level\tRows\tNz\n";
			std::cout << "--------------------------------------------------\n";
		}

		A[0].Refer(_A);
		A[0].SetupHalo();

		int level = 0;

		while (1)
		{
			SetupSmoother(A[level], S[level]);

			int n = A[level].local.size[0];

			long local_size[2];
			long global_size[2];

			local_size[0] = n;
			local_size[1] = A[level].local.rowptr[n] + A[level].exter.rowptr[n];

			MPI_Allreduce(local_size, global_size, 2, MPI_LONG, MPI_SUM, comm);

			if (level == 0)
			{
				global_size0[0] = global_size[0];
				global_size0[1] = global_size[1];
			}

			grid_complexity += (double)global_size[0] / global_size0[0];
			operator_complexity += (double)global_size[1] / global_size0[1];

			if (PrintStats && comm_rank == 0)
				std::cout << level << "\t" << global_size[0] << "\t" << global_size[1] << "\n";

			r[level].comm = comm;
			r[level].Resize(n);

			if (level == MaxLevels - 1 || global_size[0] <= (long)CoarseSize) break;

			bool* locstg = new bool[A[level].local.rowptr[n]];
			bool* extstg = new bool[A[level].exter.rowptr[n]];
			int* cfmap = new int[n];

			Strength(A[level], locstg, extstg);
			Coarsening(A[level], locstg, extstg, cfmap, level < AggressiveLevels);
			Interpolation(A[level], locstg, extstg, cfmap, P[level], level < AggressiveLevels);

			delete[] cfmap;
			delete[] locstg;
			delete[] extstg;

			P[level].SetupHalo();
			
			ParCSRTrans(P[level], R[level]);

			R[level].SetupHalo();

			ParCSRMatrix C;
			RAP(R[level], A[level], P[level], C);

			C.SetupHalo();

			Sparsification(C, A[level +1]);

			A[level + 1].SetupHalo();

			e[level].comm = comm;
			g[level].comm = comm;
			e[level].Resize(A[level + 1].local.size[0]);
			g[level].Resize(A[level + 1].local.size[0]);

			++level;
		}

		nlev = level + 1;
		
		if (PrintStats && comm_rank == 0)
		{
			std::cout << "--------------------------------------------------\n";
			std::cout << "Number of Levels: " << nlev << "\n";
			std::cout << "Grid Complexity: " << grid_complexity << "\n";
			std::cout << "Operator Complexity: " << operator_complexity << "\n";
		}
	}
	else
	{
		A[0].Refer(_A);
		A[0].SetupHalo();
		SetupSmoother(A[0], S[0], 1);
	}
}

int ParCSRPrecondAMG::InSize() const
{
	return A[0].local.size[0];
}

int ParCSRPrecondAMG::OutSize() const
{
	return A[0].local.size[0];
}

void ParCSRPrecondAMG::Apply(const ParVector& b, const ParVector& x) const
{
	switch (CycleType)
	{
	case 0:
		x.Fill(0.0);
		V_Cycle(0, b, x, 1);
		break;
	case 1:
		x.Fill(0.0);
		W_Cycle(0, b, x, 1);
		break;
	case 2:
		F_Cycle(0, b, x);
		break;
	}
}

}