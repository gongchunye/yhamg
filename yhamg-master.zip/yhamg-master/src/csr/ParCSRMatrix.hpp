/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef ParCSRMatrix_H
#define ParCSRMatrix_H

#include "ParOperator.hpp"
#include "CSRMatrix.hpp"

namespace YHAMG
{

struct ParCSRMatrix : public ParOperator
{
	CSRMatrix local;
	CSRMatrix exter;

	int nnb;
	int* nbrank;

	int* recvptr;
	int* recvind;

	int* sendptr;
	int* sendind;
	double* sendbuf;
	
	Vector recvx;

	ParCSRMatrix(MPI_Comm comm = MPI_COMM_SELF);
	ParCSRMatrix(MPI_Comm comm, int local_rows, int local_cols, int exter_cols, 
	int* local_rowptr, int* local_colind, double* local_values, int local_ref, 
	int* exter_rowptr, int* exter_colind, double* exter_values, int exter_ref,
	int nnb, int* nbrank, int* recvptr, int* recvind);
	ParCSRMatrix(const CSRMatrix& A);
	ParCSRMatrix(const ParCSRMatrix& A);
	ParCSRMatrix(ParCSRMatrix&& A);
	~ParCSRMatrix();
	ParCSRMatrix& operator=(const ParCSRMatrix& A);
	ParCSRMatrix& operator=(ParCSRMatrix&& A);
	
	void Free();
	void Refer(const ParCSRMatrix& A);
	void ExchangeHalo(const ParVector& x) const;
	void SetupHalo();
	int InSize() const;
	int OutSize() const;
	void Apply(const ParVector& x, const ParVector& y) const;
	void Apply(const ParMultiVector& X, const ParMultiVector& Y) const;
};

void ParCSRDiag(const ParCSRMatrix& A, const ParVector& D);
void ParCSREliminZeros(const ParCSRMatrix& A);
void ParCSRScale(double alpha, const ParCSRMatrix& A);
void ParCSRScaleRows(const ParVector& x, const ParCSRMatrix& A);
void ParCSRScaleCols(const ParVector& x, const ParCSRMatrix& A);
void ParCSRMatAdd(const ParCSRMatrix& A, const ParCSRMatrix& B, ParCSRMatrix& C);
void ParCSRMatMul(const ParCSRMatrix& A, const ParCSRMatrix& B, ParCSRMatrix& C);
void ParCSRMatVec(double alpha, const ParCSRMatrix& A, const ParVector& x, double beta, const ParVector& y);
void ParCSRMatMultiVec(double alpha, const ParCSRMatrix& A, const ParMultiVector& X, double beta, const ParMultiVector& Y);
void ParCSRTrans(const ParCSRMatrix& A, ParCSRMatrix& B);

}

#endif