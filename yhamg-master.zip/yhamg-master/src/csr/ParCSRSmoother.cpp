/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "ParCSRSmoother.hpp"

namespace YHAMG
{

ParCSRSmoother::~ParCSRSmoother()
{
}

void ParCSRSmoother::Pre(const ParCSRMatrix& A, const ParVector& b, const ParVector& x, int step, bool x0zero) const
{
	(*this)(A, b, x, step, x0zero);
}

void ParCSRSmoother::Pre_and_Resid(const ParCSRMatrix& A, const ParVector& b, const ParVector& x, const ParVector& r, int step, bool x0zero) const
{
	Pre(A, b, x, step, x0zero);
	r.Copy(b);
	ParCSRMatVec(-1.0, A, x, 1.0, r);
}

void ParCSRSmoother::Post(const ParCSRMatrix& A, const ParVector& b, const ParVector& x, int step) const
{
	(*this)(A, b, x, step);
}

}
