/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef ParCSRSmootherILU_H
#define ParCSRSmootherILU_H

#include "ParCSRSmoother.hpp"

namespace YHAMG
{

class ParCSRSmootherILUGlobal : public ParCSRSmoother
{
private:
	Vector D_local_recip;
	CSRMatrix L_local;
	CSRMatrix L_exter;
	CSRMatrix U_local;
	CSRMatrix U_exter;
	Vector recvx;

	bool* interior;

	int label;
	int nnb;
	int* nblab;
	int* nbrank;

	int* recvptr;
	int* sendptr;
	int* sendind;
	double* sendbuf;

	ParVector z;

public:
	ParCSRSmootherILUGlobal();
	~ParCSRSmootherILUGlobal();

	void Setup(const ParCSRMatrix& A, int REUSE = 0);
	void operator()(const ParCSRMatrix& A, const ParVector& b, const ParVector& x, int step, bool x0zero = 0) const;
};

class ParCSRSmootherILU : public ParCSRSmoother
{
private:
	int nthd;
	Vector* D_recip;
	CSRMatrix* L;
	CSRMatrix* U;
	ParVector z;

public:
	int MaxFillins;
	double DropTolerance;

	ParCSRSmootherILU(int maxfil = 0, double droptol = 0.01);
	~ParCSRSmootherILU();

	void Setup(const ParCSRMatrix& A, int REUSE = 0);
	void operator()(const ParCSRMatrix& A, const ParVector& b, const ParVector& x, int step, bool x0zero = 0) const;
};

}

#endif