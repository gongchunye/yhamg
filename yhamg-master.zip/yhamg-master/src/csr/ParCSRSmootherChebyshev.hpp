/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef ParCSRSmootherChebyshev_H
#define ParCSRSmootherChebyshev_H

#include "ParCSRSmoother.hpp"

namespace YHAMG
{

class ParCSRSmootherChebyshev : public ParCSRSmoother
{
private:
	double lambda;
	ParVector D_recip;
	ParVector z;
	ParVector r;

public:
	double EigenRatio;

	ParCSRSmootherChebyshev(double eigen_ratio = 0.3);

	void Setup(const ParCSRMatrix& A, int REUSE = 0);
	void operator()(const ParCSRMatrix& A, const ParVector& b, const ParVector& x, int step, bool x0zero = 0) const;
};

class ParCSRSmootherChebyshevXLocal : public ParCSRSmoother
{
private:
	int nthd;
	double* lambda;
	Vector D;
	Vector D_recip;
	CSRMatrix L;
	CSRMatrix U;
	CSRMatrix E;
	ParVector r;
	ParVector w;
	ParVector z;

public:
	double EigenRatio;

	ParCSRSmootherChebyshevXLocal(double eigen_ratio = 0.3);
	~ParCSRSmootherChebyshevXLocal();

	void Setup(const ParCSRMatrix& A, int REUSE = 0);
	void Pre_and_Resid(const ParCSRMatrix& A, const ParVector& b, const ParVector& x, const ParVector& r, int step, bool x0zero = 0) const;
	void operator()(const ParCSRMatrix& A, const ParVector& b, const ParVector& x, int step, bool x0zero = 0) const;
};

class ParCSRSmootherChebyshevX : public ParCSRSmoother
{
private:
	int nthd;
	double lambda;
	Vector D;
	Vector D_recip;
	CSRMatrix L;
	CSRMatrix U;
	CSRMatrix E;
	ParVector r;
	ParVector w;
	ParVector z;

public:
	double EigenRatio;

	ParCSRSmootherChebyshevX(double eigen_ratio = 0.3);

	void Setup(const ParCSRMatrix& A, int REUSE = 0);
	void Pre_and_Resid(const ParCSRMatrix& A, const ParVector& b, const ParVector& x, const ParVector& r, int step, bool x0zero = 0) const;
	void operator()(const ParCSRMatrix& A, const ParVector& b, const ParVector& x, int step, bool x0zero = 0) const;
};

}

#endif