/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <cmath>
#include "ParCSRSmootherChebyshev.hpp"

#ifdef YHAMG_USE_OPENMP
#include <omp.h>
#endif

#define MPI_TAG 200

namespace YHAMG
{

inline uint64_t xorshift128plus(uint64_t& k1, uint64_t& k2)
{
	uint64_t k3 = k1;
	const uint64_t k4 = k2;
	k1 = k4;
	k3 ^= (k3 << 23);
	k2 = k3 ^ k4 ^ (k3 >> 17) ^ (k4 >> 26);
	return k2 + k4;
}

static void DiagonalScale(const ParVector& D_recip, const ParVector& x)
{
	int n = D_recip.local.size;
	double* Drcpv = D_recip.local.values;
	double* xv = x.local.values;
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
	for (int i = 0; i < n; ++i)
		xv[i] *= Drcpv[i];
}

static double LargestEigenvalueEstimate(const ParCSRMatrix& A, const ParVector& D_recip, int iteration)
{
	MPI_Comm comm = A.comm;
	int n = A.OutSize();

	ParVector x(comm), y(comm);
	x.Resize(n);
	y.Resize(n);

	y.FillRandom();

	for (int k = 0; k < iteration; ++k)
	{
		ParVecAXPBY(1.0 / sqrt(ParVecDot(y, y)), y, 0.0, x);
		ParCSRMatVec(1.0, A, x, 0.0, y);
		DiagonalScale(D_recip, y);
	}

	return ParVecDot(x, y);
}

ParCSRSmootherChebyshev::ParCSRSmootherChebyshev(double eigen_ratio)
	: lambda(1.0),
	EigenRatio(eigen_ratio)
{
}

void ParCSRSmootherChebyshev::Setup(const ParCSRMatrix& A, int REUSE)
{
	int n = A.local.size[0];
	int* Ap = A.local.rowptr;
	int* Ai = A.local.colind;
	double* Av = A.local.values;

	if (!REUSE)
	{
		z.comm = A.comm;
		r.comm = A.comm;
		D_recip.comm = A.comm;
		z.Resize(n);
		r.Resize(n);
		D_recip.Resize(n);
	}

	double* Drcpv = D_recip.local.values;
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
	for (int i = 0; i < n; ++i)
	{
		for (int j = Ap[i]; j < Ap[i + 1]; ++j)
		{
			if (Ai[j] == i)
			{
				Drcpv[i] = 1.0 / Av[j];
				break;
			}
		}
	}

	lambda = 1.1 * LargestEigenvalueEstimate(A, D_recip, 10);
}

void ParCSRSmootherChebyshev::operator()(const ParCSRMatrix& A, const ParVector& b, const ParVector& x, int step, bool x0zero) const
{
	double alpha = lambda;
	double beta  = lambda * EigenRatio;

	double theta, delta, sigma, rho, rho1;

	theta = 2.0 / (beta + alpha);
	delta = 2.0 / (beta - alpha);
	sigma = delta / theta;
	rho = 1.0 / sigma;

	for (int k = 0; k < step; ++k)
	{
		if (k == 0)
		{
			r.Copy(b);
			if (!x0zero) ParCSRMatVec(-1.0, A, x, 1.0, r);
			DiagonalScale(D_recip, r);
			ParVecAXPBY(theta, r, 0.0, z);
		}
		else
		{
			r.Copy(b);
			ParCSRMatVec(-1.0, A, x, 1.0, r);
			DiagonalScale(D_recip, r);
			rho = 1.0 / (2.0 * sigma - rho1);
			ParVecAXPBY(2.0 * rho * delta, r, rho * rho1, z);
		}

		x.AddScaled(1.0, z);
		rho1 = rho;
	}
}

ParCSRSmootherChebyshevXLocal::ParCSRSmootherChebyshevXLocal(double eigen_ratio)
	: nthd(0),
	lambda(0),
	EigenRatio(eigen_ratio)
{
}

ParCSRSmootherChebyshevXLocal::~ParCSRSmootherChebyshevXLocal()
{
	if (lambda) delete[] lambda;
}

void ParCSRSmootherChebyshevXLocal::Setup(const ParCSRMatrix& A, int REUSE)
{
	int n = A.local.size[0];
	int* Ap = A.local.rowptr;
	int* Ai = A.local.colind;
	double* Av = A.local.values;
	
	if (!REUSE)
	{
		if (lambda) delete[] lambda;

		r.comm = A.comm;
		w.comm = A.comm;
		z.comm = A.comm;
		r.Resize(n);
		w.Resize(n);
		z.Resize(2 * n);
		D.Resize(n);
		D_recip.Resize(n);
		
		nthd = 1;
#ifdef USE_ONED_PARTITION
		nthd = omp_get_max_threads();
#endif

		lambda = new double[nthd];
		double* Dv = D.values;
		double* Drcpv = D_recip.values;

		int* Lp = new int[n + 1];
		int* Up = new int[n + 1];
		int* Ep = new int[n + 1];

		Lp[0] = 0;
		Up[0] = 0;
		Ep[0] = 0;
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		for (int t = 0; t < nthd; ++t)
		{
			int begin = t * n / nthd;
			int end = (t + 1) * n / nthd;

			for (int i = begin; i < end; ++i)
			{
				int cntl = 0;
				int cntu = 0;
				int cnte = 0;

				for (int j = Ap[i]; j < Ap[i + 1]; ++j)
				{
					int jcol = Ai[j];

					if (jcol >= begin && jcol < i) 
						++cntl;
					else if (jcol < end && jcol > i)
						++cntu;
					else if (jcol != i)
						++cnte;
				}

				Lp[i + 1] = cntl;
				Up[i + 1] = cntu;
				Ep[i + 1] = cnte;
			}
		}

		for (int i = 0; i < n;++i)
			Lp[i + 1] += Lp[i];
		for (int i = 0; i < n;++i)
			Up[i + 1] += Up[i];
		for (int i = 0; i < n;++i)
			Ep[i + 1] += Ep[i];

		int* Li = new int[Lp[n]];
		double* Lv = new double[Lp[n]];
		int* Ui = new int[Up[n]];
		double* Uv = new double[Up[n]];
		int* Ei = new int[Ep[n]];
		double* Ev = new double[Ep[n]];

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		for (int t = 0; t < nthd; ++t)
		{
			int begin = t * n / nthd;
			int end = (t + 1) * n / nthd;

			for (int i = begin; i < end; ++i)
			{
				for (int j = Ap[i], k = Lp[i], r = Up[i], s = Ep[i]; j < Ap[i + 1]; ++j)
				{
					int jcol = Ai[j];
					double jval = Av[j];

					if (jcol >= begin && jcol < i) 
					{
						Li[k] = jcol;
						Lv[k++] = jval;
					}
					else if (jcol < end && jcol > i)
					{
						Ui[r] = jcol;
						Uv[r++] = jval;
					}
					else if (jcol == i)
					{
						Dv[i] = jval;
						Drcpv[i] = 1.0 / jval;
					}
					else
					{
						Ei[s] = jcol;
						Ev[s++] = jval;
					}
				}
			}
		}

		L.size[0] = n;
		L.size[1] = n;
		L.rowptr = Lp;
		L.colind = Li;
		L.values = Lv;
		U.size[0] = n;
		U.size[1] = n;
		U.rowptr = Up;
		U.colind = Ui;
		U.values = Uv;
		E.size[0] = n;
		E.size[1] = n;
		E.rowptr = Ep;
		E.colind = Ei;
		E.values = Ev;
	}
	else
	{
		int* Lp = L.rowptr;
		int* Li = L.colind;
		double* Lv = L.values;
		int* Up = U.rowptr;
		int* Ui = U.colind;
		double* Uv = U.values;
		int* Ep = E.rowptr;
		int* Ei = E.colind;
		double* Ev = E.values;
		double* Dv = D.values;
		double* Drcpv = D_recip.values;
		
		int* w = new int[n];

		for (int i = 0; i < n; ++i)
			w[i] = -1;

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		for (int t = 0; t < nthd; ++t)
		{
			int begin = t * n / nthd;
			int end = (t + 1) * n / nthd;

			for (int i = begin; i < end; ++i)
			{
				int j0 = Ap[i];

				for (int j = Ap[i]; j < Ap[i + 1]; ++j)
					w[Ai[j]] = j;

				if (w[i] >= j0)
				{
					Dv[i] = Av[w[i]];
					Drcpv[i] = 1.0 / Av[w[i]];
				}

				for (int j = Lp[i]; j < Lp[i + 1]; ++j)
					if (w[Li[j]] >= j0) Lv[j] = Av[w[Li[j]]];
				for (int j = Up[i]; j < Up[i + 1]; ++j)
					if (w[Ui[j]] >= j0) Uv[j] = Av[w[Ui[j]]];
				for (int j = Ep[i]; j < Ep[i + 1]; ++j)
					if (w[Ei[j]] >= j0) Ev[j] = Av[w[Ei[j]]];
			}
		}
		
		delete[] w;	
	}

	int* Lp = L.rowptr;
	int* Li = L.colind;
	double* Lv = L.values;
	int* Up = U.rowptr;
	int* Ui = U.colind;
	double* Uv = U.values;
	double* Drcpv = D_recip.values;
	double* wv = w.local.values;
	double* zv = z.local.values;

	int comm_rank;
	MPI_Comm_rank(A.comm, &comm_rank);

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel
#endif
	{
		int ithd = 0;
#ifdef YHAMG_USE_OPENMP
		ithd = omp_get_thread_num();
#endif
		uint64_t k1 = ithd + 1;
		uint64_t k2 = comm_rank + 1;
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
		for (int i = 0; i < n; ++i)
			zv[2 * i] = (double)(xorshift128plus(k1, k2) & 4294967295U) / 4294967295U;
	}

	int iteration = 10;

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
	for (int t = 0; t < nthd; ++t)
	{
		int begin = t * n / nthd;
		int end = (t + 1) * n / nthd;

		for (int i = begin; i < end; ++i)
		{
			double temp = 0.0;
			for (int j = Up[i]; j< Up[i + 1]; ++j)
				temp += zv[2 * Ui[j]] * Uv[j];
			wv[i] = temp;
		}

		for (int k = 0; k < iteration; ++k)
		{
			if (k == iteration - 1)
			{
				double omega = 0.0;

				if (k & 1)
				{
					for (int i = begin; i < end; ++i)
						omega += zv[1 + 2 * i] * zv[1 + 2 * i];
					omega = 1.0 / sqrt(omega);

					for (int i = begin; i < end; ++i)
					{
						double temp = wv[i];
						for (int j = Up[i]; j < Up[i + 1]; ++j)
							temp += zv[1 + 2 * Ui[j]] * Uv[j];
						zv[2 * i] = (Drcpv[i] * temp + zv[1 + 2 * i]) * omega;
					}
				}
				else
				{
					for (int i = begin; i < end; ++i)
						omega += zv[2 * i] * zv[2 * i];
					omega = 1.0 / sqrt(omega);

					for (int i = begin; i < end; ++i)
					{
						double temp = wv[i];
						for (int j = Lp[i]; j < Lp[i + 1]; ++j)
							temp += zv[2 * Li[j]] * Lv[j];
						zv[1 + 2 * i] = (Drcpv[i] * temp + zv[2 * i]) * omega;
					}
				}

				double rtz = 0.0;
				for (int i = begin; i < end; ++i)
					rtz += zv[1 + 2 * i] * zv[2 * i];
				lambda[t] = 1.1 * omega * rtz;
			}
			else
			{
				double omega = 0.0;
				
				if (k & 1)
				{
					for (int i = begin; i < end; ++i)
						omega += zv[1 + 2 * i] * zv[1 + 2 * i];
					omega = 1.0 / sqrt(omega);

					for (int i = end - 1; i >= begin; --i)
					{
						double temp1 = 0.0;
						double temp2 = wv[i];
						for (int j = Up[i + 1] - 1; j >= Up[i]; --j)
						{
							temp1 += zv[2 * Ui[j]] * Uv[j];
							temp2 += zv[1 + 2 * Ui[j]] * Uv[j];
						}
						zv[2 * i] = (Drcpv[i] * temp2 + zv[1 + 2 * i]) * omega;
						wv[i] = temp1;
					}
				}
				else
				{
					for (int i = begin; i < end; ++i)
						omega += zv[2 * i] * zv[2 * i];
					omega = 1.0 / sqrt(omega);

					for (int i = begin; i < end; ++i)
					{
						double temp1 = wv[i];
						double temp2 = 0.0;
						for (int j = Lp[i]; j < Lp[i + 1]; ++j)
						{
							temp1 += zv[2 * Li[j]] * Lv[j];
							temp2 += zv[1 + 2 * Li[j]] * Lv[j];
						}
						zv[1 + 2 * i] = (Drcpv[i] * temp1 + zv[2 * i]) * omega;
						wv[i] = temp2;
					}
				}
			}
		}
	}
}

void ParCSRSmootherChebyshevXLocal::Pre_and_Resid(const ParCSRMatrix& A, const ParVector& b, const ParVector& x, const ParVector& r, int step, bool x0zero) const
{
	int n = A.local.size[0];

	int* Lp = L.rowptr;
	int* Li = L.colind;
	double* Lv = L.values;
	int* Up = U.rowptr;
	int* Ui = U.colind;
	double* Uv = U.values;
	int* Ep = E.rowptr;
	int* Ei = E.colind;
	double* Ev = E.values;
	int* Extp = A.exter.rowptr;
	int* Exti = A.exter.colind;
	double* Extv = A.exter.values;
	double* Dv = D.values;
	double* Drcpv = D_recip.values;
	double* xv = x.local.values;
	double* bv = b.local.values;
	double* rv = r.local.values;
	double* wv = w.local.values;
	double* zv = z.local.values;
	double* recvxv = A.recvx.values;

	if (!x0zero)
	{
		A.ExchangeHalo(x);
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		for (int i = 0; i < n; ++i)
		{
			double temp = bv[i];
			for (int j = Extp[i]; j < Extp[i + 1]; ++j)
				temp -= recvxv[Exti[j]] * Extv[j];
			for (int j = Ep[i]; j < Ep[i + 1]; ++j)
				temp -= xv[Ei[j]] * Ev[j];
			rv[i] = temp;
		}
	}
	else
		r.Copy(b);

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
	for (int t = 0; t < nthd; ++t)
	{
		int begin = t * n / nthd;
		int end = (t + 1) * n / nthd;

		double alpha = lambda[t];
		double beta  = lambda[t] * EigenRatio;

		double theta, delta, sigma, rho, rho1;

		theta = 2.0 / (beta + alpha);
		delta = 2.0 / (beta - alpha);
		sigma = delta / theta;

		if (step > 1)
		{
			if (!x0zero)
			{
				for (int i = begin; i < end; ++i)
				{
					double temp = 0.0;
					for (int j = Up[i]; j < Up[i + 1]; ++j)
						temp -= xv[Ui[j]] * Uv[j];
					wv[i] = temp;
				}

				for (int i = begin; i < end; ++i)
					zv[2 * i] = xv[i];

				for (int i = begin; i < end; ++i)
				{
					double temp1 = rv[i] + wv[i];
					double temp2 = rv[i];
					for (int j = Lp[i]; j < Lp[i + 1]; ++j)
					{
						temp1 -= zv[2 * Li[j]] * Lv[j];
						temp2 -= zv[1 + 2 * Li[j]] * Lv[j];
					}
					zv[1 + 2 * i] = temp1 * Drcpv[i] * theta + (1 - theta) * zv[2 * i];
					wv[i] = temp2;
				}
			}
			else
			{
				for (int i = begin; i < end; ++i)
				{
					zv[2 * i] = 0.0;
					zv[1 + 2 * i] = rv[i] * Drcpv[i] * theta;
				}

				for (int i = begin; i < end; ++i)
				{
					double temp = rv[i];
					for (int j = Lp[i]; j < Lp[i + 1]; ++j)
						temp -= zv[1 + 2 * Li[j]] * Lv[j];
					wv[i] = temp;
				}
			}

			rho1 = 1.0 / sigma;

			int k = 1;

			while (1)
			{
				double c1, c2;
				
				rho = 1.0 / (2.0 * sigma - rho1);

				c1 = rho * delta * 2.0;
				c2 = rho * rho1;

				if (++k == step)
				{
					for (int i = end - 1; i >= begin; --i)
					{
						double temp1 = 0.0;
						double temp2 = wv[i];
						for (int j = Up[i + 1] - 1; j >= Up[i]; --j)
						{
							temp1 -= zv[2 * Ui[j]] * Uv[j];
							temp2 -= zv[1 + 2 * Ui[j]] * Uv[j];
						}
						zv[2 * i] = (c2 - c1 + 1.0) * zv[1 + 2 * i] + c1 * (temp2 * Drcpv[i]) - c2 * zv[2 * i];
						wv[i] = temp1;
					}

					for (int i = begin; i < end; ++i)
						xv[i] = zv[2 * i];

					for (int i = begin; i < end; ++i)
					{
						double temp = wv[i];
						for (int j = Lp[i]; j < Lp[i + 1]; ++j)
							temp -= xv[Li[j]] * Lv[j];
						rv[i] = temp - Dv[i] * xv[i];
					}

					break;
				}
				else
				{
					for (int i = end - 1; i >= begin; --i)
					{
						double temp1 = 0.0;
						double temp2 = wv[i];
						for (int j = Up[i + 1] - 1; j >= Up[i]; --j)
						{
							temp1 -= zv[2 * Ui[j]] * Uv[j];
							temp2 -= zv[1 + 2 * Ui[j]] * Uv[j];
						}
						zv[2 * i] = (c2 - c1 + 1.0) * zv[1 + 2 * i] + c1 * (temp2 * Drcpv[i]) - c2 * zv[2 * i];
						wv[i] = temp1;
					}
				}

				rho1 = rho;

				c1 = rho * delta * 2.0;
				c2 = rho * rho1;

				if (++k == step)
				{
					for (int i = begin; i < end; ++i)
					{
						double temp1 = rv[i] + wv[i];
						double temp2 = 0.0;
						for (int j = Lp[i]; j < Lp[i + 1]; ++j)
						{
							temp1 -= zv[2 * Li[j]] * Lv[j];
							temp2 -= zv[1 + 2 * Li[j]] * Lv[j];
						}
						zv[1 + 2 * i] = (c2 - c1 + 1.0) * zv[2 * i] + c1 * (temp1 * Drcpv[i]) - c2 * zv[1 + 2 * i];
						wv[i] = temp2;
					}

					for (int i = begin; i < end; ++i)
						xv[i] = zv[1 + 2 * i];

					for (int i = begin; i < end; ++i)
					{
						double temp = wv[i];
						for (int j = Up[i]; j < Up[i + 1]; ++j)
							temp -= xv[Ui[j]] * Uv[j];
						rv[i] = temp - Dv[i] * xv[i];
					}

					break;
				}
				else
				{
					for (int i = begin; i < end; ++i)
					{
						double temp1 = rv[i] + wv[i];
						double temp2 = rv[i];
						for (int j = Lp[i]; j < Lp[i + 1]; ++j)
						{
							temp1 -= zv[2 * Li[j]] * Lv[j];
							temp2 -= zv[1 + 2 * Li[j]] * Lv[j];
						}
						zv[1 + 2 * i] = (c2 - c1 + 1.0) * zv[2 * i] + c1 * (temp1 * Drcpv[i]) - c2 * zv[1 + 2 * i];
						wv[i] = temp2;
					}
				}

				rho1 = rho;
			}
		}
		else
		{
			if (!x0zero)
			{
				for (int i = begin; i < end; ++i)
				{
					double temp = 0.0;
					for (int j = Up[i]; j < Up[i + 1]; ++j)
						temp -= xv[Ui[j]] * Uv[j];
					wv[i] = temp;
				}

				for (int i = begin; i < end; ++i)
					zv[2 * i] = xv[i];

				for (int i = begin; i < end; ++i)
				{
					double temp1 = rv[i] + wv[i];
					double temp2 = 0.0;
					for (int j = Lp[i]; j < Lp[i + 1]; ++j)
					{
						temp1 -= zv[2 * Li[j]] * Lv[j];
						temp2 -= zv[1 + 2 * Li[j]] * Lv[j];
					}
					zv[1 + 2 * i] = temp1 * Drcpv[i] * theta + (1 - theta) * zv[2 * i];
					wv[i] = temp2;
				}
				
				for (int i = begin; i < end; ++i)
					xv[i] = zv[1 + 2 * i];

				for (int i = begin; i < end; ++i)
				{
					double temp = wv[i];
					for (int j = Up[i]; j < Up[i + 1]; ++j)
						temp -= xv[Ui[j]] * Uv[j];
					rv[i] = temp - Dv[i] * xv[i];
				}
			}
			else
			{
				for (int i = begin; i < end; ++i)
					xv[i] = rv[i] * Drcpv[i] * theta;
				
				for (int i = begin; i < end; ++i)
				{
					double temp = 0.0;
					for (int j = Lp[i]; j < Lp[i + 1]; ++j)
						temp -= xv[Li[j]] * Lv[j];
					for (int j = Up[i]; j < Up[i + 1]; ++j)
						temp -= xv[Ui[j]] * Uv[j];
					rv[i] = temp - Dv[i] * xv[i];
				}
			}
		}
	}

	A.ExchangeHalo(x);
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
	for (int i = 0; i < n; ++i)
	{
		double temp = bv[i];
		for (int j = Extp[i]; j < Extp[i + 1]; ++j)
			temp -= recvxv[Exti[j]] * Extv[j];
		for (int j = Ep[i]; j < Ep[i + 1]; ++j)
			temp -= xv[Ei[j]] * Ev[j];
		rv[i] += temp;
	}
}

void ParCSRSmootherChebyshevXLocal::operator()(const ParCSRMatrix& A, const ParVector& b, const ParVector& x, int step, bool x0zero) const
{
	int n = A.local.size[0];

	int* Lp = L.rowptr;
	int* Li = L.colind;
	double* Lv = L.values;
	int* Up = U.rowptr;
	int* Ui = U.colind;
	double* Uv = U.values;
	int* Ep = E.rowptr;
	int* Ei = E.colind;
	double* Ev = E.values;
	int* Extp = A.exter.rowptr;
	int* Exti = A.exter.colind;
	double* Extv = A.exter.values;
	double* Drcpv = D_recip.values;
	double* xv = x.local.values;
	double* bv = b.local.values;
	double* rv = r.local.values;
	double* wv = w.local.values;
	double* zv = z.local.values;
	double* recvxv = A.recvx.values;

	if (!x0zero)
	{
		A.ExchangeHalo(x);
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		for (int i = 0; i < n; ++i)
		{
			double temp = bv[i];
			for (int j = Extp[i]; j < Extp[i + 1]; ++j)
				temp -= recvxv[Exti[j]] * Extv[j];
			for (int j = Ep[i]; j < Ep[i + 1]; ++j)
				temp -= xv[Ei[j]] * Ev[j];
			rv[i] = temp;
		}
	}
	else
		r.Copy(b);

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
	for (int t = 0; t < nthd; ++t)
	{
		int begin = t * n / nthd;
		int end = (t + 1) * n / nthd;

		double alpha = lambda[t];
		double beta  = lambda[t] * EigenRatio;

		double theta, delta, sigma, rho, rho1;

		theta = 2.0 / (beta + alpha);
		delta = 2.0 / (beta - alpha);
		sigma = delta / theta;

		if (step > 1)
		{
			if (!x0zero)
			{
				for (int i = begin; i < end; ++i)
				{
					double temp = 0.0;
					for (int j = Up[i]; j < Up[i + 1]; ++j)
						temp -= xv[Ui[j]] * Uv[j];
					wv[i] = temp;
				}
				
				for (int i = begin; i < end; ++i)
					zv[2 * i] = xv[i];

				for (int i = begin; i < end; ++i)
				{
					double temp1 = rv[i] + wv[i];
					double temp2 = rv[i];
					for (int j = Lp[i]; j < Lp[i + 1]; ++j)
					{
						temp1 -= zv[2 * Li[j]] * Lv[j];
						temp2 -= zv[1 + 2 * Li[j]] * Lv[j];
					}
					zv[1 + 2 * i] = temp1 * Drcpv[i] * theta + (1 - theta) * zv[2 * i];
					wv[i] = temp2;
				}
			}
			else
			{
				for (int i = begin; i < end; ++i)
				{
					zv[2 * i] = 0.0;
					zv[1 + 2 * i] = rv[i] * Drcpv[i] * theta;
				}

				for (int i = begin; i < end; ++i)
				{
					double temp = rv[i];
					for (int j = Lp[i]; j < Lp[i + 1]; ++j)
						temp -= zv[1 + 2 * Li[j]] * Lv[j];
					wv[i] = temp;
				}
			}

			rho1 = 1.0 / sigma;

			int k = 1;

			while (1)
			{
				double c1, c2;
				
				rho = 1.0 / (2.0 * sigma - rho1);

				c1 = rho * delta * 2.0;
				c2 = rho * rho1;

				if (++k == step)
				{
					for (int i = begin; i < end; ++i)
					{
						double temp = wv[i];
						for (int j = Up[i]; j < Up[i + 1]; ++j)
							temp -= zv[1 + 2 * Ui[j]] * Uv[j];
						xv[i] = (c2 - c1 + 1.0) * zv[1 + 2 * i] + c1 * temp * Drcpv[i] - c2 * zv[2 * i];
					}

					break;
				}
				else
				{
					for (int i = end - 1; i >= begin; --i)
					{
						double temp1 = 0.0;
						double temp2 = wv[i];
						for (int j = Up[i + 1] - 1; j >= Up[i]; --j)
						{
							temp1 -= zv[2 * Ui[j]] * Uv[j];
							temp2 -= zv[1 + 2 * Ui[j]] * Uv[j];
						}
						zv[2 * i] = (c2 - c1 + 1.0) * zv[1 + 2 * i] + c1 * (temp2 * Drcpv[i]) - c2 * zv[2 * i];
						wv[i] = temp1;
					}
				}

				rho1 = rho;

				c1 = rho * delta * 2.0;
				c2 = rho * rho1;

				if (++k == step)
				{
					for (int i = begin; i < end; ++i)
					{
						double temp = rv[i] + wv[i];
						for (int j = Lp[i]; j < Lp[i + 1]; ++j)
							temp -= zv[2 * Li[j]] * Lv[j];
						xv[i] = (c2 - c1 + 1.0) * zv[2 * i] + c1 * (temp * Drcpv[i]) - c2 * zv[1 + 2 * i];
					}

					break;
				}
				else
				{
					for (int i = begin; i < end; ++i)
					{
						double temp1 = rv[i] + wv[i];
						double temp2 = rv[i];
						for (int j = Lp[i]; j < Lp[i + 1]; ++j)
						{
							temp1 -= zv[2 * Li[j]] * Lv[j];
							temp2 -= zv[1 + 2 * Li[j]] * Lv[j];
						}
						zv[1 + 2 * i] = (c2 - c1 + 1.0) * zv[2 * i] + c1 * (temp1 * Drcpv[i]) - c2 * zv[1 + 2 * i];
						wv[i] = temp2;
					}
				}

				rho1 = rho;
			}
		}
		else
		{
			if (!x0zero)
			{
				for (int i = begin; i < end; ++i)
				{
					double temp = rv[i];
					for (int j = Lp[i]; j < Lp[i + 1]; ++j)
						temp -= xv[Li[j]] * Lv[j];
					wv[i] = temp;
				}

				for (int i = begin; i < end; ++i)
				{
					double temp = wv[i];
					for (int j = Up[i]; j < Up[i + 1]; ++j)
						temp -= xv[Ui[j]] * Uv[j];
					xv[i] = temp * Drcpv[i] * theta + (1 - theta) * xv[i];
				}
			}
			else
			{
				for (int i = begin; i < end; ++i)
					xv[i] = rv[i] * Drcpv[i] * theta;
			}
		}
	}
}

ParCSRSmootherChebyshevX::ParCSRSmootherChebyshevX(double eigen_ratio)
	: nthd(0),
	lambda(1.0),
	EigenRatio(eigen_ratio)
{
}

void ParCSRSmootherChebyshevX::Setup(const ParCSRMatrix& A, int REUSE)
{
	int n = A.local.size[0];
	int* Ap = A.local.rowptr;
	int* Ai = A.local.colind;
	double* Av = A.local.values;
	
	if (!REUSE)
	{
		r.comm = A.comm;
		w.comm = A.comm;
		z.comm = A.comm;
		r.Resize(n);
		w.Resize(n);
		z.Resize(2 * n);
		D.Resize(n);
		D_recip.Resize(n);
		
		nthd = 1;
#ifdef USE_ONED_PARTITION
		nthd = omp_get_max_threads();
#endif

		double* Dv = D.values;
		double* Drcpv = D_recip.values;

		int* Lp = new int[n + 1];
		int* Up = new int[n + 1];
		int* Ep = new int[n + 1];

		Lp[0] = 0;
		Up[0] = 0;
		Ep[0] = 0;
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		for (int t = 0; t < nthd; ++t)
		{
			int begin = t * n / nthd;
			int end = (t + 1) * n / nthd;

			for (int i = begin; i < end; ++i)
			{
				int cntl = 0;
				int cntu = 0;
				int cnte = 0;

				for (int j = Ap[i]; j < Ap[i + 1]; ++j)
				{
					int jcol = Ai[j];

					if (jcol >= begin && jcol < i) 
						++cntl;
					else if (jcol < end && jcol > i)
						++cntu;
					else if (jcol != i)
						++cnte;
				}

				Lp[i + 1] = cntl;
				Up[i + 1] = cntu;
				Ep[i + 1] = cnte;
			}
		}

		for (int i = 0; i < n;++i)
			Lp[i + 1] += Lp[i];
		for (int i = 0; i < n;++i)
			Up[i + 1] += Up[i];
		for (int i = 0; i < n;++i)
			Ep[i + 1] += Ep[i];

		int* Li = new int[Lp[n]];
		double* Lv = new double[Lp[n]];
		int* Ui = new int[Up[n]];
		double* Uv = new double[Up[n]];
		int* Ei = new int[Ep[n]];
		double* Ev = new double[Ep[n]];

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		for (int t = 0; t < nthd; ++t)
		{
			int begin = t * n / nthd;
			int end = (t + 1) * n / nthd;

			for (int i = begin; i < end; ++i)
			{
				for (int j = Ap[i], k = Lp[i], r = Up[i], s = Ep[i]; j < Ap[i + 1]; ++j)
				{
					int jcol = Ai[j];
					double jval = Av[j];

					if (jcol >= begin && jcol < i) 
					{
						Li[k] = jcol;
						Lv[k++] = jval;
					}
					else if (jcol < end && jcol > i)
					{
						Ui[r] = jcol;
						Uv[r++] = jval;
					}
					else if (jcol == i)
					{
						Dv[i] = jval;
						Drcpv[i] = 1.0 / jval;
					}
					else
					{
						Ei[s] = jcol;
						Ev[s++] = jval;
					}
				}
			}
		}

		L.size[0] = n;
		L.size[1] = n;
		L.rowptr = Lp;
		L.colind = Li;
		L.values = Lv;
		U.size[0] = n;
		U.size[1] = n;
		U.rowptr = Up;
		U.colind = Ui;
		U.values = Uv;
		E.size[0] = n;
		E.size[1] = n;
		E.rowptr = Ep;
		E.colind = Ei;
		E.values = Ev;
	}
	else
	{
		int* Lp = L.rowptr;
		int* Li = L.colind;
		double* Lv = L.values;
		int* Up = U.rowptr;
		int* Ui = U.colind;
		double* Uv = U.values;
		int* Ep = E.rowptr;
		int* Ei = E.colind;
		double* Ev = E.values;
		double* Dv = D.values;
		double* Drcpv = D_recip.values;
		
		int* w = new int[n];

		for (int i = 0; i < n; ++i)
			w[i] = -1;

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		for (int t = 0; t < nthd; ++t)
		{
			int begin = t * n / nthd;
			int end = (t + 1) * n / nthd;

			for (int i = begin; i < end; ++i)
			{
				int j0 = Ap[i];

				for (int j = Ap[i]; j < Ap[i + 1]; ++j)
					w[Ai[j]] = j;

				if (w[i] >= j0)
				{
					Dv[i] = Av[w[i]];
					Drcpv[i] = 1.0 / Av[w[i]];
				}

				for (int j = Lp[i]; j < Lp[i + 1]; ++j)
					if (w[Li[j]] >= j0) Lv[j] = Av[w[Li[j]]];
				for (int j = Up[i]; j < Up[i + 1]; ++j)
					if (w[Ui[j]] >= j0) Uv[j] = Av[w[Ui[j]]];
				for (int j = Ep[i]; j < Ep[i + 1]; ++j)
					if (w[Ei[j]] >= j0) Ev[j] = Av[w[Ei[j]]];
			}
		}
		
		delete[] w;	
	}

	int* Lp = L.rowptr;
	int* Li = L.colind;
	double* Lv = L.values;
	int* Up = U.rowptr;
	int* Ui = U.colind;
	double* Uv = U.values;
	double* Drcpv = D_recip.values;
	int* Ep = E.rowptr;
	int* Ei = E.colind;
	double* Ev = E.values;
	int* Extp = A.exter.rowptr;
	int* Exti = A.exter.colind;
	double* Extv = A.exter.values;
	double* wv = w.local.values;
	double* zv = z.local.values;

	MPI_Comm comm = A.comm;
	int nnb = A.nnb;
	int* nbrank = A.nbrank;
	int* recvptr = A.recvptr;
	int* sendptr = A.sendptr;
	int* sendind = A.sendind;
	double* sendbuf = A.sendbuf;
	double* recvxv = A.recvx.values;

	MPI_Request* recvreq = new MPI_Request[nnb];
	MPI_Request* sendreq = new MPI_Request[nnb];
	MPI_Status status;

	int comm_rank;
	MPI_Comm_rank(comm, &comm_rank);

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel
#endif
	{
		int ithd = 0;
#ifdef YHAMG_USE_OPENMP
		ithd = omp_get_thread_num();
#endif
		uint64_t k1 = ithd + 1;
		uint64_t k2 = comm_rank + 1;
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
		for (int i = 0; i < n; ++i)
			zv[2 * i] = (double)(xorshift128plus(k1, k2) & 4294967295U) / 4294967295U;
	}

	int iteration = 10;

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
	for (int i = 0; i < n; ++i)
	{
		double temp = 0.0;
		for (int j = Up[i]; j< Up[i + 1]; ++j)
			temp += zv[2 * Ui[j]] * Uv[j];
		wv[i] = temp;
	}

	for (int r = 0; r < nnb; ++r)
		if (recvptr[r + 1] > recvptr[r])
			MPI_Irecv(recvxv + recvptr[r], recvptr[r + 1] - recvptr[r], MPI_DOUBLE, nbrank[r], MPI_TAG, comm, recvreq + r);

	for (int r = 0; r < nnb; ++r)
	{
		if (sendptr[r + 1] > sendptr[r])
		{
			for (int i = sendptr[r]; i < sendptr[r + 1]; ++i)
				sendbuf[i] = zv[2 * sendind[i]];
			MPI_Isend(sendbuf + sendptr[r], sendptr[r + 1] - sendptr[r], MPI_DOUBLE, nbrank[r], MPI_TAG, comm, sendreq + r);
		}
	}

	for (int r = 0; r < nnb; ++r)
		if (recvptr[r + 1] > recvptr[r])
			MPI_Wait(recvreq + r, &status);

	for (int r = 0; r < nnb; ++r)
		if (sendptr[r + 1] > sendptr[r])
			MPI_Wait(sendreq + r, &status);

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
	for (int i = 0; i < n; ++i)
	{
		double temp = wv[i];
		for (int j = Extp[i]; j < Extp[i + 1]; ++j)
			temp -= recvxv[Exti[j]] * Extv[j];
		for (int j = Ep[i]; j < Ep[i + 1]; ++j)
			temp -= zv[2 * Ei[j]] * Ev[j];
		wv[i] = temp;
	}

	for (int k = 0; k < iteration; ++k)
	{
		if (k == iteration - 1)
		{
			double omega = 0.0;

			if (k & 1)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for reduction(+:omega)
#endif
				for (int i = 0; i < n; ++i)
					omega += zv[1 + 2 * i] * zv[1 + 2 * i];

				MPI_Allreduce(MPI_IN_PLACE, &omega, 1, MPI_DOUBLE, MPI_SUM, comm);
				omega = 1.0 / sqrt(omega);

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
				for (int i = 0; i < n; ++i)
				{
					double temp = wv[i];
					for (int j = Up[i]; j < Up[i + 1]; ++j)
						temp += zv[1 + 2 * Ui[j]] * Uv[j];
					zv[2 * i] = (Drcpv[i] * temp + zv[1 + 2 * i]) * omega;
				}
			}
			else
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for reduction(+:omega)
#endif
				for (int i = 0; i < n; ++i)
					omega += zv[2 * i] * zv[2 * i];

				MPI_Allreduce(MPI_IN_PLACE, &omega, 1, MPI_DOUBLE, MPI_SUM, comm);
				omega = 1.0 / sqrt(omega);

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
				for (int i = 0; i < n; ++i)
				{
					double temp = wv[i];
					for (int j = Lp[i]; j < Lp[i + 1]; ++j)
						temp += zv[2 * Li[j]] * Lv[j];
					zv[1 + 2 * i] = (Drcpv[i] * temp + zv[2 * i]) * omega;
				}
			}

			double rtz = 0.0;
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for reduction(+:rtz)
#endif
			for (int i = 0; i < n; ++i)
				rtz += zv[1 + 2 * i] * zv[2 * i];

			MPI_Allreduce(MPI_IN_PLACE, &rtz, 1, MPI_DOUBLE, MPI_SUM, comm);
			lambda = 1.1 * omega * rtz;
		}
		else
		{
			double omega = 0.0;

			if (k & 1)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for reduction(+:omega)
#endif
				for (int i = 0; i < n; ++i)
					omega += zv[1 + 2 * i] * zv[1 + 2 * i];

				MPI_Allreduce(MPI_IN_PLACE, &omega, 1, MPI_DOUBLE, MPI_SUM, comm);
				omega = 1.0 / sqrt(omega);

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				for (int t = 0; t < nthd; ++t)
				{
					int begin = t * n / nthd;
					int end = (t + 1) * n / nthd;

					for (int i = end - 1; i >= begin; --i)
					{
						double temp1 = 0.0;
						double temp2 = wv[i];
						for (int j = Up[i + 1] - 1; j >= Up[i]; --j)
						{
							temp1 += zv[2 * Ui[j]] * Uv[j];
							temp2 += zv[1 + 2 * Ui[j]] * Uv[j];
						}
						zv[2 * i] = (Drcpv[i] * temp2 + zv[1 + 2 * i]) * omega;
						wv[i] = temp1;
					}
				}

				for (int r = 0; r < nnb; ++r)
					if (recvptr[r + 1] > recvptr[r])
						MPI_Irecv(recvxv + recvptr[r], recvptr[r + 1] - recvptr[r], MPI_DOUBLE, nbrank[r], MPI_TAG, comm, recvreq + r);

				for (int r = 0; r < nnb; ++r)
				{
					if (sendptr[r + 1] > sendptr[r])
					{
						for (int i = sendptr[r]; i < sendptr[r + 1]; ++i)
							sendbuf[i] = zv[2 * sendind[i]];
						MPI_Isend(sendbuf + sendptr[r], sendptr[r + 1] - sendptr[r], MPI_DOUBLE, nbrank[r], MPI_TAG, comm, sendreq + r);
					}
				}

				for (int r = 0; r < nnb; ++r)
					if (recvptr[r + 1] > recvptr[r])
						MPI_Wait(recvreq + r, &status);

				for (int r = 0; r < nnb; ++r)
					if (sendptr[r + 1] > sendptr[r])
						MPI_Wait(sendreq + r, &status);

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
				for (int i = 0; i < n; ++i)
				{
					double temp = wv[i];
					for (int j = Extp[i]; j < Extp[i + 1]; ++j)
						temp -= recvxv[Exti[j]] * Extv[j];
					for (int j = Ep[i]; j < Ep[i + 1]; ++j)
						temp -= zv[2 * Ei[j]] * Ev[j];
					wv[i] = temp;
				}
			}
			else
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for reduction(+:omega)
#endif
				for (int i = 0; i < n; ++i)
					omega += zv[2 * i] * zv[2 * i];

				MPI_Allreduce(MPI_IN_PLACE, &omega, 1, MPI_DOUBLE, MPI_SUM, comm);
				omega = 1.0 / sqrt(omega);
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				for (int t = 0; t < nthd; ++t)
				{
					int begin = t * n / nthd;
					int end = (t + 1) * n / nthd;

					for (int i = begin; i < end; ++i)
					{
						double temp1 = wv[i];
						double temp2 = 0.0;
						for (int j = Lp[i]; j < Lp[i + 1]; ++j)
						{
							temp1 += zv[2 * Li[j]] * Lv[j];
							temp2 += zv[1 + 2 * Li[j]] * Lv[j];
						}
						zv[1 + 2 * i] = (Drcpv[i] * temp1 + zv[2 * i]) * omega;
						wv[i] = temp2;
					}
				}

				for (int r = 0; r < nnb; ++r)
					if (recvptr[r + 1] > recvptr[r])
						MPI_Irecv(recvxv + recvptr[r], recvptr[r + 1] - recvptr[r], MPI_DOUBLE, nbrank[r], MPI_TAG, comm, recvreq + r);

				for (int r = 0; r < nnb; ++r)
				{
					if (sendptr[r + 1] > sendptr[r])
					{
						for (int i = sendptr[r]; i < sendptr[r + 1]; ++i)
							sendbuf[i] = zv[1 + 2 * sendind[i]];
						MPI_Isend(sendbuf + sendptr[r], sendptr[r + 1] - sendptr[r], MPI_DOUBLE, nbrank[r], MPI_TAG, comm, sendreq + r);
					}
				}

				for (int r = 0; r < nnb; ++r)
					if (recvptr[r + 1] > recvptr[r])
						MPI_Wait(recvreq + r, &status);

				for (int r = 0; r < nnb; ++r)
					if (sendptr[r + 1] > sendptr[r])
						MPI_Wait(sendreq + r, &status);

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
				for (int i = 0; i < n; ++i)
				{
					double temp = wv[i];
					for (int j = Extp[i]; j < Extp[i + 1]; ++j)
						temp -= recvxv[Exti[j]] * Extv[j];
					for (int j = Ep[i]; j < Ep[i + 1]; ++j)
						temp -= zv[1 + 2 * Ei[j]] * Ev[j];
					wv[i] = temp;
				}
			}
		}
	}

	delete[] recvreq;
	delete[] sendreq;
}

void ParCSRSmootherChebyshevX::Pre_and_Resid(const ParCSRMatrix& A, const ParVector& b, const ParVector& x, const ParVector& r, int step, bool x0zero) const
{
	int n = A.local.size[0];

	int* Lp = L.rowptr;
	int* Li = L.colind;
	double* Lv = L.values;
	int* Up = U.rowptr;
	int* Ui = U.colind;
	double* Uv = U.values;
	int* Ep = E.rowptr;
	int* Ei = E.colind;
	double* Ev = E.values;
	int* Extp = A.exter.rowptr;
	int* Exti = A.exter.colind;
	double* Extv = A.exter.values;
	double* Dv = D.values;
	double* Drcpv = D_recip.values;
	double* xv = x.local.values;
	double* bv = b.local.values;
	double* rv = r.local.values;
	double* wv = w.local.values;
	double* zv = z.local.values;
	double* recvxv = A.recvx.values;

	MPI_Comm comm = A.comm;
	int nnb = A.nnb;
	int* nbrank = A.nbrank;
	int* recvptr = A.recvptr;
	int* sendptr = A.sendptr;
	int* sendind = A.sendind;
	double* sendbuf = A.sendbuf;

	MPI_Request* recvreq = new MPI_Request[nnb];
	MPI_Request* sendreq = new MPI_Request[nnb];
	MPI_Status status;

	double alpha = lambda;
	double beta  = lambda * EigenRatio;

	double theta, delta, sigma, rho, rho1;

	theta = 2.0 / (beta + alpha);
	delta = 2.0 / (beta - alpha);
	sigma = delta / theta;

	if (step > 1)
	{
		if (!x0zero)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				double temp = 0.0;
				for (int j = Up[i]; j < Up[i + 1]; ++j)
					temp -= xv[Ui[j]] * Uv[j];
				wv[i] = temp;
			}

			A.ExchangeHalo(x);
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				double temp = wv[i];
				for (int j = Extp[i]; j < Extp[i + 1]; ++j)
					temp -= recvxv[Exti[j]] * Extv[j];
				for (int j = Ep[i]; j < Ep[i + 1]; ++j)
					temp -= xv[Ei[j]] * Ev[j];
				wv[i] = temp;
			}

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			for (int i = 0; i < n; ++i)
				zv[2 * i] = xv[i];
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			for (int t = 0; t < nthd; ++t)
			{
				int begin = t * n / nthd;
				int end = (t + 1) * n / nthd;

				for (int i = begin; i < end; ++i)
				{
					double temp1 = bv[i] + wv[i];
					double temp2 = bv[i];
					for (int j = Lp[i]; j < Lp[i + 1]; ++j)
					{
						temp1 -= zv[2 * Li[j]] * Lv[j];
						temp2 -= zv[1 + 2 * Li[j]] * Lv[j];
					}
					zv[1 + 2 * i] = temp1 * Drcpv[i] * theta + (1 - theta) * zv[2 * i];
					wv[i] = temp2;
				}
			}
		}
		else
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			for (int i = 0; i < n; ++i)
			{
				zv[2 * i] = 0.0;
				zv[1 + 2 * i] = bv[i] * Drcpv[i] * theta;
			}

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				double temp = bv[i];
				for (int j = Lp[i]; j < Lp[i + 1]; ++j)
					temp -= zv[1 + 2 * Li[j]] * Lv[j];
				wv[i] = temp;
			}
		}

		for (int r = 0; r < nnb; ++r)
			if (recvptr[r + 1] > recvptr[r])
				MPI_Irecv(recvxv + recvptr[r], recvptr[r + 1] - recvptr[r], MPI_DOUBLE, nbrank[r], MPI_TAG, comm, recvreq + r);

		for (int r = 0; r < nnb; ++r)
		{
			if (sendptr[r + 1] > sendptr[r])
			{
				for (int i = sendptr[r]; i < sendptr[r + 1]; ++i)
					sendbuf[i] = zv[1 + 2 * sendind[i]];
				MPI_Isend(sendbuf + sendptr[r], sendptr[r + 1] - sendptr[r], MPI_DOUBLE, nbrank[r], MPI_TAG, comm, sendreq + r);
			}
		}

		for (int r = 0; r < nnb; ++r)
			if (recvptr[r + 1] > recvptr[r])
				MPI_Wait(recvreq + r, &status);

		for (int r = 0; r < nnb; ++r)
			if (sendptr[r + 1] > sendptr[r])
				MPI_Wait(sendreq + r, &status);

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		for (int i = 0; i < n; ++i)
		{
			double temp = wv[i];
			for (int j = Extp[i]; j < Extp[i + 1]; ++j)
				temp -= recvxv[Exti[j]] * Extv[j];
			for (int j = Ep[i]; j < Ep[i + 1]; ++j)
				temp -= zv[1 + 2 * Ei[j]] * Ev[j];
			wv[i] = temp;
		}

		rho1 = 1.0 / sigma;

		int k = 1;

		while (1)
		{
			double c1, c2;
			
			rho = 1.0 / (2.0 * sigma - rho1);

			c1 = rho * delta * 2.0;
			c2 = rho * rho1;

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			for (int t = 0; t < nthd; ++t)
			{
				int begin = t * n / nthd;
				int end = (t + 1) * n / nthd;

				for (int i = end - 1; i >= begin; --i)
				{
					double temp1 = 0.0;
					double temp2 = wv[i];
					for (int j = Up[i + 1] - 1; j >= Up[i]; --j)
					{
						temp1 -= zv[2 * Ui[j]] * Uv[j];
						temp2 -= zv[1 + 2 * Ui[j]] * Uv[j];
					}
					zv[2 * i] = (c2 - c1 + 1.0) * zv[1 + 2 * i] + c1 * (temp2 * Drcpv[i]) - c2 * zv[2 * i];
					wv[i] = temp1;
				}
			}

			for (int r = 0; r < nnb; ++r)
				if (recvptr[r + 1] > recvptr[r])
					MPI_Irecv(recvxv + recvptr[r], recvptr[r + 1] - recvptr[r], MPI_DOUBLE, nbrank[r], MPI_TAG, comm, recvreq + r);

			for (int r = 0; r < nnb; ++r)
			{
				if (sendptr[r + 1] > sendptr[r])
				{
					for (int i = sendptr[r]; i < sendptr[r + 1]; ++i)
						sendbuf[i] = zv[2 * sendind[i]];
					MPI_Isend(sendbuf + sendptr[r], sendptr[r + 1] - sendptr[r], MPI_DOUBLE, nbrank[r], MPI_TAG, comm, sendreq + r);
				}
			}

			for (int r = 0; r < nnb; ++r)
				if (recvptr[r + 1] > recvptr[r])
					MPI_Wait(recvreq + r, &status);

			for (int r = 0; r < nnb; ++r)
				if (sendptr[r + 1] > sendptr[r])
					MPI_Wait(sendreq + r, &status);

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				double temp = wv[i];
				for (int j = Extp[i]; j < Extp[i + 1]; ++j)
					temp -= recvxv[Exti[j]] * Extv[j];
				for (int j = Ep[i]; j < Ep[i + 1]; ++j)
					temp -= zv[2 * Ei[j]] * Ev[j];
				wv[i] = temp;
			}

			if (++k == step)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				for (int i = 0; i < n; ++i)
					xv[i] = zv[2 * i];

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
				for (int i = 0; i < n; ++i)
				{
					double temp = bv[i] + wv[i];
					for (int j = Lp[i]; j < Lp[i + 1]; ++j)
						temp -= xv[Li[j]] * Lv[j];
					rv[i] = temp - Dv[i] * xv[i];
				}

				break;
			}

			rho1 = rho;

			c1 = rho * delta * 2.0;
			c2 = rho * rho1;
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			for (int t = 0; t < nthd; ++t)
			{
				int begin = t * n / nthd;
				int end = (t + 1) * n / nthd;

				for (int i = begin; i < end; ++i)
				{
					double temp1 = bv[i] + wv[i];
					double temp2 = bv[i];
					for (int j = Lp[i]; j < Lp[i + 1]; ++j)
					{
						temp1 -= zv[2 * Li[j]] * Lv[j];
						temp2 -= zv[1 + 2 * Li[j]] * Lv[j];
					}
					zv[1 + 2 * i] = (c2 - c1 + 1.0) * zv[2 * i] + c1 * (temp1 * Drcpv[i]) - c2 * zv[1 + 2 * i];
					wv[i] = temp2;
				}
			}
			
			for (int r = 0; r < nnb; ++r)
				if (recvptr[r + 1] > recvptr[r])
					MPI_Irecv(recvxv + recvptr[r], recvptr[r + 1] - recvptr[r], MPI_DOUBLE, nbrank[r], MPI_TAG, comm, recvreq + r);

			for (int r = 0; r < nnb; ++r)
			{
				if (sendptr[r + 1] > sendptr[r])
				{
					for (int i = sendptr[r]; i < sendptr[r + 1]; ++i)
						sendbuf[i] = zv[1 + 2 * sendind[i]];
					MPI_Isend(sendbuf + sendptr[r], sendptr[r + 1] - sendptr[r], MPI_DOUBLE, nbrank[r], MPI_TAG, comm, sendreq + r);
				}
			}

			for (int r = 0; r < nnb; ++r)
				if (recvptr[r + 1] > recvptr[r])
					MPI_Wait(recvreq + r, &status);

			for (int r = 0; r < nnb; ++r)
				if (sendptr[r + 1] > sendptr[r])
					MPI_Wait(sendreq + r, &status);

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				double temp = wv[i];
				for (int j = Extp[i]; j < Extp[i + 1]; ++j)
					temp -= recvxv[Exti[j]] * Extv[j];
				for (int j = Ep[i]; j < Ep[i + 1]; ++j)
					temp -= zv[1 + 2 * Ei[j]] * Ev[j];
				wv[i] = temp;
			}

			if (++k == step)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				for (int i = 0; i < n; ++i)
					xv[i] = zv[1 + 2 * i];
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
				for (int i = 0; i < n; ++i)
				{
					double temp = wv[i];
					for (int j = Up[i]; j < Up[i + 1]; ++j)
						temp -= xv[Ui[j]] * Uv[j];
					rv[i] = temp - Dv[i] * xv[i];
				}

				break;
			}

			rho1 = rho;
		}
	}
	else
	{
		if (!x0zero)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				double temp = 0.0;
				for (int j = Up[i]; j < Up[i + 1]; ++j)
					temp -= xv[Ui[j]] * Uv[j];
				wv[i] = temp;
			}

			A.ExchangeHalo(x);
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				double temp = wv[i];
				for (int j = Extp[i]; j < Extp[i + 1]; ++j)
					temp -= recvxv[Exti[j]] * Extv[j];
				for (int j = Ep[i]; j < Ep[i + 1]; ++j)
					temp -= xv[Ei[j]] * Ev[j];
				wv[i] = temp;
			}

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			for (int i = 0; i < n; ++i)
				zv[2 * i] = xv[i];

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			for (int t = 0; t < nthd; ++t)
			{
				int begin = t * n / nthd;
				int end = (t + 1) * n / nthd;

				for (int i = begin; i < end; ++i)
				{
					double temp1 = bv[i] + wv[i];
					double temp2 = bv[i];
					for (int j = Lp[i]; j < Lp[i + 1]; ++j)
					{
						temp1 -= zv[2 * Li[j]] * Lv[j];
						temp2 -= zv[1 + 2 * Li[j]] * Lv[j];
					}
					zv[1 + 2 * i] = temp1 * Drcpv[i] * theta + (1 - theta) * zv[2 * i];
					wv[i] = temp2;
				}
			}

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			for (int i = 0; i < n; ++i)
				xv[i] = zv[1 + 2 * i];

			A.ExchangeHalo(x);
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				double temp = wv[i];
				for (int j = Extp[i]; j < Extp[i + 1]; ++j)
					temp -= recvxv[Exti[j]] * Extv[j];
				for (int j = Ep[i]; j < Ep[i + 1]; ++j)
					temp -= xv[Ei[j]] * Ev[j];
				wv[i] = temp;
			}

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				double temp = wv[i];
				for (int j = Up[i]; j < Up[i + 1]; ++j)
					temp -= xv[Ui[j]] * Uv[j];
				rv[i] = temp - Dv[i] * xv[i];
			}
		}
		else
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			for (int i = 0; i < n; ++i)
				xv[i] = bv[i] * Drcpv[i] * theta;

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			for (int i = 0; i < n; ++i)
			{
				double temp = bv[i];
				for (int j = Lp[i]; j < Lp[i + 1]; ++j)
					temp -= xv[Li[j]] * Lv[j];
				for (int j = Up[i]; j < Up[i + 1]; ++j)
					temp -= xv[Ui[j]] * Uv[j];
				wv[i] = temp - Dv[i] * xv[i];
			}

			A.ExchangeHalo(x);
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				double temp = wv[i];
				for (int j = Extp[i]; j < Extp[i + 1]; ++j)
					temp -= recvxv[Exti[j]] * Extv[j];
				for (int j = Ep[i]; j < Ep[i + 1]; ++j)
					temp -= xv[Ei[j]] * Ev[j];
				rv[i] = temp;
			}
		}
	}

	delete[] recvreq;
	delete[] sendreq;
}

void ParCSRSmootherChebyshevX::operator()(const ParCSRMatrix& A, const ParVector& b, const ParVector& x, int step, bool x0zero) const
{
	int n = A.local.size[0];

	int* Lp = L.rowptr;
	int* Li = L.colind;
	double* Lv = L.values;
	int* Up = U.rowptr;
	int* Ui = U.colind;
	double* Uv = U.values;
	int* Ep = E.rowptr;
	int* Ei = E.colind;
	double* Ev = E.values;
	int* Extp = A.exter.rowptr;
	int* Exti = A.exter.colind;
	double* Extv = A.exter.values;
	double* Drcpv = D_recip.values;
	double* xv = x.local.values;
	double* bv = b.local.values;
	double* wv = w.local.values;
	double* zv = z.local.values;
	double* recvxv = A.recvx.values;

	MPI_Comm comm = A.comm;
	int nnb = A.nnb;
	int* nbrank = A.nbrank;
	int* recvptr = A.recvptr;
	int* sendptr = A.sendptr;
	int* sendind = A.sendind;
	double* sendbuf = A.sendbuf;

	MPI_Request* recvreq = new MPI_Request[nnb];
	MPI_Request* sendreq = new MPI_Request[nnb];
	MPI_Status status;

	double alpha = lambda;
	double beta  = lambda * EigenRatio;

	double theta, delta, sigma, rho, rho1;

	theta = 2.0 / (beta + alpha);
	delta = 2.0 / (beta - alpha);
	sigma = delta / theta;

	if (step > 1)
	{
		if (!x0zero)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				double temp = 0.0;
				for (int j = Up[i]; j < Up[i + 1]; ++j)
					temp -= xv[Ui[j]] * Uv[j];
				wv[i] = temp;
			}

			A.ExchangeHalo(x);
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				double temp = wv[i];
				for (int j = Extp[i]; j < Extp[i + 1]; ++j)
					temp -= recvxv[Exti[j]] * Extv[j];
				for (int j = Ep[i]; j < Ep[i + 1]; ++j)
					temp -= xv[Ei[j]] * Ev[j];
				wv[i] = temp;
			}

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			for (int i = 0; i < n; ++i)
				zv[2 * i] = xv[i];
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			for (int t = 0; t < nthd; ++t)
			{
				int begin = t * n / nthd;
				int end = (t + 1) * n / nthd;

				for (int i = begin; i < end; ++i)
				{
					double temp1 = bv[i] + wv[i];
					double temp2 = bv[i];
					for (int j = Lp[i]; j < Lp[i + 1]; ++j)
					{
						temp1 -= zv[2 * Li[j]] * Lv[j];
						temp2 -= zv[1 + 2 * Li[j]] * Lv[j];
					}
					zv[1 + 2 * i] = temp1 * Drcpv[i] * theta + (1 - theta) * zv[2 * i];
					wv[i] = temp2;
				}
			}
		}
		else
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			for (int i = 0; i < n; ++i)
			{
				zv[2 * i] = 0.0;
				zv[1 + 2 * i] = bv[i] * Drcpv[i] * theta;
			}

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				double temp = bv[i];
				for (int j = Lp[i]; j < Lp[i + 1]; ++j)
					temp -= zv[1 + 2 * Li[j]] * Lv[j];
				wv[i] = temp;
			}
		}

		for (int r = 0; r < nnb; ++r)
			if (recvptr[r + 1] > recvptr[r])
				MPI_Irecv(recvxv + recvptr[r], recvptr[r + 1] - recvptr[r], MPI_DOUBLE, nbrank[r], MPI_TAG, comm, recvreq + r);

		for (int r = 0; r < nnb; ++r)
		{
			if (sendptr[r + 1] > sendptr[r])
			{
				for (int i = sendptr[r]; i < sendptr[r + 1]; ++i)
					sendbuf[i] = zv[1 + 2 * sendind[i]];
				MPI_Isend(sendbuf + sendptr[r], sendptr[r + 1] - sendptr[r], MPI_DOUBLE, nbrank[r], MPI_TAG, comm, sendreq + r);
			}
		}

		for (int r = 0; r < nnb; ++r)
			if (recvptr[r + 1] > recvptr[r])
				MPI_Wait(recvreq + r, &status);

		for (int r = 0; r < nnb; ++r)
			if (sendptr[r + 1] > sendptr[r])
				MPI_Wait(sendreq + r, &status);

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		for (int i = 0; i < n; ++i)
		{
			double temp = wv[i];
			for (int j = Extp[i]; j < Extp[i + 1]; ++j)
				temp -= recvxv[Exti[j]] * Extv[j];
			for (int j = Ep[i]; j < Ep[i + 1]; ++j)
				temp -= zv[1 + 2 * Ei[j]] * Ev[j];
			wv[i] = temp;
		}

		rho1 = 1.0 / sigma;

		int k = 1;

		while (1)
		{
			double c1, c2;
			
			rho = 1.0 / (2.0 * sigma - rho1);

			c1 = rho * delta * 2.0;
			c2 = rho * rho1;

			if (++k == step)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
				for (int i = 0; i < n; ++i)
				{
					double temp = wv[i];
					for (int j = Up[i]; j < Up[i + 1]; ++j)
						temp -= zv[1 + 2 * Ui[j]] * Uv[j];
					xv[i] = (c2 - c1 + 1.0) * zv[1 + 2 * i] + c1 * (temp * Drcpv[i]) - c2 * zv[2 * i];
				}
				break;
			}
			else
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				for (int t = 0; t < nthd; ++t)
				{
					int begin = t * n / nthd;
					int end = (t + 1) * n / nthd;

					for (int i = end - 1; i >= begin; --i)
					{
						double temp1 = 0.0;
						double temp2 = wv[i];
						for (int j = Up[i + 1] - 1; j >= Up[i]; --j)
						{
							temp1 -= zv[2 * Ui[j]] * Uv[j];
							temp2 -= zv[1 + 2 * Ui[j]] * Uv[j];
						}
						zv[2 * i] = (c2 - c1 + 1.0) * zv[1 + 2 * i] + c1 * (temp2 * Drcpv[i]) - c2 * zv[2 * i];
						wv[i] = temp1;
					}
				}

				for (int r = 0; r < nnb; ++r)
					if (recvptr[r + 1] > recvptr[r])
						MPI_Irecv(recvxv + recvptr[r], recvptr[r + 1] - recvptr[r], MPI_DOUBLE, nbrank[r], MPI_TAG, comm, recvreq + r);

				for (int r = 0; r < nnb; ++r)
				{
					if (sendptr[r + 1] > sendptr[r])
					{
						for (int i = sendptr[r]; i < sendptr[r + 1]; ++i)
							sendbuf[i] = zv[2 * sendind[i]];
						MPI_Isend(sendbuf + sendptr[r], sendptr[r + 1] - sendptr[r], MPI_DOUBLE, nbrank[r], MPI_TAG, comm, sendreq + r);
					}
				}

				for (int r = 0; r < nnb; ++r)
					if (recvptr[r + 1] > recvptr[r])
						MPI_Wait(recvreq + r, &status);

				for (int r = 0; r < nnb; ++r)
					if (sendptr[r + 1] > sendptr[r])
						MPI_Wait(sendreq + r, &status);

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
				for (int i = 0; i < n; ++i)
				{
					double temp = wv[i];
					for (int j = Extp[i]; j < Extp[i + 1]; ++j)
						temp -= recvxv[Exti[j]] * Extv[j];
					for (int j = Ep[i]; j < Ep[i + 1]; ++j)
						temp -= zv[2 * Ei[j]] * Ev[j];
					wv[i] = temp;
				}
			}

			rho1 = rho;

			c1 = rho * delta * 2.0;
			c2 = rho * rho1;

			if (++k == step)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
				for (int i = 0; i < n; ++i)
				{
					double temp = bv[i] + wv[i];
					for (int j = Lp[i]; j < Lp[i + 1]; ++j)
						temp -= zv[2 * Li[j]] * Lv[j];
					xv[i] = (c2 - c1 + 1.0) * zv[2 * i] + c1 * (temp * Drcpv[i]) - c2 * zv[1 + 2 * i];
				}

				break;
			}
			else
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				for (int t = 0; t < nthd; ++t)
				{
					int begin = t * n / nthd;
					int end = (t + 1) * n / nthd;

					for (int i = begin; i < end; ++i)
					{
						double temp1 = bv[i] + wv[i];
						double temp2 = bv[i];
						for (int j = Lp[i]; j < Lp[i + 1]; ++j)
						{
							temp1 -= zv[2 * Li[j]] * Lv[j];
							temp2 -= zv[1 + 2 * Li[j]] * Lv[j];
						}
						zv[1 + 2 * i] = (c2 - c1 + 1.0) * zv[2 * i] + c1 * (temp1 * Drcpv[i]) - c2 * zv[1 + 2 * i];
						wv[i] = temp2;
					}
				}

				for (int r = 0; r < nnb; ++r)
					if (recvptr[r + 1] > recvptr[r])
						MPI_Irecv(recvxv + recvptr[r], recvptr[r + 1] - recvptr[r], MPI_DOUBLE, nbrank[r], MPI_TAG, comm, recvreq + r);

				for (int r = 0; r < nnb; ++r)
				{
					if (sendptr[r + 1] > sendptr[r])
					{
						for (int i = sendptr[r]; i < sendptr[r + 1]; ++i)
							sendbuf[i] = zv[1 + 2 * sendind[i]];
						MPI_Isend(sendbuf + sendptr[r], sendptr[r + 1] - sendptr[r], MPI_DOUBLE, nbrank[r], MPI_TAG, comm, sendreq + r);
					}
				}

				for (int r = 0; r < nnb; ++r)
					if (recvptr[r + 1] > recvptr[r])
						MPI_Wait(recvreq + r, &status);

				for (int r = 0; r < nnb; ++r)
					if (sendptr[r + 1] > sendptr[r])
						MPI_Wait(sendreq + r, &status);

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
				for (int i = 0; i < n; ++i)
				{
					double temp = wv[i];
					for (int j = Extp[i]; j < Extp[i + 1]; ++j)
						temp -= recvxv[Exti[j]] * Extv[j];
					for (int j = Ep[i]; j < Ep[i + 1]; ++j)
						temp -= zv[1 + 2 * Ei[j]] * Ev[j];
					wv[i] = temp;
				}
			}

			rho1 = rho;
		}
	}
	else
	{
		if (!x0zero)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				double temp = 0.0;
				for (int j = Up[i]; j < Up[i + 1]; ++j)
					temp -= xv[Ui[j]] * Uv[j];
				wv[i] = temp;
			}

			A.ExchangeHalo(x);
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				double temp = wv[i];
				for (int j = Extp[i]; j < Extp[i + 1]; ++j)
					temp -= recvxv[Exti[j]] * Extv[j];
				for (int j = Ep[i]; j < Ep[i + 1]; ++j)
					temp -= xv[Ei[j]] * Ev[j];
				wv[i] = temp;
			}

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			for (int t = 0; t < nthd; ++t)
			{
				int begin = t * n / nthd;
				int end = (t + 1) * n / nthd;

				for (int i = end - 1; i >= begin; --i)
				{
					double temp = bv[i] + wv[i];
					for (int j = Lp[i + 1] - 1; j >= Lp[i]; --j)
						temp -= xv[Li[j]] * Lv[j];
					xv[i] = temp * Drcpv[i] * theta + (1 - theta) * xv[i];
				}
			}
		}
		else
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			for (int i = 0; i < n; ++i)
				xv[i] = bv[i] * Drcpv[i] * theta;
		}
	}

	delete[] recvreq;
	delete[] sendreq;
}

}
