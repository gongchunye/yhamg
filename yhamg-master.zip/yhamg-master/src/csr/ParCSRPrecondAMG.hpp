/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef ParCSRPrecondAMG_H
#define ParCSRPrecondAMG_H

#include "ParCSRPrecond.hpp"

namespace YHAMG
{

class ParCSRPrecondAMG : public ParCSRPrecond
{
private:
	class Smoother;

	int nlev;
	ParCSRMatrix* A;
	ParCSRMatrix* P;
	ParCSRMatrix* R;
	Smoother* S;

	ParVector* r;
	ParVector* e;
	ParVector* g;

	void Strength(const ParCSRMatrix& A, bool* locstg, bool* extstg) const;
	void Coarsening(const ParCSRMatrix& A, const bool* locstg, const bool* extstg, int* cfmap, int AGGRESSIVE = 0) const;
	void Interpolation(const ParCSRMatrix& A, const bool* locstg, const bool* extstg, int* cfmap, ParCSRMatrix& P, int AGGRESSIVE = 0) const;
	void RAP(const ParCSRMatrix& R, const ParCSRMatrix& A, const ParCSRMatrix& P, ParCSRMatrix& C) const;
	void Sparsification(const ParCSRMatrix& A, ParCSRMatrix& B) const;
	void SetupSmoother(const ParCSRMatrix& A, Smoother& S, int REUSE = 0) const;
	void PreSmooth(int level, const ParVector& b, const ParVector& x, bool x0zero = 0) const;
	void PreSmooth_Restriction(int level, const ParVector& b, const ParVector& x, const ParVector& g, bool x0zero = 0) const;
	void PostSmooth(int level, const ParVector& b, const ParVector& x) const;
	void CoarseSmooth(int level, const ParVector& b, const ParVector& x, bool x0zero = 0) const;
	void Restriction(int level, const ParVector& b, const ParVector& x, const ParVector& g) const;
	void Prolongation(int level, const ParVector& e, const ParVector& x) const;
	void V_Cycle(int level, const ParVector& b, const ParVector& x, bool x0zero = 0) const;
	void W_Cycle(int level, const ParVector& b, const ParVector& x, bool x0zero = 0) const;
	void F_Cycle(int level, const ParVector& b, const ParVector& x) const;

public:
	int    MaxLevels;
	int    CoarseSize;
	double StrengthThreshold;
	int    AggressiveLevels;
	int    CoarsenType;
	int    InterpType;
	int    InterpMinElements;
	int    InterpMaxElements;
	double TruncationFactor;
	double SparsificationThreshold;
	int    CycleType;
	int    PreSweeps;
	int    PostSweeps;
	int    CoarseSweeps;
	int    SmoothType;
	double JacobiFactor;
	int    SORType;
	double SORFactor;
	int    ILUMaxFillins;
	double ILUDropTolerance;
	double ChebyshevEigenRatio;
	int    PrintStats;

	ParCSRPrecondAMG(
	int    max_levels = 20,
	int    coarse_size = 8,
	double strength_threshold = 0.25,
	int    aggressive_levels = 0,
	int    coarsen_type = 0,
	int    interp_type = 0,
	int    interp_min_elements = 4,
	int    interp_max_elements = 4,	
	double truncation_factor = 0.1,
	double sparsification_threshold = 0.0,
	int    cycle_type = 0,
	int    pre_sweeps = 2,
	int    post_sweeps = 2,
	int    coarse_sweeps = 2,
	int    smooth_type = 1,
	int    print_stats = 0);
	~ParCSRPrecondAMG();
	
	void Free();
	void Setup(const ParCSRMatrix& A, int REUSE = 0);
	int InSize() const;
	int OutSize() const;
	void Apply(const ParVector& b, const ParVector& x) const;
};

}

#endif