/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "ParCSRGenerator7pt.hpp"

namespace YHAMG
{

ParCSRGenerator7pt::ParCSRGenerator7pt(MPI_Comm comm)
	: ParCSRGenerator(comm),
	nx(0),
	ny(0),
	nz(0),
	Px(0),
	Py(0),
	Pz(0),
	cx(0.0),
	cy(0.0),
	cz(0.0)
{
}

ParCSRGenerator7pt::ParCSRGenerator7pt(MPI_Comm comm, int _nx, int _ny, int _nz, int _Px, int _Py, int _Pz, double _cx, double _cy, double _cz)
	: ParCSRGenerator(comm),
	nx(_nx),
	ny(_ny),
	nz(_nz),
	Px(_Px),
	Py(_Py),
	Pz(_Pz),
	cx(_cx),
	cy(_cy),
	cz(_cz)
{
}

static inline int sub2ind(int nx, int ny, int nz, int ix, int iy, int iz)
{
	return ix * ny * nz + iy * nz + iz;
}

static inline void ind2sub(int nx, int ny, int nz, int i, int& ix, int& iy, int& iz)
{
	ix = i / (ny * nz);
	iy = i / nz - ix * ny;
	iz = i - ix * ny * nz - iy * nz;
}

void ParCSRGenerator7pt::operator()(ParCSRMatrix& A) const
{
	int comm_rank;
	MPI_Comm_rank(comm, &comm_rank);

	double b = 0.0;
	if (nx * Px > 1) b -= 2 * cx;
	if (ny * Py > 1) b -= 2 * cy;
	if (nz * Pz > 1) b -= 2 * cz;

	int size = nx * ny * nz;

	int* local_rowptr = new int[size + 1];

	local_rowptr[0] = 0;
	for (int ix = 0; ix < nx; ++ix)
	{
		for (int iy = 0; iy < ny; ++iy)
		{
			for (int iz = 0; iz < nz; ++iz)
			{
				int cnt = 1;
				if (ix > 0) ++cnt;
				if (iy > 0) ++cnt;
				if (iz > 0) ++cnt;
				if (iz < nz - 1) ++cnt;
				if (iy < ny - 1) ++cnt;
				if (ix < nx - 1) ++cnt;
				local_rowptr[sub2ind(nx, ny, nz, ix, iy, iz) + 1] = cnt;
			}
		}
	}

	for (int i = 0; i < size; ++i)
		local_rowptr[i + 1] += local_rowptr[i];

	int* local_colind = new int[local_rowptr[size]];
	double* local_values = new double[local_rowptr[size]];

	for (int ix = 0; ix < nx; ++ix)
	{
		for (int iy = 0; iy < ny; ++iy)
		{
			for (int iz = 0; iz < nz; ++iz)
			{
				int r = sub2ind(nx, ny, nz, ix, iy, iz);
				int j = local_rowptr[r];

				if (ix > 0)
				{
					local_colind[j] = sub2ind(nx, ny, nz, ix - 1, iy, iz);
					local_values[j++] = cx;
				}

				if (iy > 0)
				{
					local_colind[j] = sub2ind(nx, ny, nz, ix, iy - 1, iz);
					local_values[j++] = cy;
				}

				if (iz > 0)
				{
					local_colind[j] = sub2ind(nx, ny, nz, ix, iy, iz - 1);
					local_values[j++] = cz;
				}

				local_colind[j] = r;
				local_values[j++] = b;

				if (iz < nz - 1)
				{
					local_colind[j] = sub2ind(nx, ny, nz, ix, iy, iz + 1);
					local_values[j++] = cz;
				}

				if (iy < ny - 1)
				{
					local_colind[j] = sub2ind(nx, ny, nz, ix, iy + 1, iz);
					local_values[j++] = cy;
				}

				if (ix < nx - 1)
				{
					local_colind[j] = sub2ind(nx, ny, nz, ix + 1, iy, iz);
					local_values[j++] = cx;
				}
			}
		}
	}

	int rx, ry, rz;
	ind2sub(Px, Py, Pz, comm_rank, rx, ry, rz);

	int* exter_rowptr = new int[size + 1];
	for (int i = 0; i <= size; ++i)
		exter_rowptr[i] = 0;

	int nnb = 0;
	int* nbrank = new int[6];
	int* recvptr = new int[7];

	recvptr[0] = 0;

	if (rx > 0)
	{
		for (int iy = 0; iy < ny; ++iy)
			for (int iz = 0; iz < nz; ++iz)
				++exter_rowptr[sub2ind(nx, ny, nz, 0, iy, iz)];
		nbrank[nnb++] = sub2ind(Px, Py, Pz, rx - 1, ry, rz);
		recvptr[nnb] = ny * nz;
	}

	if (ry > 0)
	{
		for (int ix = 0; ix < nx; ++ix)
			for (int iz = 0; iz < nz; ++iz)
				++exter_rowptr[sub2ind(nx, ny, nz, ix, 0, iz)];
		nbrank[nnb++] = sub2ind(Px, Py, Pz, rx, ry - 1, rz);
		recvptr[nnb] = nx * nz;
	}

	if (rz > 0)
	{
		for (int ix = 0; ix < nx; ++ix)
			for (int iy = 0; iy < ny; ++iy)
				++exter_rowptr[sub2ind(nx, ny, nz, ix, iy, 0)];
		nbrank[nnb++] = sub2ind(Px, Py, Pz, rx, ry, rz - 1);
		recvptr[nnb] = nx * ny;
	}

	if (rz < Pz - 1)
	{
		for (int ix = 0; ix < nx; ++ix)
			for (int iy = 0; iy < ny; ++iy)
				++exter_rowptr[sub2ind(nx, ny, nz, ix, iy, nz - 1)];
		nbrank[nnb++] = sub2ind(Px, Py, Pz, rx, ry, rz + 1);
		recvptr[nnb] = nx * ny;
	}

	if (ry < Py - 1)
	{
		for (int ix = 0; ix < nx; ++ix)
			for (int iz = 0; iz < nz; ++iz)
				++exter_rowptr[sub2ind(nx, ny, nz, ix, ny - 1, iz)];
		nbrank[nnb++] = sub2ind(Px, Py, Pz, rx, ry + 1, rz);
		recvptr[nnb] = nx * nz;
	}

	if (rx < Px - 1)
	{
		for (int iy = 0; iy < ny; ++iy)
			for (int iz = 0; iz < nz; ++iz)
				++exter_rowptr[sub2ind(nx, ny, nz, nx - 1, iy, iz)];
		nbrank[nnb++] = sub2ind(Px, Py, Pz, rx + 1, ry, rz);
		recvptr[nnb] = ny * nz;
	}

	for (int i = 0; i < size; ++i)
		exter_rowptr[i + 1] += exter_rowptr[i];

	int* exter_colind = new int[exter_rowptr[size]];
	double* exter_values = new double[exter_rowptr[size]];

	for (int r = 0; r < nnb; ++r)
		recvptr[r + 1] += recvptr[r];

	int* recvind = new int[recvptr[nnb]];

	int nbind = nnb;

	if (rx < Px - 1)
	{
		int t = recvptr[nbind--];
		for (int iy = ny - 1; iy >= 0; --iy)
		{
			for (int iz = nz - 1; iz >= 0; --iz)
			{
				recvind[--t] = sub2ind(nx, ny, nz, 0, iy, iz);
				int j = --exter_rowptr[sub2ind(nx, ny, nz, nx - 1, iy, iz)];
				exter_colind[j] = t;
				exter_values[j] = cx;
			}
		}
	}

	if (ry < Py - 1)
	{
		int t = recvptr[nbind--];
		for (int ix = nx - 1; ix >= 0; --ix)
		{
			for (int iz = nz - 1; iz >= 0; --iz)
			{
				recvind[--t] = sub2ind(nx, ny, nz, ix, 0, iz);
				int j = --exter_rowptr[sub2ind(nx, ny, nz, ix, ny - 1, iz)];
				exter_colind[j] = t;
				exter_values[j] = cy;
			}
		}
	}

	if (rz < Pz - 1)
	{
		int t = recvptr[nbind--];
		for (int ix = nx - 1; ix >= 0; --ix)
		{
			for (int iy = ny - 1; iy >= 0; --iy)
			{
				recvind[--t] = sub2ind(nx, ny, nz, ix, iy, 0);
				int j = --exter_rowptr[sub2ind(nx, ny, nz, ix, iy, nz - 1)];
				exter_colind[j] = t;
				exter_values[j] = cz;
			}
		}
	}

	if (rz > 0)
	{
		int t = recvptr[nbind--];
		for (int ix = nx - 1; ix >= 0; --ix)
		{
			for (int iy = ny - 1; iy >= 0; --iy)
			{
				recvind[--t] = sub2ind(nx, ny, nz, ix, iy, nz - 1);
				int j = --exter_rowptr[sub2ind(nx, ny, nz, ix, iy, 0)];
				exter_colind[j] = t;
				exter_values[j] = cz;
			}
		}
	}

	if (ry > 0)
	{
		int t = recvptr[nbind--];
		for (int ix = nx - 1; ix >= 0; --ix)
		{
			for (int iz = nz - 1; iz >= 0; --iz)
			{
				recvind[--t] = sub2ind(nx, ny, nz, ix, ny - 1, iz);
				int j = --exter_rowptr[sub2ind(nx, ny, nz, ix, 0, iz)];
				exter_colind[j] = t;
				exter_values[j] = cy;
			}
		}
	}

	if (rx > 0)
	{
		int t = recvptr[nbind--];
		for (int iy = ny - 1; iy >= 0; --iy)
		{
			for (int iz = nz - 1; iz >= 0; --iz)
			{
				recvind[--t] = sub2ind(nx, ny, nz, nx - 1, iy, iz);
				int j = --exter_rowptr[sub2ind(nx, ny, nz, 0, iy, iz)];
				exter_colind[j] = t;
				exter_values[j] = cx;
			}
		}
	}

	A.Free();
	A.comm = comm;
	A.local.size[0] = size;
	A.local.size[1] = size;
	A.local.rowptr = local_rowptr;
	A.local.colind = local_colind;
	A.local.values = local_values;
	A.exter.size[0] = size;
	A.exter.size[1] = recvptr[nnb];
	A.exter.rowptr = exter_rowptr;
	A.exter.colind = exter_colind;
	A.exter.values = exter_values;
	A.nnb = nnb;
	A.nbrank = nbrank;
	A.recvptr = recvptr;
	A.recvind = recvind;
}

}