/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "ParCSRSmootherJacobi.hpp"

#ifdef YHAMG_USE_OPENMP
#include <omp.h>
#endif

#define MPI_TAG 200

namespace YHAMG
{

ParCSRSmootherJacobi::ParCSRSmootherJacobi(double relaxation_factor)
	: RelaxationFactor(relaxation_factor)
{
}

void ParCSRSmootherJacobi::Setup(const ParCSRMatrix& A, int REUSE)
{
	int n = A.local.size[0];
	int* Ap = A.local.rowptr;
	int* Ai = A.local.colind;
	double* Av = A.local.values;

	if (!REUSE)
	{
		D_recip.comm = A.comm;
		z.comm = A.comm;
		D_recip.Resize(n);
		z.Resize(n);
	}

	double* Drcpv = D_recip.local.values;
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
	for (int i = 0; i < n; ++i)
	{
		for (int j = Ap[i]; j < Ap[i + 1]; ++j)
		{
			if (Ai[j] == i)
			{
				Drcpv[i] = 1.0 / Av[j];
				break;
			}
		}
	}
}

void ParCSRSmootherJacobi::operator()(const ParCSRMatrix& A, const ParVector& b, const ParVector& x, int step, bool x0zero) const
{
	int n = A.local.size[0];
	double* Drcpv = D_recip.local.values;
	double* xv = x.local.values;
	double* zv = z.local.values;
	double* bv = b.local.values;

	double omega = RelaxationFactor;

	for (int k = 0; k < step; ++k)
	{
		if (!x0zero || k > 0)
		{
			z.Copy(b);
			ParCSRMatVec(-1.0, A, x, 1.0, z);

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			for (int i = 0; i < n; ++i)
				xv[i] += zv[i] * Drcpv[i] * omega;
		}
		else
		{
			for (int i = 0; i < n; ++i)
				xv[i] = bv[i] * Drcpv[i] * omega;
		}
	}
}

ParCSRSmootherJacobiXLocal::ParCSRSmootherJacobiXLocal(double relaxation_factor)
	: nthd(0),
	RelaxationFactor(relaxation_factor)
{
}

void ParCSRSmootherJacobiXLocal::Setup(const ParCSRMatrix& A, int REUSE)
{
	int n = A.local.size[0];
	int* Ap = A.local.rowptr;
	int* Ai = A.local.colind;
	double* Av = A.local.values;
	
	if (!REUSE)
	{
		r.comm = A.comm;
		w.comm = A.comm;
		z.comm = A.comm;
		r.Resize(n);
		w.Resize(n);
		z.Resize(2 * n);

		D.Resize(n);
		D_recip.Resize(n);

		nthd = 1;
#ifdef USE_ONED_PARTITION
		nthd = omp_get_max_threads();
#endif

		double* Dv = D.values;
		double* Drcpv = D_recip.values;

		int* Lp = new int[n + 1];
		int* Up = new int[n + 1];
		int* Ep = new int[n + 1];

		Lp[0] = 0;
		Up[0] = 0;
		Ep[0] = 0;
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		for (int t = 0; t < nthd; ++t)
		{
			int begin = t * n / nthd;
			int end = (t + 1) * n / nthd;

			for (int i = begin; i < end; ++i)
			{
				int cntl = 0;
				int cntu = 0;
				int cnte = 0;

				for (int j = Ap[i]; j < Ap[i + 1]; ++j)
				{
					int jcol = Ai[j];

					if (jcol >= begin && jcol < i) 
						++cntl;
					else if (jcol < end && jcol > i)
						++cntu;
					else if (jcol != i)
						++cnte;
				}

				Lp[i + 1] = cntl;
				Up[i + 1] = cntu;
				Ep[i + 1] = cnte;
			}
		}

		for (int i = 0; i < n;++i)
			Lp[i + 1] += Lp[i];
		for (int i = 0; i < n;++i)
			Up[i + 1] += Up[i];
		for (int i = 0; i < n;++i)
			Ep[i + 1] += Ep[i];

		int* Li = new int[Lp[n]];
		double* Lv = new double[Lp[n]];
		int* Ui = new int[Up[n]];
		double* Uv = new double[Up[n]];
		int* Ei = new int[Ep[n]];
		double* Ev = new double[Ep[n]];

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		for (int t = 0; t < nthd; ++t)
		{
			int begin = t * n / nthd;
			int end = (t + 1) * n / nthd;

			for (int i = begin; i < end; ++i)
			{
				for (int j = Ap[i], k = Lp[i], r = Up[i], s = Ep[i]; j < Ap[i + 1]; ++j)
				{
					int jcol = Ai[j];
					double jval = Av[j];

					if (jcol >= begin && jcol < i) 
					{
						Li[k] = jcol;
						Lv[k++] = jval;
					}
					else if (jcol < end && jcol > i)
					{
						Ui[r] = jcol;
						Uv[r++] = jval;
					}
					else if (jcol == i)
					{
						Dv[i] = jval;
						Drcpv[i] = 1.0 / jval;
					}
					else
					{
						Ei[s] = jcol;
						Ev[s++] = jval;
					}
				}
			}
		}

		L.size[0] = n;
		L.size[1] = n;
		L.rowptr = Lp;
		L.colind = Li;
		L.values = Lv;
		U.size[0] = n;
		U.size[1] = n;
		U.rowptr = Up;
		U.colind = Ui;
		U.values = Uv;
		E.size[0] = n;
		E.size[1] = n;
		E.rowptr = Ep;
		E.colind = Ei;
		E.values = Ev;
	}
	else
	{
		int* Lp = L.rowptr;
		int* Li = L.colind;
		double* Lv = L.values;
		int* Up = U.rowptr;
		int* Ui = U.colind;
		double* Uv = U.values;
		int* Ep = E.rowptr;
		int* Ei = E.colind;
		double* Ev = E.values;
		double* Dv = D.values;
		double* Drcpv = D_recip.values;
		
		int* w = new int[n];

		for (int i = 0; i < n; ++i)
			w[i] = -1;

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		for (int t = 0; t < nthd; ++t)
		{
			int begin = t * n / nthd;
			int end = (t + 1) * n / nthd;

			for (int i = begin; i < end; ++i)
			{
				int j0 = Ap[i];

				for (int j = Ap[i]; j < Ap[i + 1]; ++j)
					w[Ai[j]] = j;

				if (w[i] >= j0)
				{
					Dv[i] = Av[w[i]];
					Drcpv[i] = 1.0 / Av[w[i]];
				}

				for (int j = Lp[i]; j < Lp[i + 1]; ++j)
					if (w[Li[j]] >= j0) Lv[j] = Av[w[Li[j]]];
				for (int j = Up[i]; j < Up[i + 1]; ++j)
					if (w[Ui[j]] >= j0) Uv[j] = Av[w[Ui[j]]];
				for (int j = Ep[i]; j < Ep[i + 1]; ++j)
					if (w[Ei[j]] >= j0) Ev[j] = Av[w[Ei[j]]];
			}
		}
		
		delete[] w;	
	}
}

void ParCSRSmootherJacobiXLocal::Pre_and_Resid(const ParCSRMatrix& A, const ParVector& b, const ParVector& x, const ParVector& r, int step, bool x0zero) const
{
	int n = A.local.size[0];

	int* Lp = L.rowptr;
	int* Li = L.colind;
	double* Lv = L.values;
	int* Up = U.rowptr;
	int* Ui = U.colind;
	double* Uv = U.values;
	int* Ep = E.rowptr;
	int* Ei = E.colind;
	double* Ev = E.values;
	int* Extp = A.exter.rowptr;
	int* Exti = A.exter.colind;
	double* Extv = A.exter.values;
	double* Dv = D.values;
	double* Drcpv = D_recip.values;
	double* xv = x.local.values;
	double* bv = b.local.values;
	double* rv = r.local.values;
	double* wv = w.local.values;
	double* zv = z.local.values;
	double* recvxv = A.recvx.values;

	double omega = RelaxationFactor;

	if (!x0zero)
	{
		A.ExchangeHalo(x);
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		for (int i = 0; i < n; ++i)
		{
			double temp = bv[i];
			for (int j = Extp[i]; j < Extp[i + 1]; ++j)
				temp -= recvxv[Exti[j]] * Extv[j];
			for (int j = Ep[i]; j < Ep[i + 1]; ++j)
				temp -= xv[Ei[j]] * Ev[j];
			rv[i] = temp;
		}
	}
	else
		r.Copy(b);

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
	for (int t = 0; t < nthd; ++t)
	{
		int begin = t * n / nthd;
		int end = (t + 1) * n / nthd;

		int k = 0;

		if (x0zero)
		{
			++k;
			for (int i = begin; i < end; ++i)
				xv[i] = rv[i] * Drcpv[i] * omega;
		}

		for (int i = begin; i < end; ++i)
		{
			double temp = 0.0;
			for (int j = Up[i]; j < Up[i + 1]; ++j)
				temp -= xv[Ui[j]] * Uv[j];
			wv[i] = temp;
		}
		
		if (k < step)
		{
			for (int i = begin; i < end; ++i)
				zv[2 * i] = xv[i];

			while (1)
			{
				if (++k >= step)
				{
					for (int i = begin; i < end; ++i)
					{
						double temp1 = rv[i] + wv[i];
						double temp2 = 0.0;
						for (int j = Lp[i]; j < Lp[i + 1]; ++j)
						{
							temp1 -= zv[2 * Li[j]] * Lv[j];
							temp2 -= zv[1 + 2 * Li[j]] * Lv[j];
						}
						zv[1 + 2 * i] = temp1 * Drcpv[i] * omega + zv[2 * i] * (1 - omega);
						wv[i] = temp2;
					}

					for (int i = begin; i < end; ++i)
						xv[i] = zv[1 + 2 * i];

					for (int i = begin; i < end; ++i)
					{
						double temp = wv[i];
						for (int j = Up[i]; j < Up[i + 1]; ++j)
							temp -= xv[Ui[j]] * Uv[j];
						rv[i] = temp - Dv[i] * xv[i];
					}

					break;
				}
				else
				{
					for (int i = begin; i < end; ++i)
					{
						double temp1 = rv[i] + wv[i];
						double temp2 = rv[i];
						for (int j = Lp[i]; j < Lp[i + 1]; ++j)
						{
							temp1 -= zv[2 * Li[j]] * Lv[j];
							temp2 -= zv[1 + 2 * Li[j]] * Lv[j];
						}
						zv[1 + 2 * i] = temp1 * Drcpv[i] * omega + zv[2 * i] * (1 - omega);
						wv[i] = temp2;
					}
				}

				for (int i = end - 1; i >= begin; --i)
				{
					double temp1 = 0.0;
					double temp2 = wv[i];
					for (int j = Up[i + 1] - 1; j >= Up[i]; --j)
					{
						temp1 -= zv[2 * Ui[j]] * Uv[j];
						temp2 -= zv[1 + 2 * Ui[j]] * Uv[j];
					}
					wv[i] = temp1;
					zv[2 * i] = temp2 * Drcpv[i] * omega + zv[1 + 2 * i] * (1 - omega);
				}

				if (++k >= step)
				{
					for (int i = begin; i < end; ++i)
						xv[i] = zv[2 * i];

					for (int i = begin; i < end; ++i)
					{
						double temp = wv[i];
						for (int j = Lp[i]; j < Lp[i + 1]; ++j)
							temp -= xv[Li[j]] * Lv[j];
						rv[i] = temp - Dv[i] * xv[i];
					}

					break;
				}
			}
		}
		else
		{
			for (int i = begin; i < end; ++i)
			{
				double temp = wv[i];
				for (int j = Lp[i]; j < Lp[i + 1]; ++j)
					temp -= xv[Li[j]] * Lv[j];
				rv[i] = temp - Dv[i] * xv[i];
			}
		}
	}

	A.ExchangeHalo(x);
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
	for (int i = 0; i < n; ++i)
	{
		double temp = bv[i];
		for (int j = Extp[i]; j < Extp[i + 1]; ++j)
			temp -= recvxv[Exti[j]] * Extv[j];
		for (int j = Ep[i]; j < Ep[i + 1]; ++j)
			temp -= xv[Ei[j]] * Ev[j];
		rv[i] += temp;
	}
}

void ParCSRSmootherJacobiXLocal::operator()(const ParCSRMatrix& A, const ParVector& b, const ParVector& x, int step, bool x0zero) const
{
	int n = A.local.size[0];

	int* Lp = L.rowptr;
	int* Li = L.colind;
	double* Lv = L.values;
	int* Up = U.rowptr;
	int* Ui = U.colind;
	double* Uv = U.values;
	int* Ep = E.rowptr;
	int* Ei = E.colind;
	double* Ev = E.values;
	int* Extp = A.exter.rowptr;
	int* Exti = A.exter.colind;
	double* Extv = A.exter.values;
	double* Drcpv = D_recip.values;
	double* xv = x.local.values;
	double* bv = b.local.values;
	double* rv = r.local.values;
	double* wv = w.local.values;
	double* zv = z.local.values;
	double* recvxv = A.recvx.values;

	double omega = RelaxationFactor;

	if (!x0zero)
	{
		A.ExchangeHalo(x);
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		for (int i = 0; i < n; ++i)
		{
			double temp = bv[i];
			for (int j = Extp[i]; j < Extp[i + 1]; ++j)
				temp -= recvxv[Exti[j]] * Extv[j];
			for (int j = Ep[i]; j < Ep[i + 1]; ++j)
				temp -= xv[Ei[j]] * Ev[j];
			rv[i] = temp;
		}
	}
	else
		r.Copy(b);

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
	for (int t = 0; t < nthd; ++t)
	{
		int begin = t * n / nthd;
		int end = (t + 1) * n / nthd;

		int k = 0;

		if (x0zero)
		{
			++k;
			for (int i = begin; i < end; ++i)
				xv[i] = rv[i] * Drcpv[i] * omega;
		}

		if (k < step)
		{
			for (int i = begin; i < end; ++i)
			{
				double temp = 0.0;
				for (int j = Up[i]; j < Up[i + 1]; ++j)
					temp -= xv[Ui[j]] * Uv[j];
				wv[i] = temp;
			}

			for (int i = begin; i < end; ++i)
				zv[2 * i] = xv[i];

			while (1)
			{
				if (++k >= step)
				{
					for (int i = begin; i < end; ++i)
					{
						double temp = rv[i] + wv[i];
						for (int j = Lp[i]; j < Lp[i + 1]; ++j)
							temp -= zv[2 * Li[j]] * Lv[j];
						xv[i] = temp * Drcpv[i] * omega + zv[2 * i] * (1 - omega);
					}

					break;
				}
				else
				{
					for (int i = begin; i < end; ++i)
					{
						double temp1 = rv[i] + wv[i];
						double temp2 = rv[i];
						for (int j = Lp[i]; j < Lp[i + 1]; ++j)
						{
							temp1 -= zv[2 * Li[j]] * Lv[j];
							temp2 -= zv[1 + 2 * Li[j]] * Lv[j];
						}
						zv[1 + 2 * i] = temp1 * Drcpv[i] * omega + zv[2 * i] * (1 - omega);
						wv[i] = temp2;
					}
				}

				if (++k >= step)
				{
					for (int i = begin; i < end; ++i)
					{
						double temp = wv[i];
						for (int j = Up[i]; j < Up[i + 1]; ++j)
							temp -= zv[1 + 2 * Ui[j]] * Uv[j];
						xv[i] = temp * Drcpv[i] * omega + zv[1 + 2 * i] * (1 - omega);
					}

					break;
				}
				else
				{
					for (int i = end - 1; i >= begin; --i)
					{
						double temp1 = 0.0;
						double temp2 = wv[i];
						for (int j = Up[i + 1] - 1; j >= Up[i]; --j)
						{
							temp1 -= zv[2 * Ui[j]] * Uv[j];
							temp2 -= zv[1 + 2 * Ui[j]] * Uv[j];
						}
						wv[i] = temp1;
						zv[2 * i] = temp2 * Drcpv[i] * omega + zv[1 + 2 * i] * (1 - omega);
					}
				}
			}
		}
	}
}

ParCSRSmootherJacobiX::ParCSRSmootherJacobiX(double relaxation_factor)
	: nthd(0),
	RelaxationFactor(relaxation_factor)
{
}

void ParCSRSmootherJacobiX::Setup(const ParCSRMatrix& A, int REUSE)
{
	int n = A.local.size[0];
	int* Ap = A.local.rowptr;
	int* Ai = A.local.colind;
	double* Av = A.local.values;
	
	if (!REUSE)
	{
		w.comm = A.comm;
		z.comm = A.comm;
		w.Resize(n);
		z.Resize(2 * n);

		D.Resize(n);
		D_recip.Resize(n);

		nthd = 1;
#ifdef USE_ONED_PARTITION
		nthd = omp_get_max_threads();
#endif

		double* Dv = D.values;
		double* Drcpv = D_recip.values;

		int* Lp = new int[n + 1];
		int* Up = new int[n + 1];
		int* Ep = new int[n + 1];

		Lp[0] = 0;
		Up[0] = 0;
		Ep[0] = 0;
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		for (int t = 0; t < nthd; ++t)
		{
			int begin = t * n / nthd;
			int end = (t + 1) * n / nthd;

			for (int i = begin; i < end; ++i)
			{
				int cntl = 0;
				int cntu = 0;
				int cnte = 0;

				for (int j = Ap[i]; j < Ap[i + 1]; ++j)
				{
					int jcol = Ai[j];

					if (jcol >= begin && jcol < i) 
						++cntl;
					else if (jcol < end && jcol > i)
						++cntu;
					else if (jcol != i)
						++cnte;
				}

				Lp[i + 1] = cntl;
				Up[i + 1] = cntu;
				Ep[i + 1] = cnte;
			}
		}

		for (int i = 0; i < n;++i)
			Lp[i + 1] += Lp[i];
		for (int i = 0; i < n;++i)
			Up[i + 1] += Up[i];
		for (int i = 0; i < n;++i)
			Ep[i + 1] += Ep[i];

		int* Li = new int[Lp[n]];
		double* Lv = new double[Lp[n]];
		int* Ui = new int[Up[n]];
		double* Uv = new double[Up[n]];
		int* Ei = new int[Ep[n]];
		double* Ev = new double[Ep[n]];

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		for (int t = 0; t < nthd; ++t)
		{
			int begin = t * n / nthd;
			int end = (t + 1) * n / nthd;

			for (int i = begin; i < end; ++i)
			{
				for (int j = Ap[i], k = Lp[i], r = Up[i], s = Ep[i]; j < Ap[i + 1]; ++j)
				{
					int jcol = Ai[j];
					double jval = Av[j];

					if (jcol >= begin && jcol < i) 
					{
						Li[k] = jcol;
						Lv[k++] = jval;
					}
					else if (jcol < end && jcol > i)
					{
						Ui[r] = jcol;
						Uv[r++] = jval;
					}
					else if (jcol == i)
					{
						Dv[i] = jval;
						Drcpv[i] = 1.0 / jval;
					}
					else
					{
						Ei[s] = jcol;
						Ev[s++] = jval;
					}
				}
			}
		}

		L.size[0] = n;
		L.size[1] = n;
		L.rowptr = Lp;
		L.colind = Li;
		L.values = Lv;
		U.size[0] = n;
		U.size[1] = n;
		U.rowptr = Up;
		U.colind = Ui;
		U.values = Uv;
		E.size[0] = n;
		E.size[1] = n;
		E.rowptr = Ep;
		E.colind = Ei;
		E.values = Ev;
	}
	else
	{
		int* Lp = L.rowptr;
		int* Li = L.colind;
		double* Lv = L.values;
		int* Up = U.rowptr;
		int* Ui = U.colind;
		double* Uv = U.values;
		int* Ep = E.rowptr;
		int* Ei = E.colind;
		double* Ev = E.values;
		double* Dv = D.values;
		double* Drcpv = D_recip.values;
		
		int* w = new int[n];

		for (int i = 0; i < n; ++i)
			w[i] = -1;

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		for (int t = 0; t < nthd; ++t)
		{
			int begin = t * n / nthd;
			int end = (t + 1) * n / nthd;

			for (int i = begin; i < end; ++i)
			{
				int j0 = Ap[i];

				for (int j = Ap[i]; j < Ap[i + 1]; ++j)
					w[Ai[j]] = j;

				if (w[i] >= j0)
				{
					Dv[i] = Av[w[i]];
					Drcpv[i] = 1.0 / Av[w[i]];
				}

				for (int j = Lp[i]; j < Lp[i + 1]; ++j)
					if (w[Li[j]] >= j0) Lv[j] = Av[w[Li[j]]];
				for (int j = Up[i]; j < Up[i + 1]; ++j)
					if (w[Ui[j]] >= j0) Uv[j] = Av[w[Ui[j]]];
				for (int j = Ep[i]; j < Ep[i + 1]; ++j)
					if (w[Ei[j]] >= j0) Ev[j] = Av[w[Ei[j]]];
			}
		}
		
		delete[] w;	
	}
}

void ParCSRSmootherJacobiX::Pre_and_Resid(const ParCSRMatrix& A, const ParVector& b, const ParVector& x, const ParVector& r, int step, bool x0zero) const
{
	int n = A.local.size[0];
	int* Lp = L.rowptr;
	int* Li = L.colind;
	double* Lv = L.values;
	int* Up = U.rowptr;
	int* Ui = U.colind;
	double* Uv = U.values;
	int* Ep = E.rowptr;
	int* Ei = E.colind;
	double* Ev = E.values;
	int* Extp = A.exter.rowptr;
	int* Exti = A.exter.colind;
	double* Extv = A.exter.values;
	double* Dv = D.values;
	double* Drcpv = D_recip.values;
	double* xv = x.local.values;
	double* bv = b.local.values;
	double* wv = w.local.values;
	double* rv = r.local.values;
	double* zv = z.local.values;
	double* recvxv = A.recvx.values;

	MPI_Comm comm = A.comm;
	int nnb = A.nnb;
	int* nbrank = A.nbrank;
	int* recvptr = A.recvptr;
	int* sendptr = A.sendptr;
	int* sendind = A.sendind;
	double* sendbuf = A.sendbuf;

	MPI_Request* recvreq = new MPI_Request[nnb];
	MPI_Request* sendreq = new MPI_Request[nnb];
	MPI_Status status;

	double omega = RelaxationFactor;

	int k = 0;

	if (x0zero)
	{
		++k;
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		for (int i = 0; i < n; ++i)
			xv[i] = bv[i] * Drcpv[i] * omega;
	}

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
	for (int i = 0; i < n; ++i)
	{
		double temp = 0.0;
		for (int j = Up[i]; j < Up[i + 1]; ++j)
			temp -= xv[Ui[j]] * Uv[j];
		wv[i] = temp;
	}

	A.ExchangeHalo(x);
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
	for (int i = 0; i < n; ++i)
	{
		double temp = wv[i];
		for (int j = Extp[i]; j < Extp[i + 1]; ++j)
			temp -= recvxv[Exti[j]] * Extv[j];
		for (int j = Ep[i]; j < Ep[i + 1]; ++j)
			temp -= xv[Ei[j]] * Ev[j];
		wv[i] = temp;
	}

	if (k < step)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		for (int i = 0; i < n; ++i)
			zv[2 * i] = xv[i];

		while (1)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			for (int t = 0; t < nthd; ++t)
			{
				int begin = t * n / nthd;
				int end = (t + 1) * n / nthd;

				for (int i = begin; i < end; ++i)
				{
					double temp1 = bv[i] + wv[i];
					double temp2 = bv[i];
					for (int j = Lp[i]; j < Lp[i + 1]; ++j)
					{
						temp1 -= zv[2 * Li[j]] * Lv[j];
						temp2 -= zv[1 + 2 * Li[j]] * Lv[j];
					}
					zv[1 + 2 * i] = temp1 * Drcpv[i] * omega + zv[2 * i] * (1 - omega);
					wv[i] = temp2;
				}
			}

			for (int r = 0; r < nnb; ++r)
				if (recvptr[r + 1] > recvptr[r])
					MPI_Irecv(recvxv + recvptr[r], recvptr[r + 1] - recvptr[r], MPI_DOUBLE, nbrank[r], MPI_TAG, comm, recvreq + r);

			for (int r = 0; r < nnb; ++r)
			{
				if (sendptr[r + 1] > sendptr[r])
				{
					for (int i = sendptr[r]; i < sendptr[r + 1]; ++i)
						sendbuf[i] = zv[1 + 2 * sendind[i]];
					MPI_Isend(sendbuf + sendptr[r], sendptr[r + 1] - sendptr[r], MPI_DOUBLE, nbrank[r], MPI_TAG, comm, sendreq + r);
				}
			}

			for (int r = 0; r < nnb; ++r)
				if (recvptr[r + 1] > recvptr[r])
					MPI_Wait(recvreq + r, &status);

			for (int r = 0; r < nnb; ++r)
				if (sendptr[r + 1] > sendptr[r])
					MPI_Wait(sendreq + r, &status);
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				double temp = wv[i];
				for (int j = Extp[i]; j < Extp[i + 1]; ++j)
					temp -= recvxv[Exti[j]] * Extv[j];
				for (int j = Ep[i]; j < Ep[i + 1]; ++j)
					temp -= zv[1 + 2 * Ei[j]] * Ev[j];
				wv[i] = temp;
			}

			if (++k >= step)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				for (int i = 0; i < n; ++i)
					xv[i] = zv[1 + 2 * i];

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
				for (int i = 0; i < n; ++i)
				{
					double temp = wv[i];
					for (int j = Up[i]; j < Up[i + 1]; ++j)
						temp -= xv[Ui[j]] * Uv[j];
					rv[i] = temp - Dv[i] * xv[i];
				}

				break;
			}

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			for (int t = 0; t < nthd; ++t)
			{
				int begin = t * n / nthd;
				int end = (t + 1) * n / nthd;

				for (int i = end - 1; i >= begin; --i)
				{
					double temp1 = 0.0;
					double temp2 = wv[i];
					for (int j = Up[i + 1] - 1; j >= Up[i]; --j)
					{
						temp1 -= zv[2 * Ui[j]] * Uv[j];
						temp2 -= zv[1 + 2 * Ui[j]] * Uv[j];
					}
					wv[i] = temp1;
					zv[2 * i] = temp2 * Drcpv[i] * omega + zv[1 + 2 * i] * (1 - omega);
				}
			}

			for (int r = 0; r < nnb; ++r)
				if (recvptr[r + 1] > recvptr[r])
					MPI_Irecv(recvxv + recvptr[r], recvptr[r + 1] - recvptr[r], MPI_DOUBLE, nbrank[r], MPI_TAG, comm, recvreq + r);

			for (int r = 0; r < nnb; ++r)
			{
				if (sendptr[r + 1] > sendptr[r])
				{
					for (int i = sendptr[r]; i < sendptr[r + 1]; ++i)
						sendbuf[i] = zv[2 * sendind[i]];
					MPI_Isend(sendbuf + sendptr[r], sendptr[r + 1] - sendptr[r], MPI_DOUBLE, nbrank[r], MPI_TAG, comm, sendreq + r);
				}
			}

			for (int r = 0; r < nnb; ++r)
				if (recvptr[r + 1] > recvptr[r])
					MPI_Wait(recvreq + r, &status);

			for (int r = 0; r < nnb; ++r)
				if (sendptr[r + 1] > sendptr[r])
					MPI_Wait(sendreq + r, &status);
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				double temp = wv[i];
				for (int j = Extp[i]; j < Extp[i + 1]; ++j)
					temp -= recvxv[Exti[j]] * Extv[j];
				for (int j = Ep[i]; j < Ep[i + 1]; ++j)
					temp -= zv[2 * Ei[j]] * Ev[j];
				wv[i] = temp;
			}

			if (++k >= step)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel
#endif
				for (int i = 0; i < n; ++i)
					xv[i] = zv[2 * i];

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
				for (int i = 0; i < n; ++i)
				{
					double temp = bv[i] + wv[i];
					for (int j = Lp[i]; j < Lp[i + 1]; ++j)
						temp -= xv[Li[j]] * Lv[j];
					rv[i] = temp - Dv[i] * xv[i];
				}

				break;
			}
		}
	}
	else
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		for (int i = 0; i < n; ++i)
		{
			double temp = bv[i] + wv[i];
			for (int j = Lp[i]; j < Lp[i + 1]; ++j)
				temp -= xv[Li[j]] * Lv[j] - Dv[i] * xv[i];
			rv[i] = temp;
		}
	}

	delete[] recvreq;
	delete[] sendreq;
	
}

void ParCSRSmootherJacobiX::operator()(const ParCSRMatrix& A, const ParVector& b, const ParVector& x, int step, bool x0zero) const
{
	int n = A.local.size[0];
	int* Lp = L.rowptr;
	int* Li = L.colind;
	double* Lv = L.values;
	int* Up = U.rowptr;
	int* Ui = U.colind;
	double* Uv = U.values;
	int* Ep = E.rowptr;
	int* Ei = E.colind;
	double* Ev = E.values;
	int* Extp = A.exter.rowptr;
	int* Exti = A.exter.colind;
	double* Extv = A.exter.values;
	double* Drcpv = D_recip.values;
	double* xv = x.local.values;
	double* bv = b.local.values;
	double* wv = w.local.values;
	double* zv = z.local.values;
	double* recvxv = A.recvx.values;

	MPI_Comm comm = A.comm;
	int nnb = A.nnb;
	int* nbrank = A.nbrank;
	int* recvptr = A.recvptr;
	int* sendptr = A.sendptr;
	int* sendind = A.sendind;
	double* sendbuf = A.sendbuf;

	MPI_Request* recvreq = new MPI_Request[nnb];
	MPI_Request* sendreq = new MPI_Request[nnb];
	MPI_Status status;

	double omega = RelaxationFactor;

	int k = 0;

	if (x0zero)
	{
		++k;
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		for (int i = 0; i < n; ++i)
			xv[i] = bv[i] * Drcpv[i] * omega;
	}

	if (k < step)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		for (int i = 0; i < n; ++i)
		{
			double temp = 0.0;
			for (int j = Up[i]; j < Up[i + 1]; ++j)
				temp -= xv[Ui[j]] * Uv[j];
			wv[i] = temp;
		}

		A.ExchangeHalo(x);
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		for (int i = 0; i < n; ++i)
		{
			double temp = wv[i];
			for (int j = Extp[i]; j < Extp[i + 1]; ++j)
				temp -= recvxv[Exti[j]] * Extv[j];
			for (int j = Ep[i]; j < Ep[i + 1]; ++j)
				temp -= xv[Ei[j]] * Ev[j];
			wv[i] = temp;
		}

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		for (int i = 0; i < n; ++i)
			zv[2 * i] = xv[i];

		while (1)
		{
			if (++k >= step)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
				for (int i = 0; i < n; ++i)
				{
					double temp = bv[i] + wv[i];
					for (int j = Lp[i]; j < Lp[i + 1]; ++j)
						temp -= zv[2 * Li[j]] * Lv[j];
					xv[i] = temp * Drcpv[i] * omega + zv[2 * i] * (1 - omega);
				}

				break;
			}
			else
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				for (int t = 0; t < nthd; ++t)
				{
					int begin = t * n / nthd;
					int end = (t + 1) * n / nthd;

					for (int i = begin; i < end; ++i)
					{
						double temp1 = bv[i] + wv[i];
						double temp2 = bv[i];
						for (int j = Lp[i]; j < Lp[i + 1]; ++j)
						{
							temp1 -= zv[2 * Li[j]] * Lv[j];
							temp2 -= zv[1 + 2 * Li[j]] * Lv[j];
						}
						zv[1 + 2 * i] = temp1 * Drcpv[i] * omega + zv[2 * i] * (1 - omega);
						wv[i] = temp2;
					}
				}

				for (int r = 0; r < nnb; ++r)
					if (recvptr[r + 1] > recvptr[r])
						MPI_Irecv(recvxv + recvptr[r], recvptr[r + 1] - recvptr[r], MPI_DOUBLE, nbrank[r], MPI_TAG, comm, recvreq + r);

				for (int r = 0; r < nnb; ++r)
				{
					if (sendptr[r + 1] > sendptr[r])
					{
						for (int i = sendptr[r]; i < sendptr[r + 1]; ++i)
							sendbuf[i] = zv[1 + 2 * sendind[i]];
						MPI_Isend(sendbuf + sendptr[r], sendptr[r + 1] - sendptr[r], MPI_DOUBLE, nbrank[r], MPI_TAG, comm, sendreq + r);
					}
				}

				for (int r = 0; r < nnb; ++r)
					if (recvptr[r + 1] > recvptr[r])
						MPI_Wait(recvreq + r, &status);

				for (int r = 0; r < nnb; ++r)
					if (sendptr[r + 1] > sendptr[r])
						MPI_Wait(sendreq + r, &status);

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
				for (int i = 0; i < n; ++i)
				{
					double temp = wv[i];
					for (int j = Extp[i]; j < Extp[i + 1]; ++j)
						temp -= recvxv[Exti[j]] * Extv[j];
					for (int j = Ep[i]; j < Ep[i + 1]; ++j)
						temp -= zv[1 + 2 * Ei[j]] * Ev[j];
					wv[i] = temp;
				}
			}

			if (++k >= step)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
				for (int i = 0; i < n; ++i)
				{
					double temp = wv[i];
					for (int j = Up[i]; j < Up[i + 1]; ++j)
						temp -= zv[1 + 2 * Ui[j]] * Uv[j];
					xv[i] = temp * Drcpv[i] * omega + zv[1 + 2 * i] * (1 - omega);
				}

				break;
			}
			else
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				for (int t = 0; t < nthd; ++t)
				{
					int begin = t * n / nthd;
					int end = (t + 1) * n / nthd;

					for (int i = begin; i < end; ++i)
					{
						double temp1 = 0.0;
						double temp2 = wv[i];
						for (int j = Up[i + 1] - 1; j >= Up[i]; --j)
						{
							temp1 -= zv[2 * Ui[j]] * Uv[j];
							temp2 -= zv[1 + 2 * Ui[j]] * Uv[j];
						}
						wv[i] = temp1;
						zv[2 * i] = temp2 * Drcpv[i] * omega + zv[1 + 2 * i] * (1 - omega);
					}
				}

				for (int r = 0; r < nnb; ++r)
					if (recvptr[r + 1] > recvptr[r])
						MPI_Irecv(recvxv + recvptr[r], recvptr[r + 1] - recvptr[r], MPI_DOUBLE, nbrank[r], MPI_TAG, comm, recvreq + r);

				for (int r = 0; r < nnb; ++r)
				{
					if (sendptr[r + 1] > sendptr[r])
					{
						for (int i = sendptr[r]; i < sendptr[r + 1]; ++i)
							sendbuf[i] = zv[2 * sendind[i]];
						MPI_Isend(sendbuf + sendptr[r], sendptr[r + 1] - sendptr[r], MPI_DOUBLE, nbrank[r], MPI_TAG, comm, sendreq + r);
					}
				}

				for (int r = 0; r < nnb; ++r)
					if (recvptr[r + 1] > recvptr[r])
						MPI_Wait(recvreq + r, &status);

				for (int r = 0; r < nnb; ++r)
					if (sendptr[r + 1] > sendptr[r])
						MPI_Wait(sendreq + r, &status);
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
				for (int i = 0; i < n; ++i)
				{
					double temp = wv[i];
					for (int j = Extp[i]; j < Extp[i + 1]; ++j)
						temp -= recvxv[Exti[j]] * Extv[j];
					for (int j = Ep[i]; j < Ep[i + 1]; ++j)
						temp -= zv[2 * Ei[j]] * Ev[j];
					wv[i] = temp;
				}
			}
		}
	}

	delete[] recvreq;
	delete[] sendreq;
}

}