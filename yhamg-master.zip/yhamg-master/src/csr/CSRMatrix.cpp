/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <stdio.h>
#include "blas.hpp"
#include "spblas.hpp"
#include "CSRMatrix.hpp"

#ifdef YHAMG_USE_OPENMP
#include <omp.h>
#endif

namespace YHAMG
{

CSRMatrix::CSRMatrix()
	: ref(0),
	size{0, 0},
	rowptr(0),
	colind(0),
	values(0)
{
}


CSRMatrix::CSRMatrix(int _n, int _m, int* _rowptr, int* _colind, double* _values, int _ref)
	: ref(_ref),
	size{_n, _m},
	rowptr(_rowptr),
	colind(_colind),
	values(_values)
{
}

CSRMatrix::CSRMatrix(const COOMatrix& A)
	: ref(0),
	rowptr(new int[A.size[0] + 1]),
	colind(new int[A.nnz]),
	values(new double[A.nnz])
{
	int nnz = A.nnz;
	int* Ai = A.rowind;
	int* Aj = A.colind;
	double* Av = A.values;

	size[0] = A.size[0];
	size[1] = A.size[1];

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
	for (int i = 0; i <= size[0]; ++i)
		rowptr[i] = 0;

	for (int j = 0; j < nnz; ++j)
		++rowptr[Ai[j]];

	for (int i = 0; i < size[0]; ++i)
		rowptr[i + 1] += rowptr[i];

	for (int j = nnz - 1; j >= 0; --j)
	{
		colind[--rowptr[Ai[j]]] = Aj[j];
		values[rowptr[Ai[j]]] = Av[j];
	}
}

CSRMatrix::CSRMatrix(const CSRMatrix& A)
	: ref(0),
	size{A.size[0], A.size[1]},
	rowptr(new int[A.size[0] + 1]),
	colind(new int[A.rowptr[A.size[0]]]),
	values(new double[A.rowptr[A.size[0]]])
{
	int* Ap = A.rowptr;
	int* Ai = A.colind;
	double* Av = A.values;

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
	for (int i = 0; i <= size[0]; ++i)
		rowptr[i] = Ap[i];

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
	for (int j = 0; j < Ap[size[0]]; ++j)
	{
		colind[j] = Ai[j];
		values[j] = Av[j];
	}
}

CSRMatrix::CSRMatrix(CSRMatrix&& A)
	: ref(A.ref),
	size{A.size[0], A.size[1]},
	rowptr(A.rowptr),
	colind(A.colind),
	values(A.values)
{
	A.ref = 1;
}

CSRMatrix::~CSRMatrix()
{
	if (!ref)
	{
		if (rowptr) delete[] rowptr;
		if (colind) delete[] colind;
		if (values) delete[] values;
	}
}

CSRMatrix& CSRMatrix::operator=(const COOMatrix& A)
{
	Free();

	int nnz = A.nnz;
	int* Ai = A.rowind;
	int* Aj = A.colind;
	double* Av = A.values;

	size[0] = A.size[0];
	size[1] = A.size[1];

	rowptr = new int[size[0] + 1];
	colind = new int[nnz];
	values = new double[nnz];

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
	for (int i = 0; i <= size[0]; ++i)
		rowptr[i] = 0;

	for (int j = 0; j < nnz; ++j)
		++rowptr[Ai[j]];

	for (int i = 0; i < size[0]; ++i)
		rowptr[i + 1] += rowptr[i];

	for (int j = nnz - 1; j >= 0; --j)
	{
		colind[--rowptr[Ai[j]]] = Aj[j];
		values[rowptr[Ai[j]]] = Av[j];
	}

	return *this;
}

CSRMatrix& CSRMatrix::operator=(const CSRMatrix& A)
{
	Free();

	int* Ap = A.rowptr;
	int* Ai = A.colind;
	double* Av = A.values;

	size[0] = A.size[0];
	size[1] = A.size[1];

	rowptr = new int[size[0] + 1];
	colind = new int[Ap[size[0]]];
	values = new double[Ap[size[0]]];
	
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
	for (int i = 0; i <= size[0]; ++i)
		rowptr[i] = Ap[i];

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
	for (int j = 0; j < Ap[size[0]]; ++j)
	{
		colind[j] = Ai[j];
		values[j] = Av[j];
	}

	return *this;
}

CSRMatrix& CSRMatrix::operator=(CSRMatrix&& A)
{
	Free();

	ref = A.ref;
	size[0] = A.size[0];
	size[1] = A.size[1];
	rowptr = A.rowptr;
	colind = A.colind;
	values = A.values;

	A.ref = 1;

	return *this;
}

void CSRMatrix::Free()
{
	if (!ref)
	{
		if (rowptr) delete[] rowptr;
		if (colind) delete[] colind;
		if (values) delete[] values;
	}
	size[0] = 0;
	size[1] = 0;
	rowptr = 0;
	colind = 0;
	values = 0;
	ref = 0;
}

void CSRMatrix::Refer(const CSRMatrix& A)
{
	if (!ref)
	{
		if (rowptr) delete[] rowptr;
		if (colind) delete[] colind;
		if (values) delete[] values;
	}
	size[0] = A.size[0];
	size[1] = A.size[1];
	rowptr = A.rowptr;
	colind = A.colind;
	values = A.values;
	ref = 1;
}

int CSRMatrix::InSize() const
{
	return size[1];
}

int CSRMatrix::OutSize() const
{
	return size[0];
}

void CSRMatrix::Apply(const Vector& x, const Vector& y) const
{
	CSRMatVec(1.0, *this, x, 0.0, y);;
}

void CSRMatrix::Apply(const MultiVector& X, const MultiVector& Y) const
{
	CSRMatMultiVec(1.0, *this, X, 0.0, Y);
}

void CSRRead(const char* filename, CSRMatrix& A)
{
	COOMatrix B;
	COORead(filename, B);
	A = B;
}

void CSRWrite(const char* filename, const CSRMatrix& A)
{
	int n = A.size[0];
	int m = A.size[1];
	int nz = A.rowptr[A.size[0]];

	int* Ap = A.rowptr;
	int* Ai = A.colind;
	double* Av = A.values;

	FILE* f = fopen(filename, "w");

	fprintf(f, "%d %d %d\n", n, m, nz);

	for (int i = 0; i < n; ++i)
		for (int j = Ap[i]; j < Ap[i + 1];++j)
			fprintf(f, "%d %d %20.16g\n", i + 1, Ai[j] + 1, Av[j]);

	fclose(f);
}

void CSRDiag(const CSRMatrix& A, const Vector& D)
{
	int n = A.size[0];
	int* Ap = A.rowptr;
	int* Ai = A.colind;
	double* Av = A.values;
	double* Dv = D.values;

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
	for (int i = 0; i < n; ++i)
	{
		double diag = 0.0;
		for (int j = Ap[i]; j < Ap[i + 1]; ++j)
		{
			if (Ai[j] == i)
			{
				diag = Av[j];
				break;
			}
		}
		Dv[i] = diag;
	}
}

void CSREliminZeros(const CSRMatrix& A)
{
	int n = A.size[0];
	int* Ap = A.rowptr;
	int* Ai = A.colind;
	double* Av = A.values;

	for (int i = 0, j = 0, k = 0; i < n; Ap[++i] = k)
	{
		for ( ; j < Ap[i + 1]; ++j)
		{
			if (Av[j])
			{
				Ai[k] = Ai[j];
				Av[k++] = Av[j];
			}
		}
	}
}

void CSRScale(double alpha, const CSRMatrix& A)
{
	int n = A.size[0];
	int* Ap = A.rowptr;
	double* Av = A.values;
	blas_dscal(Ap[n], alpha, Av);
}

void CSRScaleRows(const Vector& x, const CSRMatrix& A)
{
	int n = A.size[0];
	int* Ap = A.rowptr;
	double* Av = A.values;
	double* xv = x.values;
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
	for (int i = 0; i < n; ++i)
		for (int j = Ap[i]; j < Ap[i + 1]; ++j)
			Av[j] *= xv[i];
}

void CSRScaleCols(const Vector& x, const CSRMatrix& A)
{
	int n = A.size[0];
	int* Ap = A.rowptr;
	int* Ai = A.colind;
	double* Av = A.values;
	double* xv = x.values;
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
	for (int i = 0; i < n; ++i)
		for (int j = Ap[i]; j < Ap[i + 1]; ++j)
			Av[j] *= xv[Ai[j]];
}

void CSRMatAdd(const CSRMatrix& A, const CSRMatrix& B, CSRMatrix& C)
{
	int n = A.size[0];
	int m = B.size[1];
	int* Ap = A.rowptr;
	int* Ai = A.colind;
	double* Av = A.values;
	int* Bp = B.rowptr;
	int* Bi = B.colind;
	double* Bv = B.values;

	int* Cp = new int[n + 1];
	Cp[0] = 0;
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel
#endif
	{
		int* w = new int[m];
		for (int i = 0; i < m; ++i)
			w[i] = -1;

#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
		for (int i = 0; i < n; ++i)
		{
			int cnt = Ap[i + 1] - Ap[i];

			for (int j = Ap[i]; j < Ap[i + 1]; ++j)
				w[Ai[j]] = i;

			for (int j = Bp[i]; j < Bp[i + 1]; ++j)
			{
				if (w[Bi[j]] != i)
				{
					w[Bi[j]] = i;
					++cnt;
				}
			}

			Cp[i + 1] = cnt;
		}

		delete[] w;
	}

	for (int i = 0; i < n; ++i)
		Cp[i + 1] += Cp[i];

	int* Ci = new int[Cp[n]];
	double* Cv = new double[Cp[n]];

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel
#endif
	{
		int* w = new int[m];
		for (int i = 0; i < m; ++i)
			w[i] = -1;
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
		for (int i = 0; i < n; ++i)
		{
			int r = Cp[i], r0 = Cp[i];

			for (int j = Ap[i]; j < Ap[i + 1]; ++j)
			{
				w[Ai[j]] = r;
				Ci[r] = Ai[j];
				Cv[r++] = Av[j];
			}

			for (int j = Bp[i]; j < Bp[i + 1]; ++j)
			{
				if (w[Bi[j]] < r0)
				{
					w[Bi[j]] = r;
					Ci[r] = Bi[j];
					Cv[r++] = Bv[j];
				}
				else
					Cv[w[Bi[j]]] += Bv[j];
			}
		}

		delete[] w;
	}

	C.Free();

	C.size[0] = n;
	C.size[1] = m;
	C.rowptr = Cp;
	C.colind = Ci;
	C.values = Cv;
}

void CSRMatMul(const CSRMatrix& A, const CSRMatrix& B, CSRMatrix& C)
{
	int n = A.size[0];
	int m = B.size[1];
	int* Ap = A.rowptr;
	int* Ai = A.colind;
	double* Av = A.values;
	int* Bp = B.rowptr;
	int* Bi = B.colind;
	double* Bv = B.values;

	int* Cp = new int[n + 1];
	Cp[0] = 0;
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel
#endif
	{
		int* w = new int[m];
		for (int i = 0; i < m; ++i)
			w[i] = -1;
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
		for (int i = 0; i < n; ++i)
		{
			int cnt = 0;
			for (int k = Ap[i]; k < Ap[i + 1]; ++k)
			{
				int kcol = Ai[k];
				for (int j = Bp[kcol]; j < Bp[kcol + 1]; ++j)
				{
					int jcol = Bi[j];
					if (w[jcol] != i)
					{
						w[jcol] = i;
						++cnt;
					}
				}
			}
			Cp[i + 1] = cnt;
		}
		delete[] w;
	}

	for (int i = 0; i < n; ++i)
		Cp[i + 1] += Cp[i];

	int* Ci = new int[Cp[n]];
	double* Cv = new double[Cp[n]];

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel
#endif
	{
		int* w = new int[m];
		for (int i = 0; i < m; ++i)
			w[i] = -1;
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
		for (int i = 0; i < n; ++i)
		{
			for (int k = Ap[i], r = Cp[i], r0 = Cp[i]; k < Ap[i + 1]; ++k)
			{
				int kcol = Ai[k];
				double kval = Av[k];
				for (int j = Bp[kcol]; j < Bp[kcol + 1]; ++j)
				{
					int jcol = Bi[j];
					double jval = Bv[j];
					if (w[jcol] < r0)
					{
						w[jcol] = r;
						Ci[r] = jcol;
						Cv[r++] = kval * jval;
					}
					else
						Cv[w[jcol]] += kval * jval;
				}
			}
		}
		delete[] w;
	}

	C.Free();

	C.size[0] = n;
	C.size[1] = m;
	C.rowptr = Cp;
	C.colind = Ci;
	C.values = Cv;
}

void CSRMatVec(double alpha, const CSRMatrix& A, const Vector& x, double beta, const Vector& y)
{
	int n = A.size[0];
	int* Ap = A.rowptr;
	int* Ai = A.colind;
	double* Av = A.values;
	double* xv = x.values;
	double* yv = y.values;

	spblas_dcsrmv(n, alpha, Ap, Ai, Av, xv, beta, yv);
}

void CSRMatMultiVec(double alpha, const CSRMatrix& A, const MultiVector& X, double beta, const MultiVector& Y)
{
	int n = A.size[0];
	int m = X.nvec;
	int nx = X.size;
	int ny = Y.size;
	int* Ap = A.rowptr;
	int* Ai = A.colind;
	double* Av = A.values;
	double* Xv = X.values;
	double* Yv = Y.values;
	
	spblas_dcsrmm(n, m, alpha, Ap, Ai, Av, nx, Xv, beta, ny, Yv);
}

void CSRTrans(const CSRMatrix& A, CSRMatrix& B)
{
	int n = A.size[0];
	int m = A.size[1];
	int* Ap = A.rowptr;
	int* Ai = A.colind;
	double* Av = A.values;

	int* Bp = new int[m + 1];
	int* Bi = new int[Ap[n]];
	double* Bv = new double[Ap[n]];

	int nthd = 1;
#ifdef YHAMG_USE_OPENMP
	nthd = omp_get_max_threads();
#endif

	if (nthd == 1)
	{
		for (int i = 0; i <= m; ++i)
		Bp[i] = 0;

		for (int j = Ap[0]; j < Ap[n]; ++j)
			++Bp[Ai[j]];

		for (int i = 0; i < m; ++i)
			Bp[i + 1] += Bp[i];

		for (int i = n - 1; i >= 0; --i)
		{
			for (int j = Ap[i + 1] - 1; j >= Ap[i]; --j)
			{
				Bi[--Bp[Ai[j]]] = i;
				Bv[Bp[Ai[j]]] = Av[j];
			}
		}
	}
	else
	{
		int*  _offsets = new int[m * nthd];
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		for (int i = 0; i < m * nthd; ++i)
			_offsets[i] = 0;

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		for (int t = 0; t < nthd; ++t)
		{
			int start = n * t / nthd;
			int end = n * (t + 1) / nthd;
			for (int j = Ap[start]; j < Ap[end]; ++j)
				++_offsets[Ai[j] * nthd + t];
		}

		if (nthd > 2)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			for (int t = 0; t < nthd; ++t)
			{
				int start = m * t;
				int end = m * (t + 1);

				for (int i = start + 1; i < end; ++i)
					_offsets[i] += _offsets[i - 1];
			}

			for (int t = 1; t < nthd; ++t)
			{
				int start = m * t;
				int end = m * (t + 1);
				_offsets[end - 1] += _offsets[start - 1];
			}

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			for (int t = 1; t < nthd; ++t)
			{
				int start = m * t;
				int end = m * (t + 1);
				for (int i = start; i < end - 1; ++i)
					_offsets[i] += _offsets[start - 1];
			}
		}
		else
		{
			for (int i = 1; i < m * nthd; ++i)
				_offsets[i] += _offsets[i - 1];
		}

		Bp[0] = 0;
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		for (int i = 1; i <= m; ++i)
			Bp[i] = _offsets[i * nthd - 1];

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		for (int t = 0; t < nthd; ++t)
		{
			int start = n * t / nthd;
			int end = n * (t + 1) / nthd;
			for (int i = end - 1; i >= start; --i)
			{
				for (int j = Ap[i + 1] - 1; j >= Ap[i]; --j)
				{
					Bi[--_offsets[Ai[j] * nthd + t]] = i;
					Bv[_offsets[Ai[j] * nthd + t]] = Av[j];
				}
			}
		}
		
		delete[] _offsets;
	}

	B.Free();
	B.size[0] = m;
	B.size[1] = n;
	B.rowptr = Bp;
	B.colind = Bi;
	B.values = Bv;
}

}
