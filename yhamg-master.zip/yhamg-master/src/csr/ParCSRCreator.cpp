/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "ParCSRCreator.hpp"

namespace YHAMG
{

ParCSRCreator::ParCSRCreator(MPI_Comm _comm, int n, int m)
	: comm(_comm),
	size{n, m}
{
}

void ParCSRCreator::operator()(ParCSRMatrix& A) const
{
	A.Free();
	A.comm = comm;
	A.local.size[0] = size[0];
	A.local.size[1] = size[1];
	A.local.rowptr = new int[size[0] + 1];
	for (int i = 0; i <= size[0]; ++i)
		A.local.rowptr[i] = 0;
	A.local.colind = 0;
	A.local.values = 0;
	A.exter.size[0] = size[0];
	A.exter.size[1] = 0;
	A.exter.rowptr = new int[size[0] + 1];
	for (int i = 0; i <= size[0]; ++i)
		A.exter.rowptr[i] = 0;
	A.exter.colind = 0;
	A.exter.values = 0;
	A.nnb = 0;
	A.nbrank = 0;
	A.recvptr = new int[1];
	A.recvptr[0] = 0;
	A.recvind = 0;
}

}