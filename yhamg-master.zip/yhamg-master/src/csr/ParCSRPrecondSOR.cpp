/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <set>
#include "ParCSRPrecondSOR.hpp"

namespace YHAMG
{

ParCSRPrecondSOR::ParCSRPrecondSOR(int relaxation_type, double relaxation_factor)
	: interior(0),
	label(0),
	nnb(0),
	nblab(0),
	nbrank(0),
	recvptr(0),
	sendptr(0),
	sendind(0),
	sendbuf(0),
	RelaxationType(relaxation_type),
	RelaxationFactor(relaxation_factor)
{
}

ParCSRPrecondSOR::~ParCSRPrecondSOR()
{
	if (interior) delete[] interior;
	if (nblab) delete[] nblab;
	if (recvptr) delete[] recvptr;
	if (sendptr) delete[] sendptr;
	if (sendind) delete[] sendind;
	if (sendbuf) delete[] sendbuf;
}

void ParCSRPrecondSOR::Free()
{
	D_local_recip.Free();
	L_local.Free();
	L_exter.Free();
	U_local.Free();
	U_exter.Free();
	recvx.Free();
	if (interior) delete[] interior;
	if (nblab) delete[] nblab;
	if (recvptr) delete[] recvptr;
	if (sendptr) delete[] sendptr;
	if (sendind) delete[] sendind;
	if (sendbuf) delete[] sendbuf;
	comm = 0;
	label = 0;
	nnb = 0;
	interior = 0;
	nblab = 0;
	recvptr = 0;
	sendptr = 0;
	sendind = 0;
	sendbuf = 0;
}

#define MPI_TAG 500

void ParCSRPrecondSOR::Setup(const ParCSRMatrix& A, int REUSE)
{
	int n = A.local.size[0];
	int recvcnt = A.exter.size[1];

	int* A_local_rowptr = A.local.rowptr;
	int* A_local_colind = A.local.colind;
	double* A_local_values = A.local.values;
	int* A_exter_rowptr = A.exter.rowptr;
	int* A_exter_colind = A.exter.colind;
	double* A_exter_values = A.exter.values;

	int* recvind = A.recvind;

	if (!REUSE)
	{
		Free();

		comm = A.comm;

		int comm_rank;
		MPI_Comm_rank(comm, &comm_rank);

		nnb = A.nnb;
		nbrank = new int[nnb];
		recvptr = new int[nnb + 1];
		sendptr = new int[nnb + 1];
		sendind = new int[A.sendptr[nnb]];
		sendbuf = new double[A.sendptr[nnb]];

		for (int r = 0; r < nnb; ++r)
			nbrank[r] = A.nbrank[r];
		for (int r = 0; r <= nnb; ++r)
			recvptr[r] = A.recvptr[r];
		for (int r = 0; r <= nnb; ++r)
			sendptr[r] = A.sendptr[r];
		for (int i = 0; i < A.sendptr[nnb]; ++i)
			sendind[i] = A.sendind[i];

		interior = new bool[n];
		for (int i = 0; i < n; ++i)
			interior[i] = A_exter_rowptr[i + 1] == A_exter_rowptr[i];
		for (int i = 0; i < sendptr[nnb]; ++i)
			interior[sendind[i]] = 0;

		MPI_Request* recvreq = new MPI_Request[nnb];
		MPI_Request* sendreq = new MPI_Request[nnb];
		MPI_Status status;

		label = 0;
		nblab = new int[nnb];

		std::set<int> label_set;

		for (int r = 0; r < nnb; ++r)
			MPI_Irecv(nblab + r, 1, MPI_INT, nbrank[r], MPI_TAG, comm, recvreq + r);

		for (int r = 0; r < nnb; ++r)
		{
			if (comm_rank > nbrank[r])
			{
				MPI_Wait(recvreq + r, &status);
				label_set.insert(nblab[r]);
			}
		}

		for (std::set<int>::iterator iter = label_set.begin(); iter != label_set.end(); ++iter, ++label)
			if (*iter != label) break;

		for (int r = 0; r < nnb; ++r)
			MPI_Send(&label, 1, MPI_INT, nbrank[r], MPI_TAG, comm);

		for (int r = 0; r < nnb; ++r)
			if (comm_rank < nbrank[r])
				MPI_Wait(recvreq + r, &status);

		delete[] recvreq;
		delete[] sendreq;

		int* recvfrom = new int[recvcnt];
		for (int r = 0; r < nnb; ++r)
			for (int i = recvptr[r]; i < recvptr[r + 1]; ++i)
				recvfrom[i] = r;

		D_local_recip.Resize(n);
		double* D_local_recip_values = D_local_recip.values;

		int* L_local_rowptr = new int[n + 1];
		int* U_local_rowptr = new int[n + 1];
		int* L_exter_rowptr = new int[n + 1];
		int* U_exter_rowptr = new int[n + 1];

		L_local_rowptr[0] = 0;
		U_local_rowptr[0] = 0;
		L_exter_rowptr[0] = 0;
		U_exter_rowptr[0] = 0;

		for (int i = 0, cntlocl = 0, cntlocu = 0, cntextl = 0, cntextu = 0; i < n; L_local_rowptr[++i] = cntlocl, U_local_rowptr[i] = cntlocu, L_exter_rowptr[i] = cntextl, U_exter_rowptr[i] = cntextu)
		{
			if (interior[i])
			{
				for (int j = A_local_rowptr[i]; j < A_local_rowptr[i + 1]; ++j)
				{
					int jcol = A_local_colind[j];

					if (jcol < i && interior[jcol])
						++cntlocl;
					else if (jcol != i)
						++cntlocu;
				}
			}
			else
			{
				for (int j = A_local_rowptr[i]; j < A_local_rowptr[i + 1]; ++j)
				{
					int jcol = A_local_colind[j];

					if (jcol < i || interior[jcol])
						++cntlocl;
					else if (jcol != i)
						++cntlocu;
				}

				for (int j = A_exter_rowptr[i]; j < A_exter_rowptr[i + 1]; ++j)
				{
					int jcol = A_exter_colind[j];
					int jfrom = recvfrom[jcol];

					if (label > nblab[jfrom])
						++cntextl;
					else
						++cntextu;
				}
			}
		}

		int* L_local_colind = new int[L_local_rowptr[n]];
		double* L_local_values = new double[L_local_rowptr[n]];
		int* U_local_colind = new int[U_local_rowptr[n]];
		double* U_local_values = new double[U_local_rowptr[n]];
		int* L_exter_colind = new int[L_exter_rowptr[n]];
		double* L_exter_values = new double[L_exter_rowptr[n]];
		int* U_exter_colind = new int[U_exter_rowptr[n]];
		double* U_exter_values = new double[U_exter_rowptr[n]];

		for (int i = 0; i < n; ++i)
		{
			if (interior[i])
			{
				for (int j = A_local_rowptr[i], k = L_local_rowptr[i], r = U_local_rowptr[i]; j < A_local_rowptr[i + 1]; ++j)
				{
					int jcol = A_local_colind[j];
					double jval = A_local_values[j];

					if (jcol < i && interior[jcol])
					{
						L_local_colind[k] = jcol;
						L_local_values[k++] = jval;
					}
					else if (jcol != i)
					{
						U_local_colind[r] = jcol;
						U_local_values[r++] = jval;
					}
					else
						D_local_recip_values[i] = 1.0 / jval;
				}
			}
			else
			{
				for (int j = A_local_rowptr[i], k = L_local_rowptr[i], r = U_local_rowptr[i]; j < A_local_rowptr[i + 1]; ++j)
				{
					int jcol = A_local_colind[j];
					double jval = A_local_values[j];

					if (jcol < i || interior[jcol])
					{
						L_local_colind[k] = jcol;
						L_local_values[k++] = jval;
					}
					else if (jcol != i)
					{
						U_local_colind[r] = jcol;
						U_local_values[r++] = jval;
					}
					else
						D_local_recip_values[i] = 1.0 / jval;
				}

				for (int j = A_exter_rowptr[i], k = L_exter_rowptr[i], r = U_exter_rowptr[i]; j < A_exter_rowptr[i + 1]; ++j)
				{
					int jcol = A_exter_colind[j];
					double jval = A_exter_values[j];
					int jfrom = recvfrom[jcol];

					if (label > nblab[jfrom])
					{
						L_exter_colind[k] = jcol;
						L_exter_values[k++] = jval;
					}
					else
					{
						U_exter_colind[r] = jcol;
						U_exter_values[r++] = jval;
					}
				}
			}
		}

		delete[] recvfrom;

		L_local.size[0] = n;
		L_local.size[1] = n;
		L_local.rowptr = L_local_rowptr;
		L_local.colind = L_local_colind;
		L_local.values = L_local_values;

		L_exter.size[0] = n;
		L_exter.size[1] = recvcnt;
		L_exter.rowptr = L_exter_rowptr;
		L_exter.colind = L_exter_colind;
		L_exter.values = L_exter_values;

		U_local.size[0] = n;
		U_local.size[1] = n;
		U_local.rowptr = U_local_rowptr;
		U_local.colind = U_local_colind;
		U_local.values = U_local_values;

		U_exter.size[0] = n;
		U_exter.size[1] = recvcnt;
		U_exter.rowptr = U_exter_rowptr;
		U_exter.colind = U_exter_colind;
		U_exter.values = U_exter_values;

		recvx.Resize(recvcnt);
	}
	else
	{
		int* L_local_rowptr = L_local.rowptr;
		int* L_local_colind = L_local.colind;
		double* L_local_values = L_local.values;
		int* U_local_rowptr = U_local.rowptr;
		int* U_local_colind = U_local.colind;
		double* U_local_values = U_local.values;
		int* L_exter_rowptr = L_exter.rowptr;
		int* L_exter_colind = L_exter.colind;
		double* L_exter_values = L_exter.values;
		int* U_exter_rowptr = U_exter.rowptr;
		int* U_exter_colind = U_exter.colind;
		double* U_exter_values = U_exter.values;
		double* D_local_recip_values = D_local_recip.values;

		int* w = new int[n];
		int* v = new int[recvcnt];

		for (int i = 0; i < n; ++i)
			w[i] = -1;
		for (int i = 0; i < recvcnt; ++i)
			v[i] = -1;

		for (int i = 0; i < n; ++i)
		{
			int j0 = A_local_rowptr[i];
			
			for (int j = A_local_rowptr[i]; j < A_local_rowptr[i + 1]; ++j)
				w[A_local_colind[j]] = j;

			if (w[i] >= j0)
				D_local_recip_values[i] = 1.0 / A_local_values[w[i]];

			for (int j = L_local_rowptr[i]; j < L_local_rowptr[i + 1]; ++j)
				if (w[L_local_colind[j]] >= j0) L_local_values[j] = A_local_values[w[L_local_colind[j]]];
			for (int j = U_local_rowptr[i]; j < U_local_rowptr[i + 1]; ++j)
				if (w[U_local_colind[j]] >= j0) U_local_values[j] = A_local_values[w[U_local_colind[j]]];
				
			j0 = A_exter_rowptr[i];

			for (int j = A_exter_rowptr[i]; j < A_exter_rowptr[i + 1]; ++j)
				v[A_exter_colind[j]] = j;

			for (int j = L_exter_rowptr[i]; j < L_exter_rowptr[i + 1]; ++j)
				if (v[L_exter_colind[j]] >= j0) L_exter_values[j] = A_exter_values[v[L_exter_colind[j]]];
			for (int j = U_exter_rowptr[i]; j < U_exter_rowptr[i + 1]; ++j)
				if (v[U_exter_colind[j]] >= j0) U_exter_values[j] = A_exter_values[v[U_exter_colind[j]]];
		}

		delete[] w;
		delete[] v;
	}
}

int ParCSRPrecondSOR::InSize() const
{
	return D_local_recip.size;
}

int ParCSRPrecondSOR::OutSize() const
{
	return D_local_recip.size;
}

void ParCSRPrecondSOR::Apply(const ParVector& b, const ParVector& x) const
{
	int relaxation_type = RelaxationType;
	double omega = RelaxationFactor;

	int n = D_local_recip.size;
	double* D_local_recip_values = D_local_recip.values;
	int* L_local_rowptr = L_local.rowptr;
	int* L_local_colind = L_local.colind;
	double* L_local_values = L_local.values;
	int* L_exter_rowptr = L_exter.rowptr;
	int* L_exter_colind = L_exter.colind;
	double* L_exter_values = L_exter.values;
	int* U_local_rowptr = U_local.rowptr;
	int* U_local_colind = U_local.colind;
	double* U_local_values = U_local.values;
	int* U_exter_rowptr = U_exter.rowptr;
	int* U_exter_colind = U_exter.colind;
	double* U_exter_values = U_exter.values;

	double* b_local_values = b.local.values;
	double* x_local_values = x.local.values;
	double* x_recv_values = recvx.values;

	MPI_Request* recvreq = new MPI_Request[nnb];
	MPI_Request* sendreq = new MPI_Request[nnb];
	MPI_Status status;

	if (relaxation_type == 0 || relaxation_type == 2)
	{
		if (omega == 1.0)
		{
			for (int i = 0; i < n; ++i)
			{
				if (!interior[i]) continue;
				double temp = b_local_values[i];
				for (int j = L_local_rowptr[i]; j < L_local_rowptr[i + 1]; ++j)
					temp -= x_local_values[L_local_colind[j]] * L_local_values[j];
				x_local_values[i] = temp * D_local_recip_values[i];
			}
		}
		else
		{
			for (int i = 0; i < n; ++i)
			{
				if (!interior[i]) continue;
				double temp = 0.0;
				for (int j = L_local_rowptr[i]; j < L_local_rowptr[i + 1]; ++j)
					temp -= x_local_values[L_local_colind[j]] * L_local_values[j];
				x_local_values[i] = (b_local_values[i] + omega * temp) * D_local_recip_values[i];
			}
		}

		for (int r = 0; r < nnb; ++r)
			if (label > nblab[r] && recvptr[r + 1] > recvptr[r])
				MPI_Irecv(x_recv_values + recvptr[r], recvptr[r + 1] - recvptr[r], MPI_DOUBLE, nbrank[r], MPI_TAG, comm, recvreq + r);

		for (int r = 0; r < nnb; ++r)
			if (label > nblab[r] && recvptr[r + 1] > recvptr[r])
				MPI_Wait(recvreq + r, &status);

		if (omega == 1.0)
		{
			for (int i = 0; i < n; ++i)
			{
				if (interior[i]) continue;
				double temp = b_local_values[i];
				for (int j = L_exter_rowptr[i]; j < L_exter_rowptr[i + 1]; ++j)
					temp -= x_recv_values[L_exter_colind[j]] * L_exter_values[j];
				for (int j = L_local_rowptr[i]; j < L_local_rowptr[i + 1]; ++j)
					temp -= x_local_values[L_local_colind[j]] * L_local_values[j];
				x_local_values[i] = temp * D_local_recip_values[i];
			}
		}
		else
		{
			for (int i = 0; i < n; ++i)
			{
				if (interior[i]) continue;
				double temp = 0.0;
				for (int j = L_exter_rowptr[i]; j < L_exter_rowptr[i + 1]; ++j)
					temp -= x_recv_values[L_exter_colind[j]] * L_exter_values[j];
				for (int j = L_local_rowptr[i]; j < L_local_rowptr[i + 1]; ++j)
					temp -= x_local_values[L_local_colind[j]] * L_local_values[j];
				x_local_values[i] = (b_local_values[i] + omega * temp) * D_local_recip_values[i];
			}
		}

		for (int r = 0; r < nnb; ++r)
		{
			if (label < nblab[r] && sendptr[r + 1] > sendptr[r])
			{
				for (int i = sendptr[r]; i < sendptr[r + 1]; ++i)
					sendbuf[i] = x_local_values[sendind[i]];
				MPI_Isend(sendbuf + sendptr[r], sendptr[r + 1] - sendptr[r], MPI_DOUBLE, nbrank[r], MPI_TAG, comm, sendreq + r);
			}
		}

		for (int r = 0; r < nnb; ++r)
			if (label < nblab[r] && sendptr[r + 1] > sendptr[r])
				MPI_Wait(sendreq + r, &status);
	}

	if (relaxation_type == 1)
	{

		for (int r = 0; r < nnb; ++r)
			if (label < nblab[r] && recvptr[r + 1] > recvptr[r])
				MPI_Irecv(x_recv_values + recvptr[r], recvptr[r + 1] - recvptr[r], MPI_DOUBLE, nbrank[r], MPI_TAG, comm, recvreq + r);

		for (int r = 0; r < nnb; ++r)
			if (label < nblab[r] && recvptr[r + 1] > recvptr[r])
				MPI_Wait(recvreq + r, &status);
		
		if (omega == 1.0)
		{
			for (int i = n - 1; i >= 0; --i)
			{
				if (interior[i]) continue;
				double temp = b_local_values[i];
				for (int j = U_exter_rowptr[i + 1] - 1; j >= U_exter_rowptr[i]; --j)
					temp -= x_recv_values[U_exter_colind[j]] * U_exter_values[j];
				for (int j = U_local_rowptr[i + 1] - 1; j >= U_local_rowptr[i]; --j)
					temp -= x_local_values[U_local_colind[j]] * U_local_values[j];
				x_local_values[i] = temp * D_local_recip_values[i];
			}
		}
		else
		{
			for (int i = n - 1; i >= 0; --i)
			{
				if (interior[i]) continue;
				double temp = 0.0;
				for (int j = U_exter_rowptr[i + 1] - 1; j >= U_exter_rowptr[i]; --j)
					temp -= x_recv_values[U_exter_colind[j]] * U_exter_values[j];
				for (int j = U_local_rowptr[i + 1] - 1; j >= U_local_rowptr[i]; --j)
					temp -= x_local_values[U_local_colind[j]] * U_local_values[j];
				x_local_values[i] = (b_local_values[i] + omega * temp) * D_local_recip_values[i];
			}
		}

		for (int r = 0; r < nnb; ++r)
		{
			if (label > nblab[r] && sendptr[r + 1] > sendptr[r])
			{
				for (int i = sendptr[r]; i < sendptr[r + 1]; ++i)
					sendbuf[i] = x_local_values[sendind[i]];
				MPI_Isend(sendbuf + sendptr[r], sendptr[r + 1] - sendptr[r], MPI_DOUBLE, nbrank[r], MPI_TAG, comm, sendreq + r);
			}
		}

		for (int r = 0; r < nnb; ++r)
			if (label > nblab[r] && sendptr[r + 1] > sendptr[r])
				MPI_Wait(sendreq + r, &status);

		if (omega == 1.0)
		{
			for (int i = n - 1; i >= 0; --i)
			{
				if (!interior[i]) continue;
				double temp = b_local_values[i];
				for (int j = U_local_rowptr[i + 1] - 1; j >= U_local_rowptr[i]; --j)
					temp -= x_local_values[U_local_colind[j]] * U_local_values[j];
				x_local_values[i] = temp * D_local_recip_values[i];
			}
		}
		else
		{
			for (int i = n - 1; i >= 0; --i)
			{
				if (!interior[i]) continue;
				double temp = 0.0;
				for (int j = U_local_rowptr[i + 1] - 1; j >= U_local_rowptr[i]; --j)
					temp -= x_local_values[U_local_colind[j]] * U_local_values[j];
				x_local_values[i] = (b_local_values[i] + omega * temp) * D_local_recip_values[i];
			}
		}
	}

	if (relaxation_type == 2)
	{

		for (int r = 0; r < nnb; ++r)
			if (label < nblab[r] && recvptr[r + 1] > recvptr[r])
				MPI_Irecv(x_recv_values + recvptr[r], recvptr[r + 1] - recvptr[r], MPI_DOUBLE, nbrank[r], MPI_TAG, comm, recvreq + r);

		for (int r = 0; r < nnb; ++r)
			if (label < nblab[r] && recvptr[r + 1] > recvptr[r])
				MPI_Wait(recvreq + r, &status);
		
		if (omega == 1.0)
		{
			for (int i = n - 1; i >= 0; --i)
			{
				if (interior[i]) continue;
				double temp = 0.0;
				for (int j = U_exter_rowptr[i + 1] - 1; j >= U_exter_rowptr[i]; --j)
					temp -= x_recv_values[U_exter_colind[j]] * U_exter_values[j];
				for (int j = U_local_rowptr[i + 1] - 1; j >= U_local_rowptr[i]; --j)
					temp -= x_local_values[U_local_colind[j]] * U_local_values[j];
				x_local_values[i] += temp * D_local_recip_values[i];
			}
		}
		else
		{
			for (int i = n - 1; i >= 0; --i)
			{
				if (interior[i]) continue;
				double temp = 0.0;
				for (int j = U_exter_rowptr[i + 1] - 1; j >= U_exter_rowptr[i]; --j)
					temp -= x_recv_values[U_exter_colind[j]] * U_exter_values[j];
				for (int j = U_local_rowptr[i + 1] - 1; j >= U_local_rowptr[i]; --j)
					temp -= x_local_values[U_local_colind[j]] * U_local_values[j];
				x_local_values[i] += omega * temp * D_local_recip_values[i];
			}
		}

		for (int r = 0; r < nnb; ++r)
		{
			if (label > nblab[r] && sendptr[r + 1] > sendptr[r])
			{
				for (int i = sendptr[r]; i < sendptr[r + 1]; ++i)
					sendbuf[i] = x_local_values[sendind[i]];
				MPI_Isend(sendbuf + sendptr[r], sendptr[r + 1] - sendptr[r], MPI_DOUBLE, nbrank[r], MPI_TAG, comm, sendreq + r);
			}
		}

		for (int r = 0; r < nnb; ++r)
			if (label > nblab[r] && sendptr[r + 1] > sendptr[r])
				MPI_Wait(sendreq + r, &status);

		if (omega == 1.0)
		{
			for (int i = n - 1; i >= 0; --i)
			{
				if (!interior[i]) continue;
				double temp = 0.0;
				for (int j = U_local_rowptr[i + 1] - 1; j >= U_local_rowptr[i]; --j)
					temp -= x_local_values[U_local_colind[j]] * U_local_values[j];
				x_local_values[i] += temp * D_local_recip_values[i];
			}
		}
		else
		{
			for (int i = n - 1; i >= 0; --i)
			{
				if (!interior[i]) continue;
				double temp = 0.0;
				for (int j = U_local_rowptr[i + 1] - 1; j >= U_local_rowptr[i]; --j)
					temp -= x_local_values[U_local_colind[j]] * U_local_values[j];
				x_local_values[i] += omega * temp * D_local_recip_values[i];
			}
		}
	}

	delete[] recvreq;
	delete[] sendreq;
}

}