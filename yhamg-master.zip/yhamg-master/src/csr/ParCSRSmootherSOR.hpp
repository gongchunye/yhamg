/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef ParCSRSmootherSOR_H
#define ParCSRSmootherSOR_H

#include "ParCSRSmoother.hpp"

namespace YHAMG
{

class ParCSRSmootherSORGlobal : public ParCSRSmoother
{
private:
	Vector D_local;
	Vector D_local_recip;
	CSRMatrix L_local;
	CSRMatrix L_exter;
	CSRMatrix U_local;
	CSRMatrix U_exter;
	Vector recvx;

	bool* interior;

	int label;
	int nnb;
	int* nblab;
	int* nbrank;

	int* recvptr;
	int* sendptr;
	int* sendind;
	double* sendbuf;

	ParVector z;

public:
	int RelaxationType;
	double RelaxationFactor;

	ParCSRSmootherSORGlobal(int relaxation_type = 2, double relaxation_factor = 1.0);
	~ParCSRSmootherSORGlobal();

	void Setup(const ParCSRMatrix& A, int REUSE = 0);
	void Pre_and_Resid(const ParCSRMatrix& A, const ParVector& b, const ParVector& x, const ParVector& r, int step, bool x0zero = 0) const;
	void Post(const ParCSRMatrix& A, const ParVector& b, const ParVector& x, int step) const;
	void operator()(const ParCSRMatrix& A, const ParVector& b, const ParVector& x, int step, bool x0zero = 0) const;
};

class ParCSRSmootherSORLocal : public ParCSRSmoother
{
private:
	int nthd;
	Vector D_recip;
	ParVector z;

public:
	int RelaxationType;
	double RelaxationFactor;

	ParCSRSmootherSORLocal(int relaxation_type = 2, double relaxation_factor = 1.0);

	void Setup(const ParCSRMatrix& A, int REUSE = 0);
	void Post(const ParCSRMatrix& A, const ParVector& b, const ParVector& x, int step) const;
	void operator()(const ParCSRMatrix& A, const ParVector& b, const ParVector& x, int step, bool x0zero = 0) const;
};

class ParCSRSmootherSOR : public ParCSRSmoother
{
private:
	int nthd;
	Vector D_recip;
	ParVector z;

public:
	int RelaxationType;
	double RelaxationFactor;

	ParCSRSmootherSOR(int relaxation_type = 2, double relaxation_factor = 1.0);

	void Setup(const ParCSRMatrix& A, int REUSE = 0);
	void Post(const ParCSRMatrix& A, const ParVector& b, const ParVector& x, int step) const;
	void operator()(const ParCSRMatrix& A, const ParVector& b, const ParVector& x, int step, bool x0zero = 0) const;
};

class ParCSRSmootherSORXLocal : public ParCSRSmoother
{
private:
	int nthd;
	Vector D;
	Vector D_recip;
	CSRMatrix L;
	CSRMatrix U;
	CSRMatrix E;
	ParVector z;
	ParVector w;

public:
	int RelaxationType;
	double RelaxationFactor;

	ParCSRSmootherSORXLocal(int relaxation_type = 2, double relaxation_factor = 1.0);

	void Setup(const ParCSRMatrix& A, int REUSE = 0);
	void Pre_and_Resid(const ParCSRMatrix& A, const ParVector& b, const ParVector& x, const ParVector& r, int step, bool x0zero = 0) const;
	void Post(const ParCSRMatrix& A, const ParVector& b, const ParVector& x, int step) const;
	void operator()(const ParCSRMatrix& A, const ParVector& b, const ParVector& x, int step, bool x0zero = 0) const;
};

class ParCSRSmootherSORX : public ParCSRSmoother
{
private:
	int nthd;
	Vector D;
	Vector D_recip;
	CSRMatrix L;
	CSRMatrix U;
	CSRMatrix E;
	ParVector z;
	ParVector w;

public:
	int RelaxationType;
	double RelaxationFactor;

	ParCSRSmootherSORX(int relaxation_type = 2, double relaxation_factor = 1.0);

	void Setup(const ParCSRMatrix& A, int REUSE = 0);
	void Pre_and_Resid(const ParCSRMatrix& A, const ParVector& b, const ParVector& x, const ParVector& r, int step, bool x0zero = 0) const;
	void Post(const ParCSRMatrix& A, const ParVector& b, const ParVector& x, int step) const;
	void operator()(const ParCSRMatrix& A, const ParVector& b, const ParVector& x, int step, bool x0zero = 0) const;
};

}

#endif