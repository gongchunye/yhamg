/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "ParCSRPrecondBJSOR.hpp"

#ifdef YHAMG_USE_OPENMP
#include <omp.h>
#endif

namespace YHAMG
{

ParCSRPrecondBJSOR::ParCSRPrecondBJSOR(int relaxation_type, double relaxation_factor)
	: nthd(0),
	RelaxationType(relaxation_type),
	RelaxationFactor(relaxation_factor)
{
}

void ParCSRPrecondBJSOR::Free()
{
	nthd = 0;
	D_recip.Free();
	L.Free();
	U.Free();
}

void ParCSRPrecondBJSOR::Setup(const ParCSRMatrix& A, int REUSE)
{
	int n = A.local.size[0];
	int* Ap = A.local.rowptr;
	int* Ai = A.local.colind;
	double* Av = A.local.values;
	
	if (!REUSE)
	{
		Free();

		comm = A.comm;

		D_recip.Resize(n);

		nthd = 1;
#ifdef USE_ONED_PARTITION
		nthd = omp_get_max_threads();
#endif

		double* Drcpv = D_recip.values;

		int* Lp = new int[n + 1];
		int* Up = new int[n + 1];

		Lp[0] = 0;
		Up[0] = 0;
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		for (int t = 0; t < nthd; ++t)
		{
			int begin = t * n / nthd;
			int end = (t + 1) * n / nthd;

			for (int i = begin; i < end; ++i)
			{
				int cntl = 0;
				int cntu = 0;

				for (int j = Ap[i]; j < Ap[i + 1]; ++j)
				{
					int jcol = Ai[j];

					if (jcol >= begin && jcol < i) 
						++cntl;
					else if (jcol < end && jcol > i)
						++cntu;
				}

				Lp[i + 1] = cntl;
				Up[i + 1] = cntu;
			}
		}

		for (int i = 0; i < n;++i)
			Lp[i + 1] += Lp[i];
		for (int i = 0; i < n;++i)
			Up[i + 1] += Up[i];

		int* Li = new int[Lp[n]];
		double* Lv = new double[Lp[n]];
		int* Ui = new int[Up[n]];
		double* Uv = new double[Up[n]];

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		for (int t = 0; t < nthd; ++t)
		{
			int begin = t * n / nthd;
			int end = (t + 1) * n / nthd;

			for (int i = begin; i < end; ++i)
			{
				for (int j = Ap[i], k = Lp[i], r = Up[i]; j < Ap[i + 1]; ++j)
				{
					int jcol = Ai[j];
					double jval = Av[j];

					if (jcol >= begin && jcol < i) 
					{
						Li[k] = jcol;
						Lv[k++] = jval;
					}
					else if (jcol < end && jcol > i)
					{
						Ui[r] = jcol;
						Uv[r++] = jval;
					}
					else if (jcol == i)
						Drcpv[i] = 1.0 / jval;
				}
			}
		}

		L.size[0] = n;
		L.size[1] = n;
		L.rowptr = Lp;
		L.colind = Li;
		L.values = Lv;
		U.size[0] = n;
		U.size[1] = n;
		U.rowptr = Up;
		U.colind = Ui;
		U.values = Uv;
	}
	else
	{
		int* Lp = L.rowptr;
		int* Li = L.colind;
		double* Lv = L.values;
		int* Up = U.rowptr;
		int* Ui = U.colind;
		double* Uv = U.values;
		double* Drcpv = D_recip.values;
		
		int* w = new int[n];

		for (int i = 0; i < n; ++i)
			w[i] = -1;

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		for (int t = 0; t < nthd; ++t)
		{
			int begin = t * n / nthd;
			int end = (t + 1) * n / nthd;

			for (int i = begin; i < end; ++i)
			{
				int j0 = Ap[i];

				for (int j = Ap[i]; j < Ap[i + 1]; ++j)
					if (Ai[j] >= begin && Ai[j] < end) w[Ai[j]] = j;

				if (w[i] >= j0)
					Drcpv[i] = 1.0 / Av[w[i]];

				for (int j = Lp[i]; j < Lp[i + 1]; ++j)
					if (w[Li[j]] >= j0) Lv[j] = Av[w[Li[j]]];
				for (int j = Up[i]; j < Up[i + 1]; ++j)
					if (w[Ui[j]] >= j0) Uv[j] = Av[w[Ui[j]]];
			}
		}
		
		delete[] w;	
	}
}

int ParCSRPrecondBJSOR::InSize() const
{
	return D_recip.size;
}

int ParCSRPrecondBJSOR::OutSize() const
{
	return D_recip.size;
}

void ParCSRPrecondBJSOR::Apply(const ParVector& b, const ParVector& x) const
{
	int relaxation_type = RelaxationType;
	double omega = RelaxationFactor;
	
	int n = D_recip.size;
	double* Drcpv = D_recip.values;
	int* Lp = L.rowptr;
	int* Li = L.colind;
	double* Lv = L.values;
	int* Up = U.rowptr;
	int* Ui = U.colind;
	double* Uv = U.values;
	double* bv = b.local.values;
	double* xv = x.local.values;

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
	for (int t = 0; t < nthd; ++t)
	{
		int begin = t * n / nthd;
		int end = (t + 1) * n / nthd;

		if (relaxation_type == 0 || relaxation_type == 2)
		{
			if (omega == 1.0)
			{
				for (int i = begin; i < end; ++i)
				{
					double temp = bv[i];
					for (int j = Lp[i]; j < Lp[i + 1]; ++j)
						temp -= xv[Li[j]] * Lv[j];
					xv[i] = temp * Drcpv[i];
				}
			}
			else
			{
				for (int i = begin; i < end; ++i)
				{
					double temp = 0.0;
					for (int j = Lp[i]; j < Lp[i + 1]; ++j)
						temp -= xv[Li[j]] * Lv[j];
					xv[i] = (bv[i] + omega * temp) * Drcpv[i];
				}
			}
		}

		if (relaxation_type == 1)
		{
			if (omega == 1.0)
			{
				for (int i = end - 1; i >= begin; --i)
				{
					double temp = bv[i];
					for (int j = Up[i + 1] - 1; j >= Up[i]; --j)
						temp -= xv[Ui[j]] * Uv[j];
					xv[i] = temp * Drcpv[i];
				}
			}
			else
			{
				for (int i = end - 1; i >= begin; --i)
				{
					double temp = 0.0;
					for (int j = Up[i + 1] - 1; j >= Up[i]; --j)
						temp -= xv[Ui[j]] * Uv[j];
					xv[i] = (bv[i] + omega * temp) * Drcpv[i];
				}
			}
		}

		if (relaxation_type == 2)
		{
			if (omega == 1.0)
			{
				for (int i = end - 1; i >= begin; --i)
				{
					double temp = 0.0;
					for (int j = Up[i + 1] - 1; j >= Up[i]; --j)
						temp -= xv[Ui[j]] * Uv[j];
					xv[i] += temp * Drcpv[i];
				}
			}
			else
			{
				for (int i = end - 1; i >= begin; --i)
				{
					double temp = 0.0;
					for (int j = Up[i + 1] - 1; j >= Up[i]; --j)
						temp -= xv[Ui[j]] * Uv[j];
					xv[i] += omega * temp * Drcpv[i];
				}
			}
		}
	}
}

}