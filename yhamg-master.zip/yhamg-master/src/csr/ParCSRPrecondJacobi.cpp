/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "ParCSRPrecondJacobi.hpp"

namespace YHAMG
{

void ParCSRPrecondJacobi::Free()
{
	D_recip.Free();
}

void ParCSRPrecondJacobi::Setup(const ParCSRMatrix& A, int REUSE)
{
	int n = A.local.size[0];
	int* Ap = A.local.rowptr;
	int* Ai = A.local.colind;
	double* Av = A.local.values;

	if (!REUSE)
	{
		comm = A.comm;
		D_recip.Resize(n);
	}

	double* Drcpv = D_recip.values;

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
	for (int i = 0; i < n; ++i)
	{
		for (int j = Ap[i]; j < Ap[i + 1]; ++j)
		{
			if (Ai[j] == i)
			{
				Drcpv[i] = 1.0 / Av[j];
				break;
			}
		}
	}
}

int ParCSRPrecondJacobi::InSize() const
{
	return D_recip.size;
}

int ParCSRPrecondJacobi::OutSize() const
{
	return D_recip.size;
}

void ParCSRPrecondJacobi::Apply(const ParVector& b, const ParVector& x) const
{
	int n = D_recip.size;
	double* Drcpv = D_recip.values;
	double* xv = x.local.values;
	double* bv = b.local.values;

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
	for (int i = 0; i < n; ++i)
		xv[i] = bv[i] * Drcpv[i];
}

}