/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "sort.hpp"
#include "ParCSRPrecondBJILU.hpp"

#ifdef YHAMG_USE_OPENMP
#include <omp.h>
#endif

namespace YHAMG
{

ParCSRPrecondBJILU::ParCSRPrecondBJILU(int maxfil, double droptol)
	: nthd(0),
	D_recip(0),
	L(0),
	U(0),
	MaxFillins(maxfil),
	DropTolerance(droptol)
{
}

ParCSRPrecondBJILU::~ParCSRPrecondBJILU()
{
	if(D_recip) delete[] D_recip;
	if(L) delete[] L;
	if(U) delete[] U;
}

void ParCSRPrecondBJILU::Free()
{
	if(D_recip) delete[] D_recip;
	if(L) delete[] L;
	if(U) delete[] U;
	nthd = 0;
	D_recip = 0;
	L = 0;
	U = 0;
}

#define ABS(x) ((x) > 0 ? (x) : -(x))
#define MIN(a, b) ((a) < (b) ? (a) : (b))

static inline void swap(int& a, int& b)
{
	int temp = a;
	a = b;
	b = temp;
}

static inline void swap(double& a, double& b)
{
	double temp = a;
	a = b;
	b = temp;
}

static void SortIndAsc(int* a, double* x, int left, int right)
{
	if (left >= right) return;

	swap(a[left], a[(left + right) / 2]);
	swap(x[left], x[(left + right) / 2]);

	int last = left;
	for (int i = left + 1; i <= right; ++i)
	{
		if (a[i] < a[left])
		{
			swap(a[++last], a[i]);
			swap(x[last], x[i]);
		}
	}

	swap(a[left], a[last]);
	swap(x[left], x[last]);

	SortIndAsc(a, x, left, last - 1);
	SortIndAsc(a, x, last + 1, right);
}

static void SortAbsDesc(int* a, double* x, int left, int right)
{
	if (left >= right) return;

	swap(a[left], a[(left + right) / 2]);
	swap(x[left], x[(left + right) / 2]);

	int last = left;
	for (int i = left + 1; i <= right; ++i)
	{
		if (ABS(x[i]) > ABS(x[left]))
		{
			swap(a[++last], a[i]);
			swap(x[last], x[i]);
		}
	}

	swap(a[left], a[last]);
	swap(x[left], x[last]);

	SortAbsDesc(a, x, left, last - 1);
	SortAbsDesc(a, x, last + 1, right);
}

void ParCSRPrecondBJILU::Setup(const ParCSRMatrix& A, int REUSE)
{
	int n = A.local.size[0];
	int* Ap = A.local.rowptr;
	int* Ai = A.local.colind;
	double* Av = A.local.values;

	int maxfil = MIN(MaxFillins, n);
	double droptol = DropTolerance;

	if (!REUSE)
	{
		Free();

		comm = A.comm;

		nthd = 1;
#ifdef USE_ONED_PARTITION
		nthd = omp_get_max_threads();
#endif

		D_recip = new Vector[nthd];
		L = new CSRMatrix[nthd];
		U = new CSRMatrix[nthd];

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		for (int t = 0; t < nthd; ++t)
		{
			int begin = t * n / nthd;
			int end = (t + 1) * n / nthd;
			int m = end - begin;

			D_recip[t].Resize(m);
			double* Drcpv = D_recip[t].values;

			int* w = new int[m];
			double* x = new double[m];

			for (int i = 0; i < m; ++i)
				w[i] = -1;

			int lnz = 0, unz = 0;
			for (int i = begin; i < end; ++i)
			{
				for (int j = Ap[i]; j < Ap[i + 1]; ++j)
				{
					if (Ai[j] >= begin && Ai[j] < i)
						++lnz;
					else if (Ai[j] > i && Ai[j] < end)
						++unz;
				}
			}

			int* Lp = new int[m + 1];
			int* Li = new int[lnz + m * maxfil + m];
			double* Lv = new double[lnz + m * maxfil + m];
			int* Up = new int[m + 1];
			int* Ui = new int[unz + m * maxfil + m];
			double* Uv = new double[unz + m * maxfil + m];

			Lp[0] = 0;
			Up[0] = 0;
			for (int i1 = begin, i = 0; i1 < end; ++i1, ++i)
			{
				int r0 = Lp[i], r1 = r0;
				int s0 = Up[i], s1 = s0;

				w[i] = i;
				x[i] = 0.0;

				double anorm = 0.0;

				for (int j = Ap[i1]; j < Ap[i1 + 1]; ++j)
				{
					if (Ai[j] < begin || Ai[j] >= end)
						continue;

					int jcol = Ai[j] - begin;
					double jval = Av[j];

					if (ABS(jval) > anorm)
						anorm = ABS(jval);

					w[jcol] = i;
					x[jcol] = jval;

					if (jcol < i)
						Li[r1++] = jcol;
					else if (jcol > i)
						Ui[s1++] = jcol;
				}

				int r = r1, r2 = r1;
				int s = s1, s2 = s1;

				sort(Li, r0, r1 - 1);

				int k1 = r0, k2 = r1;
				while (k1 < r1 || k2 < r2)
				{
					int k = (k2 == r2 || (k1 < r1 && Li[k1] < Li[k2]) ? k1 : k2)++;

					int kcol = Li[k];
					double kval = x[kcol];

					if (k < r1 || (maxfil && ABS(kval) > droptol * anorm))
					{
						kval *= Drcpv[kcol];
						
						if (k < r1)
							Lv[k] = kval;
						else
						{
							Li[r] = kcol;
							Lv[r++] = kval;
						}

						for (int j = Up[kcol]; j < Up[kcol + 1]; ++j)
						{
							int jcol = Ui[j];
							double jval = Uv[j];
							double prod = kval * jval;

							if (w[jcol] == i)
								x[jcol] -= prod;
							else
							{
								w[jcol] = i;
								x[jcol] = -prod;
								if (jcol < i)
								{
									for (int p = r2++; ; --p)
									{
										if (p == k2 || Li[p - 1] < jcol)
										{
											Li[p] = jcol;
											break;
										}
										Li[p] = Li[p - 1];
									}
								}
								else
									Ui[s2++] = jcol;
							}
						}
					}
				}

				if (r > r1 + maxfil)
				{
					SortAbsDesc(Li, Lv, r1, r - 1);
					r = r1 + maxfil;
				}
				SortIndAsc(Li, Lv, r0, r - 1);

				for (int j = s0; j < s1; ++j)
					Uv[j] = x[Ui[j]];
				for (int j = s1; j < s2; ++j)
				{
					int jcol = Ui[j];
					double jval = x[jcol];
					if (ABS(jval) > droptol * anorm)
					{
						Ui[s] = jcol;
						Uv[s++] = jval;
					}
				}

				if (s > s1 + maxfil)
				{
					SortAbsDesc(Ui, Uv, s1, s - 1);
					s = s1 + maxfil;
				}
				SortIndAsc(Ui, Uv, s0, s - 1);

				Drcpv[i] = 1.0 / x[i];

				Lp[i + 1] = r;
				Up[i + 1] = s;
			}

			L[t].size[0] = m;
			L[t].size[1] = m;
			L[t].rowptr = Lp;
			L[t].colind = Li;
			L[t].values = Lv;
			U[t].size[0] = m;
			U[t].size[1] = m;
			U[t].rowptr = Up;
			U[t].colind = Ui;
			U[t].values = Uv;

			delete[] w;
			delete[] x;
		}
	}
	else
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		for (int t = 0; t < nthd; ++t)
		{
			int begin = t * n / nthd;
			int end = (t + 1) * n / nthd;
			int m = end - begin;

			double* Drcpv = D_recip[t].values;
			int* Lp = L[t].rowptr;
			int* Li = L[t].colind;
			double* Lv = L[t].values;
			int* Up = U[t].rowptr;
			int* Ui = U[t].colind;
			double* Uv = U[t].values;

			int* w = new int[m];
			double* x = new double[m];

			for (int i = 0; i < m; ++i)
				w[i] = -1;

			for (int i1 = begin, i = 0; i1 < end; ++i1, ++i)
			{
				w[i] = i;
				x[i] = 0.0;

				for (int j = Lp[i]; j < Lp[i + 1]; ++j)
				{
					w[Li[j]] = i;
					x[Li[j]] = 0.0;
				}

				for (int j = Up[i]; j < Up[i + 1]; ++j)
				{
					w[Ui[j]] = i;
					x[Ui[j]] = 0.0;
				}

				for (int j = Ap[i1]; j < Ap[i1 + 1]; ++j)
					if (Ai[j] >= begin && Ai[j] < end)
						x[Ai[j] - begin] = Av[j];

				for (int k = Lp[i]; k < Lp[i + 1]; ++k)
				{
					int kcol = Li[k];
					double kval = x[kcol] * Drcpv[kcol];

					Lv[k] = kval;

					for (int j = Up[kcol]; j < Up[kcol + 1]; ++j)
					{
						int jcol = Ui[j];
						double jval = Uv[j];
						double prod = kval * jval;

						if (w[jcol] == i)
							x[jcol] -= prod;
					}
				}

				Drcpv[i] = 1.0 / x[i];
				for (int j = Up[i]; j < Up[i + 1]; ++j)
					Uv[j] = x[Ui[j]];
			}

			delete[] w;
			delete[] x;
		}
	}
}

int ParCSRPrecondBJILU::InSize() const
{
	int result = 0;
	for (int t = 0; t < nthd; ++t)
		result += D_recip[t].size;
	return result;
}

int ParCSRPrecondBJILU::OutSize() const
{
	int result = 0;
	for (int t = 0; t < nthd; ++t)
		result += D_recip[t].size;
	return result;
}

void ParCSRPrecondBJILU::Apply(const ParVector& b, const ParVector& x) const
{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
	for (int t = 0; t < nthd; ++t)
	{
		int begin = 0;
		for (int s = 0; s < t; ++s)
			begin += D_recip[s].size;
		int m = D_recip[t].size;
		int end = begin + m;

		double* Drcpv = D_recip[t].values;
		int* Lp = L[t].rowptr;
		int* Li = L[t].colind;
		double* Lv = L[t].values;
		int* Up = U[t].rowptr;
		int* Ui = U[t].colind;
		double* Uv = U[t].values;
		double* bv = b.local.values + begin;
		double* xv = x.local.values + begin;

		for (int i = 0; i < m; ++i)
		{
			double temp = bv[i];
			for (int j = Lp[i]; j < Lp[i + 1]; ++j)
				temp -= xv[Li[j]] * Lv[j];
			xv[i] = temp;
		}

		for (int i = m - 1; i >= 0; --i)
		{
			double temp = xv[i];
			for (int j = Up[i + 1] - 1; j >= Up[i]; --j)
				temp -= xv[Ui[j]] * Uv[j];
			xv[i] = temp * Drcpv[i];
		}
	}
}

}