/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef CSRMatrix_H
#define CSRMatrix_H

#include "Operator.hpp"
#include "COOMatrix.hpp"

namespace YHAMG
{

struct CSRMatrix : public Operator
{
	int ref;
	int size[2];

	int* rowptr;
	int* colind;
	double* values;

	CSRMatrix();
	CSRMatrix(int n, int m, int* rowptr, int* colind, double* values, int ref);
	CSRMatrix(const COOMatrix& A);
	CSRMatrix(const CSRMatrix& A);
	CSRMatrix(CSRMatrix&& A);
	~CSRMatrix();
	CSRMatrix& operator=(const COOMatrix& A);
	CSRMatrix& operator=(const CSRMatrix& A);
	CSRMatrix& operator=(CSRMatrix&& A);

	void Free();
	void Refer(const CSRMatrix& A);
	int InSize() const;
	int OutSize() const;
	void Apply(const Vector& x, const Vector& y) const;
	void Apply(const MultiVector& X, const MultiVector& Y) const;
};

void CSRRead(const char* filename, CSRMatrix& A);
void CSRWrite(const char* filename, const CSRMatrix& A);
void CSRDiag(const CSRMatrix& A, const Vector& D);
void CSREliminZeros(const CSRMatrix& A);
void CSRScale(double alpha, const CSRMatrix& A);
void CSRScaleRows(const Vector& x, const CSRMatrix& A);
void CSRScaleCols(const Vector& x, const CSRMatrix& A);
void CSRMatAdd(const CSRMatrix& A, const CSRMatrix& B, CSRMatrix& C);
void CSRMatMul(const CSRMatrix& A, const CSRMatrix& B, CSRMatrix& C);
void CSRMatVec(double alpha, const CSRMatrix& A, const Vector& x, double beta, const Vector& y);
void CSRMatMultiVec(double alpha, const CSRMatrix& A, const MultiVector& X, double beta, const MultiVector& Y);
void CSRTrans(const CSRMatrix& A, CSRMatrix& B);

}

#endif
