/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <set>
#include <map>
#include <vector>
#include <cmath>
#include <stdlib.h>
#include <random>
#include "random.hpp"
#include "global.hpp"
#include "RugeStuben.hpp"

#ifdef YHAMG_USE_OPENMP
#include <omp.h>
#endif

namespace YHAMG
{

#define ABS(x) ((x) > 0 ? (x) : -(x))
#define _(x) (((x) > 0) ^ (diagonal > 0) ? (x) : 0)
#define COARSE 1
#define FINE -1
#define ISOLATED -2
#define S2_FINE -3
#define UNASSIGNED 0

#define MPI_TAG 400

static inline void swap(int& a, int& b)
{
	int temp = a;
	a = b;
	b = temp;
}

static inline void swap(double& a, double& b)
{
	double temp = a;
	a = b;
	b = temp;
}

static void SortAbsDesc(int* a, double* x, int left, int right)
{
	if (left >= right) return;

	swap(a[left], a[(left + right) / 2]);
	swap(x[left], x[(left + right) / 2]);

	int last = left;
	for (int i = left + 1; i <= right; ++i)
	{
		if (ABS(x[i]) > ABS(x[left]))
		{
			swap(a[++last], a[i]);
			swap(x[last], x[i]);
		}
	}

	swap(a[left], a[last]);
	swap(x[left], x[last]);

	SortAbsDesc(a, x, left, last - 1);
	SortAbsDesc(a, x, last + 1, right);
}

namespace RugeStuben
{

void Strength(const ParCSRMatrix& A, bool* locstg, bool* extstg, double threshold)
{
	int n = A.local.size[0];
	int* local_rowptr = A.local.rowptr;
	int* local_colind = A.local.colind;
	double* local_values = A.local.values;
	int* exter_rowptr = A.exter.rowptr;
	int* exter_colind = A.exter.colind;
	double* exter_values = A.exter.values;

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
	for (int i = 0; i < n; ++i)
	{
		double theta = 0.0;
		for (int j = local_rowptr[i]; j < local_rowptr[i + 1]; ++j)
		{
			if (local_colind[j] == i) continue;
			double abs_jval = ABS(local_values[j]);
			if (abs_jval > theta) theta = abs_jval;
		}
		for (int j = exter_rowptr[i]; j < exter_rowptr[i + 1]; ++j)
		{
			double abs_jval = ABS(exter_values[j]);
			if (abs_jval > theta) theta = abs_jval;
		}
		theta *= threshold;
		for (int j = local_rowptr[i]; j < local_rowptr[i + 1]; ++j)
			locstg[j] = local_colind[j] != i && ABS(local_values[j]) > theta;
		for (int j = exter_rowptr[i]; j < exter_rowptr[i + 1]; ++j)
			extstg[j] = ABS(exter_values[j]) > theta;
	}
}

static void ExchangeCFmap(const ParCSRMatrix& A, const int* cfmap, int* recvcf, int* nbmask = 0)
{
	MPI_Comm comm = A.comm;

	int nnb = A.nnb;
	int* nbrank = A.nbrank;
	int* recvptr = A.recvptr;
	int* sendptr = A.sendptr;
	int* sendind = A.sendind;

	int* sendbuf = new int[sendptr[nnb]];
	MPI_Request* recvreq = new MPI_Request[nnb];
	MPI_Request* sendreq = new MPI_Request[nnb];
	MPI_Status status;

	for (int r = 0; r < nnb; ++r)
		if (recvptr[r + 1] > recvptr[r] && (!nbmask || nbmask[r]))
			MPI_Irecv(recvcf + recvptr[r], recvptr[r + 1] - recvptr[r], MPI_INT, nbrank[r], MPI_TAG, comm, recvreq + r);

	for (int r = 0; r < nnb; ++r)
	{
		if (sendptr[r + 1] > sendptr[r] && (!nbmask || nbmask[r]))
		{
			for (int i = sendptr[r]; i < sendptr[r + 1]; ++i)
				sendbuf[i] = cfmap[sendind[i]];
			MPI_Isend(sendbuf + sendptr[r], sendptr[r + 1] - sendptr[r], MPI_INT, nbrank[r], MPI_TAG, comm, sendreq + r);
		}
	}

	for (int r = 0; r < nnb; ++r)
		if (recvptr[r + 1] > recvptr[r] && (!nbmask || nbmask[r]))
			MPI_Wait(recvreq + r, &status);

	for (int r = 0; r < nnb; ++r)
		if (sendptr[r + 1] > sendptr[r] && (!nbmask || nbmask[r]))
			MPI_Wait(sendreq + r, &status);

	delete[] sendbuf;
	delete[] recvreq;
	delete[] sendreq;
}

static void ExchangeWeights(const ParCSRMatrix& A, const int* weights, int* recvwgt)
{
	MPI_Comm comm = A.comm;

	int nnb = A.nnb;
	int* nbrank = A.nbrank;
	int* recvptr = A.recvptr;
	int* sendptr = A.sendptr;
	int* sendind = A.sendind;

	int* sendbuf = new int[sendptr[nnb]];
	MPI_Request* recvreq = new MPI_Request[nnb];
	MPI_Request* sendreq = new MPI_Request[nnb];
	MPI_Status status;

	for (int r = 0; r < nnb; ++r)
		if (recvptr[r + 1] > recvptr[r])
			MPI_Irecv(recvwgt + recvptr[r], recvptr[r + 1] - recvptr[r], MPI_INT, nbrank[r], MPI_TAG, comm, recvreq + r);

	for (int r = 0; r < nnb; ++r)
	{
		if (sendptr[r + 1] > sendptr[r])
		{
			for (int i = sendptr[r]; i < sendptr[r + 1]; ++i)
				sendbuf[i] = weights[sendind[i]];
			MPI_Isend(sendbuf + sendptr[r], sendptr[r + 1] - sendptr[r], MPI_INT, nbrank[r], MPI_TAG, comm, sendreq + r);
		}
	}

	for (int r = 0; r < nnb; ++r)
		if (recvptr[r + 1] > recvptr[r])
			MPI_Wait(recvreq + r, &status);

	for (int r = 0; r < nnb; ++r)
		if (sendptr[r + 1] > sendptr[r])
			MPI_Wait(sendreq + r, &status);

	delete[] sendbuf;
	delete[] recvreq;
	delete[] sendreq;
}

static void UpdateWeights(const ParCSRMatrix& A, int* weights, const int* recvwgt)
{
	MPI_Comm comm = A.comm;

	int nnb = A.nnb;
	int* nbrank = A.nbrank;
	int* recvptr = A.recvptr;
	int* sendptr = A.sendptr;
	int* sendind = A.sendind;

	int* sendbuf = new int[sendptr[nnb]];
	MPI_Request* recvreq = new MPI_Request[nnb];
	MPI_Request* sendreq = new MPI_Request[nnb];
	MPI_Status status;

	for (int r = 0; r < nnb; ++r)
		if (sendptr[r + 1] > sendptr[r])
			MPI_Irecv(sendbuf + sendptr[r], sendptr[r + 1] - sendptr[r], MPI_INT, nbrank[r], MPI_TAG, comm, recvreq + r);

	for (int r = 0; r < nnb; ++r)
		if (recvptr[r + 1] > recvptr[r])
			MPI_Isend(recvwgt + recvptr[r], recvptr[r + 1] - recvptr[r], MPI_INT, nbrank[r], MPI_TAG, comm, sendreq + r);

	for (int r = 0; r < nnb; ++r)
	{
		if (sendptr[r + 1] > sendptr[r])
		{
			MPI_Wait(recvreq + r, &status);
			for (int i = sendptr[r]; i < sendptr[r + 1]; ++i)
				weights[sendind[i]] += sendbuf[i];
		}
	}

	for (int r = 0; r < nnb; ++r)
		if (recvptr[r + 1] > recvptr[r])
			MPI_Wait(sendreq + r, &status);

	delete[] sendbuf;
	delete[] recvreq;
	delete[] sendreq;
}

static void UpdateMask(const ParCSRMatrix& A, int f, int* nbmask)
{
	MPI_Comm comm = A.comm;

	int nnb = A.nnb;
	int* nbrank = A.nbrank;

	int* _nbmask = new int[nnb];
	for (int r = 0; r < nnb; ++r)
		_nbmask[r] = nbmask[r];

	MPI_Request* recvreq = new MPI_Request[nnb];
	MPI_Status status;

	for (int r = 0; r < nnb; ++r)
		if (_nbmask[r])
			MPI_Irecv(nbmask + r, 1, MPI_INT, nbrank[r], MPI_TAG, comm, recvreq + r);

	for (int r = 0; r < nnb; ++r)
		if (_nbmask[r])
			MPI_Send(&f, 1, MPI_INT, nbrank[r], MPI_TAG, comm);

	for (int r = 0; r < nnb; ++r)
		if (_nbmask[r])
			MPI_Wait(recvreq + r, &status);

	delete[] _nbmask;
	delete[] recvreq;
}

inline uint64_t xorshift128plus(uint64_t& k1, uint64_t& k2)
{
	uint64_t k3 = k1;
	const uint64_t k4 = k2;
	k1 = k4;
	k3 ^= (k3 << 23);
	k2 = k3 ^ k4 ^ (k3 >> 17) ^ (k4 >> 26);
	return k2 + k4;
}

int HMISCoarsening(const ParCSRMatrix& A, const bool* locstg, const bool* extstg, int* cfmap)
{
	MPI_Comm comm = A.comm;

	int comm_rank;
	MPI_Comm_rank(comm, &comm_rank);

	int n = A.local.size[0];
	int recvcnt = A.exter.size[1];

	int* local_rowptr = A.local.rowptr;
	int* local_colind = A.local.colind;
	int* exter_rowptr = A.exter.rowptr;
	int* exter_colind = A.exter.colind;

	int nifrow = 0;
	int* ifrows = new int[n];
	for (int i = 0; i < n; ++i)
		if (exter_rowptr[i + 1] > exter_rowptr[i])
			ifrows[nifrow++] = i;

	int nnb = A.nnb;
	int* nbrank = A.nbrank;
	int* recvptr = A.recvptr;

	int* weights = new int[n];

	int* Stp = new int[n + 1];
	for (int i = 0; i <= n; ++i)
		Stp[i] = 0;

	for (int j = local_rowptr[0]; j < local_rowptr[n]; ++j)
		if (locstg[j]) ++Stp[local_colind[j]];

	for (int i = 0; i < n; ++i)
		Stp[i + 1] += Stp[i];

	int* Sti = new int[Stp[n]];

	for (int i = n - 1; i >= 0; --i)
		for (int j = local_rowptr[i + 1] - 1; j >= local_rowptr[i]; --j)
			if (locstg[j]) Sti[--Stp[local_colind[j]]] = i;

	for (int i = 0; i < n; ++i)
		weights[i] = Stp[i + 1] - Stp[i];

	int nc = 0;
	int nf = 0;

	for (int i = 0; i < n; ++i)
	{
		if (weights[i] == 0)
		{
			cfmap[i] = ISOLATED;
			++nf;
		}
		else
			cfmap[i] = UNASSIGNED;
	}

	while (nc + nf < n)
	{
		for (int i = 0; i < n; ++i)
		{
			int r = i;

			if (cfmap[r] == UNASSIGNED)
			{
			L0:
				for (int j = local_rowptr[r]; j < local_rowptr[r + 1]; ++j)
				{
					int jcol = local_colind[j];

					if (locstg[j] && cfmap[jcol] == UNASSIGNED && weights[r] < weights[jcol])
					{
						r = jcol;
						goto L0;
					}
				}

				for (int j = Stp[r]; j < Stp[r + 1]; ++j)
				{
					int jcol = Sti[j];

					if (cfmap[jcol] == UNASSIGNED && weights[r] < weights[jcol])
					{
						r = jcol;
						goto L0;
					}
				}

				cfmap[r] = COARSE;
				++nc;

				for (int j = Stp[r]; j < Stp[r + 1]; ++j)
				{
					int jcol = Sti[j];
					if (cfmap[jcol] == UNASSIGNED)
					{
						cfmap[jcol] = FINE;
						++nf;

						for (int k = local_rowptr[jcol]; k < local_rowptr[jcol + 1]; ++k)
						{
							int kcol = local_colind[k];

							if (locstg[k] && cfmap[kcol] == UNASSIGNED)
								++weights[kcol];
						}
					}
				}

				for (int j = local_rowptr[r]; j < local_rowptr[r + 1]; ++j)
				{
					int jcol = local_colind[j];

					if (locstg[j] && cfmap[jcol] == UNASSIGNED)
					{
						if (--weights[jcol] == 0)
						{
							cfmap[jcol] = FINE;
							++nf;

							for (int k = local_rowptr[jcol]; k < local_rowptr[jcol + 1]; ++k)
							{
								int kcol = local_colind[k];

								if (locstg[k] && cfmap[kcol] == UNASSIGNED)
									++weights[kcol];
							}
						}
					}
				}
			}
		}
	}

	int lambda = 32768;

	for (int i = 0; i < nifrow; ++i)
	{
		int irow = ifrows[i];
		weights[irow] = (Stp[irow + 1] - Stp[irow]) * lambda + random() & 32767;
	}

	int* recvwgt = new int[recvcnt];

	for (int i = 0; i < recvcnt; ++i)
		recvwgt[i] = 0;

	for (int j = exter_rowptr[0]; j < exter_rowptr[n]; ++j)
		if (extstg[j]) recvwgt[exter_colind[j]] += lambda;

	int* recvfrom = new int[recvcnt];
	for (int r = 0; r < nnb; ++r)
		for (int i = recvptr[r]; i < recvptr[r + 1]; ++i)
			recvfrom[i] = nbrank[r];
	
	UpdateWeights(A, weights, recvwgt);
	ExchangeWeights(A, weights, recvwgt);

	delete[] Stp;
	delete[] Sti;

	for (int i = 0; i < nifrow; ++i)
	{
		int irow = ifrows[i];
		--(cfmap[irow] == COARSE ? nc : nf);
		cfmap[irow] = UNASSIGNED;
	}

	for (int i = 0; i < nifrow; ++i)
	{
		int irow = ifrows[i];

		if (weights[irow] < lambda)
		{
			cfmap[irow] = ISOLATED;
			++nf;
			continue;
		}

		for (int j = local_rowptr[irow]; j < local_rowptr[irow + 1]; ++j)
		{
			int jcol = local_colind[j];

			if (locstg[j] && cfmap[jcol] == COARSE)
			{
				cfmap[irow] = FINE;
				++nf;
				break;
			}
		}
	}

	int* recvcf = new int[recvcnt];
	
	ExchangeCFmap(A, cfmap, recvcf);

	int* nbmask = new int[nnb];
	for (int r = 0; r < nnb; ++r)
		nbmask[r] = 1;

	int LESS = 0;
	int GREATER = 2;

	while (1)
	{
		UpdateMask(A, nc + nf < n, nbmask);

		if (nc + nf == n) break;

		swap(LESS, GREATER);

		for (int i = 0; i < nifrow; ++i)
		{
			int irow = ifrows[i];

			if (cfmap[irow] == GREATER)
			{
				for (int j = local_rowptr[irow]; j < local_rowptr[irow + 1]; ++j)
				{
					int jcol = local_colind[j];

					if (locstg[j] && (cfmap[jcol] == GREATER || cfmap[jcol] == LESS))
					{
						if (weights[jcol] > weights[irow] || (weights[jcol] == weights[irow] && jcol < irow))
						{
							cfmap[irow] = LESS;
							break;
						}
						else
							cfmap[jcol] = LESS;
					}
				}
			}
		}

		for (int i = 0; i < nifrow; ++i)
		{
			int irow = ifrows[i];

			if (cfmap[irow] == GREATER)
			{
				for (int j = exter_rowptr[irow]; j < exter_rowptr[irow + 1]; ++j)
				{
					int jcol = exter_colind[j];

					if (extstg[j] && recvcf[jcol] == GREATER)
					{
						if (recvwgt[jcol] > weights[irow] || (recvwgt[jcol] == weights[irow] && recvfrom[jcol] < comm_rank))
						{
							cfmap[irow] = LESS;
							break;
						}
					}

				}
			}
		}
		
		ExchangeCFmap(A, cfmap, recvcf, nbmask);

		for (int i = 0; i < nifrow; ++i)
		{
			int irow = ifrows[i];

			if (cfmap[irow] == GREATER)
			{
				cfmap[irow] = COARSE;
				++nc;
			}
		}

		for (int i = 0; i < nifrow; ++i)
		{
			int irow = ifrows[i];

			if (cfmap[irow] == LESS)
			{
				for (int j = local_rowptr[irow]; j < local_rowptr[irow + 1]; ++j)
				{
					if (locstg[j] && cfmap[local_colind[j]] == COARSE)
					{
						cfmap[irow] = FINE;
						++nf;
						break;
					}
				}
			}
		}

		for (int i = 0; i < nifrow; ++i)
		{
			int irow = ifrows[i];

			if (cfmap[irow] == LESS)
			{
				for (int j = exter_rowptr[irow]; j < exter_rowptr[irow + 1]; ++j)
				{
					if (extstg[j] && recvcf[exter_colind[j]] == GREATER)
					{
						cfmap[irow] = FINE;
						++nf;
						break;
					}
				}
			}
		}

		ExchangeCFmap(A, cfmap, recvcf, nbmask);
	}

	delete[] recvfrom;
	delete[] weights;
	delete[] ifrows;
	delete[] recvwgt;
	delete[] recvcf;
	delete[] nbmask;

	return nc;
}

int PMISCoarsening(const ParCSRMatrix& A, const bool* locstg, const bool* extstg, int* cfmap)
{
	MPI_Comm comm = A.comm;

	int comm_rank, comm_size;
	MPI_Comm_rank(comm, &comm_rank);
	MPI_Comm_size(comm, &comm_size);

	int n = A.local.size[0];
	int recvcnt = A.exter.size[1];

	int* local_rowptr = A.local.rowptr;
	int* local_colind = A.local.colind;
	int* exter_rowptr = A.exter.rowptr;
	int* exter_colind = A.exter.colind;

	int nifrow = 0;
	int* ifrows = new int[n];
	for (int i = 0; i < n; ++i)
		if (exter_rowptr[i + 1] > exter_rowptr[i])
			ifrows[nifrow++] = i;

	int nnb = A.nnb;
	int* nbrank = A.nbrank;
	int* recvptr = A.recvptr;

	int* weights = new int[n];
	int* recvwgt = new int[recvcnt];

	int* recvfrom = new int[recvcnt];
	for (int r = 0; r < nnb; ++r)
		for (int i = recvptr[r]; i < recvptr[r + 1]; ++i)
			recvfrom[i] = nbrank[r];

	int lambda = 32768;

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel
#endif
	{
		int ithd = 0;
#ifdef YHAMG_USE_OPENMP
		ithd = omp_get_thread_num();
#endif
		uint64_t k1 = ithd + 1;
		uint64_t k2 = comm_rank + 1;
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
		for (int i = 0; i < n; ++i)
			weights[i] = xorshift128plus(k1, k2) & 32767;
	}

	for (int i = 0; i < recvcnt; ++i)
		recvwgt[i] = 0;

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
 	for (int j = local_rowptr[0]; j < local_rowptr[n]; ++j)
		if (locstg[j])
#ifdef YHAMG_USE_OPENMP
#pragma omp atomic
#endif
			weights[local_colind[j]] += lambda;

	for (int j = exter_rowptr[0]; j < exter_rowptr[n]; ++j)
		if (extstg[j]) recvwgt[exter_colind[j]] += lambda;
	
	UpdateWeights(A, weights, recvwgt);

	ExchangeWeights(A, weights, recvwgt);

	int nc = 0;
	int nf = 0;

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for reduction(+:nf) schedule(guided)
#endif
	for (int i = 0; i < n; ++i)
	{
		if (weights[i] < lambda)
		{
			cfmap[i] = ISOLATED;
			++nf;
		}
		else
			cfmap[i] = UNASSIGNED;
	}

	int* recvcf = new int[recvcnt];
	for (int i = 0; i < recvcnt; ++i)
		recvcf[i] = recvwgt[i] < lambda ? ISOLATED : UNASSIGNED;

	int* nbmask = new int[nnb];
	for (int r = 0; r < nnb; ++r)
		nbmask[r] = 1;

	int LESS = 0;
	int GREATER = 2;

	while (1)
	{
		UpdateMask(A, nc + nf < n, nbmask);

		if (nc + nf == n) break;

		swap(LESS, GREATER);

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		for (int i = 0; i < n; ++i)
		{
			if (cfmap[i] == GREATER)
			{
				for (int j = local_rowptr[i]; j < local_rowptr[i + 1]; ++j)
				{
					int jcol = local_colind[j];

					if (locstg[j] && (cfmap[jcol] == GREATER || cfmap[jcol] == LESS))
					{
						if (weights[jcol] > weights[i] || (weights[jcol] == weights[i] && jcol < i))
						{
							cfmap[i] = LESS;
							break;
						}
						else
							cfmap[jcol] = LESS;
					}
				}
			}
		}

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		for (int i = 0; i < nifrow; ++i)
		{
			int irow = ifrows[i];

			if (cfmap[irow] == GREATER)
			{
				for (int j = exter_rowptr[irow]; j < exter_rowptr[irow + 1]; ++j)
				{
					int jcol = exter_colind[j];

					if (extstg[j] && recvcf[jcol] == GREATER)
					{
						if (recvwgt[jcol] > weights[irow] || (recvwgt[jcol] == weights[irow] && recvfrom[jcol] < comm_rank))
						{
							cfmap[irow] = LESS;
							break;
						}
					}

				}
			}
		}
		
		ExchangeCFmap(A, cfmap, recvcf, nbmask);

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for reduction(+:nc) schedule(guided) 
#endif
		for (int i = 0; i < n; ++i)
		{
			if (cfmap[i] == GREATER)
			{
				cfmap[i] = COARSE;
				++nc;
			}
		}

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for reduction(+:nf) schedule(guided) 
#endif
		for (int i = 0; i < n; ++i)
		{
			if (cfmap[i] == LESS)
			{
				for (int j = local_rowptr[i]; j < local_rowptr[i + 1]; ++j)
				{
					if (locstg[j] && cfmap[local_colind[j]] == COARSE)
					{
						cfmap[i] = FINE;
						++nf;
						break;
					}
				}
			}
		}

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for reduction(+:nf) schedule(guided)
#endif
		for (int i = 0; i < nifrow; ++i)
		{
			int irow = ifrows[i];

			if (cfmap[irow] == LESS)
			{
				for (int j = exter_rowptr[irow]; j < exter_rowptr[irow + 1]; ++j)
				{
					if (extstg[j] && recvcf[exter_colind[j]] == GREATER)
					{
						cfmap[irow] = FINE;
						++nf;
						break;
					}
				}
			}
		}

		ExchangeCFmap(A, cfmap, recvcf, nbmask);
	}

	delete[] recvfrom;
	delete[] weights;
	delete[] ifrows;
	delete[] recvwgt;
	delete[] recvcf;
	delete[] nbmask;

	return nc;
}

static int HMISCoarsening(const ParCSRMatrix& S2, int* cfmap)
{
	MPI_Comm comm = S2.comm;

	int comm_rank;
	MPI_Comm_rank(comm, &comm_rank);

	int n = S2.local.size[0];
	int recvcnt = S2.exter.size[1];

	int* local_rowptr = S2.local.rowptr;
	int* local_colind = S2.local.colind;
	int* exter_rowptr = S2.exter.rowptr;
	int* exter_colind = S2.exter.colind;

	int nifrow = 0;
	int* ifrows = new int[n];
	for (int i = 0; i < n; ++i)
		if (exter_rowptr[i + 1] > exter_rowptr[i])
			ifrows[nifrow++] = i;

	int nnb = S2.nnb;
	int* nbrank = S2.nbrank;
	int* recvptr = S2.recvptr;

	int* weights = new int[n];

	int* S2tp = new int[n + 1];
	for (int i = 0; i <= n; ++i)
		S2tp[i] = 0;

	for (int j = local_rowptr[0]; j < local_rowptr[n]; ++j)
		++S2tp[local_colind[j]];

	for (int i = 0; i < n; ++i)
		S2tp[i + 1] += S2tp[i];

	int* S2ti = new int[S2tp[n]];

	for (int i = n - 1; i >= 0; --i)
		for (int j = local_rowptr[i + 1] - 1; j >= local_rowptr[i]; --j)
			S2ti[--S2tp[local_colind[j]]] = i;

	for (int i = 0; i < n; ++i)
		weights[i] = S2tp[i + 1] - S2tp[i];

	int nc = 0;
	int nf = 0;

	for (int i = 0; i < n; ++i)
		cfmap[i] = UNASSIGNED;

	while (nc + nf < n)
	{
		for (int i = 0; i < n; ++i)
		{
			int r = i;

			if (cfmap[r] == UNASSIGNED)
			{
			L0:
				for (int j = local_rowptr[r]; j < local_rowptr[r + 1]; ++j)
				{
					int jcol = local_colind[j];

					if (cfmap[jcol] == UNASSIGNED)
					{
						if (weights[r] < weights[jcol])
						{
							r = jcol;
							goto L0;
						}
					}
				}

				for (int j = S2tp[r]; j < S2tp[r + 1]; ++j)
				{
					int jcol = S2ti[j];

					if (cfmap[jcol] == UNASSIGNED)
					{
						if (weights[r] < weights[jcol])
						{
							r = jcol;
							goto L0;
						}
					}
				}

				cfmap[r] = COARSE;
				++nc;

				for (int j = S2tp[r]; j < S2tp[r + 1]; ++j)
				{
					int jcol = S2ti[j];
					if (cfmap[jcol] == UNASSIGNED)
					{
						cfmap[jcol] = FINE;
						++nf;

						for (int k = local_rowptr[jcol]; k < local_rowptr[jcol + 1]; ++k)
						{
							int kcol = local_colind[k];

							if (cfmap[kcol] == UNASSIGNED)
								++weights[kcol];
						}
					}
				}

				for (int j = local_rowptr[r]; j < local_rowptr[r + 1]; ++j)
				{
					int jcol = local_colind[j];

					if (cfmap[jcol] == UNASSIGNED)
					{
						if (--weights[jcol] == 0)
						{
							cfmap[jcol] = FINE;
							++nf;

							for (int k = local_rowptr[jcol]; k < local_rowptr[jcol + 1]; ++k)
							{
								int kcol = local_colind[k];

								if (cfmap[kcol] == UNASSIGNED)
									++weights[kcol];
							}
						}
					}
				}
			}
		}
	}

	int lambda = 32768;

	for (int i = 0; i < nifrow; ++i)
	{
		int irow = ifrows[i];
		weights[irow] = (S2tp[irow + 1] - S2tp[irow]) * lambda + random() & 32767;
	}

	int* recvwgt = new int[recvcnt];
	for (int i = 0; i < recvcnt; ++i)
		recvwgt[i] = 0;

	for (int j = exter_rowptr[0]; j < exter_rowptr[n]; ++j)
		recvwgt[exter_colind[j]] += lambda;

	int* recvfrom = new int[recvcnt];
	for (int r = 0; r < nnb; ++r)
		for (int i = recvptr[r]; i < recvptr[r + 1]; ++i)
			recvfrom[i] = nbrank[r];
	
	UpdateWeights(S2, weights, recvwgt);
	ExchangeWeights(S2, weights, recvwgt);

	delete[] S2tp;
	delete[] S2ti;

	for (int i = 0; i < nifrow; ++i)
	{
		int irow = ifrows[i];
		--(cfmap[irow] == COARSE ? nc : nf);
		cfmap[irow] = UNASSIGNED;
	}

	for (int i = 0; i < nifrow; ++i)
	{
		int irow = ifrows[i];

		for (int j = local_rowptr[irow]; j < local_rowptr[irow + 1]; ++j)
		{
			int jcol = local_colind[j];

			if (cfmap[jcol] == COARSE)
			{
				cfmap[irow] = FINE;
				++nf;
				break;
			}
		}
	}

	int* recvcf = new int[recvcnt];
	ExchangeCFmap(S2, cfmap, recvcf);

	int* nbmask = new int[nnb];
	for (int r = 0; r < nnb; ++r)
		nbmask[r] = 1;

	int LESS = 0;
	int GREATER = 2;

	while (1)
	{
		UpdateMask(S2, nc + nf < n, nbmask);

		if (nc + nf == n) break;

		swap(LESS, GREATER);

		for (int i = 0; i < nifrow; ++i)
		{
			int irow = ifrows[i];

			if (cfmap[irow] == GREATER)
			{
				for (int j = local_rowptr[irow]; j < local_rowptr[irow + 1]; ++j)
				{
					int jcol = local_colind[j];

					if ((cfmap[jcol] == GREATER || cfmap[jcol] == LESS))
					{
						if (weights[jcol] > weights[irow] || (weights[jcol] == weights[irow] && jcol < irow))
						{
							cfmap[irow] = LESS;
							break;
						}
						else
							cfmap[jcol] = LESS;
					}
				}
			}
		}

		for (int i = 0; i < nifrow; ++i)
		{
			int irow = ifrows[i];

			if (cfmap[irow] == GREATER)
			{
				for (int j = exter_rowptr[irow]; j < exter_rowptr[irow + 1]; ++j)
				{
					int jcol = exter_colind[j];

					if (recvcf[jcol] == GREATER)
					{
						if (recvwgt[jcol] > weights[irow] || (recvwgt[jcol] == weights[irow] && recvfrom[jcol] < comm_rank))
						{
							cfmap[irow] = LESS;
							break;
						}
					}

				}
			}
		}
		
		ExchangeCFmap(S2, cfmap, recvcf, nbmask);

		for (int i = 0; i < nifrow; ++i)
		{
			int irow = ifrows[i];

			if (cfmap[irow] == GREATER)
			{
				cfmap[irow] = COARSE;
				++nc;
			}
		}

		for (int i = 0; i < nifrow; ++i)
		{
			int irow = ifrows[i];

			if (cfmap[irow] == LESS)
			{
				for (int j = local_rowptr[irow]; j < local_rowptr[irow + 1]; ++j)
				{
					if (cfmap[local_colind[j]] == COARSE)
					{
						cfmap[irow] = FINE;
						++nf;
						break;
					}
				}
			}
		}

		for (int i = 0; i < nifrow; ++i)
		{
			int irow = ifrows[i];

			if (cfmap[irow] == LESS)
			{
				for (int j = exter_rowptr[irow]; j < exter_rowptr[irow + 1]; ++j)
				{
					if (recvcf[exter_colind[j]] == GREATER)
					{
						cfmap[irow] = FINE;
						++nf;
						break;
					}
				}
			}
		}

		ExchangeCFmap(S2, cfmap, recvcf, nbmask);
	}

	delete[] recvfrom;
	delete[] weights;
	delete[] ifrows;
	delete[] recvwgt;
	delete[] recvcf;
	delete[] nbmask;

	return nc;
}

static int PMISCoarsening(const ParCSRMatrix& S2, int* cfmap)
{
	MPI_Comm comm = S2.comm;

	int comm_rank, comm_size;
	MPI_Comm_rank(comm, &comm_rank);
	MPI_Comm_size(comm, &comm_size);

	int n = S2.local.size[0];
	int recvcnt = S2.exter.size[1];

	int* local_rowptr = S2.local.rowptr;
	int* local_colind = S2.local.colind;
	int* exter_rowptr = S2.exter.rowptr;
	int* exter_colind = S2.exter.colind;

	int nifrow = 0;
	int* ifrows = new int[n];
	for (int i = 0; i < n; ++i)
		if (exter_rowptr[i + 1] > exter_rowptr[i])
			ifrows[nifrow++] = i;

	int nnb = S2.nnb;
	int* nbrank = S2.nbrank;
	int* recvptr = S2.recvptr;

	int* weights = new int[n];
	int* recvwgt = new int[recvcnt];

	int* recvfrom = new int[recvcnt];
	for (int r = 0; r < nnb; ++r)
		for (int i = recvptr[r]; i < recvptr[r + 1]; ++i)
			recvfrom[i] = nbrank[r];

	int lambda = 32768;

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel
#endif
	{
		int ithd = 0;
#ifdef YHAMG_USE_OPENMP	
		ithd = omp_get_thread_num();
#endif
		uint64_t k1 = ithd + 1;
		uint64_t k2 = comm_rank + 1;
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
		for (int i = 0; i < n; ++i)
			weights[i] = xorshift128plus(k1, k2) & 32767;
	}

 	for (int i = 0; i < recvcnt; ++i)
		recvwgt[i] = 0;

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
 	for (int j = local_rowptr[0]; j < local_rowptr[n]; ++j)
#ifdef YHAMG_USE_OPENMP
#pragma omp atomic
#endif
		weights[local_colind[j]] += lambda;

	for (int j = exter_rowptr[0]; j < exter_rowptr[n]; ++j)
		recvwgt[exter_colind[j]] += lambda;
	
	UpdateWeights(S2, weights, recvwgt);
	ExchangeWeights(S2, weights, recvwgt);

	int nc = 0;
	int nf = 0;

	for (int i = 0; i < n; ++i)
		cfmap[i] = UNASSIGNED;

	int* recvcf = new int[recvcnt];
	for (int i = 0; i < recvcnt; ++i)
		recvcf[i] = UNASSIGNED;

	int* nbmask = new int[nnb];
	for (int r = 0; r < nnb; ++r)
		nbmask[r] = 1;

	int LESS = 0;
	int GREATER = 2;

	while (1)
	{
		UpdateMask(S2, nc + nf < n, nbmask);

		if (nc + nf == n) break;

		swap(LESS, GREATER);

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		for (int i = 0; i < n; ++i)
		{
			if (cfmap[i] == GREATER)
			{
				for (int j = local_rowptr[i]; j < local_rowptr[i + 1]; ++j)
				{
					int jcol = local_colind[j];

					if ((cfmap[jcol] == GREATER || cfmap[jcol] == LESS))
					{
						if (weights[jcol] > weights[i] || (weights[jcol] == weights[i] && jcol < i))
						{
							cfmap[i] = LESS;
							break;
						}
						else
							cfmap[jcol] = LESS;
					}
				}
			}
		}

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		for (int i = 0; i < nifrow; ++i)
		{
			int irow = ifrows[i];

			if (cfmap[irow] == GREATER)
			{
				for (int j = exter_rowptr[irow]; j < exter_rowptr[irow + 1]; ++j)
				{
					int jcol = exter_colind[j];

					if (recvcf[jcol] == GREATER)
					{
						if (recvwgt[jcol] > weights[irow] || (recvwgt[jcol] == weights[irow] && recvfrom[jcol] < comm_rank))
						{
							cfmap[irow] = LESS;
							break;
						}
					}
				}
			}
		}
		
		ExchangeCFmap(S2, cfmap, recvcf, nbmask);

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for reduction(+:nc) schedule(guided) 
#endif
		for (int i = 0; i < n; ++i)
		{
			if (cfmap[i] == GREATER)
			{
				cfmap[i] = COARSE;
				++nc;
			}
		}

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for reduction(+:nf) schedule(guided) 
#endif
		for (int i = 0; i < n; ++i)
		{
			if (cfmap[i] == LESS)
			{
				for (int j = local_rowptr[i]; j < local_rowptr[i + 1]; ++j)
				{
					if (cfmap[local_colind[j]] == COARSE)
					{
						cfmap[i] = FINE;
						++nf;
						break;
					}
				}
			}
		}

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for reduction(+:nf) schedule(guided)
#endif
		for (int i = 0; i < nifrow; ++i)
		{
			int irow = ifrows[i];

			if (cfmap[irow] == LESS)
			{
				for (int j = exter_rowptr[irow]; j < exter_rowptr[irow + 1]; ++j)
				{
					if (recvcf[exter_colind[j]] == GREATER)
					{
						cfmap[irow] = FINE;
						++nf;
						break;
					}
				}
			}
		}

		ExchangeCFmap(S2, cfmap, recvcf, nbmask);
	}

	delete[] recvfrom;
	delete[] weights;
	delete[] ifrows;
	delete[] recvwgt;
	delete[] recvcf;
	delete[] nbmask;

	return nc;
}

static void Strength2(const ParCSRMatrix& A, const bool* locstg, const bool* extstg, int* cfmap, ParCSRMatrix& S2)
{
	MPI_Comm comm = A.comm;

	int comm_rank;
	MPI_Comm_rank(comm, &comm_rank);

	int n = A.local.size[0];
	int recvcnt = A.exter.size[1];

	int* A_local_rowptr = A.local.rowptr;
	int* A_local_colind = A.local.colind;
	int* A_exter_rowptr = A.exter.rowptr;
	int* A_exter_colind = A.exter.colind;

	int nnb = A.nnb;
	int* nbrank = A.nbrank;
	int* recvptr = A.recvptr;
	int* sendptr = A.sendptr;
	int* sendind = A.sendind;
	int* sendcf = new int[sendptr[nnb]];

	int nc = 0;
	for (int i = 0; i < n; ++i)
		if (cfmap[i] >= 0)
			cfmap[i] = nc++;

	int* recvcf = new int[recvcnt];

	MPI_Request* recvreq = new MPI_Request[nnb];
	MPI_Request* sendreq = new MPI_Request[nnb];
	MPI_Status status;

	for (int r = 0; r < nnb; ++r)
		if (recvptr[r + 1] > recvptr[r])
			MPI_Irecv(recvcf + recvptr[r], recvptr[r + 1] - recvptr[r], MPI_INT, nbrank[r], MPI_TAG, comm, recvreq + r);

	for (int r = 0; r < nnb; ++r)
	{
		if (sendptr[r + 1] > sendptr[r])
		{
			for (int i = sendptr[r]; i < sendptr[r + 1]; ++i)
				sendcf[i] = cfmap[sendind[i]];
			MPI_Isend(sendcf + sendptr[r], sendptr[r + 1] - sendptr[r], MPI_INT, nbrank[r], MPI_TAG, comm, sendreq + r);
		}
	}

	for (int r = 0; r < nnb; ++r)
		if (recvptr[r + 1] > recvptr[r])
			MPI_Wait(recvreq + r, &status);

	for (int r = 0; r < nnb; ++r)
		if (sendptr[r + 1] > sendptr[r])
			MPI_Wait(sendreq + r, &status);

	delete[] sendcf;

	int* Sc_recvind = new int[recvcnt];
	int* Sc_recvptr = new int[nnb + 1];

	Sc_recvptr[0] = 0;
	for (int r = 0, k = 0; r < nnb; Sc_recvptr[++r] = k)
	{
		for (int i = recvptr[r]; i < recvptr[r + 1]; ++i)
		{
			if (recvcf[i] >= 0)
			{
				Sc_recvind[k] = recvcf[i];
				recvcf[i] = k++;
			}
		}
	}

	int* Sc_local_rowptr = new int[n + 1];
	int* Sc_exter_rowptr = new int[n + 1];

	Sc_local_rowptr[0] = 0;
	Sc_exter_rowptr[0] = 0;

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
	for (int i = 0; i < n; ++i)
	{
		if (cfmap[i] < 0)
		{
			int cntloc = 0;
			int cntext = 0;

			for (int j = A_local_rowptr[i]; j < A_local_rowptr[i + 1]; ++j)
				if (locstg[j] && cfmap[A_local_colind[j]] >= 0) ++cntloc;
			for (int j = A_exter_rowptr[i]; j < A_exter_rowptr[i + 1]; ++j)
				if (extstg[j] && recvcf[A_exter_colind[j]] >= 0) ++cntext;

			Sc_local_rowptr[i + 1] = cntloc;
			Sc_exter_rowptr[i + 1] = cntext;
		}
		else
		{
			Sc_local_rowptr[i + 1] = 0;
			Sc_exter_rowptr[i + 1] = 0;
		}
	}

	for (int i = 0; i < n; ++i)
		Sc_local_rowptr[i + 1] += Sc_local_rowptr[i];
	for (int i = 0; i < n; ++i)
		Sc_exter_rowptr[i + 1] += Sc_exter_rowptr[i];

	int* Sc_local_colind = new int[Sc_local_rowptr[n]];
	int* Sc_exter_colind = new int[Sc_exter_rowptr[n]];

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
	for (int i = 0; i < n; ++i)
	{
		if (cfmap[i] < 0)
		{
			for (int j = A_local_rowptr[i], k = Sc_local_rowptr[i]; j < A_local_rowptr[i + 1]; ++j)
				if (locstg[j] && cfmap[A_local_colind[j]] >= 0)
					Sc_local_colind[k++] = cfmap[A_local_colind[j]];

			for (int j = A_exter_rowptr[i], k = Sc_exter_rowptr[i]; j < A_exter_rowptr[i + 1]; ++j)
				if (extstg[j] && recvcf[A_exter_colind[j]] >= 0)
					Sc_exter_colind[k++] = recvcf[A_exter_colind[j]];
		}
	}

	int* Sc_recvfrom = new int[Sc_recvptr[nnb]];
	for (int r = 0; r < nnb; ++r)
		for (int i = Sc_recvptr[r]; i < Sc_recvptr[r + 1]; ++i)
			Sc_recvfrom[i] = r;

	std::map<int, int> nbmap;
	for (int r = 0; r < nnb; ++r)
		nbmap.insert(std::pair<int, int>(nbrank[r], r));

	std::set<int>* nbset = new std::set<int>[nnb];

	for (int r = 0; r < nnb; ++r)
	{
		for (int i = sendptr[r]; i < sendptr[r + 1]; ++i)
		{
			int irow = sendind[i];
			for (int j = Sc_exter_rowptr[irow]; j < Sc_exter_rowptr[irow + 1]; ++j)
			{
				int jfrom = Sc_recvfrom[Sc_exter_colind[j]];
				if (jfrom != r)
				{
					nbset[r].insert(nbrank[jfrom]);
					nbset[jfrom].insert(nbrank[r]);
				}
			}
		}
	}

	int** recvnbset = new int* [nnb];
	int** sendnbset = new int* [nnb];

	for (int r = 0; r < nnb; ++r)
	{
		sendnbset[r] = new int[nbset[r].size()];
		int i = 0;
		for (std::set<int>::iterator iter = nbset[r].begin(); iter != nbset[r].end(); ++iter)
			sendnbset[r][i++] = *iter;
		MPI_Isend(sendnbset[r], nbset[r].size(), MPI_INT, nbrank[r], MPI_TAG, comm, sendreq + r);
	}

	for (int r = 0; r < nnb; ++r)
	{
		int cnt;
		MPI_Probe(nbrank[r], MPI_TAG, comm, &status);
		MPI_Get_count(&status, MPI_INT, &cnt);
		recvnbset[r] = new int[cnt];
		MPI_Irecv(recvnbset[r], cnt, MPI_INT, nbrank[r], MPI_TAG, comm, recvreq + r);
	}

	for (int r = 0; r < nnb; ++r)
	{
		int cnt;
		MPI_Wait(recvreq + r, &status);
		MPI_Get_count(&status, MPI_INT, &cnt);
		for (int i = 0; i < cnt; ++i)
			nbmap.insert(std::pair<int, int>(recvnbset[r][i], nbmap.size()));
		delete[] recvnbset[r];
	}

	for (int r = 0; r < nnb; ++r)
	{
		MPI_Wait(sendreq + r, &status);
		delete[] sendnbset[r];
	}

	delete[] nbset;
	delete[] recvnbset;
	delete[] sendnbset;

	int S2_nnb = nbmap.size();
	int* S2_nbrank = new int[S2_nnb];
	for (std::map<int, int>::iterator iter = nbmap.begin(); iter != nbmap.end(); ++iter)
		S2_nbrank[iter->second] = iter->first;

	int* sendbufsize = new int[nnb];
	int* recvbufsize = new int[nnb];

	for (int r = 0; r < nnb; ++r)
		if (recvptr[r + 1] > recvptr[r])
			MPI_Irecv(recvbufsize + r, 1, MPI_INT, nbrank[r], MPI_TAG, comm, recvreq + r);

	for (int r = 0; r < nnb; ++r)
	{
		if (sendptr[r + 1] > sendptr[r])
		{
			int nrow = sendptr[r + 1] - sendptr[r];
			int nnz = 0;
			for (int i = sendptr[r]; i < sendptr[r + 1]; ++i)
				nnz += Sc_local_rowptr[sendind[i] + 1] - Sc_local_rowptr[sendind[i]] + Sc_exter_rowptr[sendind[i] + 1] - Sc_exter_rowptr[sendind[i]];
			sendbufsize[r] = (nrow + 2 * nnz) * sizeof(int);
			MPI_Send(sendbufsize + r, 1, MPI_INT, nbrank[r], MPI_TAG, comm);
		}
	}

	for (int r = 0; r < nnb; ++r)
		if (recvptr[r + 1] > recvptr[r])
			MPI_Wait(recvreq + r, &status);

	char** recvbuf = new char* [nnb];
	char** sendbuf = new char* [nnb];

	for (int r = 0; r < nnb; ++r)
	{
		if (recvptr[r + 1] > recvptr[r])
		{
			recvbuf[r] = (char*)malloc(recvbufsize[r]);
			MPI_Irecv(recvbuf[r], recvbufsize[r], MPI_PACKED, nbrank[r], MPI_TAG, comm, recvreq + r);
		}
	}

	for (int r = 0; r < nnb; ++r)
	{
		if (sendptr[r + 1] > sendptr[r])
		{
			sendbuf[r] = (char*)malloc(sendbufsize[r]);

			int position = 0;
			for (int i = sendptr[r]; i < sendptr[r + 1]; ++i)
			{
				int row = sendind[i];
				int length = Sc_local_rowptr[row + 1] - Sc_local_rowptr[row] + Sc_exter_rowptr[row + 1] - Sc_exter_rowptr[row];

				int* colfrom = new int[length];
				int* colind = new int[length];

				int j = 0;
				for (int k = Sc_local_rowptr[row]; k < Sc_local_rowptr[row + 1]; ++k)
				{
					colfrom[j] = comm_rank;
					colind[j++] = Sc_local_colind[k];
				}
				for (int k = Sc_exter_rowptr[row]; k < Sc_exter_rowptr[row + 1]; ++k)
				{
					int kcol = Sc_exter_colind[k];
					colfrom[j] = nbrank[Sc_recvfrom[kcol]];
					colind[j++] = Sc_recvind[kcol];
				}

				MPI_Pack(&length, 1, MPI_INT, sendbuf[r], sendbufsize[r], &position, comm);
				MPI_Pack(colfrom, length, MPI_INT, sendbuf[r], sendbufsize[r], &position, comm);
				MPI_Pack(colind, length, MPI_INT, sendbuf[r], sendbufsize[r], &position, comm);

				delete[] colfrom;
				delete[] colind;
			}

			MPI_Isend(sendbuf[r], sendbufsize[r], MPI_PACKED, nbrank[r], MPI_TAG, comm, sendreq + r);
		}
	}

	std::map<int, int>* recvmap = new std::map<int, int>[S2_nnb];
	for (int r = 0; r < nnb; ++r)
		for (int i = Sc_recvptr[r], j = 0; i < Sc_recvptr[r + 1]; ++i, ++j)
			recvmap[r].insert(std::pair<int, int>(Sc_recvind[i], j));

	int Sc_recvnnz = 0;
	for (int r = 0; r < nnb; ++r)
	{
		if (recvptr[r + 1] > recvptr[r])
		{
			int nrow = recvptr[r + 1] - recvptr[r];
			int nnz = (recvbufsize[r] - nrow * sizeof(int)) / (2 * sizeof(int));
			Sc_recvnnz += nnz;
		}
	}

	int* Sc_recvloc_rowptr = new int[recvcnt + 1];
	int* Sc_recvloc_colind = new int[Sc_recvnnz];
	int* Sc_recvext_rowptr = new int[recvcnt + 1];
	int* Sc_recvext_colind = new int[Sc_recvnnz];
	int* Sc_recvext_colfrom = new int[Sc_recvnnz];

	Sc_recvloc_rowptr[0] = 0;
	Sc_recvext_rowptr[0] = 0;
	for (int r = 0; r < nnb; ++r)
	{
		if (recvptr[r + 1] > recvptr[r])
		{
			MPI_Wait(recvreq + r, &status);

			int position = 0;

			for (int i = recvptr[r], k = Sc_recvloc_rowptr[i], t = Sc_recvext_rowptr[i]; i < recvptr[r + 1]; Sc_recvloc_rowptr[++i] = k, Sc_recvext_rowptr[i] = t)
			{
				int length;
				MPI_Unpack(recvbuf[r], recvbufsize[r], &position, &length, 1, MPI_INT, comm);

				int* colfrom = new int[length];
				int* colind = new int[length];

				MPI_Unpack(recvbuf[r], recvbufsize[r], &position, colfrom, length, MPI_INT, comm);
				MPI_Unpack(recvbuf[r], recvbufsize[r], &position, colind, length, MPI_INT, comm);

				for (int j = 0; j < length; ++j)
				{
					if (colfrom[j] == comm_rank)
						Sc_recvloc_colind[k++] = colind[j];
					else
					{
						int jfrom = r;
						if (colfrom[j] != nbrank[r])
							jfrom = nbmap[colfrom[j]];
						Sc_recvext_colfrom[t] = jfrom;
						std::pair<std::map<int, int>::iterator, bool> ret = recvmap[jfrom].insert(std::pair<int, int>(colind[j], recvmap[jfrom].size()));
						Sc_recvext_colind[t++] = ret.first->second;
					}
				}

				delete[] colfrom;
				delete[] colind;
			}

			free(recvbuf[r]);
		}
	}

	for (int r = 0; r < nnb; ++r)
	{
		if (sendptr[r + 1] > sendptr[r])
		{
			MPI_Wait(sendreq + r, &status);
			free(sendbuf[r]);
		}
	}

	delete[] recvbufsize;
	delete[] recvbuf;
	delete[] recvreq;
	delete[] sendbufsize;
	delete[] sendbuf;
	delete[] sendreq;

	int* S2_recvptr = new int[S2_nnb + 1];
	S2_recvptr[0] = 0;
	for (int r = 0; r < S2_nnb; ++r)
		S2_recvptr[r + 1] = S2_recvptr[r] + recvmap[r].size();

	int* S2_recvind = new int[S2_recvptr[S2_nnb]];
	for (int r = 0; r < S2_nnb; ++r)
		for (std::map<int, int>::iterator iter = recvmap[r].begin(); iter != recvmap[r].end(); ++iter)
			S2_recvind[S2_recvptr[r] + iter->second] = iter->first;

	for (int j = 0; j < Sc_recvext_rowptr[recvcnt]; ++j)
		Sc_recvext_colind[j] += S2_recvptr[Sc_recvext_colfrom[j]];

	for (int j = 0; j < Sc_exter_rowptr[nc]; ++j)
	{
		int r = Sc_recvfrom[Sc_exter_colind[j]];
		Sc_exter_colind[j] += S2_recvptr[r] - Sc_recvptr[r];
	}

	delete[] recvmap;
	delete[] Sc_recvfrom;
	delete[] Sc_recvext_colfrom;

	int* S2_local_rowptr = new int[nc + 1];
	int* S2_exter_rowptr = new int[nc + 1];

	S2_local_rowptr[0] = 0;
	S2_exter_rowptr[0] = 0;
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel
#endif
	{
		int* w = new int[nc];
		for (int i = 0; i < nc; ++i)
			w[i] = -1;

		int* v = new int[S2_recvptr[S2_nnb]];
		for (int i = 0; i < S2_recvptr[S2_nnb]; ++i)
			v[i] = -1;

#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
		for (int i = 0; i < n; ++i)
		{
			if (cfmap[i] >= 0)
			{
				int imap = cfmap[i];
				int cntloc = 0;
				int cntext = 0;

				for (int k = A_local_rowptr[i]; k < A_local_rowptr[i + 1]; ++k)
				{
					if (!locstg[k]) continue;

					int kcol = A_local_colind[k];
					for (int j = Sc_local_rowptr[kcol]; j < Sc_local_rowptr[kcol + 1]; ++j)
					{
						int jcol = Sc_local_colind[j];
						if (w[jcol] != i && jcol != imap)
						{
							w[jcol] = i;
							++cntloc;
						}
					}

					for (int j = Sc_exter_rowptr[kcol]; j < Sc_exter_rowptr[kcol + 1]; ++j)
					{
						int jcol = Sc_exter_colind[j];
						if (v[jcol] != i)
						{
							v[jcol] = i;
							++cntext;
						}
					}
				}

				for (int k = A_exter_rowptr[i]; k < A_exter_rowptr[i + 1]; ++k)
				{
					if (!extstg[k]) continue;

					int kcol = A_exter_colind[k];
					for (int j = Sc_recvloc_rowptr[kcol]; j < Sc_recvloc_rowptr[kcol + 1]; ++j)
					{
						int jcol = Sc_recvloc_colind[j];
						if (w[jcol] != i && jcol != imap)
						{
							w[jcol] = i;
							++cntloc;
						}
					}

					for (int j = Sc_recvext_rowptr[kcol]; j < Sc_recvext_rowptr[kcol + 1]; ++j)
					{
						int jcol = Sc_recvext_colind[j];
						if (v[jcol] != i)
						{
							v[jcol] = i;
							++cntext;
						}
					}
				}

				S2_local_rowptr[imap + 1] = cntloc;
				S2_exter_rowptr[imap + 1] = cntext;
			}
		}

		delete[] w;
		delete[] v;
	}

	for (int i = 0; i < nc; ++i)
		S2_local_rowptr[i + 1] += S2_local_rowptr[i];
	for (int i = 0; i < nc; ++i)
		S2_exter_rowptr[i + 1] += S2_exter_rowptr[i];

	int* S2_local_colind = new int[S2_local_rowptr[nc]];
	int* S2_exter_colind = new int[S2_exter_rowptr[nc]];

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel
#endif
	{
		int* w = new int[nc];
		for (int i = 0; i < nc; ++i)
			w[i] = -1;

		int* v = new int[S2_recvptr[S2_nnb]];
		for (int i = 0; i < S2_recvptr[S2_nnb]; ++i)
			v[i] = -1;

#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
		for (int i = 0; i < n; ++i)
		{
			if (cfmap[i] >= 0)
			{
				int imap = cfmap[i];
				int r = S2_local_rowptr[imap];
				int s = S2_exter_rowptr[imap];

				for (int k = A_local_rowptr[i]; k < A_local_rowptr[i + 1]; ++k)
				{
					if (!locstg[k]) continue;

					int kcol = A_local_colind[k];
					for (int j = Sc_local_rowptr[kcol]; j < Sc_local_rowptr[kcol + 1]; ++j)
					{
						int jcol = Sc_local_colind[j];
						if (w[jcol] != i && jcol != imap)
						{
							w[jcol] = i;
							S2_local_colind[r++] = jcol;
						}
					}

					for (int j = Sc_exter_rowptr[kcol]; j < Sc_exter_rowptr[kcol + 1]; ++j)
					{
						int jcol = Sc_exter_colind[j];
						if (v[jcol] != i)
						{
							v[jcol] = i;
							S2_exter_colind[s++] = jcol;
						}
					}
				}

				for (int k = A_exter_rowptr[i]; k < A_exter_rowptr[i + 1]; ++k)
				{
					if (!extstg[k]) continue;

					int kcol = A_exter_colind[k];
					for (int j = Sc_recvloc_rowptr[kcol]; j < Sc_recvloc_rowptr[kcol + 1]; ++j)
					{
						int jcol = Sc_recvloc_colind[j];
						if (w[jcol] != i && jcol != imap)
						{
							w[jcol] = i;
							S2_local_colind[r++] = jcol;
						}
					}

					for (int j = Sc_recvext_rowptr[kcol]; j < Sc_recvext_rowptr[kcol + 1]; ++j)
					{
						int jcol = Sc_recvext_colind[j];
						if (v[jcol] != i)
						{
							v[jcol] = i;
							S2_exter_colind[s++] = jcol;
						}
					}
				}
			}
		}

		delete[] w;
		delete[] v;
	}

	S2.Free();

	S2.comm = comm;
	S2.local.size[0] = nc;
	S2.local.size[1] = nc;
	S2.local.rowptr = S2_local_rowptr;
	S2.local.colind = S2_local_colind;
	S2.local.values = new double[1];
	S2.exter.size[0] = nc;
	S2.exter.size[1] = S2_recvptr[S2_nnb];
	S2.exter.rowptr = S2_exter_rowptr;
	S2.exter.colind = S2_exter_colind;
	S2.exter.values = new double[1];
	S2.nnb = S2_nnb;
	S2.nbrank = S2_nbrank;
	S2.recvptr = S2_recvptr;
	S2.recvind = S2_recvind;
}

int AggressiveHMISCoarsening(const ParCSRMatrix& A, const bool* locstg, const bool* extstg, int* cfmap)
{
	int n = A.local.size[0];

	int nc;
	nc = HMISCoarsening(A, locstg, extstg, cfmap);

	ParCSRMatrix S2;
	Strength2(A, locstg, extstg, cfmap, S2);

	S2.SetupHalo();

	int* aggcf = new int[nc];

	int aggnc;
	aggnc = HMISCoarsening(S2, aggcf);

	for (int i = 0, j = 0; i < n; ++i)
		if (cfmap[i] >= 0)
			cfmap[i] = aggcf[j++];

	delete[] aggcf;

	return aggnc;
}

int AggressivePMISCoarsening(const ParCSRMatrix& A, const bool* locstg, const bool* extstg, int* cfmap)
{
	int n = A.local.size[0];

	int nc;
	nc = PMISCoarsening(A, locstg, extstg, cfmap);

	ParCSRMatrix S2;
	Strength2(A, locstg, extstg, cfmap, S2);

	S2.SetupHalo();

	int* aggcf = new int[nc];

	int aggnc;
	aggnc = PMISCoarsening(S2, aggcf);

	for (int i = 0, j = 0; i < n; ++i)
		if (cfmap[i] >= 0)
			cfmap[i] = aggcf[j++];

	delete[] aggcf;

	return aggnc;
}

void DirectInterpolation(const ParCSRMatrix& A, const bool* locstg, const bool* extstg, int* cfmap, ParCSRMatrix& P)
{
	MPI_Comm comm = A.comm;

	int n = A.local.size[0];
	int recvcnt = A.exter.size[1];

	int* A_local_rowptr = A.local.rowptr;
	int* A_local_colind = A.local.colind;
	double* A_local_values = A.local.values;
	int* A_exter_rowptr = A.exter.rowptr;
	int* A_exter_colind = A.exter.colind;
	double* A_exter_values = A.exter.values;

	int nnb = A.nnb;
	int* nbrank = A.nbrank;

	int* recvptr = A.recvptr;
	int* recvind = A.recvind;

	int* sendptr = A.sendptr;
	int* sendind = A.sendind;
	int* sendbuf = new int[sendptr[nnb]];

	int nc = 0;
	for (int i = 0; i < n; ++i)
		if (cfmap[i] >= 0)
			cfmap[i] = nc++;

	int* recvcf = new int[recvcnt];

	MPI_Request* recvreq = new MPI_Request[nnb];
	MPI_Request* sendreq = new MPI_Request[nnb];
	MPI_Status status;

	for (int r = 0; r < nnb; ++r)
		if (recvptr[r + 1] > recvptr[r])
			MPI_Irecv(recvcf + recvptr[r], recvptr[r + 1] - recvptr[r],
				MPI_INT, nbrank[r], MPI_TAG, comm, recvreq + r);

	for (int r = 0; r < nnb; ++r)
	{
		if (sendptr[r + 1] > sendptr[r])
		{
			for (int i = sendptr[r]; i < sendptr[r + 1]; ++i)
				sendbuf[i] = cfmap[sendind[i]];
			MPI_Isend(sendbuf + sendptr[r], sendptr[r + 1] - sendptr[r], MPI_INT, nbrank[r], MPI_TAG, comm, sendreq + r);
		}
	}

	for (int r = 0; r < nnb; ++r)
		if (recvptr[r + 1] > recvptr[r])
			MPI_Wait(recvreq + r, &status);

	for (int r = 0; r < nnb; ++r)
		if (sendptr[r + 1] > sendptr[r])
			MPI_Wait(sendreq + r, &status);

	delete[] recvreq;
	delete[] sendreq;
	delete[] sendbuf;
	
	int* P_recvind = new int[recvcnt];
	int* P_recvptr = new int[nnb + 1];

	P_recvptr[0] = 0;
	for (int r = 0, k = 0; r < nnb; P_recvptr[++r] = k)
	{
		for (int i = recvptr[r]; i < recvptr[r + 1]; ++i)
		{
			if (recvcf[i] >= 0)
			{
				P_recvind[k] = recvcf[i];
				recvcf[i] = k++;
			}
		}
	}

	int* P_local_rowptr = new int[n + 1];
	int* P_exter_rowptr = new int[n + 1];

	P_local_rowptr[0] = 0;
	P_exter_rowptr[0] = 0;

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
	for (int i = 0; i < n; ++i)
	{
		if (cfmap[i] < 0)
		{
			int cntloc_cs = 0;
			int cntext_cs = 0;

			for (int j = A_local_rowptr[i]; j < A_local_rowptr[i + 1]; ++j)
			{
				int jcol = A_local_colind[j];
				if (locstg[j] && cfmap[jcol] >= 0) ++cntloc_cs;
			}

			for (int j = A_exter_rowptr[i]; j < A_exter_rowptr[i + 1]; ++j)
			{
				int jcol = A_exter_colind[j];
				if (extstg[j] && recvcf[jcol] >= 0) ++cntext_cs;
			}

			P_local_rowptr[i + 1] = cntloc_cs;
			P_exter_rowptr[i + 1] = cntext_cs;
		}
		else
		{
			P_local_rowptr[i + 1] = 1;
			P_exter_rowptr[i + 1] = 0;
		}
	}

	for (int i = 0; i < n; ++i)
		P_local_rowptr[i + 1] += P_local_rowptr[i];
	for (int i = 0; i < n; ++i)
		P_exter_rowptr[i + 1] += P_exter_rowptr[i];

	int* P_local_colind = new int[P_local_rowptr[n]];
	double* P_local_values = new double[P_local_rowptr[n]];
	int* P_exter_colind = new int[P_exter_rowptr[n]];
	double* P_exter_values = new double[P_exter_rowptr[n]];

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
	for (int i = 0; i < n; ++i)
	{
		if (cfmap[i] < 0)
		{
			double diagonal = 0.0;
			double sum_n = 0.0;
			double sum_p = 0.0;

			for (int j = A_local_rowptr[i]; j < A_local_rowptr[i + 1]; ++j)
			{
				if (A_local_colind[j] == i)
					diagonal = A_local_values[j];
				else
					sum_n += A_local_values[j];
			}

			for (int j = A_exter_rowptr[i]; j < A_exter_rowptr[i + 1]; ++j)
				sum_n += A_exter_values[j];

			for (int j = A_local_rowptr[i], k = P_local_rowptr[i]; j < A_local_rowptr[i + 1]; ++j)
			{
				int jcol = A_local_colind[j];

				if (locstg[j] && cfmap[jcol] >= 0)
				{
					double _jval = _(A_local_values[j]);
					P_local_colind[k] = cfmap[jcol];
					P_local_values[k++] = _jval;
					sum_p += _jval;
				}
			}

			for (int j = A_exter_rowptr[i], k = P_exter_rowptr[i]; j < A_exter_rowptr[i + 1]; ++j)
			{
				int jcol = A_exter_colind[j];

				if (extstg[j] && recvcf[jcol] >= 0)
				{
					double _jval = _(A_exter_values[j]);
					P_exter_colind[k] = recvcf[jcol];
					P_exter_values[k++] = _jval;
					sum_p += _jval;
				}
			}

			double omega = (sum_p != 0 && diagonal != 0) ? -sum_n / (diagonal * sum_p) : 0.0;
			for (int j = P_local_rowptr[i]; j < P_local_rowptr[i + 1]; ++j)
				P_local_values[j] *= omega;
			for (int j = P_exter_rowptr[i]; j < P_exter_rowptr[i + 1]; ++j)
				P_exter_values[j] *= omega;
		}
		else
		{
			P_local_colind[P_local_rowptr[i]] = cfmap[i];
			P_local_values[P_local_rowptr[i]] = 1.0;
		}
	}

	int* P_nbrank = new int[nnb];
	for (int r = 0; r < nnb; ++r)
		P_nbrank[r] = nbrank[r];

	delete[] recvcf;

	P.Free();

	P.comm = comm;
	P.local.size[0] = n;
	P.local.size[1] = nc;
	P.local.rowptr = P_local_rowptr;
	P.local.colind = P_local_colind;
	P.local.values = P_local_values;

	P.exter.size[0] = n;
	P.exter.size[1] = P_recvptr[nnb];
	P.exter.rowptr = P_exter_rowptr;
	P.exter.colind = P_exter_colind;
	P.exter.values = P_exter_values;

	P.nnb = nnb;
	P.nbrank = P_nbrank;
	P.recvptr = P_recvptr;
	P.recvind = P_recvind;
}	

void JacobiInterpolation(const ParCSRMatrix& A, ParCSRMatrix& P, const bool* mask)
{
	MPI_Comm comm = A.comm;

	int comm_rank;
	MPI_Comm_rank(comm, &comm_rank);

	int nnb = A.nnb;
	int* nbrank = A.nbrank;

	int* recvptr = A.recvptr;
	int* sendptr = A.sendptr;
	int* sendind = A.sendind;

	int n = A.local.size[0];
	int m = P.local.size[1];

	int* A_local_rowptr = A.local.rowptr;
	int* A_local_colind = A.local.colind;
	double* A_local_values = A.local.values;

	int* A_exter_rowptr = A.exter.rowptr;
	int* A_exter_colind = A.exter.colind;
	double* A_exter_values = A.exter.values;

	int* P_local_rowptr = P.local.rowptr;
	int* P_local_colind = P.local.colind;
	double* P_local_values = P.local.values;

	int* P_exter_rowptr = P.exter.rowptr;
	int* P_exter_colind = P.exter.colind;
	double* P_exter_values = P.exter.values;

	int P_nnb = P.nnb;
	int* P_nbrank = P.nbrank;
	int* P_recvptr = P.recvptr;
	int* P_recvind = P.recvind;

	int* P_recvfrom = new int[P.exter.size[1]];
	for (int r = 0; r < P_nnb; ++r)
		for (int i = P_recvptr[r]; i < P_recvptr[r + 1]; ++i)
			P_recvfrom[i] = r;

	std::map<int, int> nbmap;
	for (int r = 0; r < P_nnb; ++r)
		nbmap.insert(std::pair<int, int>(P_nbrank[r], r));
	for (int r = 0; r < nnb; ++r)
		nbmap.insert(std::pair<int, int>(nbrank[r], nbmap.size()));

	int Q_nnb = nbmap.size();
	int* Q_nbrank = new int[Q_nnb];
	for (std::map<int, int>::iterator iter = nbmap.begin(); iter != nbmap.end(); ++iter)
		Q_nbrank[iter->second] = iter->first;

	std::set<int>* nbset = new std::set<int>[Q_nnb];

	for (int r = 0; r < nnb; ++r)
	{
		int _r = nbmap[nbrank[r]];
		for (int i = sendptr[r]; i < sendptr[r + 1]; ++i)
		{
			int irow = sendind[i];
			for (int j = P_exter_rowptr[irow]; j < P_exter_rowptr[irow + 1]; ++j)
			{
				int jfrom = P_recvfrom[P_exter_colind[j]];
				if (jfrom != _r)
				{
					nbset[_r].insert(P_nbrank[jfrom]);
					nbset[jfrom].insert(nbrank[r]);
				}
			}
		}
	}

	int** recvnbset = new int* [Q_nnb];
	int** sendnbset = new int* [Q_nnb];

	MPI_Request* recvreq = new MPI_Request[Q_nnb];
	MPI_Request* sendreq = new MPI_Request[Q_nnb];
	MPI_Status status;

	for (int r = 0; r < Q_nnb; ++r)
	{
		sendnbset[r] = new int[nbset[r].size()];
		int i = 0;
		for (std::set<int>::iterator iter = nbset[r].begin(); iter != nbset[r].end(); ++iter)
			sendnbset[r][i++] = *iter;
		MPI_Isend(sendnbset[r], nbset[r].size(), MPI_INT, Q_nbrank[r], MPI_TAG, comm, sendreq + r);
	}

	for (int r = 0; r < Q_nnb; ++r)
	{
		int cnt;
		MPI_Probe(Q_nbrank[r], MPI_TAG, comm, &status);
		MPI_Get_count(&status, MPI_INT, &cnt);
		recvnbset[r] = new int[cnt];
		MPI_Recv(recvnbset[r], cnt, MPI_INT, Q_nbrank[r], MPI_TAG, comm, &status);
		for (int i = 0; i < cnt; ++i)
			nbmap.insert(std::pair<int, int>(recvnbset[r][i], nbmap.size()));
		delete[] recvnbset[r];
	}

	for (int r = 0; r < Q_nnb; ++r)
	{
		MPI_Wait(sendreq + r, &status);
		delete[] sendnbset[r];
	}

	delete[] nbset;
	delete[] Q_nbrank;
	delete[] recvnbset;
	delete[] sendnbset;

	Q_nnb = nbmap.size();
	Q_nbrank = new int[Q_nnb];
	for (std::map<int, int>::iterator iter = nbmap.begin(); iter != nbmap.end(); ++iter)
		Q_nbrank[iter->second] = iter->first;

	int* sendbufsize = new int[nnb];
	int* recvbufsize = new int[nnb];

	for (int r = 0; r < nnb; ++r)
		if (recvptr[r + 1] > recvptr[r])
			MPI_Irecv(recvbufsize + r, 1, MPI_INT, nbrank[r], MPI_TAG, comm, recvreq + r);

	for (int r = 0; r < nnb; ++r)
	{
		if (sendptr[r + 1] > sendptr[r])
		{
			int nrow = sendptr[r + 1] - sendptr[r];
			int nnz = 0;
			for (int i = sendptr[r]; i < sendptr[r + 1]; ++i)
				nnz += P_local_rowptr[sendind[i] + 1] - P_local_rowptr[sendind[i]] + P_exter_rowptr[sendind[i] + 1] - P_exter_rowptr[sendind[i]];
			sendbufsize[r] = (nrow + 2 * nnz) * sizeof(int) + nnz * sizeof(double);
			MPI_Send(sendbufsize + r, 1, MPI_INT, nbrank[r], MPI_TAG, comm);
		}
	}

	for (int r = 0; r < nnb; ++r)
		if (recvptr[r + 1] > recvptr[r])
			MPI_Wait(recvreq + r, &status);

	char** recvbuf = new char* [nnb];
	char** sendbuf = new char* [nnb];
	
	for (int r = 0; r < nnb; ++r)
	{
		if (recvptr[r + 1] > recvptr[r])
		{
			recvbuf[r] = (char*)malloc(recvbufsize[r]);
			MPI_Irecv(recvbuf[r], recvbufsize[r], MPI_PACKED, nbrank[r], MPI_TAG, comm, recvreq + r);
		}
	}

	for (int r = 0; r < nnb; ++r)
	{
		if (sendptr[r + 1] > sendptr[r])
		{
			sendbuf[r] = (char*)malloc(sendbufsize[r]);

			int position = 0;
			for (int i = sendptr[r]; i < sendptr[r + 1]; ++i)
			{
				int irow = sendind[i];
				int length = P_local_rowptr[irow + 1] - P_local_rowptr[irow] + P_exter_rowptr[irow + 1] - P_exter_rowptr[irow];

				int* colfrom = new int[length];
				int* colind = new int[length];
				double* values = new double[length];

				int j = 0;
				for (int k = P_local_rowptr[irow]; k < P_local_rowptr[irow + 1]; ++k)
				{
					colfrom[j] = comm_rank;
					colind[j] = P_local_colind[k];
					values[j++] = P_local_values[k];
				}
				for (int k = P_exter_rowptr[irow]; k < P_exter_rowptr[irow + 1]; ++k)
				{
					int kcol = P_exter_colind[k];
					colfrom[j] = P_nbrank[P_recvfrom[kcol]];
					colind[j] = P_recvind[kcol];
					values[j++] = P_exter_values[k];
				}
				
				MPI_Pack(&length, 1, MPI_INT, sendbuf[r], sendbufsize[r], &position, comm);
				MPI_Pack(colfrom, length, MPI_INT, sendbuf[r], sendbufsize[r], &position, comm);
				MPI_Pack(colind, length, MPI_INT, sendbuf[r], sendbufsize[r], &position, comm);
				MPI_Pack(values, length, MPI_DOUBLE, sendbuf[r], sendbufsize[r], &position, comm);

				delete[] colfrom;
				delete[] colind;
				delete[] values;
			}

			MPI_Isend(sendbuf[r], sendbufsize[r], MPI_PACKED, nbrank[r], MPI_TAG, comm, sendreq + r);
		}
	}

	std::map<int, int>* recvmap = new std::map<int, int>[Q_nnb];
	for (int r = 0; r < P_nnb; ++r)
		for (int i = P_recvptr[r], j = 0; i < P_recvptr[r + 1]; ++i, ++j)
			recvmap[r].insert(std::pair<int, int>(P_recvind[i], j));

	int P_recvnnz = 0;
	for (int r = 0; r < nnb; ++r)
	{
		if (recvptr[r + 1] > recvptr[r])
		{
			int nrow = recvptr[r + 1] - recvptr[r];
			int nnz = (recvbufsize[r] - nrow * sizeof(int)) / (2 * sizeof(int) + sizeof(double));
			P_recvnnz += nnz;
		}
	}

	int* P_recvloc_rowptr = new int[A.exter.size[1] + 1];
	int* P_recvloc_colind = new int[P_recvnnz];
	double* P_recvloc_values = new double[P_recvnnz];
	int* P_recvext_rowptr = new int[A.exter.size[1] + 1];
	int* P_recvext_colind = new int[P_recvnnz];
	double* P_recvext_values = new double[P_recvnnz];
	int* P_recvext_colfrom = new int[P_recvnnz];

	P_recvloc_rowptr[0] = 0;
	P_recvext_rowptr[0] = 0;
	for (int r = 0; r < nnb; ++r)
	{
		if (recvptr[r + 1] > recvptr[r])
		{
			MPI_Wait(recvreq + r, &status);

			int position = 0;
			for (int i = recvptr[r], k = P_recvloc_rowptr[i], t = P_recvext_rowptr[i]; i < recvptr[r + 1]; P_recvloc_rowptr[++i] = k, P_recvext_rowptr[i] = t)
			{
				int length;
				MPI_Unpack(recvbuf[r], recvbufsize[r], &position, &length, 1, MPI_INT, comm);

				int* colfrom = new int[length];
				int* colind = new int[length];
				double* values = new double[length];

				MPI_Unpack(recvbuf[r], recvbufsize[r], &position, colfrom, length, MPI_INT, comm);
				MPI_Unpack(recvbuf[r], recvbufsize[r], &position, colind, length, MPI_INT, comm);
				MPI_Unpack(recvbuf[r], recvbufsize[r], &position, values, length, MPI_DOUBLE, comm);

				for (int j = 0; j < length; ++j)
				{
					if (colfrom[j] == comm_rank)
					{
						P_recvloc_colind[k] = colind[j];
						P_recvloc_values[k++] = values[j];
					}
					else
					{
						int jfrom = nbmap[colfrom[j]];
						P_recvext_colfrom[t] = jfrom;
						std::pair<std::map<int, int>::iterator, bool> ret = recvmap[jfrom].insert(std::pair<int, int>(colind[j], recvmap[jfrom].size()));
						P_recvext_colind[t] = ret.first->second;
						P_recvext_values[t++] = values[j];
					}
				}

				delete[] colfrom;
				delete[] colind;
				delete[] values;
			}
			
			free(recvbuf[r]);
		}
	}

	for (int r = 0; r < nnb; ++r)
	{
		if (sendptr[r + 1] > sendptr[r])
		{
			MPI_Wait(sendreq + r, &status);
			free(sendbuf[r]);
		}
	}

	delete[] recvbufsize;
	delete[] recvbuf;
	delete[] recvreq;
	delete[] sendbufsize;
	delete[] sendbuf;
	delete[] sendreq;

	int* Q_recvptr = new int[Q_nnb + 1];
	Q_recvptr[0] = 0;
	for (int r = 0; r < Q_nnb; ++r)
		Q_recvptr[r + 1] = Q_recvptr[r] + recvmap[r].size();
	
	int Q_recvcnt = Q_recvptr[Q_nnb];
	int* Q_recvind = new int[Q_recvcnt];
	for (int r = 0; r < Q_nnb; ++r)
		for (std::map<int, int>::iterator iter = recvmap[r].begin(); iter != recvmap[r].end(); ++iter)
			Q_recvind[Q_recvptr[r] + iter->second] = iter->first;

	for (int j = 0; j < P_recvext_rowptr[A.exter.size[1]]; ++j)
		P_recvext_colind[j] += Q_recvptr[P_recvext_colfrom[j]];

	int* _P_exter_colind = new int[P_exter_rowptr[P.exter.size[0]]];

	for (int j = 0; j < P_exter_rowptr[P.exter.size[0]]; ++j)
	{
		int r = P_recvfrom[P_exter_colind[j]];
		_P_exter_colind[j] = P_exter_colind[j] - P_recvptr[r] + Q_recvptr[r];
	}

	delete[] recvmap;
	delete[] P_recvfrom;
	delete[] P_recvext_colfrom;
	
	int* Q_local_rowptr = new int[n + 1];
	int* Q_exter_rowptr = new int[n + 1];

	Q_local_rowptr[0] = 0;
	Q_exter_rowptr[0] = 0;

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel
#endif
	{
		int* w = new int[m];
		int* v = new int[Q_recvcnt];
		for (int i = 0; i < m; ++i)
			w[i] = -1;
		for (int i = 0; i < Q_recvcnt; ++i)
			v[i] = -1;
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
		for (int i = 0; i < n; ++i)
		{
			if (mask[i])
			{
				Q_local_rowptr[i + 1] = P_local_rowptr[i + 1] - P_local_rowptr[i];
				Q_exter_rowptr[i + 1] = P_exter_rowptr[i + 1] - P_exter_rowptr[i];
			}
			else
			{
				int cntloc = 0;
				int cntext = 0;
				for (int k = A_local_rowptr[i]; k < A_local_rowptr[i + 1]; ++k)
				{
					int kcol = A_local_colind[k];
					if (kcol == i) continue;
					for (int j = P_local_rowptr[kcol]; j < P_local_rowptr[kcol + 1]; ++j)
					{
						int jcol = P_local_colind[j];
						if (w[jcol] != i)
						{
							w[jcol] = i;
							++cntloc;
						}
					}

					for (int j = P_exter_rowptr[kcol]; j < P_exter_rowptr[kcol + 1]; ++j)
					{
						int jcol = _P_exter_colind[j];
						if (v[jcol] != i)
						{
							v[jcol] = i;
							++cntext;
						}
					}
				}

				for (int k = A_exter_rowptr[i]; k < A_exter_rowptr[i + 1]; ++k)
				{
					int kcol = A_exter_colind[k];

					for (int j = P_recvloc_rowptr[kcol]; j < P_recvloc_rowptr[kcol + 1]; ++j)
					{
						int jcol = P_recvloc_colind[j];
						if (w[jcol] != i)
						{
							w[jcol] = i;
							++cntloc;
						}
					}

					for (int j = P_recvext_rowptr[kcol]; j < P_recvext_rowptr[kcol + 1]; ++j)
					{
						int jcol = P_recvext_colind[j];
						if (v[jcol] != i)
						{
							v[jcol] = i;
							++cntext;
						}
					}
				}

				Q_local_rowptr[i + 1] = cntloc;
				Q_exter_rowptr[i + 1] = cntext;
			}
		}

		delete[] w;
		delete[] v;
	}

	for (int i = 0; i < n; ++i)
		Q_local_rowptr[i + 1] += Q_local_rowptr[i];
	for (int i = 0; i < n; ++i)
		Q_exter_rowptr[i + 1] += Q_exter_rowptr[i];

	int* Q_local_colind = new int[Q_local_rowptr[n]];
	double* Q_local_values = new double[Q_local_rowptr[n]];
	int* Q_exter_colind = new int[Q_exter_rowptr[n]];
	double* Q_exter_values = new double[Q_exter_rowptr[n]];

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel
#endif
	{
		int* w = new int[m];
		int* v = new int[Q_recvcnt];
		for (int i = 0; i < m; ++i)
			w[i] = -1;
		for (int i = 0; i < Q_recvcnt; ++i)
			v[i] = -1;
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
		for (int i = 0; i < n; ++i)
		{
			if (mask[i])
			{
				for (int j = P_local_rowptr[i], k = Q_local_rowptr[i]; j < P_local_rowptr[i + 1]; ++j, ++k)
				{
					Q_local_colind[k] = P_local_colind[j];
					Q_local_values[k] = P_local_values[j];
				}
				for (int j = P_exter_rowptr[i], k = Q_exter_rowptr[i]; j < P_exter_rowptr[i + 1]; ++j, ++k)
				{
					Q_exter_colind[k] = _P_exter_colind[j];
					Q_exter_values[k] = P_exter_values[j];
				}
			}
			else
			{
				int r = Q_local_rowptr[i];
				int r0 = Q_local_rowptr[i];
				int t = Q_exter_rowptr[i];
				int t0 = Q_exter_rowptr[i];

				double diagonal = 0.0;
				double sum_n = 0.0;
				double sum_q = 0.0;

				for (int k = A_local_rowptr[i]; k < A_local_rowptr[i + 1]; ++k)
				{
					if (A_local_colind[k] == i)
					{
						diagonal = A_local_values[k];
						break;
					}
				}

				for (int k = A_local_rowptr[i]; k < A_local_rowptr[i + 1]; ++k)
				{
					int kcol = A_local_colind[k];
					if (kcol == i) continue;
					double kval = A_local_values[k];
					double _kval = _(kval);
					sum_n += kval;

					for (int j = P_local_rowptr[kcol]; j < P_local_rowptr[kcol + 1]; ++j)
					{
						int jcol = P_local_colind[j];
						double jval = P_local_values[j];

						if (w[jcol] < r0)
						{
							w[jcol] = r;
							Q_local_colind[r] = jcol;
							Q_local_values[r++] = _kval * jval;
						}
						else
							Q_local_values[w[jcol]] += _kval * jval;
					}

					for (int j = P_exter_rowptr[kcol]; j < P_exter_rowptr[kcol + 1]; ++j)
					{
						int jcol = _P_exter_colind[j];
						double jval = P_exter_values[j];

						if (v[jcol] < t0)
						{
							v[jcol] = t;
							Q_exter_colind[t] = jcol;
							Q_exter_values[t++] = _kval * jval;
						}
						else
							Q_exter_values[v[jcol]] += _kval * jval;
					}
				}

				for (int k = A_exter_rowptr[i]; k < A_exter_rowptr[i + 1]; ++k)
				{
					int kcol = A_exter_colind[k];
					double kval = A_exter_values[k];
					double _kval = _(kval);
					sum_n += kval;

					for (int j = P_recvloc_rowptr[kcol]; j < P_recvloc_rowptr[kcol + 1]; ++j)
					{
						int jcol = P_recvloc_colind[j];
						double jval = P_recvloc_values[j];

						if (w[jcol] < r0)
						{
							w[jcol] = r;
							Q_local_colind[r] = jcol;
							Q_local_values[r++] = _kval * jval;
						}
						else
							Q_local_values[w[jcol]] += _kval * jval;
					}

					for (int j = P_recvext_rowptr[kcol]; j < P_recvext_rowptr[kcol + 1]; ++j)
					{
						int jcol = P_recvext_colind[j];
						double jval = P_recvext_values[j];

						if (v[jcol] < t0)
						{
							v[jcol] = t;
							Q_exter_colind[t] = jcol;
							Q_exter_values[t++] = _kval * jval;
						}
						else
							Q_exter_values[v[jcol]] += _kval * jval;
					}
				}

				for (int j = Q_local_rowptr[i]; j < Q_local_rowptr[i + 1]; ++j)
					sum_q += Q_local_values[j];
				for (int j = Q_exter_rowptr[i]; j < Q_exter_rowptr[i + 1]; ++j)
					sum_q += Q_exter_values[j];
				double omega = (sum_q != 0 && diagonal != 0) ? -sum_n/ (diagonal * sum_q) : 0.0;
				for (int j = Q_local_rowptr[i]; j < Q_local_rowptr[i + 1]; ++j)
					Q_local_values[j] *= omega;
				for (int j = Q_exter_rowptr[i]; j < Q_exter_rowptr[i + 1]; ++j)
					Q_exter_values[j] *= omega;
			}
		}

		delete[] w;
		delete[] v;
	}

	delete[] _P_exter_colind;

	P.Free();

	P.comm = comm;

	P.local.size[0] = n;
	P.local.size[1] = m;
	P.local.rowptr = Q_local_rowptr;
	P.local.colind = Q_local_colind;
	P.local.values = Q_local_values;

	P.exter.size[0] = n;
	P.exter.size[1] = Q_recvcnt;
	P.exter.rowptr = Q_exter_rowptr;
	P.exter.colind = Q_exter_colind;
	P.exter.values = Q_exter_values;

	P.nnb = Q_nnb;
	P.nbrank = Q_nbrank;
	P.recvptr = Q_recvptr;
	P.recvind = Q_recvind;
}

void InterpTruncation(ParCSRMatrix& P, int* cfmap, int max_elements, double truncation_factor)
{	
	MPI_Comm comm = P.comm;

	int n = P.local.size[0];
	int nc = P.local.size[1];
	int* P_local_rowptr = P.local.rowptr;
	int* P_local_colind = P.local.colind;
	double* P_local_values = P.local.values;

	int* P_exter_rowptr = P.exter.rowptr;
	int* P_exter_colind = P.exter.colind;
	double* P_exter_values = P.exter.values;

	int P_nnb = P.nnb;
	int* P_nbrank = P.nbrank;
	int* P_recvptr = P.recvptr;
	int* P_recvind = P.recvind;

	int* Q_local_rowptr = new int[n + 1];
	int* Q_exter_rowptr = new int[n + 1];

	Q_local_rowptr[0] = 0;
	Q_exter_rowptr[0] = 0;

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel
#endif
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
		for (int i = 0; i < n; ++i)
		{
			if (cfmap[i] < 0)
			{
				int m = P_local_rowptr[i + 1] - P_local_rowptr[i] + P_exter_rowptr[i + 1] - P_exter_rowptr[i];
				if (m == 0) 
				{
					Q_local_rowptr[i + 1] = 0;
					Q_exter_rowptr[i + 1] = 0;
				}
				else
				{
					int* colind = new int[m];
					double* values = new double[m];
					
					int k = 0;
					
					for (int j = P_local_rowptr[i]; j < P_local_rowptr[i + 1]; ++j, ++k)
					{
						colind[k] = P_local_colind[j];
						values[k] = P_local_values[j];
					}

					for (int j = P_exter_rowptr[i]; j < P_exter_rowptr[i + 1]; ++j, ++k)
					{
						colind[k] = P_exter_colind[j] + nc;
						values[k] = P_exter_values[j];
					}
					
					SortAbsDesc(colind, values, 0, m - 1);

					int cntloc = 0;
					int cntext = 0;

					double theta = truncation_factor * ABS(values[0]);

					double sum = 0.0;
					double drop = 0.0;	

					for (int j = 0; j < m; ++j)
					{
						if (ABS(values[j]) < theta || j == max_elements) break;
						
						if (colind[j] < nc)
						{
							P_local_colind[P_local_rowptr[i] + cntloc] = colind[j];
							P_local_values[P_local_rowptr[i] + cntloc++] = values[j];
							sum += values[j];
						}
						else
						{
							P_exter_colind[P_exter_rowptr[i] + cntext] = colind[j] - nc;
							P_exter_values[P_exter_rowptr[i] + cntext++] = values[j];
							sum += values[j];
						}
					}
				
					for (int j = cntloc + cntext; j < m; ++j)
						drop += values[j];

					delete[] colind;
					delete[] values;

					double omega = sum != 0 ? (sum + drop) / sum : 0.0;
					for (int j = P_local_rowptr[i]; j < P_local_rowptr[i] + cntloc; ++j)
						P_local_values[j] *= omega;
					for (int j = P_exter_rowptr[i]; j < P_exter_rowptr[i] + cntext; ++j)
						P_exter_values[j] *= omega;

					Q_local_rowptr[i + 1] = cntloc;
					Q_exter_rowptr[i + 1] = cntext;
				}
			}
			else
			{
				Q_local_rowptr[i + 1] = 1;
				Q_exter_rowptr[i + 1] = 0;
			}
		}
	}

	for (int i = 0; i < n; ++i)
		Q_local_rowptr[i + 1] += Q_local_rowptr[i];
	for (int i = 0; i < n; ++i)
		Q_exter_rowptr[i + 1] += Q_exter_rowptr[i];

	int* Q_local_colind = new int[Q_local_rowptr[n]];
	double* Q_local_values = new double[Q_local_rowptr[n]];
	int* Q_exter_colind = new int[Q_exter_rowptr[n]];
	double* Q_exter_values = new double[Q_exter_rowptr[n]];

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
	for (int i = 0; i < n; ++i)
	{
		for (int j = P_local_rowptr[i], k = Q_local_rowptr[i]; k < Q_local_rowptr[i + 1]; ++j, ++k)
		{
			Q_local_colind[k] = P_local_colind[j];
			Q_local_values[k] = P_local_values[j];
		}

		for (int j = P_exter_rowptr[i], k = Q_exter_rowptr[i]; k < Q_exter_rowptr[i + 1]; ++j, ++k)
		{
			Q_exter_colind[k] = P_exter_colind[j];
			Q_exter_values[k] = P_exter_values[j];
		}
	}

	int* Q_nbrank = new int[P_nnb];
	for (int r = 0; r < P_nnb; ++r)
		Q_nbrank[r] = P_nbrank[r];

	int* w = new int[P.exter.size[1]];
	for (int i = 0; i < P.exter.size[1]; ++i)
		w[i] = -1;

	for (int j = Q_exter_rowptr[0]; j < Q_exter_rowptr[n]; ++j)
		w[Q_exter_colind[j]] = 1;

	int* Q_recvind = new int[P.exter.size[1]];
	int* Q_recvptr = new int[P_nnb + 1];

	Q_recvptr[0] = 0;

	for (int r = 0, k = 0; r < P_nnb; Q_recvptr[++r] = k)
	{
		for (int i = P_recvptr[r]; i < P_recvptr[r + 1]; ++i)
		{
			if (w[i] == 1)
			{
				w[i] = k;
				Q_recvind[k++] = P_recvind[i];
			}
		}
	}

	for (int j = Q_exter_rowptr[0]; j < Q_exter_rowptr[n]; ++j)
		Q_exter_colind[j] = w[Q_exter_colind[j]];

	delete[] w;

	P.Free();

	P.comm = comm;

	P.local.size[0] = n;
	P.local.size[1] = nc;
	P.local.rowptr = Q_local_rowptr;
	P.local.colind = Q_local_colind;
	P.local.values = Q_local_values;

	P.exter.size[0] = n;
	P.exter.size[1] = Q_recvptr[P_nnb];
	P.exter.rowptr = Q_exter_rowptr;
	P.exter.colind = Q_exter_colind;
	P.exter.values = Q_exter_values;

	P.nnb = P_nnb;
	P.nbrank = Q_nbrank;
	P.recvptr = Q_recvptr;
	P.recvind = Q_recvind;
}

void LongRangeInterpolation(const ParCSRMatrix& A, const bool* locstg, const bool* extstg, int* cfmap, ParCSRMatrix& P, int min_elements, int max_elements, double truncation_factor)
{
	int n = A.local.size[0];

	DirectInterpolation(A, locstg, extstg, cfmap, P);

	bool* mask = new bool[n];
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
	for (int i = 0; i < n; ++i)
	{
		int num_p = P.local.rowptr[i + 1] - P.local.rowptr[i] + P.exter.rowptr[i + 1] - P.exter.rowptr[i];
		int num_n = A.local.rowptr[i + 1] - A.local.rowptr[i] - 1 + A.exter.rowptr[i + 1] - A.exter.rowptr[i];
		mask[i] = cfmap[i] >= 0 || num_p >= min_elements || num_n == num_p;
	}

	JacobiInterpolation(A, P, mask);

	delete[] mask;
	
	InterpTruncation(P, cfmap, max_elements, truncation_factor);
}

void AggressiveLongRangeInterpolation(const ParCSRMatrix& A, const bool* locstg, const bool* extstg, int* cfmap, ParCSRMatrix& P, int min_elements, int max_elements, double truncation_factor)
{
	int n = A.local.size[0];

	DirectInterpolation(A, locstg, extstg, cfmap, P);

	bool* mask = new bool[n];
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
	for (int i = 0; i < n; ++i)
		mask[i] = cfmap[i] >= 0 || (cfmap[i] == FINE && (P.local.rowptr[i + 1] > P.local.rowptr[i] || P.exter.rowptr[i + 1] > P.exter.rowptr[i]));
	JacobiInterpolation(A, P, mask);

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
	for (int i = 0; i < n; ++i)
		mask[i] = cfmap[i] >= 0 || cfmap[i] == S2_FINE;
	JacobiInterpolation(A, P, mask);

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
	for (int i = 0; i < n; ++i)
		mask[i] = cfmap[i] >= 0 || (P.local.rowptr[i + 1] - P.local.rowptr[i] + P.exter.rowptr[i + 1] - P.exter.rowptr[i] >= min_elements);
	JacobiInterpolation(A, P, mask);

	delete[] mask;

	InterpTruncation(P, cfmap, max_elements, truncation_factor);
}

static void ExchangeAggregates(const ParCSRMatrix& A, const global* aggregates, global* recvagg)
{
	MPI_Comm comm = A.comm;

	int nnb = A.nnb;
	int* nbrank = A.nbrank;
	int* recvptr = A.recvptr;
	int* sendptr = A.sendptr;
	int* sendind = A.sendind;

	global* sendbuf = new global[sendptr[nnb]];
	MPI_Request* recvreq = new MPI_Request[nnb];
	MPI_Request* sendreq = new MPI_Request[nnb];
	MPI_Status status;

	for (int r = 0; r < nnb; ++r)
		if (recvptr[r + 1] > recvptr[r])
			MPI_Irecv(recvagg + recvptr[r], (recvptr[r + 1] - recvptr[r]) * sizeof(global), MPI_BYTE, nbrank[r], MPI_TAG, comm, recvreq + r);

	for (int r = 0; r < nnb; ++r)
	{
		if (sendptr[r + 1] > sendptr[r])
		{
			for (int i = sendptr[r]; i < sendptr[r + 1]; ++i)
				sendbuf[i] = aggregates[sendind[i]];
			MPI_Isend(sendbuf + sendptr[r], (sendptr[r + 1] - sendptr[r]) * sizeof(global), MPI_BYTE, nbrank[r], MPI_TAG, comm, sendreq + r);
		}
	}

	for (int r = 0; r < nnb; ++r)
		if (recvptr[r + 1] > recvptr[r])
			MPI_Wait(recvreq + r, &status);

	for (int r = 0; r < nnb; ++r)
		if (sendptr[r + 1] > sendptr[r])
			MPI_Wait(sendreq + r, &status);

	delete[] sendbuf;
	delete[] recvreq;
	delete[] sendreq;
}

static void UpdateNeighbors(const ParCSRMatrix& A, const global* aggregates, std::map<int, int>& nbmap)
{
	MPI_Comm comm = A.comm;

	int comm_rank;
	MPI_Comm_rank(comm, &comm_rank);

	int nnb = A.nnb;
	int* nbrank = A.nbrank;
	int* recvptr = A.recvptr;
	int* sendptr = A.sendptr;
	int* sendind = A.sendind;

	int _nnb = nbmap.size();
	int* _nbrank = new int[_nnb];
	for (std::map<int, int>::iterator iter = nbmap.begin(); iter != nbmap.end(); ++iter)
		_nbrank[iter->second] = iter->first;

	std::set<int>* nbset = new std::set<int>[_nnb];

	for (int r = 0; r < nnb; ++r)
	{
		for (int i = sendptr[r]; i < sendptr[r + 1]; ++i)
		{
			int t = owner(aggregates[sendind[i]]);
			if (t == comm_rank || t == nbrank[r] || t == ~0U) continue;
			std::map<int, int>::iterator iter = nbmap.find(t);
			if (iter != nbmap.end())
			{
				nbset[r].insert(t);
				nbset[iter->second].insert(nbrank[r]);
			}
		}
	}
	
	int** recvbuf = new int*[_nnb];
	int** sendbuf = new int*[_nnb];

	MPI_Request* recvreq = new MPI_Request[_nnb];
	MPI_Request* sendreq = new MPI_Request[_nnb];
	MPI_Status status;

	for (int r = 0; r < _nnb; ++r)
	{
		sendbuf[r] = new int[nbset[r].size()];
		int i = 0;
		for (std::set<int>::iterator iter = nbset[r].begin(); iter != nbset[r].end(); ++iter)
			sendbuf[r][i++] = *iter;
		MPI_Isend(sendbuf[r], nbset[r].size(), MPI_INT, _nbrank[r], MPI_TAG, comm, sendreq + r);
	}

	for (int r = 0; r < _nnb; ++r)
	{
		int cnt;
		MPI_Probe(_nbrank[r], MPI_TAG, comm, &status);
		MPI_Get_count(&status, MPI_INT, &cnt);
		recvbuf[r] = new int[cnt];
		MPI_Recv(recvbuf[r], cnt, MPI_INT, _nbrank[r], MPI_TAG, comm, &status);
		for (int i = 0; i < cnt; ++i)
			nbmap.insert(std::pair<int, int>(recvbuf[r][i], nbmap.size()));
		delete[] recvbuf[r];
	}

	for (int r = 0; r < _nnb; ++r)
	{
		MPI_Wait(sendreq + r, &status);
		delete[] sendbuf[r];
	}
	
	delete[] _nbrank;
	delete[] nbset;
	delete[] recvbuf;
	delete[] sendbuf;
	delete[] recvreq;
	delete[] sendreq;
}

static void DiagonalScale(const Vector& D_recip, const ParVector& x)
{
	int n = D_recip.size;
	double* Drcpv = D_recip.values;
	double* xv = x.local.values;
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
	for (int i = 0; i < n; ++i)
		xv[i] *= Drcpv[i];
}

static double LargestEigenvalueEstimate(const ParCSRMatrix& A, const Vector D_recip, int iteration)
{
	MPI_Comm comm = A.comm;
	int n = A.OutSize();

	ParVector x(comm), y(comm);
	x.Resize(n);
	y.Resize(n);

	y.FillRandom();

	for (int k = 0; k < iteration; ++k)
	{
		ParVecAXPBY(1.0 / sqrt(ParVecDot(y, y)), y, 0.0, x);
		A.Apply(x, y);
		DiagonalScale(D_recip, y);
	}

	return ParVecDot(x, y);
}

void SmoothedAggregation(const ParCSRMatrix& A, const bool* locstg, const bool* extstg, int* cfmap, ParCSRMatrix& P)
{
	MPI_Comm comm = A.comm;

	int comm_rank, comm_size;
	MPI_Comm_rank(comm, &comm_rank);
	MPI_Comm_size(comm, &comm_size);

	int n = A.local.size[0];
	int recvcnt = A.exter.size[1];

	int* A_local_rowptr = A.local.rowptr;
	int* A_local_colind = A.local.colind;
	double* A_local_values = A.local.values;
	int* A_exter_rowptr = A.exter.rowptr;
	int* A_exter_colind = A.exter.colind;
	double* A_exter_values = A.exter.values;

	int nnb = A.nnb;
	int* nbrank = A.nbrank;

	int* recvptr = A.recvptr;

	int nc = 0;
	for (int i = 0; i < n; ++i)
		if (cfmap[i] >= 0)
			cfmap[i] = nc++;

	int* recvcf = new int[recvcnt];
	ExchangeCFmap(A, cfmap, recvcf);

	int* recvfrom = new int[recvcnt];
	for (int r = 0; r < nnb; ++r)
		for (int i = recvptr[r]; i < recvptr[r + 1]; ++i)
			recvfrom[i] = nbrank[r];

	global* aggregates = new global[n];	
	global* recvagg = new global[recvcnt];

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
	for (int i = 0; i < n; ++i)
	{
		if (cfmap[i] < 0)
		{
			global iagg = ~0UL;
			double amax = -1.0;

			for (int j = A_local_rowptr[i]; j < A_local_rowptr[i + 1]; ++j)
			{
				if (!locstg[j]) continue;
				int jcol = A_local_colind[j];
				double abs_jval = ABS(A_local_values[j]);
				if (cfmap[jcol] >= 0 && abs_jval > amax)
				{
					iagg = global(cfmap[jcol], comm_rank);
					amax = abs_jval;
				}
			}

			for (int j = A_exter_rowptr[i]; j < A_exter_rowptr[i + 1]; ++j)
			{
				if (!extstg[j]) continue;
				int jcol = A_exter_colind[j];
				double abs_jval = ABS(A_exter_values[j]);
				if (recvcf[jcol] >= 0 && abs_jval > amax)
				{
					iagg = global(recvcf[jcol], recvfrom[jcol]);
					amax = abs_jval;
				}
			}

			aggregates[i] = iagg;
		}
		else
			aggregates[i] = global(cfmap[i], comm_rank);
	}

	delete[] recvcf;
	delete[] recvfrom;

	std::map<int, int> nbmap;
	for (int r = 0; r < nnb; ++r)
		nbmap.insert(std::pair<int, int>(nbrank[r], r));

	UpdateNeighbors(A, aggregates, nbmap);
	ExchangeAggregates(A, aggregates, recvagg);

	bool* mask = new bool[n];
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
	for (int i = 0; i < n; ++i)
		mask[i] = aggregates[i] != ~0UL;

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
	for (int i = 0; i < n; ++i)
	{
		if (!mask[i])
		{
			std::map<global, double> iaggwgt;

			for (int j = A_local_rowptr[i]; j < A_local_rowptr[i + 1]; ++j)
			{
				int jcol = A_local_colind[j];
				double abs_jval = ABS(A_local_values[j]);
				if (mask[jcol])
					iaggwgt[aggregates[jcol]] += abs_jval;
			}

			for (int j = A_exter_rowptr[i]; j < A_exter_rowptr[i + 1]; ++j)
			{
				int jcol = A_exter_colind[j];
				double abs_jval = ABS(A_exter_values[j]);
				if (recvagg[jcol] != ~0UL)
					iaggwgt[recvagg[jcol]] += abs_jval;
			}

			global iagg = aggregates[i];
			double amax = -1.0;

			for (std::map<global, double>::iterator iter = iaggwgt.begin(); iter != iaggwgt.end(); ++iter)
			{
				if (iter->second > amax)
				{
					iagg = iter->first;
					amax = iter->second;
				}
			}

			aggregates[i] = iagg;
		}
	}

	delete[] mask;

	UpdateNeighbors(A, aggregates, nbmap);
	ExchangeAggregates(A, aggregates, recvagg);

	int* aggind = new int[n];
	int* recvaggind = new int[recvcnt];
	int* recvaggfrom = new int[recvcnt];

	int P_nnb = nbmap.size();
	int* P_nbrank = new int[P_nnb];
	for (std::map<int, int>::iterator iter = nbmap.begin(); iter != nbmap.end(); ++iter)
		P_nbrank[iter->second] = iter->first;

	std::map<int, int>* recvmap = new std::map<int, int>[P_nnb];

	for (int r = 0; r < nnb; ++r)
	{
		for (int i = recvptr[r]; i < recvptr[r + 1]; ++i)
		{
			int t = owner(recvagg[i]);
			if (t == ~0U)
			{
				recvaggfrom[i] = -1;
				recvaggind[i] = -1;
			}
			else if (t == comm_rank)
			{
				recvaggfrom[i] = -1;
				recvaggind[i] = local(recvagg[i]);
			}
			else
			{
				int _t = r;
				if (t != nbrank[r])
				{
					std::map<int, int>::iterator iter = nbmap.find(t);
					if (iter == nbmap.end())
					{
						recvaggfrom[i] = -1;
						recvaggind[i] = -1;
						continue;
					}
					else
						_t = iter->second;
				}
				std::pair<std::map<int, int>::iterator, bool> ret = recvmap[_t].insert(std::pair<int, int>(local(recvagg[i]), recvmap[_t].size()));
				recvaggfrom[i] = _t;
				recvaggind[i] = ret.first->second;
			}
		}
	}

	int P_recvcnt = 0;
	for (int r = 0; r < P_nnb; ++r)
		P_recvcnt += recvmap[r].size();

	int* P_recvptr = new int[P_nnb + 1];
	int* P_recvind = new int[P_recvcnt];

	P_recvptr[0] = 0;
	for (int r = 0; r < P_nnb; ++r)
	{
		P_recvptr[r + 1] = P_recvptr[r] + recvmap[r].size();
		for (std::map<int, int>::iterator iter = recvmap[r].begin(); iter != recvmap[r].end(); ++iter)
			P_recvind[P_recvptr[r] + iter->second] = iter->first;
	}

	for (int i = 0; i < recvcnt; ++i)
		if (recvaggfrom[i] != -1) recvaggind[i] += P_recvptr[recvaggfrom[i]] + nc;

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif	
	for (int i = 0; i < n; ++i)
	{
		int t = owner(aggregates[i]);
		if (t == ~0U)
			aggind[i] = -1;
		else if (t == comm_rank)
			aggind[i] = local(aggregates[i]);
		else
		{
			std::map<int, int>::iterator iter1 = nbmap.find(t);
			if (iter1 == nbmap.end())
				aggind[i] = -1;
			else
			{
				int _t = iter1->second;
				std::map<int, int>::iterator iter2 = recvmap[_t].find(local(aggregates[i]));
				if (iter2 == recvmap[_t].end())
					aggind[i] = -1;
				else
					aggind[i] = iter2->second + P_recvptr[_t] + nc;
			}
		}
	}

	delete[] aggregates;
	delete[] recvmap;
	delete[] recvagg;
	delete[] recvaggfrom;

	Vector D_recip;
	D_recip.Resize(n);

	double* Drcpv = D_recip.values;
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
	for (int i = 0; i < n; ++i)
	{
		for (int j = A_local_rowptr[i]; j < A_local_rowptr[i + 1]; ++j)
		{
			if (A_local_colind[j] == i)
			{
				Drcpv[i] = 1.0 / A_local_values[j];
				break;
			}
		}
	}

	double omega = 4.0 / (3.3 * LargestEigenvalueEstimate(A, D_recip, 10));

	int* P_local_rowptr = new int[n + 1];
	int* P_exter_rowptr = new int[n + 1];

	P_local_rowptr[0] = 0;
	P_exter_rowptr[0] = 0;

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel
#endif
	{
		int* w = new int[nc + P_recvcnt];
		for (int i = 0; i < nc + P_recvcnt; ++i)
			w[i] = -1;
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
		for (int i = 0; i < n; ++i)
		{
			int cntloc = 0;
			int cntext = 0;

			if (aggind[i] != -1)
			{
				w[aggind[i]] = i;
				++(aggind[i] < nc ? cntloc : cntext);
			}

			for (int j = A_local_rowptr[i]; j < A_local_rowptr[i + 1]; ++j)
			{
				int jcol = A_local_colind[j];
				if (jcol == i) continue;
				int jagg = aggind[A_local_colind[j]];
				if (jagg != -1 && w[jagg] != i)
				{
					w[jagg] = i;
					++(jagg < nc ? cntloc : cntext);
				}
			}

			for (int j = A_exter_rowptr[i]; j < A_exter_rowptr[i + 1]; ++j)
			{
				int jagg = recvaggind[A_exter_colind[j]];
				if (jagg != -1 && w[jagg] != i)
				{
					w[jagg] = i;
					++(jagg < nc ? cntloc : cntext);
				}
			}

			P_local_rowptr[i + 1] = cntloc;
			P_exter_rowptr[i + 1] = cntext;
		}

		delete[] w;
	}

	for (int i = 0; i < n; ++i)
		P_local_rowptr[i + 1] += P_local_rowptr[i];
	for (int i = 0; i < n; ++i)
		P_exter_rowptr[i + 1] += P_exter_rowptr[i];

	int* P_local_colind = new int[P_local_rowptr[n]];
	double* P_local_values = new double[P_local_rowptr[n]];
	int* P_exter_colind = new int[P_exter_rowptr[n]];
	double* P_exter_values = new double[P_exter_rowptr[n]];

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel
#endif
	{
		int* w = new int[nc + P_recvcnt];
		for (int i = 0; i < nc + P_recvcnt; ++i)
			w[i] = -1;
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
		for (int i = 0; i < n; ++i)
		{
			int k = P_local_rowptr[i];
			int t = P_exter_rowptr[i];
			int k0 = k, t0 = t;

			if (aggind[i] != -1)
			{
				if (aggind[i] < nc)
				{
					w[aggind[i]] = k;
					P_local_colind[k] = aggind[i];
					P_local_values[k++] = 1.0 - omega;
				}
				else
				{
					w[aggind[i]] = t;
					P_exter_colind[t] = aggind[i] - nc;
					P_exter_values[t++] = 1.0 - omega;
				}
			}

			double multiplier = -omega * Drcpv[i];

			for (int j = A_local_rowptr[i]; j < A_local_rowptr[i + 1]; ++j)
			{
				int jcol = A_local_colind[j];
				double jval = A_local_values[j];
				int jagg = aggind[jcol];
				if (jcol == i || jagg == -1) continue;
				if (jagg < nc)
				{
					if (w[jagg] < k0)
					{
						w[jagg] = k;
						P_local_colind[k] = jagg;
						P_local_values[k++] = multiplier * jval;
					}
					else
						P_local_values[w[jagg]] += multiplier * jval;
				}
				else
				{
					if (w[jagg] < t0)
					{
						w[jagg] = t;
						P_exter_colind[t] = jagg - nc;
						P_exter_values[t++] = multiplier * jval;
					}
					else
						P_exter_values[w[jagg]] += multiplier * jval;
				}
			}
			
			for (int j = A_exter_rowptr[i]; j < A_exter_rowptr[i + 1]; ++j)
			{
				int jcol = A_exter_colind[j];
				double jval = A_exter_values[j];
				int jagg = recvaggind[jcol];
				if (jagg == -1) continue;
				if (jagg < nc)
				{
					if (w[jagg] < k0)
					{
						w[jagg] = k;
						P_local_colind[k] = jagg;
						P_local_values[k++] = multiplier * jval;
					}
					else
						P_local_values[w[jagg]] += multiplier * jval;
				}
				else
				{
					if (w[jagg] < t0)
					{
						w[jagg] = t;
						P_exter_colind[t] = jagg - nc;
						P_exter_values[t++] = multiplier * jval;
					}
					else
						P_exter_values[w[jagg]] += multiplier * jval;
				}
			}
		}

		delete[] w;
	}

	delete[] aggind;
	delete[] recvaggind;

	P.comm = comm;

	P.local.size[0] = n;
	P.local.size[1] = nc;
	P.local.rowptr = P_local_rowptr;
	P.local.colind = P_local_colind;
	P.local.values = P_local_values;

	P.exter.size[0] = n;
	P.exter.size[1] = P_recvcnt;
	P.exter.rowptr = P_exter_rowptr;
	P.exter.colind = P_exter_colind;
	P.exter.values = P_exter_values;

	P.nnb = P_nnb;
	P.nbrank = P_nbrank;
	P.recvptr = P_recvptr;
	P.recvind = P_recvind;
}

void AggressiveSmoothedAggregation(const ParCSRMatrix& A, const bool* locstg, const bool* extstg, int* cfmap, ParCSRMatrix& P)
{
	MPI_Comm comm = A.comm;

	int comm_rank, comm_size;
	MPI_Comm_rank(comm, &comm_rank);
	MPI_Comm_size(comm, &comm_size);

	int n = A.local.size[0];
	int recvcnt = A.exter.size[1];

	int* A_local_rowptr = A.local.rowptr;
	int* A_local_colind = A.local.colind;
	double* A_local_values = A.local.values;
	int* A_exter_rowptr = A.exter.rowptr;
	int* A_exter_colind = A.exter.colind;
	double* A_exter_values = A.exter.values;

	int nnb = A.nnb;
	int* nbrank = A.nbrank;

	int* recvptr = A.recvptr;

	int nc = 0;
	for (int i = 0; i < n; ++i)
		if (cfmap[i] >= 0)
			cfmap[i] = nc++;

	int* recvcf = new int[recvcnt];
	ExchangeCFmap(A, cfmap, recvcf);

	int* recvfrom = new int[recvcnt];
	for (int r = 0; r < nnb; ++r)
		for (int i = recvptr[r]; i < recvptr[r + 1]; ++i)
			recvfrom[i] = nbrank[r];

	global* aggregates = new global[n];	
	global* recvagg = new global[recvcnt];

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
	for (int i = 0; i < n; ++i)
	{
		if (cfmap[i] < 0)
		{
			global iagg = ~0UL;
			double amax = -1.0;

			for (int j = A_local_rowptr[i]; j < A_local_rowptr[i + 1]; ++j)
			{
				if (!locstg[j]) continue;
				int jcol = A_local_colind[j];
				double abs_jval = ABS(A_local_values[j]);
				if (cfmap[jcol] >= 0 && abs_jval > amax)
				{
					iagg = global(cfmap[jcol], comm_rank);
					amax = abs_jval;
				}
			}

			for (int j = A_exter_rowptr[i]; j < A_exter_rowptr[i + 1]; ++j)
			{
				if (!extstg[j]) continue;
				int jcol = A_exter_colind[j];
				double abs_jval = ABS(A_exter_values[j]);
				if (recvcf[jcol] >= 0 && abs_jval > amax)
				{
					iagg = global(recvcf[jcol], recvfrom[jcol]);
					amax = abs_jval;
				}
			}

			aggregates[i] = iagg;
		}
		else
			aggregates[i] = global(cfmap[i], comm_rank);
	}

	delete[] recvcf;
	delete[] recvfrom;

	std::map<int, int> nbmap;
	for (int r = 0; r < nnb; ++r)
		nbmap.insert(std::pair<int, int>(nbrank[r], r));

	UpdateNeighbors(A, aggregates, nbmap);
	ExchangeAggregates(A, aggregates, recvagg);

	bool* mask = new bool[n];

	for (int k = 0; k < 3; ++k)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		for (int i = 0; i < n; ++i)
			mask[i] = aggregates[i] != ~0UL;

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		for (int i = 0; i < n; ++i)
		{
			if (!mask[i])
			{
				std::map<global, double> iaggwgt;

				for (int j = A_local_rowptr[i]; j < A_local_rowptr[i + 1]; ++j)
				{
					int jcol = A_local_colind[j];
					double abs_jval = ABS(A_local_values[j]);
					if (mask[jcol])
						iaggwgt[aggregates[jcol]] += abs_jval;
				}

				for (int j = A_exter_rowptr[i]; j < A_exter_rowptr[i + 1]; ++j)
				{
					int jcol = A_exter_colind[j];
					double abs_jval = ABS(A_exter_values[j]);
					if (recvagg[jcol] != ~0UL)
						iaggwgt[recvagg[jcol]] += abs_jval;
				}

				global iagg = aggregates[i];
				double amax = -1.0;

				for (std::map<global, double>::iterator iter = iaggwgt.begin(); iter != iaggwgt.end(); ++iter)
				{
					if (iter->second > amax)
					{
						iagg = iter->first;
						amax = iter->second;
					}
				}

				aggregates[i] = iagg;
			}
		}

		UpdateNeighbors(A, aggregates, nbmap);
		ExchangeAggregates(A, aggregates, recvagg);
	}

	delete[] mask;

	int* aggind = new int[n];
	int* recvaggind = new int[recvcnt];
	int* recvaggfrom = new int[recvcnt];

	int P_nnb = nbmap.size();
	int* P_nbrank = new int[P_nnb];
	for (std::map<int, int>::iterator iter = nbmap.begin(); iter != nbmap.end(); ++iter)
		P_nbrank[iter->second] = iter->first;

	std::map<int, int>* recvmap = new std::map<int, int>[P_nnb];

	for (int r = 0; r < nnb; ++r)
	{
		for (int i = recvptr[r]; i < recvptr[r + 1]; ++i)
		{
			int t = owner(recvagg[i]);
			if (t == ~0U)
			{
				recvaggfrom[i] = -1;
				recvaggind[i] = -1;
			}
			else if (t == comm_rank)
			{
				recvaggfrom[i] = -1;
				recvaggind[i] = local(recvagg[i]);
			}
			else
			{
				int _t = r;
				if (t != nbrank[r])
				{
					std::map<int, int>::iterator iter = nbmap.find(t);
					if (iter == nbmap.end())
					{
						recvaggfrom[i] = -1;
						recvaggind[i] = -1;
						continue;
					}
					else
						_t = iter->second;
				}
				std::pair<std::map<int, int>::iterator, bool> ret = recvmap[_t].insert(std::pair<int, int>(local(recvagg[i]), recvmap[_t].size()));
				recvaggfrom[i] = _t;
				recvaggind[i] = ret.first->second;
			}
		}
	}

	int P_recvcnt = 0;
	for (int r = 0; r < P_nnb; ++r)
		P_recvcnt += recvmap[r].size();

	int* P_recvptr = new int[P_nnb + 1];
	int* P_recvind = new int[P_recvcnt];

	P_recvptr[0] = 0;
	for (int r = 0; r < P_nnb; ++r)
	{
		P_recvptr[r + 1] = P_recvptr[r] + recvmap[r].size();
		for (std::map<int, int>::iterator iter = recvmap[r].begin(); iter != recvmap[r].end(); ++iter)
			P_recvind[P_recvptr[r] + iter->second] = iter->first;
	}

	for (int i = 0; i < recvcnt; ++i)
		if (recvaggfrom[i] != -1) recvaggind[i] += P_recvptr[recvaggfrom[i]] + nc;

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif	
	for (int i = 0; i < n; ++i)
	{
		int t = owner(aggregates[i]);
		if (t == ~0U)
			aggind[i] = -1;
		else if (t == comm_rank)
			aggind[i] = local(aggregates[i]);
		else
		{
			std::map<int, int>::iterator iter1 = nbmap.find(t);
			if (iter1 == nbmap.end())
				aggind[i] = -1;
			else
			{
				int _t = iter1->second;
				std::map<int, int>::iterator iter2 = recvmap[_t].find(local(aggregates[i]));
				if (iter2 == recvmap[_t].end())
					aggind[i] = -1;
				else
					aggind[i] = iter2->second + P_recvptr[_t] + nc;
			}
		}
	}

	delete[] aggregates;
	delete[] recvmap;
	delete[] recvagg;
	delete[] recvaggfrom;

	Vector D_recip;
	D_recip.Resize(n);

	double* Drcpv = D_recip.values;
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
	for (int i = 0; i < n; ++i)
	{
		for (int j = A_local_rowptr[i]; j < A_local_rowptr[i + 1]; ++j)
		{
			if (A_local_colind[j] == i)
			{
				Drcpv[i] = 1.0 / A_local_values[j];
				break;
			}
		}
	}

	double omega = 4.0 / (3.3 * LargestEigenvalueEstimate(A, D_recip, 10));

	int* P_local_rowptr = new int[n + 1];
	int* P_exter_rowptr = new int[n + 1];

	P_local_rowptr[0] = 0;
	P_exter_rowptr[0] = 0;

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel
#endif
	{
		int* w = new int[nc + P_recvcnt];
		for (int i = 0; i < nc + P_recvcnt; ++i)
			w[i] = -1;
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
		for (int i = 0; i < n; ++i)
		{
			int cntloc = 0;
			int cntext = 0;

			if (aggind[i] != -1)
			{
				w[aggind[i]] = i;
				++(aggind[i] < nc ? cntloc : cntext);
			}

			for (int j = A_local_rowptr[i]; j < A_local_rowptr[i + 1]; ++j)
			{
				int jcol = A_local_colind[j];
				if (jcol == i) continue;
				int jagg = aggind[A_local_colind[j]];
				if (jagg != -1 && w[jagg] != i)
				{
					w[jagg] = i;
					++(jagg < nc ? cntloc : cntext);
				}
			}

			for (int j = A_exter_rowptr[i]; j < A_exter_rowptr[i + 1]; ++j)
			{
				int jagg = recvaggind[A_exter_colind[j]];
				if (jagg != -1 && w[jagg] != i)
				{
					w[jagg] = i;
					++(jagg < nc ? cntloc : cntext);
				}
			}

			P_local_rowptr[i + 1] = cntloc;
			P_exter_rowptr[i + 1] = cntext;
		}

		delete[] w;
	}

	for (int i = 0; i < n; ++i)
		P_local_rowptr[i + 1] += P_local_rowptr[i];
	for (int i = 0; i < n; ++i)
		P_exter_rowptr[i + 1] += P_exter_rowptr[i];

	int* P_local_colind = new int[P_local_rowptr[n]];
	double* P_local_values = new double[P_local_rowptr[n]];
	int* P_exter_colind = new int[P_exter_rowptr[n]];
	double* P_exter_values = new double[P_exter_rowptr[n]];

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel
#endif
	{
		int* w = new int[nc + P_recvcnt];
		for (int i = 0; i < nc + P_recvcnt; ++i)
			w[i] = -1;
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
		for (int i = 0; i < n; ++i)
		{
			int k = P_local_rowptr[i];
			int t = P_exter_rowptr[i];
			int k0 = k, t0 = t;

			if (aggind[i] != -1)
			{
				if (aggind[i] < nc)
				{
					w[aggind[i]] = k;
					P_local_colind[k] = aggind[i];
					P_local_values[k++] = 1.0 - omega;
				}
				else
				{
					w[aggind[i]] = t;
					P_exter_colind[t] = aggind[i] - nc;
					P_exter_values[t++] = 1.0 - omega;
				}
			}

			double multiplier = -omega * Drcpv[i];

			for (int j = A_local_rowptr[i]; j < A_local_rowptr[i + 1]; ++j)
			{
				int jcol = A_local_colind[j];
				double jval = A_local_values[j];
				int jagg = aggind[jcol];
				if (jcol == i || jagg == -1) continue;
				if (jagg < nc)
				{
					if (w[jagg] < k0)
					{
						w[jagg] = k;
						P_local_colind[k] = jagg;
						P_local_values[k++] = multiplier * jval;
					}
					else
						P_local_values[w[jagg]] += multiplier * jval;
				}
				else
				{
					if (w[jagg] < t0)
					{
						w[jagg] = t;
						P_exter_colind[t] = jagg - nc;
						P_exter_values[t++] = multiplier * jval;
					}
					else
						P_exter_values[w[jagg]] += multiplier * jval;
				}
			}
			
			for (int j = A_exter_rowptr[i]; j < A_exter_rowptr[i + 1]; ++j)
			{
				int jcol = A_exter_colind[j];
				double jval = A_exter_values[j];
				int jagg = recvaggind[jcol];
				if (jagg == -1) continue;
				if (jagg < nc)
				{
					if (w[jagg] < k0)
					{
						w[jagg] = k;
						P_local_colind[k] = jagg;
						P_local_values[k++] = multiplier * jval;
					}
					else
						P_local_values[w[jagg]] += multiplier * jval;
				}
				else
				{
					if (w[jagg] < t0)
					{
						w[jagg] = t;
						P_exter_colind[t] = jagg - nc;
						P_exter_values[t++] = multiplier * jval;
					}
					else
						P_exter_values[w[jagg]] += multiplier * jval;
				}
			}
		}

		delete[] w;
	}

	delete[] aggind;
	delete[] recvaggind;

	P.comm = comm;

	P.local.size[0] = n;
	P.local.size[1] = nc;
	P.local.rowptr = P_local_rowptr;
	P.local.colind = P_local_colind;
	P.local.values = P_local_values;

	P.exter.size[0] = n;
	P.exter.size[1] = P_recvcnt;
	P.exter.rowptr = P_exter_rowptr;
	P.exter.colind = P_exter_colind;
	P.exter.values = P_exter_values;

	P.nnb = P_nnb;
	P.nbrank = P_nbrank;
	P.recvptr = P_recvptr;
	P.recvind = P_recvind;
}

void Sparsification(const ParCSRMatrix& A, ParCSRMatrix& B, double threshold)
{
	MPI_Comm comm = A.comm;
	int n = A.local.size[0];
	int recvcnt = A.exter.size[1];
	int* A_local_rowptr = A.local.rowptr;
	int* A_local_colind = A.local.colind;
	double* A_local_values = A.local.values;

	int* A_exter_rowptr = A.exter.rowptr;
	int* A_exter_colind = A.exter.colind;
	double* A_exter_values = A.exter.values;

	int nnb = A.nnb;
	int* A_nbrank = A.nbrank;
	int* A_recvptr = A.recvptr;
	int* A_recvind = A.recvind;
	int* A_sendptr = A.sendptr;
	int* A_sendind = A.sendind;

#ifdef YHAMG_USE_OPENMP
	omp_lock_t lock;
	omp_init_lock(&lock);
#endif

	double* rmax = new double[n];
	double* cmax = new double[n];

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
	for (int i = 0; i < n; ++i)
		rmax[i] = 0.0;
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
	for (int i = 0; i < n; ++i)
		cmax[i] = 0.0;

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
	for (int i = 0; i < n; ++i)
	{
		for (int j = A_local_rowptr[i]; j < A_local_rowptr[i + 1]; ++j)
		{
			int jcol = A_local_colind[j];
			if (jcol == i) continue;
			double abs_jval = ABS(A_local_values[j]);
			if (abs_jval > rmax[i]) rmax[i] = abs_jval;
#ifdef YHAMG_USE_OPENMP
			omp_set_lock(&lock);
#endif
			if (abs_jval > cmax[jcol]) cmax[jcol] = abs_jval;
#ifdef YHAMG_USE_OPENMP
			omp_unset_lock(&lock);
#endif
		}
	}

#ifdef YHAMG_USE_OPENMP
	omp_unset_lock(&lock);
#endif

	double* recvcmax = new double[recvcnt];
	for (int i = 0; i < recvcnt; ++i)
		recvcmax[i] = 0.0;
	for (int i = 0; i < n; ++i)
	{
		for (int j = A_exter_rowptr[i]; j < A_exter_rowptr[i + 1]; ++j)
		{
			int jcol = A_exter_colind[j];
			double abs_jval = ABS(A_exter_values[j]);
			if (abs_jval > rmax[i]) rmax[i] = abs_jval;
			if (abs_jval > recvcmax[jcol]) recvcmax[jcol] = abs_jval;
		}
	}

	double* sendbuf = new double[A_sendptr[nnb]];
	MPI_Request* recvreq = new MPI_Request[nnb];
	MPI_Request* sendreq = new MPI_Request[nnb];
	MPI_Status status;

	for (int r = 0; r < nnb; ++r)
		if (A_sendptr[r + 1] > A_sendptr[r])
			MPI_Irecv(sendbuf + A_sendptr[r], A_sendptr[r + 1] - A_sendptr[r], MPI_DOUBLE, A_nbrank[r], MPI_TAG, comm, recvreq + r);

	for (int r = 0; r < nnb; ++r)
		if (A_recvptr[r + 1] > A_recvptr[r])
			MPI_Isend(recvcmax + A_recvptr[r], A_recvptr[r + 1] - A_recvptr[r], MPI_DOUBLE, A_nbrank[r], MPI_TAG, comm, sendreq + r);

	for (int r = 0; r < nnb; ++r)
	{
		if (A_sendptr[r + 1] > A_sendptr[r])
		{
			MPI_Wait(recvreq + r, &status);
			for (int i = A_sendptr[r]; i < A_sendptr[r + 1]; ++i)
				if (sendbuf[i] > cmax[A_sendind[i]]) cmax[A_sendind[i]] = sendbuf[i];
		}
	}

	for (int r = 0; r < nnb; ++r)
		if (A_recvptr[r + 1] > A_recvptr[r])
			MPI_Wait(sendreq + r, &status);

	for (int r = 0; r < nnb; ++r)
		if (A_recvptr[r + 1] > A_recvptr[r])
			MPI_Irecv(recvcmax + A_recvptr[r], A_recvptr[r + 1] - A_recvptr[r], MPI_DOUBLE, A_nbrank[r], MPI_TAG, comm, recvreq + r);

	for (int r = 0; r < nnb; ++r)
	{
		if (A_sendptr[r + 1] > A_sendptr[r])
		{
			for (int i = A_sendptr[r]; i < A_sendptr[r + 1]; ++i)
				sendbuf[i] = cmax[A_sendind[i]];
			MPI_Isend(sendbuf + A_sendptr[r], A_sendptr[r + 1] - A_sendptr[r], MPI_DOUBLE, A_nbrank[r], MPI_TAG, comm, sendreq + r);
		}
	}
	
	for (int r = 0; r < nnb; ++r)
		if (A_recvptr[r + 1] > A_recvptr[r])
			MPI_Wait(recvreq + r, &status);

	for (int r = 0; r < nnb; ++r)
		if (A_sendptr[r + 1] > A_sendptr[r])
			MPI_Wait(sendreq + r, &status);

	delete[] sendbuf;
	delete[] recvreq;
	delete[] sendreq;

	bool* locstg = new bool[A.local.rowptr[n]];
	bool* extstg = new bool[A.exter.rowptr[n]];

	int* B_local_rowptr = new int[n + 1];
	int* B_exter_rowptr = new int[n + 1];

	B_local_rowptr[0] = 0;
	B_exter_rowptr[0] = 0;

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
	for (int i = 0; i < n; ++i)
	{
		int cntloc = 1;
		int cntext = 0;

		for (int j = A_local_rowptr[i]; j < A_local_rowptr[i + 1]; ++j)
		{
			locstg[j] = A_local_colind[j] != i && (ABS(A_local_values[j]) > rmax[i] * threshold || ABS(A_local_values[j]) > cmax[A_local_colind[j]] * threshold);
			if (locstg[j]) ++cntloc;
		}

		for (int j = A_exter_rowptr[i]; j < A_exter_rowptr[i + 1]; ++j)
		{
			extstg[j] = ABS(A_exter_values[j]) > rmax[i] * threshold || ABS(A_exter_values[j]) > recvcmax[A_exter_colind[j]] * threshold;
			if (extstg[j]) ++cntext;
		}

		B_local_rowptr[i + 1] = cntloc;
		B_exter_rowptr[i + 1] = cntext;
	}

	delete[] rmax;
	delete[] cmax;
	delete[] recvcmax;
	
	for (int i = 0; i < n; ++i)
		B_local_rowptr[i + 1] += B_local_rowptr[i];
	for (int i = 0; i < n; ++i)
		B_exter_rowptr[i + 1] += B_exter_rowptr[i];

	int* B_local_colind = new int[B_local_rowptr[n]];
	double* B_local_values = new double[B_local_rowptr[n]];
	int* B_exter_colind = new int[B_exter_rowptr[n]];
	double* B_exter_values = new double[B_exter_rowptr[n]];

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
	for (int i = 0; i < n; ++i)
	{
		double diagonal = 0.0;
		for (int j = A_local_rowptr[i], k = B_local_rowptr[i] + 1; j < A_local_rowptr[i + 1]; ++j)
		{
			if (locstg[j])
			{
				B_local_colind[k] = A_local_colind[j];
				B_local_values[k++] = A_local_values[j];
			}
			else
				diagonal += A_local_values[j];
		}

		for (int j = A_exter_rowptr[i], k = B_exter_rowptr[i]; j < A_exter_rowptr[i + 1]; ++j)
		{
			if (extstg[j])
			{
				B_exter_colind[k] = A_exter_colind[j];
				B_exter_values[k++] = A_exter_values[j];
			}
			else
				diagonal += A_exter_values[j];
		}

		B_local_colind[B_local_rowptr[i]] = i;
		B_local_values[B_local_rowptr[i]] = diagonal;
	}

	delete[] locstg;
	delete[] extstg;

	int* B_nbrank = new int[nnb];
	for (int r = 0; r < nnb; ++r)
		B_nbrank[r] = A_nbrank[r];

	int* v = new int[A.exter.size[1]];
	for (int i = 0; i < A.exter.size[1]; ++i)
		v[i] = -1;

	for (int j = 0; j < B_exter_rowptr[n]; ++j)
		v[B_exter_colind[j]] = 1;

	int* B_recvind = new int[A.exter.size[1]];
	int* B_recvptr = new int[nnb + 1];

	B_recvptr[0] = 0;
	for (int r = 0, k = 0; r < nnb; B_recvptr[++r] = k)
	{
		for (int i = A_recvptr[r]; i < A_recvptr[r + 1]; ++i)
		{
			if (v[i] == 1)
			{
				v[i] = k;
				B_recvind[k++] = A_recvind[i];
			}
		}
	}

	for (int j = 0; j < B_exter_rowptr[n]; ++j)
		B_exter_colind[j] = v[B_exter_colind[j]];

	delete[] v;

	B.Free();

	B.comm = comm;

	B.local.size[0] = n;
	B.local.size[1] = n;
	B.local.rowptr = B_local_rowptr;
	B.local.colind = B_local_colind;
	B.local.values = B_local_values;

	B.exter.size[0] = n;
	B.exter.size[1] = B_recvptr[nnb];
	B.exter.rowptr = B_exter_rowptr;
	B.exter.colind = B_exter_colind;
	B.exter.values = B_exter_values;

	B.nnb = nnb;
	B.nbrank = B_nbrank;
	B.recvptr = B_recvptr;
	B.recvind = B_recvind;
}

}

}