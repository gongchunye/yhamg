/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "ParEigenSolver.hpp"
#include "ParOperatorIdent.hpp"

namespace YHAMG
{

ParEigenSolver::~ParEigenSolver()
{
}

void ParEigenSolver::operator()(const ParOperator& A, const ParVector& x, double& lambda, int& iter, double& res) const
{
	ParMultiVector X{x.comm, 1, x.local.size, x.local.values, 1};
	Vector Lambda{1, &lambda, 1};
	Vector Res{1, &res, 1};
	(*this)(A, X, Lambda, iter, Res);
}

void ParEigenSolver::operator()(const ParOperator& A, const ParOperator& T, const ParVector& x, double& lambda, int& iter, double& res) const
{
	ParMultiVector X{x.comm, 1, x.local.size, x.local.values, 1};
	Vector Lambda{1, &lambda, 1};
	Vector Res{1, &res, 1};
	(*this)(A, T, X, Lambda, iter, Res);
}

void ParEigenSolver::operator()(const ParOperator& A, const ParOperator& B, const ParOperator& T, const ParVector& x, double& lambda, int& iter, double& res) const
{
	ParMultiVector X{x.comm, 1, x.local.size, x.local.values, 1};
	Vector Lambda{1, &lambda, 1};
	Vector Res{1, &res, 1};
	(*this)(A, B, T, X, Lambda, iter, Res);
}

void ParEigenSolver::operator()(const ParOperator& A, const ParMultiVector& Y, const ParVector& x, double& lambda, int& iter, double& res) const
{
	ParMultiVector X{x.comm, 1, x.local.size, x.local.values, 1};
	Vector Lambda{1, &lambda, 1};
	Vector Res{1, &res, 1};
	(*this)(A, Y, X, Lambda, iter, Res);
}

void ParEigenSolver::operator()(const ParOperator& A, const ParOperator& T, const ParMultiVector& Y, const ParVector& x, double& lambda, int& iter, double& res) const
{
	ParMultiVector X{x.comm, 1, x.local.size, x.local.values, 1};
	Vector Lambda{1, &lambda, 1};
	Vector Res{1, &res, 1};
	(*this)(A, T, Y, X, Lambda, iter, Res);
}

void ParEigenSolver::operator()(const ParOperator& A, const ParOperator& B, const ParOperator& T, const ParMultiVector& Y, const ParVector& x, double& lambda, int& iter, double& res) const
{
	ParMultiVector X{x.comm, 1, x.local.size, x.local.values, 1};
	Vector Lambda{1, &lambda, 1};
	Vector Res{1, &res, 1};
	(*this)(A, B, T, Y, X, Lambda, iter, Res);
}

void ParEigenSolver::operator()(const ParOperator& A, const ParMultiVector& X, const Vector& Lambda, int& iter, const Vector& Res) const
{
	(*this)(A, ParOperatorIdent{A.comm, A.InSize()}, ParOperatorIdent{A.comm, A.InSize()}, ParMultiVector{A.comm, 0, A.InSize()}, X, Lambda, iter, Res);
}

void ParEigenSolver::operator()(const ParOperator& A, const ParOperator& T, const ParMultiVector& X, const Vector& Lambda, int& iter, const Vector& Res) const
{
	(*this)(A, ParOperatorIdent{A.comm, A.InSize()}, T, ParMultiVector{A.comm, 0, A.InSize()}, X, Lambda, iter, Res);
}

void ParEigenSolver::operator()(const ParOperator& A, const ParOperator& B, const ParOperator& T, const ParMultiVector& X, const Vector& Lambda, int& iter, const Vector& Res) const
{
	(*this)(A, B, T, ParMultiVector{A.comm, 0, A.InSize()}, X, Lambda, iter, Res);
}

void ParEigenSolver::operator()(const ParOperator& A, const ParMultiVector& Y, const ParMultiVector& X, const Vector& Lambda, int& iter, const Vector& Res) const
{
	(*this)(A, ParOperatorIdent{A.comm, A.InSize()}, ParOperatorIdent{A.comm, A.InSize()}, Y, X, Lambda, iter, Res);
}

void ParEigenSolver::operator()(const ParOperator& A, const ParOperator& T, const ParMultiVector& Y, const ParMultiVector& X, const Vector& Lambda, int& iter, const Vector& Res) const
{
	(*this)(A, ParOperatorIdent{A.comm, A.InSize()}, T, Y, X, Lambda, iter, Res);
}
}