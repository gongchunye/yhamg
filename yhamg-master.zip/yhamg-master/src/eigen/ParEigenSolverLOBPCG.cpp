/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <cmath>
#include <iostream>
#include "ParEigenSolverLOBPCG.hpp"

#ifdef YHAMG_USE_LAPACKE
#include <lapacke.h>
#endif

namespace YHAMG
{

typedef struct
{
	int size[2];
	int ld;
	double* values;
} ColMajorMatrix;

static inline ColMajorMatrix ColMajor(int n, int m, int ld, double* values)
{
	ColMajorMatrix A;
	A.size[0] = n;
	A.size[1] = m;
	A.ld = ld;
	A.values = values;
	return A;
}

static void SetToZeros(const ColMajorMatrix& A)
{
	int n = A.size[0];
	int m = A.size[1];
	int ld = A.ld;
	double* Av = A.values;
	for (int j = 0; j < m; ++j)
		for (int i = 0; i < n; ++i)
			Av[i + j * ld] = 0.0;
}

static void SetToIdentity(const ColMajorMatrix& A)
{
	int n = A.size[0];
	int ld = A.ld;
	double* Av = A.values;
	for (int j = 0; j < n; ++j)
	{
		for (int i = 0; i < n; ++i)
			Av[i + j * ld] = 0.0;
		Av[j + j * ld] = 1.0;
	}
}

static void SetDiagonal(const Vector& D, const ColMajorMatrix& A)
{
	int n = D.size;
	int ld = A.ld;
	double* Dv = D.values;
	double* Av = A.values;
	for (int j = 0; j < n; ++j)
		Av[j + j * ld] = Dv[j];
}

static int CholeskyFactorize(const ColMajorMatrix& A)
{
	int n = A.size[0];
	int ld = A.ld;
	double* Av = A.values;
	for (int i = 0; i < n; ++i)
	{
		for (int k = 0; k < i; ++k)
			Av[i + i * ld] -= Av[k + i * ld] * Av[k + i * ld];
		if (Av[i + i * ld] <= 0) return 1;
		Av[i + i * ld] = sqrt(Av[i + i * ld]);
		for (int j = i + 1; j < n; ++j)
		{
			for (int k = 0; k < i; ++k)
				Av[i + j * ld] -= Av[k + i * ld] * Av[k + j * ld];
			Av[i + j * ld] /= Av[i + i * ld];
		}
	}
	return 0;
}

#define ABS(x) ((x) > 0 ? (x) : -(x))

static inline void swap(double& a, double& b)
{
	double temp = a;
	a = b;
	b = temp;
}

static void EigenSortAbs(const Vector& Lambda, const ColMajorMatrix& X)
{
	int m = Lambda.size;
	int n = X.size[0];
	int ld = X.ld;
	double* Lamv = Lambda.values;
	double* Xv = X.values;

	for (int k = 0; k < m; ++k)
	{
		int r = k;
		double min = ABS(Lamv[k]);
		for (int j = k + 1; j < m; ++j)
		{
			if (ABS(Lamv[j]) < min)
			{
				r = j;
				min = ABS(Lamv[j]);
			}
		}
		if (r > k)
		{
			swap(Lamv[k], Lamv[r]);
			for (int i = 0; i < n; ++i)
				swap(Xv[i + k * ld], Xv[i + r * ld]);
		}
	}
}

static inline int GeneralizedEigenSolve(const ColMajorMatrix& A, const ColMajorMatrix& B, const Vector& D)
{
#ifdef YHAMG_USE_LAPACKE
	return LAPACKE_dsygv(LAPACK_COL_MAJOR, 1, 'V', 'U', A.size[0], A.values, A.ld, B.values, B.ld, D.values);
#endif
	return 1;
}

static void ParMultiVecCopy(const ParMultiVector& X, const ParMultiVector& Y)
{
	int m = X.local.nvec;
	for (int j = 0; j < m; ++j)
		Y(j).Copy(X(j));
}

static void ParMultiVecRDivU(const ParMultiVector& X, const ColMajorMatrix& U)
{
	int m = X.local.nvec;
	int ld = U.ld;
	double* Uv = U.values;
	for (int j = 0; j < m; ++j)
	{
		int i = 0;
		for ( ; i + 1 < j; i += 2)
			X(j).Add2Scaled(-Uv[i + j * ld], X(i), -Uv[i + 1 + j * ld], X(i + 1));
		if (i + 1 == j)
			X(j).AddScaled(-Uv[i + j * ld], X(i));
		X(j).Scale(1.0 / Uv[j + j * ld]);
	}
}

static void ParMultiVecXAPBY(const ParMultiVector& X, const ColMajorMatrix& A, double b, const ParMultiVector& Y)
{
	int n = X.local.nvec;
	int m = Y.local.nvec;
	int ld = A.ld;
	double* Av = A.values;
	for (int j = 0; j < m; ++j)	
	{
		Y(j).Scale(b);
		int i = 0;
		for ( ; i + 1 < n; i += 2)
			Y(j).Add2Scaled(Av[i + j * ld], X(i), Av[i + 1 + j * ld], X(i + 1));
		if (i + 1 == n)
			Y(j).AddScaled(Av[i + j * ld], X(i));
	}
}

static void ParMultiVecXDPBY(const ParMultiVector& X, const Vector& D, double b, const ParMultiVector& Y)
{
	int m = Y.local.nvec;
	double* Dv = D.values;
	for (int j = 0; j < m; ++j)
		ParVecAXPBY(Dv[j], X(j), b, Y(j));
}

static void ParMultiVecDot(const ParMultiVector& X, const ParMultiVector& Y, const ColMajorMatrix& A)
{
	int n = X.local.nvec;
	int m = Y.local.nvec;
	int ld = A.ld;
	double* Av = A.values;
	double* temp = new double[n * m];
	for (int i = 0; i < n; ++i)
		for (int j = 0; j < m; ++j)
			temp[i + j * n] = VecDot(X.local(i), Y.local(j));
	MPI_Allreduce(MPI_IN_PLACE, temp, n * m, MPI_DOUBLE, MPI_SUM, X.comm);
	for (int i = 0; i < n; ++i)
		for (int j = 0; j < m; ++j)
			Av[i + j * ld] = temp[i + j * n];
	delete[] temp;
}

static void ParMultiVecDotU(const ParMultiVector& X, const ParMultiVector& Y, const ColMajorMatrix& U)
{
	int m = X.local.nvec;
	int ld = U.ld;
	double* Uv = U.values;
	double* temp = new double[(m + 1) * m / 2];
	for (int i = 0; i < m; ++i)
		for (int j = i; j < m; ++j)
			temp[i + (j + 1) * j / 2] = VecDot(X.local(i), Y.local(j));
	MPI_Allreduce(MPI_IN_PLACE, temp, (m + 1) * m / 2, MPI_DOUBLE, MPI_SUM, X.comm);
	for (int i = 0; i < m; ++i)
		for (int j = i; j < m; ++j)
			Uv[i + j * ld] = temp[i + (j + 1) * j / 2];
	delete[] temp;
}

static void ParMultiVecDotD(const ParMultiVector& X, const ParMultiVector& Y, const Vector& D)
{
	int m = X.local.nvec;
	double* Dv = D.values;
	for (int j = 0; j < m; ++j)
		Dv[j] = VecDot(X.local(j), Y.local(j));
	MPI_Allreduce(MPI_IN_PLACE, Dv, m, MPI_DOUBLE, MPI_SUM, X.comm);
}

static void VecSqrt(const Vector& x)
{
	int n = x.size;
	double* xv = x.values;
	for (int i = 0; i < n; ++i)
		xv[i] = sqrt(xv[i]);
}

static int LOBPCG_CheckResidual(const Vector& Res, double tol, bool* ConvergedFlag)
{
	int m = Res.size;
	double* Resv = Res.values;
	int NumCoverged = 0;

	for (int i = 0; i < m; ++i)
		if (ConvergedFlag[i] = Resv[i] <= tol) ++NumCoverged;

	return NumCoverged;
}

static void LOBPCG_Deflation(ParMultiVector& X, const bool* Flag)
{
	int m = X.local.nvec;
	int m1 = 0;
	for (int j = 0; j < m; ++j)
	{
		if (Flag[j]) continue;
		if (m1 < j) X(m1).Copy(X(j));
		++m1;
	}
	X.local.nvec = m1;
}

ParEigenSolverLOBPCG::ParEigenSolverLOBPCG(int max_iters, double tolerance, int print_stats)
	:MaxIters(max_iters),
	Tolerance(tolerance),
	PrintStats(print_stats)
{
}

void ParEigenSolverLOBPCG::operator()(const ParOperator& A, const ParOperator& B, const ParOperator& T, const ParMultiVector& Y, const ParMultiVector& X, const Vector& Lambda, int& iter, const Vector& Res) const
{
	MPI_Comm comm = A.comm;

	int comm_rank;
	MPI_Comm_rank(comm, &comm_rank);

	int n = A.OutSize();
	int m = X.local.nvec;
	int m1 = m;

	int my = 0;
	my = Y.local.nvec;

	ParMultiVector R(comm), W(comm), P(comm), Y1(comm), BY(comm), AX(comm), BX(comm), AW(comm), BW(comm), AP(comm), BP(comm), TempVec(comm);
	ColMajorMatrix GramA, GramB, GramY, YBY, YBX, YBW, XAX, XBX, WAW, WBW, PAP, PBP, XAW, XBW, XAP, XBP, WAP, WBP, Yx, Yw, Yp;
	Vector GramLamdba;

	R.Allocate(m, n);
	W.Allocate(m, n);
	P.Allocate(m, n);
	Y1.Allocate(my, n);
	BY.Allocate(my, n);
	AX.Allocate(m, n);
	BX.Allocate(m, n);
	AW.Allocate(m, n);
	BW.Allocate(m, n);
	AP.Allocate(m, n);
	BP.Allocate(m, n);
	TempVec.Allocate(m, n);
	GramLamdba.Resize(3 * m);

	double* GramAv = new double[9 * m * m];
	double* GramBv = new double[9 * m * m];
	double* GramYv = new double[my * (my + 2 * m)];
	
	if (PrintStats && comm_rank == 0)
	{
		std::cout << "Iter\tResidual\n";
		std::cout << "--------------------------------------------------\n";
	}

	GramA = ColMajor(3 * m, 3 * m, 3 * m, GramAv);
	GramB = ColMajor(3 * m, 3 * m, 3 * m, GramBv);
	GramY = ColMajor(my, my + 2 * m, my, GramYv);
	
	XAX = ColMajor(m, m, 3 * m, GramAv);
	XBX = ColMajor(m, m, 3 * m, GramBv);
	YBY = ColMajor(my, my, my, GramYv);
	YBX = ColMajor(my, m, my, GramYv + my * my);

	SetToZeros(GramA);
	SetToZeros(GramB);

	bool* ConvergedFlag = new bool[m];
	bool ExplicitGramFlag = 0;

	iter = 0;
	int iter1 = 0;

	ParMultiVecCopy(Y, Y1);

	B.Apply(Y1, BY);

	ParMultiVecDotU(BY, Y1, YBY);
	if (CholeskyFactorize(YBY))
		goto breakdown;

	ParMultiVecRDivU(Y1, YBY);

	ParMultiVecRDivU(BY, YBY);

	ParMultiVecDot(BY, X, YBX);
	ParMultiVecXAPBY(Y1, YBX, -1.0, X);

	B.Apply(X, BX);

	ParMultiVecDotU(BX, X, XBX);

	if (CholeskyFactorize(XBX))
		goto breakdown;

	ParMultiVecRDivU(X, XBX);

	ParMultiVecRDivU(BX, XBX);
	
	SetToIdentity(XBX);

	A.Apply(X, AX);
	ParMultiVecDotU(AX, X, XAX);

	if (GeneralizedEigenSolve(XAX, XBX, Lambda))
		goto breakdown;

	ParMultiVecXAPBY(X, XAX, 0.0, TempVec);
	ParMultiVecCopy(TempVec, X);
	ParMultiVecXAPBY(AX, XAX, 0.0, TempVec);
	ParMultiVecCopy(TempVec, AX);

	ParMultiVecXAPBY(BX, XAX, 0.0, TempVec);
	ParMultiVecCopy(TempVec, BX);

	while (1)
	{
		R.local.nvec = m;

		ParMultiVecCopy(AX, R);
		ParMultiVecXDPBY(BX, Lambda, -1.0, R);

		ParMultiVecDotD(R, R, Res);
		
		if (!ExplicitGramFlag)
			ExplicitGramFlag = 4.0 + Res.values[0] == 4.0;

		VecSqrt(Res);

		m1 = m - LOBPCG_CheckResidual(Res, Tolerance, ConvergedFlag);

		if (PrintStats && comm_rank == 0)
		{
			std::cout << iter;
			for (int j = 0; j < m; ++j)
			{
				if (ConvergedFlag[j])
					std::cout << "\t" << Res.values[j] << " *\n";
				else
					std::cout << "\t" << Res.values[j] << "\n";
			}
		}

		if (m1 == 0 || iter == MaxIters) break;

		LOBPCG_Deflation(R, ConvergedFlag);

		W.local.nvec = m1;
		AW.local.nvec = m1;
		BW.local.nvec = m1;

		XAX = ColMajor(m, m, 3 * m, GramAv);
		XAW = ColMajor(m, m1, 3 * m, GramAv + 3 * m * m);
		WAW = ColMajor(m1, m1, 3 * m, GramAv + m + 3 * m * m);

		XBX = ColMajor(m, m, 3 * m, GramBv);
		XBW = ColMajor(m, m1, 3 * m, GramBv + 3 * m * m);
		WBW = ColMajor(m1, m1, 3 * m, GramBv + m + 3 * m * m);

		T.Apply(R, W);

		YBW = ColMajor(my, m1, my, GramYv + my * (my + m));

		ParMultiVecDot(BY, W, YBW);
		ParMultiVecXAPBY(Y1, YBW, -1.0, W);

		ParMultiVecDot(BX, W, XBW);
		ParMultiVecXAPBY(X, XBW, -1.0, W);

		B.Apply(W, BW);
			
		ParMultiVecDotU(BW, W, WBW);

		if (CholeskyFactorize(WBW))
			goto breakdown;

		ParMultiVecRDivU(W, WBW);

		ParMultiVecRDivU(BW, WBW);

		A.Apply(W, AW);
		ParMultiVecDot(AX, W, XAW);
		ParMultiVecDotU(AW, W, WAW);

		if (ExplicitGramFlag)
		{
			ParMultiVecDotU(AX, X, XAX);
			ParMultiVecDotU(BX, X, XBX);
			ParMultiVecDotU(BW, W, WBW);
			ParMultiVecDot(BX, W, XBW);
		}
		else
		{
			SetToZeros(XAX);
			SetDiagonal(Lambda, XAX);
			SetToIdentity(XBX);
			SetToIdentity(WBW);
			SetToZeros(XBW);
		}

restart:
		if (iter1 > 0)
		{
			XAP = ColMajor(m, m1, 3 * m, GramAv + 3 * m * (m + m1));
			WAP = ColMajor(m1, m1, 3 * m, GramAv + m + 3 * m * (m + m1));
			PAP = ColMajor(m1, m1, 3 * m, GramAv + m + m1 + 3 * m * (m + m1));
			
			XBP = ColMajor(m, m1, 3 * m, GramBv + 3 * m * (m + m1));
			WBP = ColMajor(m1, m1, 3 * m, GramBv + m + 3 * m * (m + m1));
			PBP = ColMajor(m1, m1, 3 * m, GramBv + m + m1 + 3 * m * (m + m1));
			
			GramA = ColMajor(m + m1 + m1, m + m1 + m1, 3 * m, GramAv);
			GramB = ColMajor(m + m1 + m1, m + m1 + m1, 3 * m, GramBv);
			GramLamdba.size = m + m1 + m1;
			
			LOBPCG_Deflation(P, ConvergedFlag);
			LOBPCG_Deflation(AP, ConvergedFlag);
			LOBPCG_Deflation(BP, ConvergedFlag);

			ParMultiVecDotU(BP, P, PBP);

			if (CholeskyFactorize(PBP))
			{
				iter1 = 0;
				goto restart;
			}

			ParMultiVecRDivU(P, PBP);
			ParMultiVecRDivU(AP, PBP);

			ParMultiVecRDivU(BP, PBP);
			
			ParMultiVecDot(AX, P, XAP);
			ParMultiVecDot(AW, P, WAP);
			ParMultiVecDotU(AP, P, PAP);
			
			ParMultiVecDot(BX, P, XBP);
			ParMultiVecDot(BW, P, WBP);

			if (ExplicitGramFlag)
				ParMultiVecDotU(BP, P, PBP);
			else
				SetToIdentity(PBP);

			if (GeneralizedEigenSolve(GramA, GramB, GramLamdba))
			{
				iter1 = 0;
				goto restart;
			}

			EigenSortAbs(GramLamdba, GramA);

			GramLamdba.size = m;
			Yx = ColMajor(m, m, 3 * m, GramAv);
			Yw = ColMajor(m1, m, 3 * m, GramAv + m);
			Yp = ColMajor(m1, m, 3 * m, GramAv + m + m1);

			Lambda.Copy(GramLamdba);

			ParMultiVecXAPBY(P, Yp, 0.0, TempVec);
			ParMultiVecXAPBY(W, Yw, 1.0, TempVec);
			P.local.nvec = m;
			ParMultiVecCopy(TempVec, P);
			
			ParMultiVecXAPBY(X, Yx, 1.0, TempVec);
			ParMultiVecCopy(TempVec, X);
			
			ParMultiVecXAPBY(AP, Yp, 0.0, TempVec);
			ParMultiVecXAPBY(AW, Yw, 1.0, TempVec);
			AP.local.nvec = m;
			ParMultiVecCopy(TempVec, AP);

			ParMultiVecXAPBY(AX, Yx, 1.0, TempVec);
			ParMultiVecCopy(TempVec, AX);

			ParMultiVecXAPBY(BP, Yp, 0.0, TempVec);
			ParMultiVecXAPBY(BW, Yw, 1.0, TempVec);
			BP.local.nvec = m;
			ParMultiVecCopy(TempVec, BP);

			ParMultiVecXAPBY(BX, Yx, 1.0, TempVec);
			ParMultiVecCopy(TempVec, BX);
		}
		else
		{
			GramA = ColMajor(m + m1, m + m1, 3 * m, GramAv);
			GramB = ColMajor(m + m1, m + m1, 3 * m, GramBv);
			GramLamdba.size = m + m1;

			if (GeneralizedEigenSolve(GramA, GramB, GramLamdba))
				goto breakdown;

			EigenSortAbs(GramLamdba, GramA);

			GramLamdba.size = m;
			Yx = ColMajor(m, m, 3 * m, GramAv);
			Yw = ColMajor(m1, m, 3 * m, GramAv + m);

			Lambda.Copy(GramLamdba);

			ParMultiVecXAPBY(W, Yw, 0.0, TempVec);
			P.local.nvec = m;
			ParMultiVecCopy(TempVec, P);
			
			ParMultiVecXAPBY(X, Yx, 1.0, TempVec);
			ParMultiVecCopy(TempVec, X);

			ParMultiVecXAPBY(AW, Yw, 0.0, TempVec);
			AP.local.nvec = m;
			ParMultiVecCopy(TempVec, AP);

			ParMultiVecXAPBY(AX, Yx, 1.0, TempVec);
			ParMultiVecCopy(TempVec, AX);

			ParMultiVecXAPBY(BW, Yw, 0.0, TempVec);
			BP.local.nvec = m;
			ParMultiVecCopy(TempVec, BP);

			ParMultiVecXAPBY(BX, Yx, 1.0, TempVec);
			ParMultiVecCopy(TempVec, BX);
		}
		
		++iter;
		++iter1;
	}

breakdown:
	if (PrintStats && comm_rank == 0)
	{
		std::cout << "--------------------------------------------------\n";
		std::cout << "Iterations: " << iter << "\n";
		std::cout << "Converged Eigenpairs: " << m - m1 << "/" << m << "\n";
	}

	delete[] GramAv;
	delete[] GramBv;
	delete[] GramYv;
	delete[] ConvergedFlag;
}

}
