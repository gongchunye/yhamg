/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef ParEigenSolver_H
#define ParEigenSolver_H

#include "ParOperator.hpp"

namespace YHAMG
{

class ParEigenSolver
{
public:
	virtual ~ParEigenSolver();
	virtual void operator()(const ParOperator& A, const ParVector& x, double& lambda, int& iter, double& res) const;
	virtual void operator()(const ParOperator& A, const ParOperator& T, const ParVector& x, double& lambda, int& iter, double& res) const;
	virtual void operator()(const ParOperator& A, const ParOperator& B, const ParOperator& T, const ParVector& x, double& lambda, int& iter, double& res) const;
	virtual void operator()(const ParOperator& A, const ParMultiVector& Y, const ParVector& x, double& lambda, int& iter, double& res) const;
	virtual void operator()(const ParOperator& A, const ParOperator& T, const ParMultiVector& Y, const ParVector& x, double& lambda, int& iter, double& res) const;
	virtual void operator()(const ParOperator& A, const ParOperator& B, const ParOperator& T, const ParMultiVector& Y, const ParVector& x, double& lambda, int& iter, double& res) const;
	virtual void operator()(const ParOperator& A, const ParMultiVector& X, const Vector& Lambda, int& iter, const Vector& Res) const;
	virtual void operator()(const ParOperator& A, const ParOperator& T, const ParMultiVector& X, const Vector& Lambda, int& iter, const Vector& Res) const;
	virtual void operator()(const ParOperator& A, const ParOperator& B, const ParOperator& T, const ParMultiVector& X, const Vector& Lambda, int& iter, const Vector& Res) const;
	virtual void operator()(const ParOperator& A, const ParMultiVector& Y, const ParMultiVector& X, const Vector& Lambda, int& iter, const Vector& Res) const;
	virtual void operator()(const ParOperator& A, const ParOperator& T, const ParMultiVector& Y, const ParMultiVector& X, const Vector& Lambda, int& iter, const Vector& Res) const;
	virtual void operator()(const ParOperator& A, const ParOperator& B, const ParOperator& T, const ParMultiVector& Y, const ParMultiVector& X, const Vector& Lambda, int& iter, const Vector& Res) const = 0;
};

}

#endif