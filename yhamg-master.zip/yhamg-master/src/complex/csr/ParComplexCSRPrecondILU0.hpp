/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef ParComplexCSRPrecondILU0_H
#define ParComplexCSRPrecondILU0_H

#include "ParComplexCSRPrecond.hpp"

namespace YHAMG
{

class ParComplexCSRPrecondILU0 : public ParComplexCSRPrecond
{
private:
	ComplexVector D_local_recip;
	ComplexCSRMatrix L_local;
	ComplexCSRMatrix L_exter;
	ComplexCSRMatrix U_local;
	ComplexCSRMatrix U_exter;
	ComplexVector recvx;

	bool* interior;

	int label;
	int nnb;
	int* nblab;
	int* nbrank;

	int* recvptr;
	int* sendptr;
	int* sendind;
	zomplex* sendbuf;

public:
	ParComplexCSRPrecondILU0();
	~ParComplexCSRPrecondILU0();

	void Free();
	void Setup(const ParComplexCSRMatrix& A, int REUSE = 0);
	int InSize() const;
	int OutSize() const;
	void Apply(const ParComplexVector& b, const ParComplexVector& x) const;
};

}

#endif