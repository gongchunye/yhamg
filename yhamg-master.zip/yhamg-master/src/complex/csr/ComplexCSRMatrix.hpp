/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef ComplexCSRMatrix_H
#define ComplexCSRMatrix_H

#include "ComplexOperator.hpp"
#include "ComplexCOOMatrix.hpp"
#include "CSRMatrix.hpp"

namespace YHAMG
{

struct ComplexCSRMatrix : public ComplexOperator
{
	int ref;
	int size[2];

	int* rowptr;
	int* colind;
	zomplex* values;

	ComplexCSRMatrix();
	ComplexCSRMatrix(int n, int m, int* rowptr, int* colind, zomplex* values, int ref);
	ComplexCSRMatrix(const CSRMatrix& A);
	ComplexCSRMatrix(const ComplexCSRMatrix& A);
	ComplexCSRMatrix(const ComplexCOOMatrix& A);
	ComplexCSRMatrix(ComplexCSRMatrix&& A);
	~ComplexCSRMatrix();
	ComplexCSRMatrix& operator=(const ComplexCOOMatrix& A);
	ComplexCSRMatrix& operator=(const ComplexCSRMatrix& A);
	ComplexCSRMatrix& operator=(ComplexCSRMatrix&& A);

	void Free();
	void Refer(const ComplexCSRMatrix& A);
	int InSize() const;
	int OutSize() const;
	void Apply(const ComplexVector& x, const ComplexVector& y) const;
};

void ComplexCSRRead(const char* filename, ComplexCSRMatrix& A);
void ComplexCSRWrite(const char* filename, const ComplexCSRMatrix& A);
void ComplexCSRDiag(const ComplexCSRMatrix& A, const ComplexVector& D);
void ComplexCSREliminZeros(const ComplexCSRMatrix& A);
void ComplexCSRConj(const ComplexCSRMatrix& A);
void ComplexCSRScale(zomplex alpha, const ComplexCSRMatrix& A);
void ComplexCSRScaleRows(const ComplexVector& x, const ComplexCSRMatrix& A);
void ComplexCSRScaleCols(const ComplexVector& x, const ComplexCSRMatrix& A);
void ComplexCSRMatAdd(const ComplexCSRMatrix& A, const ComplexCSRMatrix& B, ComplexCSRMatrix& C);
void ComplexCSRMatMul(const ComplexCSRMatrix& A, const ComplexCSRMatrix& B, ComplexCSRMatrix& C);
void ComplexCSRMatVec(zomplex alpha, const ComplexCSRMatrix& A, const ComplexVector& x, zomplex beta, const ComplexVector& y);
void ComplexCSRTrans(const ComplexCSRMatrix& A, ComplexCSRMatrix& B);
void ComplexCSRConjTrans(const ComplexCSRMatrix& A, ComplexCSRMatrix& B);

}

#endif
