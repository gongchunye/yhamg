/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <stdio.h>
#include "blas.hpp"
#include "spblas.hpp"
#include "ComplexCSRMatrix.hpp"

#ifdef YHAMG_USE_OPENMP
#include <omp.h>
#endif

namespace YHAMG
{

ComplexCSRMatrix::ComplexCSRMatrix()
	: ref(0),
	size{0, 0},
	rowptr(0),
	colind(0),
	values(0)
{
}

ComplexCSRMatrix::ComplexCSRMatrix(int _n, int _m, int* _rowptr, int* _colind, zomplex* _values, int _ref)
	: ref(_ref),
	size{_n, _m},
	rowptr(_rowptr),
	colind(_colind),
	values(_values)
{
}

ComplexCSRMatrix::ComplexCSRMatrix(const CSRMatrix& A)
	: ref(0),
	size{A.size[0], A.size[1]},
	rowptr(new int[A.size[0] + 1]),
	colind(new int[A.rowptr[A.size[0]]]),
	values(new zomplex[A.rowptr[A.size[0]]])
{
	int* Ap = A.rowptr;
	int* Ai = A.colind;
	double* Av = A.values;

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
	for (int i = 0; i <= size[0]; ++i)
		rowptr[i] = Ap[i];

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
	for (int j = 0; j < Ap[size[0]]; ++j)
	{
		colind[j] = Ai[j];
		values[j] = Av[j];
	}
}

ComplexCSRMatrix::ComplexCSRMatrix(const ComplexCSRMatrix& A)
	: ref(0),
	size{A.size[0], A.size[1]},
	rowptr(new int[A.size[0] + 1]),
	colind(new int[A.rowptr[A.size[0]]]),
	values(new zomplex[A.rowptr[A.size[0]]])
{
	int* Ap = A.rowptr;
	int* Ai = A.colind;
	zomplex* Av = A.values;

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
	for (int i = 0; i <= size[0]; ++i)
		rowptr[i] = Ap[i];

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
	for (int j = 0; j < Ap[size[0]]; ++j)
	{
		colind[j] = Ai[j];
		values[j] = Av[j];
	}
}

ComplexCSRMatrix::ComplexCSRMatrix(const ComplexCOOMatrix& A)
	: ref(0),
	rowptr(new int[A.size[0] + 1]),
	colind(new int[A.nnz]),
	values(new zomplex[A.nnz])
{
	int nnz = A.nnz;
	int* Ai = A.rowind;
	int* Aj = A.colind;
	zomplex* Av = A.values;

	size[0] = A.size[0];
	size[1] = A.size[1];

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
	for (int i = 0; i <= size[0]; ++i)
		rowptr[i] = 0;

	for (int j = 0; j < nnz; ++j)
		++rowptr[Ai[j]];

	for (int i = 0; i < size[0]; ++i)
		rowptr[i + 1] += rowptr[i];

	for (int j = nnz - 1; j >= 0; --j)
	{
		colind[--rowptr[Ai[j]]] = Aj[j];
		values[rowptr[Ai[j]]] = Av[j];
	}
}

ComplexCSRMatrix::ComplexCSRMatrix(ComplexCSRMatrix&& A)
	: ref(A.ref),
	size{A.size[0], A.size[1]},
	rowptr(A.rowptr),
	colind(A.colind),
	values(A.values)
{
	A.ref = 1;
}

ComplexCSRMatrix::~ComplexCSRMatrix()
{
	if (!ref)
	{
		if (rowptr) delete[] rowptr;
		if (colind) delete[] colind;
		if (values) delete[] values;
	}
}

ComplexCSRMatrix& ComplexCSRMatrix::operator=(const ComplexCSRMatrix& A)
{
	Free();

	int* Ap = A.rowptr;
	int* Ai = A.colind;
	zomplex* Av = A.values;

	size[0] = A.size[0];
	size[1] = A.size[1];

	rowptr = new int[size[0] + 1];
	colind = new int[Ap[size[0]]];
	values = new zomplex[Ap[size[0]]];

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
	for (int i = 0; i <= size[0]; ++i)
		rowptr[i] = Ap[i];

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
	for (int j = 0; j < Ap[size[0]]; ++j)
	{
		colind[j] = Ai[j];
		values[j] = Av[j];
	}

	return *this;
}


ComplexCSRMatrix& ComplexCSRMatrix::operator=(const ComplexCOOMatrix& A)
{
	Free();

	int nnz = A.nnz;
	int* Ai = A.rowind;
	int* Aj = A.colind;
	zomplex* Av = A.values;

	size[0] = A.size[0];
	size[1] = A.size[1];

	rowptr = new int[size[0] + 1];
	colind = new int[nnz];
	values = new zomplex[nnz];

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
	for (int i = 0; i <= size[0]; ++i)
		rowptr[i] = 0;

	for (int j = 0; j < nnz; ++j)
		++rowptr[Ai[j]];

	for (int i = 0; i < size[0]; ++i)
		rowptr[i + 1] += rowptr[i];

	for (int j = nnz - 1; j >= 0; --j)
	{
		colind[--rowptr[Ai[j]]] = Aj[j];
		values[rowptr[Ai[j]]] = Av[j];
	}

	return *this;
}

ComplexCSRMatrix& ComplexCSRMatrix::operator=(ComplexCSRMatrix&& A)
{
	Free();

	ref = A.ref;
	size[0] = A.size[0];
	size[1] = A.size[1];
	rowptr = A.rowptr;
	colind = A.colind;
	values = A.values;

	A.ref = 1;

	return *this;
}

void ComplexCSRMatrix::Free()
{
	if (!ref)
	{
		if (rowptr) delete[] rowptr;
		if (colind) delete[] colind;
		if (values) delete[] values;
	}
	size[0] = 0;
	size[1] = 0;
	rowptr = 0;
	colind = 0;
	values = 0;
	ref = 0;
}

void ComplexCSRMatrix::Refer(const ComplexCSRMatrix& A)
{
	if (!ref)
	{
		if (rowptr) delete[] rowptr;
		if (colind) delete[] colind;
		if (values) delete[] values;
	}
	size[0] = A.size[0];
	size[1] = A.size[1];
	rowptr = A.rowptr;
	colind = A.colind;
	values = A.values;
	ref = 1;
}


int ComplexCSRMatrix::InSize() const
{
	return size[1];
}

int ComplexCSRMatrix::OutSize() const
{
	return size[0];
}

void ComplexCSRMatrix::Apply(const ComplexVector& x, const ComplexVector& y) const
{
	ComplexCSRMatVec(1.0, *this, x, 0.0, y);
}

void ComplexCSRRead(const char* filename, ComplexCSRMatrix& A)
{
	ComplexCOOMatrix B;
	ComplexCOORead(filename, B);
	A = B;
}

void ComplexCSRWrite(const char* filename, const ComplexCSRMatrix& A)
{
	int n = A.size[0];
	int m = A.size[1];
	int nz = A.rowptr[A.size[0]];

	int* Ap = A.rowptr;
	int* Ai = A.colind;
	zomplex* Av = A.values;

	FILE* f = fopen(filename, "w");

	fprintf(f, "%d %d %d\n", n, m, nz);

	for (int i = 0; i < n; ++i)
		for (int j = Ap[i]; j < Ap[i + 1];++j)
			fprintf(f, "%d %d %20.16g %20.16g\n", i + 1, Ai[j] + 1, zreal(Av[j]), zimag(Av[j]));

	fclose(f);
}

void ComplexCSRDiag(const ComplexCSRMatrix& A, const ComplexVector& D)
{
	int n = A.size[0];
	int* Ap = A.rowptr;
	int* Ai = A.colind;
	zomplex* Av = A.values;
	zomplex* Dv = D.values;

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
	for (int i = 0; i < n; ++i)
	{
		for (int j = Ap[i]; j < Ap[i + 1]; ++j)
		{
			zomplex diag = 0.0;
			if (Ai[j] == i)
			{
				diag = Av[j];
				break;
			}
			Dv[i] = diag;
		}
	}
}

void ComplexCSREliminZeros(const ComplexCSRMatrix& A)
{
	int n = A.size[0];
	int* Ap = A.rowptr;
	int* Ai = A.colind;
	zomplex* Av = A.values;

	for (int i = 0, j = 0, k = 0; i < n; Ap[++i] = k)
	{
		for ( ; j < Ap[i + 1]; ++j)
		{
			if (Av[j] != 0.0)
			{
				Ai[k] = Ai[j];
				Av[k++] = Av[j];
			}
		}
	}
}

void ComplexCSRConj(const ComplexCSRMatrix& A)
{
	int n = A.size[0];
	int* Ap = A.rowptr;
	zomplex* Av = A.values;
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
	for (int j = 0; j < Ap[n]; ++j)
		Av[j] = zconj(Av[j]);
}

void ComplexCSRScale(zomplex alpha, const ComplexCSRMatrix& A)
{
	int n = A.size[0];
	int* Ap = A.rowptr;
	zomplex* Av = A.values;
	blas_zscal(Ap[n], alpha, Av);
}

void ComplexCSRScaleRows(const ComplexVector& x, const ComplexCSRMatrix& A)
{
	int n = A.size[0];
	int* Ap = A.rowptr;
	zomplex* Av = A.values;
	zomplex* xv = x.values;
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
	for (int i = 0; i < n; ++i)
		for (int j = Ap[i]; j < Ap[i + 1]; ++j)
			Av[j] *= xv[i];
}

void ComplexCSRScaleCols(const ComplexVector& x, const ComplexCSRMatrix& A)
{
	int n = A.size[0];
	int* Ap = A.rowptr;
	int* Ai = A.colind;
	zomplex* Av = A.values;
	zomplex* xv = x.values;
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
	for (int i = 0; i < n; ++i)
		for (int j = Ap[i]; j < Ap[i + 1]; ++j)
			Av[j] *= xv[Ai[j]];
}

void ComplexCSRMatAdd(const ComplexCSRMatrix& A, const ComplexCSRMatrix& B, ComplexCSRMatrix& C)
{
	int n = A.size[0];
	int m = B.size[1];
	int* Ap = A.rowptr;
	int* Ai = A.colind;
	zomplex* Av = A.values;
	int* Bp = B.rowptr;
	int* Bi = B.colind;
	zomplex* Bv = B.values;

	int* Cp = new int[n + 1];
	Cp[0] = 0;
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel
#endif
	{
		int* w = new int[m];
		for (int i = 0; i < m; ++i)
			w[i] = -1;

#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
		for (int i = 0; i < n; ++i)
		{
			int cnt = Ap[i + 1] - Ap[i];

			for (int j = Ap[i]; j < Ap[i + 1]; ++j)
				w[Ai[j]] = i;

			for (int j = Bp[i]; j < Bp[i + 1]; ++j)
			{
				if (w[Bi[j]] != i)
				{
					w[Bi[j]] = i;
					++cnt;
				}
			}

			Cp[i + 1] = cnt;
		}

		delete[] w;
	}

	for (int i = 0; i < n; ++i)
		Cp[i + 1] += Cp[i];

	int* Ci = new int[Cp[n]];
	zomplex* Cv = new zomplex[Cp[n]];

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel
#endif
	{
		int* w = new int[m];
		for (int i = 0; i < m; ++i)
			w[i] = -1;
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
		for (int i = 0; i < n; ++i)
		{
			int r = Cp[i], r0 = Cp[i];

			for (int j = Ap[i]; j < Ap[i + 1]; ++j)
			{
				w[Ai[j]] = r;
				Ci[r] = Ai[j];
				Cv[r++] = Av[j];
			}

			for (int j = Bp[i]; j < Bp[i + 1]; ++j)
			{
				if (w[Bi[j]] < r0)
				{
					w[Bi[j]] = r;
					Ci[r] = Bi[j];
					Cv[r++] = Bv[j];
				}
				else
					Cv[w[Bi[j]]] += Bv[j];
			}
		}

		delete[] w;
	}

	C.Free();

	C.size[0] = n;
	C.size[1] = m;
	C.rowptr = Cp;
	C.colind = Ci;
	C.values = Cv;
}

void ComplexCSRMatMul(const ComplexCSRMatrix& A, const ComplexCSRMatrix& B, ComplexCSRMatrix& C)
{
	int n = A.size[0];
	int m = B.size[1];
	int* Ap = A.rowptr;
	int* Ai = A.colind;
	zomplex* Av = A.values;
	int* Bp = B.rowptr;
	int* Bi = B.colind;
	zomplex* Bv = B.values;

	int* Cp = new int[n + 1];
	Cp[0] = 0;
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel
#endif
	{
		int* w = new int[m];
		for (int i = 0; i < m; ++i)
			w[i] = -1;
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
		for (int i = 0; i < n; ++i)
		{
			int cnt = 0;
			for (int k = Ap[i]; k < Ap[i + 1]; ++k)
			{
				int kcol = Ai[k];
				for (int j = Bp[kcol]; j < Bp[kcol + 1]; ++j)
				{
					int jcol = Bi[j];
					if (w[jcol] != i)
					{
						w[jcol] = i;
						++cnt;
					}
				}
			}
			Cp[i + 1] = cnt;
		}
		delete[] w;
	}

	for (int i = 0; i < n; ++i)
		Cp[i + 1] += Cp[i];

	int* Ci = new int[Cp[n]];
	zomplex* Cv = new zomplex[Cp[n]];

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel
#endif
	{
		int* w = new int[m];
		for (int i = 0; i < m; ++i)
			w[i] = -1;
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
		for (int i = 0; i < n; ++i)
		{
			for (int k = Ap[i], r = Cp[i], r0 = Cp[i]; k < Ap[i + 1]; ++k)
			{
				int kcol = Ai[k];
				zomplex kval = Av[k];
				for (int j = Bp[kcol]; j < Bp[kcol + 1]; ++j)
				{
					int jcol = Bi[j];
					zomplex jval = Bv[j];
					if (w[jcol] < r0)
					{
						w[jcol] = r;
						Ci[r] = jcol;
						Cv[r++] = kval * jval;
					}
					else
						Cv[w[jcol]] += kval * jval;
				}
			}
		}
		delete[] w;
	}

	C.Free();

	C.size[0] = n;
	C.size[1] = m;
	C.rowptr = Cp;
	C.colind = Ci;
	C.values = Cv;
}

void ComplexCSRMatVec(zomplex alpha, const ComplexCSRMatrix& A, const ComplexVector& x, zomplex beta, const ComplexVector& y)
{
	int n = A.size[0];
	int* Ap = A.rowptr;
	int* Ai = A.colind;
	zomplex* Av = A.values;
	zomplex* xv = x.values;
	zomplex* yv = y.values;
	spblas_zcsrmv(n, alpha, Ap, Ai, Av, xv, beta, yv);
}

void ComplexCSRTrans(const ComplexCSRMatrix& A, ComplexCSRMatrix& B)
{
	int n = A.size[0];
	int m = A.size[1];
	int* Ap = A.rowptr;
	int* Ai = A.colind;
	zomplex* Av = A.values;

	int* Bp = new int[m + 1];
	int* Bi = new int[Ap[n]];
	zomplex* Bv = new zomplex[Ap[n]];

	int nthd = 1;
#ifdef YHAMG_USE_OPENMP
	nthd = omp_get_max_threads();
#endif

	if (nthd == 1)
	{
		for (int i = 0; i <= m; ++i)
		Bp[i] = 0;

		for (int j = Ap[0]; j < Ap[n]; ++j)
			++Bp[Ai[j]];

		for (int i = 0; i < m; ++i)
			Bp[i + 1] += Bp[i];

		for (int i = n - 1; i >= 0; --i)
		{
			for (int j = Ap[i + 1] - 1; j >= Ap[i]; --j)
			{
				Bi[--Bp[Ai[j]]] = i;
				Bv[Bp[Ai[j]]] = Av[j];
			}
		}
	}
	else
	{
		int*  _offsets = new int[m * nthd];
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		for (int i = 0; i < m * nthd; ++i)
			_offsets[i] = 0;

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		for (int t = 0; t < nthd; ++t)
		{
			int start = n * t / nthd;
			int end = n * (t + 1) / nthd;
			for (int j = Ap[start]; j < Ap[end]; ++j)
				++_offsets[Ai[j] * nthd + t];
		}

		if (nthd > 2)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			for (int t = 0; t < nthd; ++t)
			{
				int start = m * t;
				int end = m * (t + 1);

				for (int i = start + 1; i < end; ++i)
					_offsets[i] += _offsets[i - 1];
			}

			for (int t = 1; t < nthd; ++t)
			{
				int start = m * t;
				int end = m * (t + 1);
				_offsets[end - 1] += _offsets[start - 1];
			}

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			for (int t = 1; t < nthd; ++t)
			{
				int start = m * t;
				int end = m * (t + 1);
				for (int i = start; i < end - 1; ++i)
					_offsets[i] += _offsets[start - 1];
			}
		}
		else
		{
			for (int i = 1; i < m * nthd; ++i)
				_offsets[i] += _offsets[i - 1];
		}

		Bp[0] = 0;
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		for (int i = 1; i <= m; ++i)
			Bp[i] = _offsets[i * nthd - 1];

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		for (int t = 0; t < nthd; ++t)
		{
			int start = n * t / nthd;
			int end = n * (t + 1) / nthd;
			for (int i = end - 1; i >= start; --i)
			{
				for (int j = Ap[i + 1] - 1; j >= Ap[i]; --j)
				{
					Bi[--_offsets[Ai[j] * nthd + t]] = i;
					Bv[_offsets[Ai[j] * nthd + t]] = Av[j];
				}
			}
		}
		
		delete[] _offsets;
	}

	B.Free();
	B.size[0] = m;
	B.size[1] = n;
	B.rowptr = Bp;
	B.colind = Bi;
	B.values = Bv;
}

void ComplexCSRConjTrans(const ComplexCSRMatrix& A, ComplexCSRMatrix& B)
{
	int n = A.size[0];
	int m = A.size[1];
	int* Ap = A.rowptr;
	int* Ai = A.colind;
	zomplex* Av = A.values;

	int* Bp = new int[m + 1];
	int* Bi = new int[Ap[n]];
	zomplex* Bv = new zomplex[Ap[n]];

	int nthd = 1;
#ifdef YHAMG_USE_OPENMP
	nthd = omp_get_max_threads();
#endif

	if (nthd == 1)
	{
		for (int i = 0; i <= m; ++i)
		Bp[i] = 0;

		for (int j = Ap[0]; j < Ap[n]; ++j)
			++Bp[Ai[j]];

		for (int i = 0; i < m; ++i)
			Bp[i + 1] += Bp[i];

		for (int i = n - 1; i >= 0; --i)
		{
			for (int j = Ap[i + 1] - 1; j >= Ap[i]; --j)
			{
				Bi[--Bp[Ai[j]]] = i;
				Bv[Bp[Ai[j]]] = zconj(Av[j]);
			}
		}
	}
	else
	{
		int*  _offsets = new int[m * nthd];
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		for (int i = 0; i < m * nthd; ++i)
			_offsets[i] = 0;

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		for (int t = 0; t < nthd; ++t)
		{
			int start = n * t / nthd;
			int end = n * (t + 1) / nthd;
			for (int j = Ap[start]; j < Ap[end]; ++j)
				++_offsets[Ai[j] * nthd + t];
		}

		if (nthd > 2)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			for (int t = 0; t < nthd; ++t)
			{
				int start = m * t;
				int end = m * (t + 1);

				for (int i = start + 1; i < end; ++i)
					_offsets[i] += _offsets[i - 1];
			}

			for (int t = 1; t < nthd; ++t)
			{
				int start = m * t;
				int end = m * (t + 1);
				_offsets[end - 1] += _offsets[start - 1];
			}

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			for (int t = 1; t < nthd; ++t)
			{
				int start = m * t;
				int end = m * (t + 1);
				for (int i = start; i < end - 1; ++i)
					_offsets[i] += _offsets[start - 1];
			}
		}
		else
		{
			for (int i = 1; i < m * nthd; ++i)
				_offsets[i] += _offsets[i - 1];
		}

		Bp[0] = 0;
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		for (int i = 1; i <= m; ++i)
			Bp[i] = _offsets[i * nthd - 1];

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		for (int t = 0; t < nthd; ++t)
		{
			int start = n * t / nthd;
			int end = n * (t + 1) / nthd;
			for (int i = end - 1; i >= start; --i)
			{
				for (int j = Ap[i + 1] - 1; j >= Ap[i]; --j)
				{
					Bi[--_offsets[Ai[j] * nthd + t]] = i;
					Bv[_offsets[Ai[j] * nthd + t]] = zconj(Av[j]);
				}
			}
		}
		
		delete[] _offsets;
	}

	B.Free();
	B.size[0] = m;
	B.size[1] = n;
	B.rowptr = Bp;
	B.colind = Bi;
	B.values = Bv;
}

}