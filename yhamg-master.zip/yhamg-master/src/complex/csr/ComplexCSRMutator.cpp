/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <map>
#include "ComplexCSRMutator.hpp"

namespace YHAMG
{

ComplexCSRMutator::ComplexCSRMutator(const ComplexCSRMatrix& _A)
	: A(_A.size[0], _A.size[1], _A.rowptr, _A.colind, _A.values, 1),
	marks(new bool[_A.size[0]]),
	data(new std::map<int, zomplex>[_A.size[0]])
{
	int n = _A.size[0];
	for (int i = 0; i < n; ++i)
		marks[i] = 0;
}

ComplexCSRMutator::~ComplexCSRMutator()
{
	if (marks) delete[] marks;
	if (data) delete[] (std::map<int, zomplex>*)data;
}

zomplex* ComplexCSRMutator::Find(int row, int col) const
{
	if (!marks[row])
	{
		int* Ap = A.rowptr;
		int* Ai = A.colind;
		zomplex* Av = A.values;
		for (int j = Ap[row]; j < Ap[row + 1]; ++j)
			((std::map<int, zomplex>*)data)[row].insert(std::pair<int, zomplex>(Ai[j], Av[j]));
		marks[row] = 1;
	}

	std::map<int, zomplex>::iterator iter = ((std::map<int, zomplex>*)data)[row].find(col);
	return iter == ((std::map<int, zomplex>*)data)[row].end() ? 0 : &iter->second;
}

zomplex* ComplexCSRMutator::Insert(int row, int col) const
{
	if (!marks[row])
	{
		int* Ap = A.rowptr;
		int* Ai = A.colind;
		zomplex* Av = A.values;
		for (int j = Ap[row]; j < Ap[row + 1]; ++j)
			((std::map<int, zomplex>*)data)[row].insert(std::pair<int, zomplex>(Ai[j], Av[j]));
		marks[row] = 1;
	}

	return &((std::map<int, zomplex>*)data)[row].insert(std::pair<int, zomplex>(col, 0.0)).first->second;
}

void ComplexCSRMutator::Erase(int row, int col) const
{
	if (!marks[row])
	{
		int* Ap = A.rowptr;
		int* Ai = A.colind;
		zomplex* Av = A.values;
		for (int j = Ap[row]; j < Ap[row + 1]; ++j)
			((std::map<int, zomplex>*)data)[row].insert(std::pair<int, zomplex>(Ai[j], Av[j]));
		marks[row] = 1;
	}

	std::map<int, zomplex>::iterator iter = ((std::map<int, zomplex>*)data)[row].find(col);
	if (iter != ((std::map<int, zomplex>*)data)[row].end()) ((std::map<int, zomplex>*)data)[row].erase(iter);
}

void ComplexCSRMutator::operator()(ComplexCSRMatrix& _A)
{
	int n = A.size[0];
	int m = A.size[1];
	int* Ap = A.rowptr;
	int* Ai = A.colind;
	zomplex* Av = A.values;

	int* _Ap = new int[n + 1];

	_Ap[0] = 0;
	for (int i = 0; i < n; ++i)
		_Ap[i + 1] = marks[i] ? ((std::map<int, zomplex>*)data)[i].size() : Ap[i + 1] - Ap[i];

	for (int i = 0; i < n; ++i)
		_Ap[i + 1] += _Ap[i];

	int* _Ai = new int[_Ap[n]];
	zomplex* _Av = new zomplex[_Ap[n]];

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
	for (int i = 0; i < n; ++i)
	{
		if (marks[i])
		{
			std::map<int, zomplex>::iterator iter = ((std::map<int, zomplex>*)data)[i].begin();
			for (int j = _Ap[i]; j < _Ap[i + 1]; ++j, ++iter)
			{
				_Ai[j] = iter->first;
				_Av[j] = iter->second;
			}
		}
		else
		{
			for (int j = _Ap[i], k = Ap[i]; j < _Ap[i + 1]; ++j, ++k)
			{
				_Ai[j] = Ai[k];
				_Av[j] = Av[k];
			}
		}
	}

	_A.Free();
	_A.size[0] = n;
	_A.size[1] = m;
	_A.rowptr = _Ap;
	_A.colind = _Ai;
	_A.values = _Av;

	A.rowptr = _Ap;
	A.colind = _Ai;
	A.values = _Av;
}

}