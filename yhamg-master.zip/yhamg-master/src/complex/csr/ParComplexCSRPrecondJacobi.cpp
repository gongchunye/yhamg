/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "ParComplexCSRPrecondJacobi.hpp"

namespace YHAMG
{

void ParComplexCSRPrecondJacobi::Free()
{
	D_recip.Free();
}

void ParComplexCSRPrecondJacobi::Setup(const ParComplexCSRMatrix& A, int REUSE)
{
	int n = A.local.size[0];
	int* Ap = A.local.rowptr;
	int* Ai = A.local.colind;
	zomplex* Av = A.local.values;

	if (!REUSE)
	{
		comm = A.comm;
		D_recip.Resize(n);
	}

	zomplex* Drcpv = D_recip.values;

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
	for (int i = 0; i < n; ++i)
	{
		for (int j = Ap[i]; j < Ap[i + 1]; ++j)
		{
			if (Ai[j] == i)
			{
				Drcpv[i] = zomplex(1.0) / Av[j];
				break;
			}
		}
	}
}

int ParComplexCSRPrecondJacobi::InSize() const
{
	return D_recip.size;
}

int ParComplexCSRPrecondJacobi::OutSize() const
{
	return D_recip.size;
}

void ParComplexCSRPrecondJacobi::Apply(const ParComplexVector& b, const ParComplexVector& x) const
{
	int n = D_recip.size;
	zomplex* Drcpv = D_recip.values;
	zomplex* xv = x.local.values;
	zomplex* bv = b.local.values;

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
	for (int i = 0; i < n; ++i)
		xv[i] = bv[i] * Drcpv[i];
}

}