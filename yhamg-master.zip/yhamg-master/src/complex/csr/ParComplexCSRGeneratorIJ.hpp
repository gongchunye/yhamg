/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef ParComplexCSRGeneratorIJ_H
#define ParComplexCSRGeneratorIJ_H

#include "global.hpp"
#include "ParComplexCSRGenerator.hpp"

namespace YHAMG
{

class ParComplexCSRGeneratorIJ : public ParComplexCSRGenerator
{
public:
	int size[2];
	const int* rowptr;
	const global* colind;
	const zomplex* values;
	int pattern_symmetry;

	ParComplexCSRGeneratorIJ(MPI_Comm comm = MPI_COMM_SELF);
	ParComplexCSRGeneratorIJ(MPI_Comm comm, int n, int m, const int* rowptr, const global* colind, const zomplex* values, int pattern_symmetry = 0);
	void operator()(ParComplexCSRMatrix& A) const;
};

}

#endif