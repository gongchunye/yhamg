/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "ParComplexCSRAccessor.hpp"

namespace YHAMG
{

ParComplexCSRAccessor::ParComplexCSRAccessor(const ParComplexCSRMatrix& A)
	: comm(A.comm),
	locref(A.local.size[0], A.local.size[1], A.local.rowptr, A.local.colind, A.local.values, 1),
	extref(A.exter.size[0], A.exter.size[1], A.exter.rowptr, A.exter.colind, A.exter.values, 1),
	recvind(new int[A.exter.size[1]]),
	recvfrom(new int[A.exter.size[1]])
{
	int _nnb = A.nnb;
	int* _nbrank = A.nbrank;
	int* _recvptr = A.recvptr;
	int* _recvind = A.recvind;

	for (int r = 0; r < _nnb; ++r)
	{
		for (int i = _recvptr[r]; i < _recvptr[r + 1]; ++i)
		{
			recvfrom[i] = _nbrank[r];
			recvind[i] = _recvind[i];
		}
	}
}

ParComplexCSRAccessor::~ParComplexCSRAccessor()
{
	if (recvind) delete[] recvind;
	if (recvfrom) delete[] recvfrom;
}

zomplex* ParComplexCSRAccessor::Find(int row, global col) const
{
	int comm_rank;
	MPI_Comm_rank(comm, &comm_rank);

	if (owner(col) == comm_rank)
	{
		int* local_rowptr = locref.rowptr;
		int* local_colind = locref.colind;
		zomplex* local_values = locref.values;

		for (int j = local_rowptr[row]; j < local_rowptr[row + 1]; ++j)
			if (local_colind[j] == local(col)) return local_values + j;

		return 0;
	}
	else
	{
		int* exter_rowptr = extref.rowptr;
		int* exter_colind = extref.colind;
		zomplex* exter_values = extref.values;

		for (int j = exter_rowptr[row]; j < exter_rowptr[row + 1]; ++j)
			if (recvind[exter_colind[j]] == local(col) && recvfrom[exter_colind[j]] == owner(col))
				return exter_values + j;

		return 0;
	}
}

}