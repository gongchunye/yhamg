/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <map>
#include "ParComplexCSRMutator.hpp"

namespace YHAMG
{

ParComplexCSRMutator::ParComplexCSRMutator(const ParComplexCSRMatrix& A)
	: comm(A.comm),
	locref(A.local.size[0], A.local.size[1], A.local.rowptr, A.local.colind, A.local.values, 1),
	extref(A.exter.size[0], A.exter.size[1], A.exter.rowptr, A.exter.colind, A.exter.values, 1),
	recvind(new int[A.exter.size[1]]),
	recvfrom(new int[A.exter.size[1]]),
	marks(new bool[A.local.size[0]]),
	data(new std::map<global, zomplex>[A.local.size[0]])
{
	int n = A.local.size[0];
	int _nnb = A.nnb;
	int* _nbrank = A.nbrank;
	int* _recvptr = A.recvptr;
	int* _recvind = A.recvind;

	for (int r = 0; r < _nnb; ++r)
	{
		for (int i = _recvptr[r]; i < _recvptr[r + 1]; ++i)
		{
			recvfrom[i] = _nbrank[r];
			recvind[i] = _recvind[i];
		}
	}

	for (int i = 0; i < n; ++i)
		marks[i] = 0;
}

ParComplexCSRMutator::~ParComplexCSRMutator()
{
	if (recvind) delete[] recvind;
	if (recvfrom) delete[] recvfrom;
	if (marks) delete[] marks;
	if (data) delete[] (std::map<global, zomplex>*)data;
}

zomplex* ParComplexCSRMutator::Find(int row, global col) const
{
	if (!marks[row])
	{
		int comm_rank;
		MPI_Comm_rank(comm, &comm_rank);

		int n = locref.size[0];
		int* local_rowptr = locref.rowptr;
		int* local_colind = locref.colind;
		zomplex* local_values = locref.values;
		int* exter_rowptr = extref.rowptr;
		int* exter_colind = extref.colind;
		zomplex* exter_values = extref.values;

		for (int j = local_rowptr[row]; j < local_rowptr[row + 1]; ++j)
			((std::map<global, zomplex>*)data)[row].insert(std::pair<global, zomplex>(global(local_colind[j], comm_rank), local_values[j]));

		for (int j = exter_rowptr[row]; j < exter_rowptr[row + 1]; ++j)
			((std::map<global, zomplex>*)data)[row].insert(std::pair<global, zomplex>(global(recvind[exter_colind[j]], recvfrom[exter_colind[j]]), exter_values[j]));

		marks[row] = 1;
	}

	std::map<global, zomplex>::iterator iter = ((std::map<global, zomplex>*)data)[row].find(col);
	return iter == ((std::map<global, zomplex>*)data)[row].end() ? 0 : &iter->second;
}

zomplex* ParComplexCSRMutator::Insert(int row, global col) const
{
	if (!marks[row])
	{
		int comm_rank;
		MPI_Comm_rank(comm, &comm_rank);

		int n = locref.size[0];
		int* local_rowptr = locref.rowptr;
		int* local_colind = locref.colind;
		zomplex* local_values = locref.values;
		int* exter_rowptr = extref.rowptr;
		int* exter_colind = extref.colind;
		zomplex* exter_values = extref.values;

		for (int j = local_rowptr[row]; j < local_rowptr[row + 1]; ++j)
			((std::map<global, zomplex>*)data)[row].insert(std::pair<global, zomplex>(global(local_colind[j], comm_rank), local_values[j]));

		for (int j = exter_rowptr[row]; j < exter_rowptr[row + 1]; ++j)
			((std::map<global, zomplex>*)data)[row].insert(std::pair<global, zomplex>(global(recvind[exter_colind[j]], recvfrom[exter_colind[j]]), exter_values[j]));

		marks[row] = 1;
	}

	return &((std::map<global, zomplex>*)data)[row].insert(std::pair<global, zomplex>(col, 0.0)).first->second;
}

void ParComplexCSRMutator::Erase(int row, global col) const
{
	if (!marks[row])
	{
		int comm_rank;
		MPI_Comm_rank(comm, &comm_rank);

		int n = locref.size[0];
		int* local_rowptr = locref.rowptr;
		int* local_colind = locref.colind;
		zomplex* local_values = locref.values;
		int* exter_rowptr = extref.rowptr;
		int* exter_colind = extref.colind;
		zomplex* exter_values = extref.values;

		for (int j = local_rowptr[row]; j < local_rowptr[row + 1]; ++j)
			((std::map<global, zomplex>*)data)[row].insert(std::pair<global, zomplex>(global(local_colind[j], comm_rank), local_values[j]));

		for (int j = exter_rowptr[row]; j < exter_rowptr[row + 1]; ++j)
			((std::map<global, zomplex>*)data)[row].insert(std::pair<global, zomplex>(global(recvind[exter_colind[j]], recvfrom[exter_colind[j]]), exter_values[j]));

		marks[row] = 1;
	}

	std::map<global, zomplex>::iterator iter = ((std::map<global, zomplex>*)data)[row].find(col);
	if (iter != ((std::map<global, zomplex>*)data)[row].end()) ((std::map<global, zomplex>*)data)[row].erase(iter);
}

void ParComplexCSRMutator::operator()(ParComplexCSRMatrix& A)
{
	int n = locref.size[0];
	int m = locref.size[1];
	int* local_rowptr = locref.rowptr;
	int* local_colind = locref.colind;
	zomplex* local_values = locref.values;
	int* exter_rowptr = extref.rowptr;
	int* exter_colind = extref.colind;
	zomplex* exter_values = extref.values;

	int comm_size, comm_rank;

	MPI_Comm_size(comm, &comm_size);
	MPI_Comm_rank(comm, &comm_rank);

	int* _local_rowptr = new int[n + 1];
	int* _exter_rowptr = new int[n + 1];

	_local_rowptr[0] = 0;
	_exter_rowptr[0] = 0;
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
	for (int i = 0; i < n; ++i)
	{
		if (marks[i])
		{
			int cntloc = 0, cntext = 0;
			for (std::map<global, zomplex>::iterator iter = ((std::map<global, zomplex>*)data)[i].begin(); iter != ((std::map<global, zomplex>*)data)[i].end(); ++iter)
				++(owner(iter->first) == comm_rank ? cntloc : cntext);
			_local_rowptr[i + 1] = cntloc;
			_exter_rowptr[i + 1] = cntext;
		}
		else
		{
			_local_rowptr[i + 1] = local_rowptr[i + 1] - local_rowptr[i];
			_exter_rowptr[i + 1] = exter_rowptr[i + 1] - exter_rowptr[i];
		}
	}

	for (int i = 0; i < n; ++i)
		_local_rowptr[i + 1] += _local_rowptr[i];
	for (int i = 0; i < n; ++i)
		_exter_rowptr[i + 1] += _exter_rowptr[i];
	
	int* _local_colind = new int[_local_rowptr[n]];
	zomplex* _local_values = new zomplex[_local_rowptr[n]];
	int* _exter_colind = new int[_exter_rowptr[n]];
	int* _exter_colfrom = new int[_exter_rowptr[n]];
	zomplex* _exter_values = new zomplex[_exter_rowptr[n]];

	char* recvmark = new char[comm_size];
	for (int r = 0; r < comm_size; ++r)
		recvmark[r] = 0;
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
	for (int i = 0; i < n; ++i)
	{
		if (marks[i])
		{
			int j = _local_rowptr[i];
			int k = _exter_rowptr[i];
			for (std::map<global, zomplex>::iterator iter = ((std::map<global, zomplex>*)data)[i].begin(); iter != ((std::map<global, zomplex>*)data)[i].end(); ++iter)
			{
				if (owner(iter->first) == comm_rank)
				{
					_local_colind[j] = local(iter->first);
					_local_values[j++] = iter->second;
				}
				else
				{
					_exter_colind[k] = local(iter->first);
					_exter_colfrom[k] = owner(iter->first);
					_exter_values[k++] = iter->second;
					recvmark[owner(iter->first)] = 1;
				}
			}
		}
		else
		{
			for (int j = _local_rowptr[i], k = local_rowptr[i]; j < _local_rowptr[i + 1]; ++j, ++k)
			{
				_local_colind[j] = local_colind[k];
				_local_values[j] = local_values[k];
			}

			for (int j = _exter_rowptr[i], k = exter_rowptr[i]; j < _exter_rowptr[i + 1]; ++j, ++k)
			{
				_exter_colind[j] = recvind[exter_colind[k]];
				_exter_colfrom[j] = recvfrom[exter_colind[k]];
				_exter_values[j] = exter_values[k];
				recvmark[recvfrom[exter_colind[k]]] = 1;
			}
		}
	}

	int _nnb = 0;
	std::map<int, int> _nbmap;

	char* sendmark = new char[comm_size];

	MPI_Alltoall(recvmark, 1, MPI_CHAR, sendmark, 1, MPI_CHAR, comm);

	for (int r = 0; r < comm_size; ++r)
		if (recvmark[r] || sendmark[r]) _nbmap.insert(std::pair<int, int>(r, _nnb++));

	delete[] recvmark;
	delete[] sendmark;

	std::map<int, int>* _recvmap = new std::map<int, int>[_nnb];

	for (int i = 0; i < n; ++i)
	{
		for (int j = _exter_rowptr[i]; j < _exter_rowptr[i + 1]; ++j)
		{
			int jfrom = _nbmap[_exter_colfrom[j]];
			_exter_colfrom[j] = jfrom;
			std::pair<std::map<int, int>::iterator, bool> ret = _recvmap[jfrom].insert(std::pair<int, int>(_exter_colind[j], _recvmap[jfrom].size()));
			_exter_colind[j] = ret.first->second;
		}
	}

	int* _nbrank = new int[_nnb];
	for (std::map<int, int>::iterator iter = _nbmap.begin(); iter != _nbmap.end(); ++iter)
		_nbrank[iter->second] = iter->first;

	int* _recvptr = new int[_nnb + 1];

	_recvptr[0] = 0;
	for (int r = 0; r < _nnb; ++r)
		_recvptr[r + 1] = _recvptr[r] + _recvmap[r].size();

	int* _recvind = new int[_recvptr[_nnb]];

	for (int r = 0; r < _nnb; ++r)
		for (std::map<int, int>::iterator iter = _recvmap[r].begin(); iter != _recvmap[r].end(); ++iter)
			_recvind[_recvptr[r] + iter->second] = iter->first;

	for (int j = 0; j < _exter_rowptr[n]; ++j)
		_exter_colind[j] += _recvptr[_exter_colfrom[j]];

	delete[] _recvmap;
	delete[] _exter_colfrom;

	A.Free();

	A.comm = comm;
	A.local.size[0] = n;
	A.local.size[1] = m;
	A.local.rowptr = _local_rowptr;
	A.local.colind = _local_colind;
	A.local.values = _local_values;

	A.exter.size[0] = n;
	A.exter.size[1] = _recvptr[_nnb];
	A.exter.rowptr = _exter_rowptr;
	A.exter.colind = _exter_colind;
	A.exter.values = _exter_values;

	A.nnb = _nnb;
	A.nbrank = _nbrank;

	A.recvptr = _recvptr;
	A.recvind = _recvind;

	locref.rowptr = _local_rowptr;
	locref.colind = _local_colind;
	locref.values = _local_values;

	extref.size[1] = _recvptr[_nnb];
	extref.rowptr = _exter_rowptr;
	extref.colind = _exter_colind;
	extref.values = _exter_values;

	if (recvind) delete[] recvind;
	if (recvfrom) delete[] recvfrom;

	recvind = new int[_recvptr[_nnb]];
	recvfrom = new int[_recvptr[_nnb]];

	for (int r = 0; r < _nnb; ++r)
	{
		for (int i = _recvptr[r]; i < _recvptr[r + 1]; ++i)
		{
			recvfrom[i] = _nbrank[r];
			recvind[i] = _recvind[i];
		}
	}
}

}