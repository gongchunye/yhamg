/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef ParComplexCSRMatrix_H
#define ParComplexCSRMatrix_H

#include "ParComplexOperator.hpp"
#include "ComplexCSRMatrix.hpp"
#include "ParCSRMatrix.hpp"

namespace YHAMG
{

struct ParComplexCSRMatrix : public ParComplexOperator
{
	ComplexCSRMatrix local;
	ComplexCSRMatrix exter;

	int nnb;
	int* nbrank;

	int* recvptr;
	int* recvind;

	int* sendptr;
	int* sendind;
	zomplex* sendbuf;
	
	ComplexVector recvx;

	ParComplexCSRMatrix(MPI_Comm comm = MPI_COMM_SELF);
	ParComplexCSRMatrix(MPI_Comm comm, int local_rows, int local_cols, int exter_cols, 
	int* local_rowptr, int* local_colind, zomplex* local_values, int local_ref, 
	int* exter_rowptr, int* exter_colind, zomplex* exter_values, int exter_ref,
	int nnb, int* nbrank, int* recvptr, int* recvind);
	ParComplexCSRMatrix(const ComplexCSRMatrix& A);
	ParComplexCSRMatrix(const ParCSRMatrix& A);
	ParComplexCSRMatrix(const ParComplexCSRMatrix& A);
	ParComplexCSRMatrix(ParComplexCSRMatrix&& A);
	~ParComplexCSRMatrix();
	ParComplexCSRMatrix& operator=(const ParComplexCSRMatrix& A);
	ParComplexCSRMatrix& operator=(ParComplexCSRMatrix&& A);
	
	void Free();
	void Refer(const ParComplexCSRMatrix& A);
	void ExchangeHalo(const ParComplexVector& x) const;
	void SetupHalo();
	int InSize() const;
	int OutSize() const;
	void Apply(const ParComplexVector& x, const ParComplexVector& y) const;
};

void ParComplexCSRDiag(const ParComplexCSRMatrix& A, const ParComplexVector& D);
void ParComplexCSREliminZeros(const ParComplexCSRMatrix& A);
void ParComplexCSRConj(const ParComplexCSRMatrix& A);
void ParComplexCSRScale(zomplex alpha, const ParComplexCSRMatrix& A);
void ParComplexCSRScaleRows(const ParComplexVector& x, const ParComplexCSRMatrix& A);
void ParComplexCSRScaleCols(const ParComplexVector& x, const ParComplexCSRMatrix& A);
void ParComplexCSRMatAdd(const ParComplexCSRMatrix& A, const ParComplexCSRMatrix& B, ParComplexCSRMatrix& C);
void ParComplexCSRMatMul(const ParComplexCSRMatrix& A, const ParComplexCSRMatrix& B, ParComplexCSRMatrix& C);
void ParComplexCSRMatVec(zomplex alpha, const ParComplexCSRMatrix& A, const ParComplexVector& x, zomplex beta, const ParComplexVector& y);
void ParComplexCSRTrans(const ParComplexCSRMatrix& A, ParComplexCSRMatrix& B);
void ParComplexCSRConjTrans(const ParComplexCSRMatrix& A, ParComplexCSRMatrix& B);

}

#endif