/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <cmath>
#include <iostream>
#include "ParComplexSolverCG.hpp"

namespace YHAMG
{

ParComplexSolverCG::ParComplexSolverCG(int max_iters, double tolerance, int print_stats)
	: MaxIters(max_iters),
	Tolerance(tolerance),
	PrintStats(print_stats)
{
}

#define CABS(x) zabs(x)

void ParComplexSolverCG::operator()(const ParComplexOperator& A, const ParComplexOperator& P, const ParComplexVector& b, const ParComplexVector& x, int& iter, double& relres) const
{
	MPI_Comm comm = A.comm;

	int comm_rank;
	MPI_Comm_rank(comm, &comm_rank);

	int n = A.OutSize();

	double normb, res;
	zomplex alpha, beta, rho, rho1;
	ParComplexVector r(comm), z(comm), p(comm), v(comm);

	r.Resize(n);
	z.Resize(n);
	p.Resize(n);
	v.Resize(n);

	if (PrintStats && comm_rank == 0)
	{
		std::cout << "Iter\tResidual\n";
		std::cout << "--------------------------------------------------\n";
	}

	iter = 0;

	A.Apply(x, r);
	ParComplexVecAXPBY(1.0, b, -1.0, r);

	res = sqrt(CABS(ParComplexVecConjDot(r, r)));
	normb = sqrt(CABS(ParComplexVecConjDot(b, b)));

	while (1)
	{
		if (PrintStats && comm_rank == 0)
			std::cout << iter << "\t" << res << "\n";

		if (res / normb <= Tolerance || iter == MaxIters) break;

		P.Apply(r, z);

		rho = ParComplexVecConjDot(r, z);

		if (iter == 0)
			p.Copy(z);
		else
		{
			beta = rho / rho1;
			ParComplexVecAXPBY(1.0, z, beta, p);
		}

		A.Apply(p, v);

		alpha = rho / ParComplexVecConjDot(v, p);
		rho1 = rho;

		x.AddScaled(alpha, p);
		r.AddScaled(-alpha, v);

		res = sqrt(CABS(ParComplexVecConjDot(r, r)));

		++iter;
	}

	relres = res / normb;

	if (PrintStats && comm_rank == 0)
	{
		std::cout << "--------------------------------------------------\n";
		std::cout << "Iterations: " << iter << "\n";
		std::cout << "Final Relative Residual: " << relres << "\n";
	}
}

}