/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <cmath>
#include <iostream>
#include "ParComplexSolverBCGS.hpp"

namespace YHAMG
{

ParComplexSolverBCGS::ParComplexSolverBCGS(int max_iters, double tolerance, int print_stats)
	: MaxIters(max_iters),
	Tolerance(tolerance),
	PrintStats(print_stats)
{
}

#define CABS(x) zabs(x)

void ParComplexSolverBCGS::operator()(const ParComplexOperator& A, const ParComplexOperator& P, const ParComplexVector& b, const ParComplexVector& x, int& iter, double& relres) const
{
	MPI_Comm comm = A.comm;
	
	int comm_rank;
	MPI_Comm_rank(comm, &comm_rank);

	int n = A.OutSize();

	double normb, res;
	zomplex alpha, beta, omega, rho, rho1;
	ParComplexVector r(comm), r0(comm), p(comm), q(comm), v(comm), s(comm), t(comm);

	r.Resize(n);
	r0.Resize(n);
	p.Resize(n);
	q.Resize(n);
	v.Resize(n);
	s.Resize(n);
	t.Resize(n);

	if (PrintStats && comm_rank == 0)
	{
		std::cout << "Iter\tResidual\n";
		std::cout << "--------------------------------------------------\n";
	}

	iter = 0;

	A.Apply(x, r);
	ParComplexVecAXPBY(1.0, b, -1.0, r);

	r0.Copy(r);
	rho = ParComplexVecConjDot(r, r);
	res = sqrt(CABS(rho));
	normb = sqrt(CABS(ParComplexVecConjDot(b, b)));

	while (1)
	{
		if (PrintStats && comm_rank == 0)
			std::cout << iter << "\t" << res << "\n";

		if (res / normb <= Tolerance || iter == MaxIters) break;

		if (iter == 0)
			p.Copy(r);
		else
		{
			beta = (alpha / omega) * (rho / rho1);
			ParComplexVecAXPBYPCZ(1.0, r, -beta * omega, v, beta, p);
		}

		P.Apply(p, q);
		A.Apply(q, v);

		alpha = rho / ParComplexVecConjDot(r0, v);

		r.AddScaled(-alpha, v);

		P.Apply(r, s);
		A.Apply(s, t);

		omega = ParComplexVecConjDot(t, r) / ParComplexVecConjDot(t, t);

		x.Add2Scaled(alpha, q, omega, s);
		
		r.AddScaled(-omega, t);

		rho1 = rho;
		rho = ParComplexVecConjDot(r0, r);
		res = sqrt(CABS(ParComplexVecConjDot(r, r)));
		
		++iter;
	}

	relres = res / normb;

	if (PrintStats && comm_rank == 0)
	{
		std::cout << "--------------------------------------------------\n";
		std::cout << "Iterations: " << iter << "\n";
		std::cout << "Final Relative Residual: " << relres << "\n";
	}
}

}