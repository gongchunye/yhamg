/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef ParComplexSolver_H
#define ParComplexSolver_H

#include "ParComplexOperator.hpp"
#include "ParComplexVector.hpp"

namespace YHAMG
{

class ParComplexSolver
{
public:
	virtual ~ParComplexSolver();
	virtual void operator()(const ParComplexOperator& A, const ParComplexVector& b, const ParComplexVector& x, int& iter, double& relres) const;
	virtual void operator()(const ParComplexOperator& A, const ParComplexOperator& P, const ParComplexVector& b, const ParComplexVector& x, int& iter, double& relres) const = 0;
};

}

#endif
