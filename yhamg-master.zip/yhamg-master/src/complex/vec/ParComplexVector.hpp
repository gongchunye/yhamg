/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef ParComplexVector_H
#define ParComplexVector_H

#include <mpi.h>
#include "ComplexVector.hpp"
#include "ParVector.hpp"

namespace YHAMG
{

struct ParComplexVector
{
	MPI_Comm comm;
	ComplexVector local;

	ParComplexVector(MPI_Comm comm = MPI_COMM_SELF);
	ParComplexVector(MPI_Comm comm, int local_size);
	ParComplexVector(MPI_Comm comm, int local_size, zomplex* local_values, int local_ref);
	ParComplexVector(const ComplexVector& x);
	ParComplexVector(const ParVector& x);
	ParComplexVector(const ParComplexVector& x);
	ParComplexVector(ParComplexVector&& x);
	ParComplexVector& operator=(zomplex a);
	ParComplexVector& operator=(const ParComplexVector& x);
	ParComplexVector& operator=(ParComplexVector&& x);
	zomplex& operator[](int i) const;

	void Free();
	void Resize(int n);
	void Refer(const ParComplexVector& x);
	void Fill(zomplex a) const;
	void FillRandom() const;
	void Copy(const ParComplexVector& x) const;
	void Scale(zomplex a) const;
	void AddScaled(zomplex a, const ParComplexVector& x) const;
	void Add2Scaled(zomplex a, const ParComplexVector& x, zomplex b, const ParComplexVector& y) const;
};

void ParComplexVecAXPBY(zomplex alpha, const ParComplexVector& x, zomplex beta, const ParComplexVector& y);
void ParComplexVecAXPBYPCZ(zomplex alpha, const ParComplexVector& x, zomplex beta, const ParComplexVector& y, zomplex gamma, const ParComplexVector& z);
zomplex ParComplexVecConjDot(const ParComplexVector& x, const ParComplexVector& y);
zomplex ParComplexVecDot(const ParComplexVector& x, const ParComplexVector& y);
void ParComplexVecElemMul(const ParComplexVector& x, const ParComplexVector& y);
void ParComplexVecElemMulConj(const ParComplexVector& x, const ParComplexVector& y);
void ParComplexVecConj(const ParComplexVector& x);
void ParComplexVecRecip(const ParComplexVector& x);

}

#endif