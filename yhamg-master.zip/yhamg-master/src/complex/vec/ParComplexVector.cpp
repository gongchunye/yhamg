/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "ParComplexVector.hpp"

namespace YHAMG
{

ParComplexVector::ParComplexVector(MPI_Comm _comm)
	: comm(_comm)
{
}

ParComplexVector::ParComplexVector(MPI_Comm _comm, int local_size)
	: comm(_comm),
	local(local_size)
{
}

ParComplexVector::ParComplexVector(MPI_Comm _comm, int local_size, zomplex* local_values, int local_ref)
	: comm(_comm),
	local(local_size, local_values, local_ref)
{
}

ParComplexVector::ParComplexVector(const ComplexVector& x)
	: comm(MPI_COMM_SELF),
	local(x)
{
}

ParComplexVector::ParComplexVector(const ParVector& x)
	: comm(x.comm),
	local(x.local)
{
}

ParComplexVector::ParComplexVector(const ParComplexVector& x)
	: comm(x.comm),
	local(x.local)
{
}

ParComplexVector::ParComplexVector(ParComplexVector&& x)
	: comm(x.comm),
	local(x.local.size, x.local.values, x.local.ref)
{
	x.local.ref = 1;
}

ParComplexVector& ParComplexVector::operator=(zomplex a)
{
	local = a;
	return *this;
}

ParComplexVector& ParComplexVector::operator=(const ParComplexVector& x)
{
	comm = x.comm;
	local = x.local;
	return *this;
}

ParComplexVector& ParComplexVector::operator=(ParComplexVector&& x)
{
	Free();
	comm = x.comm;
	local.ref = x.local.ref;
	local.size = x.local.size;
	local.values = x.local.values;
	x.local.ref = 1;
	return *this;
}

zomplex& ParComplexVector::operator[](int i) const
{
	return local.values[i];
}

void ParComplexVector::Free()
{
	local.Free();
}

void ParComplexVector::Resize(int n)
{
	local.Resize(n);
}

void ParComplexVector::Refer(const ParComplexVector& x)
{
	comm = x.comm;
	local.Refer(x.local);
}

void ParComplexVector::Fill(zomplex a) const
{
	local.Fill(a);
}

void ParComplexVector::FillRandom() const
{
	local.FillRandom();
}

void ParComplexVector::Copy(const ParComplexVector& x) const
{
	local.Copy(x.local);
}

void ParComplexVector::Scale(zomplex a) const
{
	local.Scale(a);
}

void ParComplexVector::AddScaled(zomplex a, const ParComplexVector& x) const
{
	local.AddScaled(a, x.local);
}

void ParComplexVector::Add2Scaled(zomplex a, const ParComplexVector& x, zomplex b, const ParComplexVector& y) const
{
	local.Add2Scaled(a, x.local, b, y.local);
}

void ParComplexVecAXPBY(zomplex alpha, const ParComplexVector& x, zomplex beta, const ParComplexVector& y)
{
	ComplexVecAXPBY(alpha, x.local, beta, y.local);
}

void ParComplexVecAXPBYPCZ(zomplex alpha, const ParComplexVector& x, zomplex beta, const ParComplexVector& y, zomplex gamma, const ParComplexVector& z)
{
	ComplexVecAXPBYPCZ(alpha, x.local, beta, y.local, gamma, z.local);
}

zomplex ParComplexVecConjDot(const ParComplexVector& x, const ParComplexVector& y)
{
	double buf[2];
	zomplex temp = ComplexVecConjDot(x.local, y.local);
	buf[0] = zreal(temp);
	buf[1] = zimag(temp);
	MPI_Allreduce(MPI_IN_PLACE, buf, 2, MPI_DOUBLE, MPI_SUM, x.comm);
	return zomplex(buf[0], buf[1]);
}

zomplex ParComplexVecDot(const ParComplexVector& x, const ParComplexVector& y)
{
	double buf[2];
	zomplex temp = ComplexVecDot(x.local, y.local);
	buf[0] = zreal(temp);
	buf[1] = zimag(temp);
	MPI_Allreduce(MPI_IN_PLACE, buf, 2, MPI_DOUBLE, MPI_SUM, x.comm);
	return zomplex(buf[0], buf[1]);
}

void ParComplexVecElemMul(const ParComplexVector& x, const ParComplexVector& y)
{
	ComplexVecElemMul(x.local, y.local);
}

void ParComplexVecElemMulConj(const ParComplexVector& x, const ParComplexVector& y)
{
	ComplexVecElemMulConj(x.local, y.local);
}

void ParComplexVecConj(const ParComplexVector& x)
{
	ComplexVecConj(x.local);
}

void ParComplexVecRecip(const ParComplexVector& x)
{
	ComplexVecRecip(x.local);
}

}