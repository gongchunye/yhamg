/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <stdio.h>
#include "random.hpp"
#include "blas.hpp"
#include "ComplexVector.hpp"

namespace YHAMG
{

ComplexVector::ComplexVector()
	: ref(0),
	size(0),
	values(0)
{
}

ComplexVector::ComplexVector(int _n)
	: ref(0),
	size(_n),
	values(new zomplex[_n])
{
}

ComplexVector::ComplexVector(int _n, zomplex* _values, int _ref)
	: ref(_ref),
	size(_n),
	values(_values)
{
}

ComplexVector::ComplexVector(const Vector& x)
	: ref(0),
	size(x.size),
	values(new zomplex[x.size])
{
	double* xv = x.values;
	for (int i = 0; i < size; ++i)
		values[i] = xv[i];
}

ComplexVector::ComplexVector(const ComplexVector& x)
	: ref(0),
	size(x.size),
	values(new zomplex[x.size])
{
	zomplex* xv = x.values;
	blas_zcopy(size, xv, values);
}

ComplexVector::ComplexVector(ComplexVector&& x)
	: ref(x.ref),
	size(x.size),
	values(x.values)
{
	x.ref = 1;
}

ComplexVector::~ComplexVector()
{
	if (!ref && values)
		delete[] values;
}

ComplexVector& ComplexVector::operator=(zomplex a)
{
	blas_zfill(size, a, values);
	return *this;
}

ComplexVector& ComplexVector::operator=(const ComplexVector& x)
{
	Resize(x.size);
	zomplex* xv = x.values;
	blas_zcopy(size, xv, values);
	return *this;
}

ComplexVector& ComplexVector::operator=(ComplexVector&& x)
{
	if (!ref && values)
		delete[] values;
	ref = x.ref;
	size = x.size;
	values = x.values;
	x.ref = 1;
	return *this;
}

zomplex& ComplexVector::operator[](int i) const
{
	return values[i];
}

void ComplexVector::Free()
{
	if (!ref && values)
		delete[] values;
	size = 0;
	values = 0;
	ref = 0;
}

void ComplexVector::Resize(int n)
{
	if (!ref && values)
		delete[] values;
	size = n;
	values = new zomplex[n];
	ref = 0;
}

void ComplexVector::Fill(zomplex a) const
{
	blas_zfill(size, a, values);
}

void ComplexVector::FillRandom() const
{
	for (int i = 0; i < size; ++i)
		values[i] = (double)(random() & 4294967295U) / 4294967295U;
}

void ComplexVector::Copy(const ComplexVector& x) const
{
	zomplex* xv = x.values;
	blas_zcopy(size, xv, values);
}

void ComplexVector::Scale(zomplex a) const
{
	blas_zscal(size, a, values);
}

void ComplexVector::AddScaled(zomplex a, const ComplexVector& x) const
{
	zomplex* xv = x.values;
	blas_zaxpy(size, a, xv, values);
}

void ComplexVector::Add2Scaled(zomplex a, const ComplexVector& x, zomplex b, const ComplexVector& y) const
{
	zomplex* xv = x.values;
	zomplex* yv = y.values;
	blas_zaxpbypz(size, a, xv, b, yv, values);
}

void ComplexVector::Refer(const ComplexVector& x)
{
	if (!ref && values)
		delete[] values;
	size = x.size;
	values = x.values;
	ref = 1;
}

void ComplexVecRead(const char* filename, ComplexVector& x)
{
	FILE* f = fopen(filename, "r");

	int n;

	fscanf(f, "%d\n", &n);

	zomplex* xv = new zomplex[n];

	for (int i = 0; i < n; ++i)
	{
		double re, im;
		fscanf(f, "%lg %lg\n", &re, &im);
		xv[i] = zomplex(re, im);
	}

	fclose(f);

	x.Free();
	x.size = n;
	x.values = xv;
}

void ComplexVecWrite(const char* filename, const ComplexVector& x)
{
	int n = x.size;
	zomplex* xv = x.values;

	FILE* f = fopen(filename, "w");

	fprintf(f, "%d\n", n);

	for (int i = 0; i < n; ++i)
		fprintf(f, "%20.16g %20.16g\n", zreal(xv[i]), zimag(xv[i]));

	fclose(f);
}

void ComplexVecAXPBY(zomplex alpha, const ComplexVector& x, zomplex beta, const ComplexVector& y)
{
	int n = y.size;
	zomplex* xv = x.values;
	zomplex* yv = y.values;
	blas_zaxpby(n, alpha, xv, beta, yv);
}

void ComplexVecAXPBYPCZ(zomplex alpha, const ComplexVector& x, zomplex beta, const ComplexVector& y, zomplex gamma, const ComplexVector& z)
{
	int n = z.size;
	zomplex* xv = x.values;
	zomplex* yv = y.values;
	zomplex* zv = z.values;
	blas_zaxpbypcz(n, alpha, xv, beta, yv, gamma, zv);
}

zomplex ComplexVecConjDot(const ComplexVector& x, const ComplexVector& y)
{
	int n = x.size;
	zomplex* xv = x.values;
	zomplex* yv = y.values;

	return blas_zdotc(n, xv, yv);
}

zomplex ComplexVecDot(const ComplexVector& x, const ComplexVector& y)
{
	int n = x.size;
	zomplex* xv = x.values;
	zomplex* yv = y.values;

	return blas_zdotu(n, xv, yv);
}

void ComplexVecElemMul(const ComplexVector& x, const ComplexVector& y)
{
	int n = x.size;
	zomplex* xv = x.values;
	zomplex* yv = y.values;
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
	for (int i = 0; i < n; ++i)
		yv[i] *= xv[i];
}

void ComplexVecElemMulConj(const ComplexVector& x, const ComplexVector& y)
{
	int n = x.size;
	zomplex* xv = x.values;
	zomplex* yv = y.values;
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
	for (int i = 0; i < n; ++i)
		yv[i] *= zconj(xv[i]);
}

void ComplexVecConj(const ComplexVector& x)
{
	int n = x.size;
	zomplex* xv = x.values;
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
	for (int i = 0; i < n; ++i)
		xv[i] = zconj(xv[i]);
}

void ComplexVecRecip(const ComplexVector& x)
{
	int n = x.size;
	zomplex* xv = x.values;
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
	for (int i = 0; i < n; ++i)
		xv[i] = zomplex(1.0) / xv[i];
}

}