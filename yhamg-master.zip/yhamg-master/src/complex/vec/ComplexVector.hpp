/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef ComplexVector_H
#define ComplexVector_H

#include "complex.hpp"
#include "Vector.hpp"

namespace YHAMG
{

struct ComplexVector
{
	int ref;
	int size;
	zomplex* values;

	ComplexVector();
	ComplexVector(int n);
	ComplexVector(int n, zomplex* values, int ref);
	ComplexVector(const Vector& x);
	ComplexVector(const ComplexVector& x);
	ComplexVector(ComplexVector&& x); 
	~ComplexVector();
	ComplexVector& operator=(zomplex a);
	ComplexVector& operator=(const ComplexVector& x);
	ComplexVector& operator=(ComplexVector&& x);
	zomplex& operator[](int i) const;

	void Free();
	void Resize(int n);
	void Fill(zomplex a) const;
	void FillRandom() const;
	void Copy(const ComplexVector& x) const;
	void Scale(zomplex a) const;
	void AddScaled(zomplex a, const ComplexVector& x) const;
	void Add2Scaled(zomplex a, const ComplexVector& x, zomplex b, const ComplexVector& y) const;
	void Refer(const ComplexVector& x);
};

void ComplexVecRead(const char* filename, ComplexVector& x);
void ComplexVecWrite(const char* filename, const ComplexVector& x);
void ComplexVecAXPBY(zomplex alpha, const ComplexVector& x, zomplex beta, const ComplexVector& y);
void ComplexVecAXPBYPCZ(zomplex alpha, const ComplexVector& x, zomplex beta, const ComplexVector& y, zomplex gamma, const ComplexVector& z);
zomplex ComplexVecConjDot(const ComplexVector& x, const ComplexVector& y);
zomplex ComplexVecDot(const ComplexVector& x, const ComplexVector& y);
void ComplexVecElemMul(const ComplexVector& x, const ComplexVector& y);
void ComplexVecElemMulConj(const ComplexVector& x, const ComplexVector& y);
void ComplexVecConj(const ComplexVector& x);
void ComplexVecRecip(const ComplexVector& x);

}

#endif