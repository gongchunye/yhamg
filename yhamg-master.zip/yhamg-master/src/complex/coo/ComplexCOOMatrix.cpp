/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <stdio.h>
#include "ComplexCOOMatrix.hpp"

namespace YHAMG
{

ComplexCOOMatrix::ComplexCOOMatrix()
	: ref(0),
	size{0, 0},
	nnz(0),
	rowind(0),
	colind(0),
	values(0)
{
}

ComplexCOOMatrix::ComplexCOOMatrix(int _n, int _m, int _nnz, int* _rowind, int* _colind, zomplex* _values, int _ref)
	: ref(_ref),
	size{_n, _m},
	nnz(_nnz),
	rowind(_rowind),
	colind(_colind),
	values(_values)
{
}

ComplexCOOMatrix::ComplexCOOMatrix(const COOMatrix& A)
	: ref(0),
	size{A.size[0], A.size[1]},
	nnz(A.nnz), 
	rowind(new int[A.nnz]),
	colind(new int[A.nnz]),
	values(new zomplex[A.nnz])
{
	int* Ai = A.rowind;
	int* Aj = A.colind;
	double* Av = A.values;

	for (int j = 0; j < nnz; ++j)
	{
		rowind[j] = Ai[j];
		colind[j] = Aj[j];
		values[j] = Av[j];
	}
}

ComplexCOOMatrix::ComplexCOOMatrix(const ComplexCOOMatrix& A)
	: ref(0),
	size{A.size[0], A.size[1]},
	nnz(A.nnz), 
	rowind(new int[A.nnz]),
	colind(new int[A.nnz]),
	values(new zomplex[A.nnz])
{
	int* Ai = A.rowind;
	int* Aj = A.colind;
	zomplex* Av = A.values;

	for (int j = 0; j < nnz; ++j)
	{
		rowind[j] = Ai[j];
		colind[j] = Aj[j];
		values[j] = Av[j];
	}
}

ComplexCOOMatrix::ComplexCOOMatrix(ComplexCOOMatrix&& A)
	: ref(A.ref),
	size{A.size[0], A.size[1]},
	nnz(A.nnz), 
	rowind(A.rowind),
	colind(A.colind),
	values(A.values)
{
	A.ref = 1;
}

ComplexCOOMatrix::~ComplexCOOMatrix()
{
	if (!ref)
	{
		if (rowind) delete[] rowind;
		if (colind) delete[] colind;
		if (values) delete[] values;
	}
}

ComplexCOOMatrix& ComplexCOOMatrix::operator=(const ComplexCOOMatrix& A)
{
	Free();

	int* Ai = A.rowind;
	int* Aj = A.colind;
	zomplex* Av = A.values;

	size[0] = A.size[0];
	size[1] = A.size[1];
	nnz = A.nnz;

	rowind = new int[nnz];
	colind = new int[nnz];
	values = new zomplex[nnz];

	for (int j = 0; j < nnz; ++j)
	{
		rowind[j] = Ai[j];
		colind[j] = Aj[j];
		values[j] = Av[j];
	}

	return *this;
}

ComplexCOOMatrix& ComplexCOOMatrix::operator=(ComplexCOOMatrix&& A)
{
	Free();

	ref = A.ref;
	size[0] = A.size[0];
	size[1] = A.size[1];
	nnz = A.nnz;
	rowind = A.rowind;
	colind = A.colind;
	values = A.values;

	A.ref = 1;

	return *this;
}


void ComplexCOOMatrix::Free()
{
	if (!ref)
	{
		if (rowind) delete[] rowind;
		if (colind) delete[] colind;
		if (values) delete[] values;
	}
	size[0] = 0;
	size[1] = 0;
	nnz = 0;
	rowind = 0;
	colind = 0;
	values = 0;
	ref = 0;
}

void ComplexCOOMatrix::Refer(const ComplexCOOMatrix& A)
{
	if (!ref)
	{
		if (rowind) delete[] rowind;
		if (colind) delete[] colind;
		if (values) delete[] values;
	}
	size[0] = A.size[0];
	size[1] = A.size[1];
	nnz = A.nnz;
	rowind = A.rowind;
	colind = A.colind;
	values = A.values;
	ref = 1;
}

int ComplexCOOMatrix::InSize() const
{
	return size[1];
}

int ComplexCOOMatrix::OutSize() const
{
	return size[0];
}

void ComplexCOOMatrix::Apply(const ComplexVector& x, const ComplexVector& y) const
{
	zomplex* xv = x.values;
	zomplex* yv = y.values;

	for (int i = 0; i < size[0]; ++i)
		yv[i] = 0.0;

	for (int j = 0; j < nnz; ++j)
		yv[rowind[j]] += values[j] * xv[colind[j]];
}

void ComplexCOORead(const char* filename, ComplexCOOMatrix& A)
{
	FILE* f = fopen(filename, "r");

	int n, m, nz;

	fscanf(f, "%d %d %d\n", &n, &m, &nz);

	int* Ai = new int[nz];
	int* Aj = new int[nz];
	zomplex* Av = new zomplex[nz];

	for (int j = 0; j < nz; ++j)
	{
		double re, im;
		fscanf(f, "%d %d %lg %lg\n", &Ai[j], &Aj[j], &re, &im);
		Av[j] = zomplex(re, im);
		--Ai[j];
		--Aj[j];
	}

	fclose(f);

	A.Free();
	A.size[0] = n;
	A.size[1] = m;
	A.nnz = nz;
	A.rowind = Ai;
	A.colind = Aj;
	A.values = Av;
}

void ComplexCOOWrite(const char* filename, const ComplexCOOMatrix& A)
{
	int n = A.size[0];
	int m = A.size[1];
	int nz = A.nnz;

	int* Ai = A.rowind;
	int* Aj = A.colind;
	zomplex* Av = A.values;

	FILE* f = fopen(filename, "w");

	fprintf(f, "%d %d %d\n", n, m, nz);

	for (int i = 0; i < nz; ++i)
		fprintf(f, "%d %d %20.16g %20.16g\n", Ai[i] + 1, Aj[i] + 1, zreal(Av[i]), zimag(Av[i]));

	fclose(f);
}

}
