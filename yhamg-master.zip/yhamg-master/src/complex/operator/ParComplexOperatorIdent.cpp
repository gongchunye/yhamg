/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "ParComplexOperatorIdent.hpp"

namespace YHAMG
{

ParComplexOperatorIdent::ParComplexOperatorIdent(MPI_Comm comm, int n)
	: ParComplexOperator(comm),
	size{n, n}
{
}

ParComplexOperatorIdent::ParComplexOperatorIdent(MPI_Comm comm, int n, int m)
	: ParComplexOperator(comm),
	size{n, m}
{
}

int ParComplexOperatorIdent::InSize() const
{
	return size[1];
}

int ParComplexOperatorIdent::OutSize() const
{
	return size[0];
}

void ParComplexOperatorIdent::Apply(const ParComplexVector& x, const ParComplexVector& y) const
{
	zomplex* xv = x.local.values;
	zomplex* yv = y.local.values;
	if (size[0] > size[1])
	{
		for (int i = 0; i < size[1]; ++i)
			yv[i] = xv[i];
		for (int i = size[1]; i < size[0]; ++i)
			yv[i] = 0.0;
	}
	else
	{
		for (int i = 0; i < size[0]; ++i)
			yv[i] = xv[i];
	}
}

}