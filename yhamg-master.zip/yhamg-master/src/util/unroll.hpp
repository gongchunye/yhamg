/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef UNROLL_H
#define UNROLL_H

#define UNROLL_REPEAT_1(X) X(0)
#define UNROLL_REPEAT_2(X) UNROLL_REPEAT_1(X) X(1)
#define UNROLL_REPEAT_3(X) UNROLL_REPEAT_2(X) X(2)
#define UNROLL_REPEAT_4(X) UNROLL_REPEAT_3(X) X(3)
#define UNROLL_REPEAT_5(X) UNROLL_REPEAT_4(X) X(4)
#define UNROLL_REPEAT_6(X) UNROLL_REPEAT_5(X) X(5)
#define UNROLL_REPEAT_7(X) UNROLL_REPEAT_6(X) X(6)
#define UNROLL_REPEAT_8(X) UNROLL_REPEAT_7(X) X(7)

#define UNROLL_REPEAT_I_0(X, ...)
#define UNROLL_REPEAT_I_1(X, ...) X(0, __VA_ARGS__)
#define UNROLL_REPEAT_I_2(X, ...) UNROLL_REPEAT_I_1(X, __VA_ARGS__) X(1, __VA_ARGS__)
#define UNROLL_REPEAT_I_3(X, ...) UNROLL_REPEAT_I_2(X, __VA_ARGS__) X(2, __VA_ARGS__)
#define UNROLL_REPEAT_I_4(X, ...) UNROLL_REPEAT_I_3(X, __VA_ARGS__) X(3, __VA_ARGS__)
#define UNROLL_REPEAT_I_5(X, ...) UNROLL_REPEAT_I_4(X, __VA_ARGS__) X(4, __VA_ARGS__)
#define UNROLL_REPEAT_I_6(X, ...) UNROLL_REPEAT_I_5(X, __VA_ARGS__) X(5, __VA_ARGS__)
#define UNROLL_REPEAT_I_7(X, ...) UNROLL_REPEAT_I_6(X, __VA_ARGS__) X(6, __VA_ARGS__)
#define UNROLL_REPEAT_I_8(X, ...) UNROLL_REPEAT_I_7(X, __VA_ARGS__) X(7, __VA_ARGS__)

#define UNROLL_REPEAT_J_0(X, ...)
#define UNROLL_REPEAT_J_1(X, ...) X(0, __VA_ARGS__)
#define UNROLL_REPEAT_J_2(X, ...) UNROLL_REPEAT_J_1(X, __VA_ARGS__) X(1, __VA_ARGS__)
#define UNROLL_REPEAT_J_3(X, ...) UNROLL_REPEAT_J_2(X, __VA_ARGS__) X(2, __VA_ARGS__)
#define UNROLL_REPEAT_J_4(X, ...) UNROLL_REPEAT_J_3(X, __VA_ARGS__) X(3, __VA_ARGS__)
#define UNROLL_REPEAT_J_5(X, ...) UNROLL_REPEAT_J_4(X, __VA_ARGS__) X(4, __VA_ARGS__)
#define UNROLL_REPEAT_J_6(X, ...) UNROLL_REPEAT_J_5(X, __VA_ARGS__) X(5, __VA_ARGS__)
#define UNROLL_REPEAT_J_7(X, ...) UNROLL_REPEAT_J_6(X, __VA_ARGS__) X(6, __VA_ARGS__)
#define UNROLL_REPEAT_J_8(X, ...) UNROLL_REPEAT_J_7(X, __VA_ARGS__) X(7, __VA_ARGS__)

#define UNROLL_REPEAT_K_0(X, ...)
#define UNROLL_REPEAT_K_1(X, ...) X(0, __VA_ARGS__)
#define UNROLL_REPEAT_K_2(X, ...) UNROLL_REPEAT_K_1(X, __VA_ARGS__) X(1, __VA_ARGS__)
#define UNROLL_REPEAT_K_3(X, ...) UNROLL_REPEAT_K_2(X, __VA_ARGS__) X(2, __VA_ARGS__)
#define UNROLL_REPEAT_K_4(X, ...) UNROLL_REPEAT_K_3(X, __VA_ARGS__) X(3, __VA_ARGS__)
#define UNROLL_REPEAT_K_5(X, ...) UNROLL_REPEAT_K_4(X, __VA_ARGS__) X(4, __VA_ARGS__)
#define UNROLL_REPEAT_K_6(X, ...) UNROLL_REPEAT_K_5(X, __VA_ARGS__) X(5, __VA_ARGS__)
#define UNROLL_REPEAT_K_7(X, ...) UNROLL_REPEAT_K_6(X, __VA_ARGS__) X(6, __VA_ARGS__)
#define UNROLL_REPEAT_K_8(X, ...) UNROLL_REPEAT_K_7(X, __VA_ARGS__) X(7, __VA_ARGS__)

#define UNROLL_REPEAT_R_1(X, ...) X(0, __VA_ARGS__)
#define UNROLL_REPEAT_R_2(X, ...) X(1, __VA_ARGS__) UNROLL_REPEAT_R_1(X, __VA_ARGS__)
#define UNROLL_REPEAT_R_3(X, ...) X(2, __VA_ARGS__) UNROLL_REPEAT_R_2(X, __VA_ARGS__)
#define UNROLL_REPEAT_R_4(X, ...) X(3, __VA_ARGS__) UNROLL_REPEAT_R_3(X, __VA_ARGS__)
#define UNROLL_REPEAT_R_5(X, ...) X(4, __VA_ARGS__) UNROLL_REPEAT_R_4(X, __VA_ARGS__)
#define UNROLL_REPEAT_R_6(X, ...) X(5, __VA_ARGS__) UNROLL_REPEAT_R_5(X, __VA_ARGS__)
#define UNROLL_REPEAT_R_7(X, ...) X(6, __VA_ARGS__) UNROLL_REPEAT_R_6(X, __VA_ARGS__)
#define UNROLL_REPEAT_R_8(X, ...) X(7, __VA_ARGS__) UNROLL_REPEAT_R_7(X, __VA_ARGS__)

#define UNROLL_EXPAND(...) __VA_ARGS__

#define UNROLL_REPEAT_(N, X) UNROLL_EXPAND(UNROLL_REPEAT_ ## N)(X)
#define UNROLL_REPEAT(N, X) UNROLL_REPEAT_(N, X)
#define UNROLL_REPEAT_I_(N, ...) UNROLL_EXPAND(UNROLL_REPEAT_I_ ## N)(__VA_ARGS__)
#define UNROLL_REPEAT_I(N, ...) UNROLL_REPEAT_I_(N, __VA_ARGS__)
#define UNROLL_REPEAT_J_(N, ...) UNROLL_EXPAND(UNROLL_REPEAT_J_ ## N)(__VA_ARGS__)
#define UNROLL_REPEAT_J(N, ...) UNROLL_REPEAT_J_(N, __VA_ARGS__)
#define UNROLL_REPEAT_K_(N, ...) UNROLL_EXPAND(UNROLL_REPEAT_K_ ## N)(__VA_ARGS__)
#define UNROLL_REPEAT_K(N, ...) UNROLL_REPEAT_K_(N, __VA_ARGS__)
#define UNROLL_REPEAT_R_(N, ...) UNROLL_EXPAND(UNROLL_REPEAT_R_ ## N)(__VA_ARGS__)
#define UNROLL_REPEAT_R(N, ...) UNROLL_REPEAT_R_(N, __VA_ARGS__)

#endif