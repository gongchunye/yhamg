/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <cmath>
#include "unroll.hpp"
#include "blas.hpp"

#ifdef YHAMG_USE_OPENMP
#include <omp.h>
#endif

namespace YHAMG
{

#define BLAS_UNROLL 4

#define BLAS_1V_IT(I, X0, Op0) (X0 [I]) Op0
#define BLAS_2V_IT(I, X0, Op0, X1, Op1) (X0 [I]) Op0 (X1 [I]) Op1
#define BLAS_3V_IT(I, X0, Op0, X1, Op1, X2, Op2) (X0 [I]) Op0 (X1 [I]) Op1 (X2 [I]) Op2
#define BLAS_4V_IT(I, X0, Op0, X1, Op1, X2, Op2, X3, Op3) (X0 [I]) Op0 (X1 [I]) Op1 (X2 [I]) Op2 (X3 [I]) Op3

#ifdef BLAS_UNROLL

#define BLAS_UNROLL_IT(K, X, ...) X(blas_index + K, __VA_ARGS__);

#define BLAS_1V(...) \
	for (int blas_index = BLAS_BIGEN; blas_index <= BLAS_END - BLAS_UNROLL; blas_index += BLAS_UNROLL) \
	{ UNROLL_REPEAT_I(BLAS_UNROLL, BLAS_UNROLL_IT, BLAS_1V_IT, __VA_ARGS__) } \
	for (int blas_index = BLAS_BIGEN + (BLAS_END - BLAS_BIGEN) / BLAS_UNROLL * BLAS_UNROLL; blas_index < BLAS_END; ++blas_index) \
	{ BLAS_1V_IT(blas_index, __VA_ARGS__); }

#define BLAS_2V(...) \
	for (int blas_index = BLAS_BIGEN; blas_index <= BLAS_END - BLAS_UNROLL; blas_index += BLAS_UNROLL) \
	{ UNROLL_REPEAT_I(BLAS_UNROLL, BLAS_UNROLL_IT, BLAS_2V_IT, __VA_ARGS__) } \
	for (int blas_index = BLAS_BIGEN + (BLAS_END - BLAS_BIGEN) / BLAS_UNROLL * BLAS_UNROLL; blas_index < BLAS_END; ++blas_index) \
	{ BLAS_2V_IT(blas_index, __VA_ARGS__); }

#define BLAS_3V(...) \
	for (int blas_index = BLAS_BIGEN; blas_index <= BLAS_END - BLAS_UNROLL; blas_index += BLAS_UNROLL) \
	{ UNROLL_REPEAT_I(BLAS_UNROLL, BLAS_UNROLL_IT, BLAS_3V_IT, __VA_ARGS__) } \
	for (int blas_index = BLAS_BIGEN + (BLAS_END - BLAS_BIGEN) / BLAS_UNROLL * BLAS_UNROLL; blas_index < BLAS_END; ++blas_index) \
	{ BLAS_3V_IT(blas_index, __VA_ARGS__); }

#define BLAS_4V(...) \
	for (int blas_index = BLAS_BIGEN; blas_index <= BLAS_END - BLAS_UNROLL; blas_index += BLAS_UNROLL) \
	{ UNROLL_REPEAT_I(BLAS_UNROLL, BLAS_UNROLL_IT, BLAS_4V_IT, __VA_ARGS__) } \
	for (int blas_index = BLAS_BIGEN + (BLAS_END - BLAS_BIGEN) / BLAS_UNROLL * BLAS_UNROLL; blas_index < BLAS_END; ++blas_index) \
	{ BLAS_4V_IT(blas_index, __VA_ARGS__); }

#else

#define BLAS_1V(...) \
	for (int blas_index = BLAS_BIGEN; blas_index < BLAS_END; ++blas_index) \
	{ BLAS_1V_IT(blas_index, __VA_ARGS__); }

#define BLAS_2V(...) \
	for (int blas_index = BLAS_BIGEN; blas_index < BLAS_END; ++blas_index) \
	{ BLAS_2V_IT(blas_index, __VA_ARGS__); }

#define BLAS_3V(...) \
	for (int blas_index = BLAS_BIGEN; blas_index < BLAS_END; ++blas_index) \
	{ BLAS_3V_IT(blas_index, __VA_ARGS__); }

#define BLAS_4V(...) \
	for (int blas_index = BLAS_BIGEN; blas_index < BLAS_END; ++blas_index) \
	{ BLAS_4V_IT(blas_index, __VA_ARGS__); }

#endif

#define BLAS_BIGEN 0
#define BLAS_END   n

void blas_sfill(int n, float a, float* x)
{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
	BLAS_1V(x, = a)
}

void blas_dfill(int n, double a, double* x)
{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
	BLAS_1V(x, = a)
}

void blas_cfill(int n, complex a, complex* x)
{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
	BLAS_1V(x, = a)
}

void blas_zfill(int n, zomplex a, zomplex* x)
{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
	BLAS_1V(x, = a)
}

void blas_sscal(int n, float a, float* x)
{
	if (a == 0.0)
		blas_sfill(n, 0.0, x);
	else if (a == -1.0)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		BLAS_2V(x, = -, x, )
	}
	else if (a != 1)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		BLAS_1V(x, *= a)
	}
}

void blas_dscal(int n, double a, double* x)
{
	if (a == 0.0)
		blas_dfill(n, 0.0, x);
	else if (a == -1.0)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		BLAS_2V(x, = -, x, )
	}
	else if (a != 1)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		BLAS_1V(x, *= a)
	}
}

void blas_cscal(int n, complex a, complex* x)
{
	if (a == 0.0)
		blas_cfill(n, 0.0, x);
	else if (a == 1.0)
		return;
	else if (a == -1.0)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		BLAS_2V(x, = -, x, )
	}
	else if (cimag(a) == 0.0)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		BLAS_1V(x, *= creal(a))
	}
	else
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		BLAS_1V(x, *= a)
	}
}

void blas_zscal(int n, zomplex a, zomplex* x)
{
	if (a == 0.0)
		blas_zfill(n, 0.0, x);
	else if (a == 1.0)
		return;
	else if (a == -1.0)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		BLAS_2V(x, = -, x, )
	}
	else if (zimag(a) == 0.0)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		BLAS_1V(x, *= zreal(a))
	}
	else
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		BLAS_1V(x, *= a)
	}
}

void blas_scopy(int n, const float* restrict x, float* restrict y)
{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
	BLAS_2V(y, =, x, )
}

void blas_dcopy(int n, const double* restrict x, double* restrict y)
{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
	BLAS_2V(y, =, x, )
}

void blas_ccopy(int n, const complex* restrict x, complex* restrict y)
{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
	BLAS_2V(y, =, x, )
}

void blas_zcopy(int n, const zomplex* restrict x, zomplex* restrict y)
{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
	BLAS_2V(y, =, x, )
}

void blas_saxpy(int n, float a, const float* restrict x, float* restrict y)
{
	if (a == 1.0)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		BLAS_2V(y, +=, x, )
	}
	else if (a == -1.0)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		BLAS_2V(y, -=, x, )
	}
	else if (a != 0.0)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		BLAS_2V(y, += a *, x, )
	}
}

void blas_daxpy(int n, double a, const double* restrict x, double* restrict y)
{
	if (a == 1.0)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		BLAS_2V(y, +=, x, )
	}
	else if (a == -1.0)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		BLAS_2V(y, -=, x, )
	}
	else if (a != 0.0)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		BLAS_2V(y, += a *, x, )
	}
}

void blas_caxpy(int n, complex a, const complex* restrict x, complex* restrict y)
{
	if (a == 0.0)
		return;
	if (a == 1.0)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		BLAS_2V(y, +=, x, )
	}
	else if (a == -1.0)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		BLAS_2V(y, -=, x, )
	}
	else if (cimag(a) == 0.0)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		BLAS_2V(y, +=, x, * creal(a))
	}
	else
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		BLAS_2V(y, +=, x, * a)
	}
}

void blas_zaxpy(int n, zomplex a, const zomplex* restrict x, zomplex* restrict y)
{
	if (a == 0.0)
		return;
	if (a == 1.0)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		BLAS_2V(y, +=, x, )
	}
	else if (a == -1.0)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		BLAS_2V(y, -=, x, )
	}
	else if (zimag(a) == 0.0)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		BLAS_2V(y, +=, x, * zreal(a))
	}
	else
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		BLAS_2V(y, +=, x, * a)
	}
}

void blas_saxpby(int n, float a, const float* restrict x, float b, float* restrict y)
{
	if (a == 0.0)
		blas_sscal(n, b, y);
	else if (b == 1.0)
		blas_saxpy(n, a, x, y);
	else if (b == 0.0)
	{
		if (a == 1.0)
			blas_scopy(n, x, y);
		else if (a == -1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_2V(y, = -, x, )
		}
		else
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_2V(y, = a *, x, )
		}
	}
	else if (b == -1.0)
	{
		if (a == 1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif	
			BLAS_3V(y, =, x, -, y, )
		}
		else if (a == -1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_3V(y, = -, x, -, y, )
		}
		else
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_3V(y, = a *, x, -, y, )
		}
	}
	else if (a == 1.0)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		BLAS_3V(y, =, x, + b *, y, )
	}
	else if (a == -1.0)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		BLAS_3V(y, = -, x, + b *, y, )
	}
	else
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		BLAS_3V(y, = a *, x, + b *, y, )
	}
}

void blas_daxpby(int n, double a, const double* restrict x, double b, double* restrict y)
{
	if (a == 0.0)
		blas_dscal(n, b, y);
	else if (b == 1.0)
		blas_daxpy(n, a, x, y);
	else if (b == 0.0)
	{
		if (a == 1.0)
			blas_dcopy(n, x, y);
		else if (a == -1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_2V(y, = -, x, )
		}
		else
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_2V(y, = a *, x, )
		}
	}
	else if (b == -1.0)
	{
		if (a == 1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif	
			BLAS_3V(y, =, x, -, y, )
		}
		else if (a == -1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_3V(y, = -, x, -, y, )
		}
		else
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_3V(y, = a *, x, -, y, )
		}
	}
	else if (a == 1.0)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		BLAS_3V(y, =, x, + b *, y, )
	}
	else if (a == -1.0)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		BLAS_3V(y, = -, x, + b *, y, )
	}
	else
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		BLAS_3V(y, = a *, x, + b *, y, )
	}
}

void blas_caxpby(int n, complex a, const complex* restrict x, complex b, complex* restrict y)
{
	if (a == 0.0)
		blas_cscal(n, b, y);
	else if (b == 1.0)
		blas_caxpy(n, a, x, y);
	else if (b == 0.0)
	{
		if (a == 1.0)
			blas_ccopy(n, x, y);
		else if (a == -1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_2V(y, = -, x, )
		}
		else if (cimag(a) == 0.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_2V(y, =, x, * creal(a))
		}
		else
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_2V(y, =, x, * a)
		}
	}
	else if (b == -1.0)
	{
		if (a == 1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif	
			BLAS_3V(y, =, x, -, y, )
		}
		else if (a == -1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_3V(y, = -, x, -, y, )
		}
		else if (cimag(a) == 0.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_3V(y, =, x, * creal(a) -, y, )
		}
		else
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_3V(y, =, x, * a -, y, )
		}
	}
	else if (cimag(b) == 0.0)
	{
		if (a == 1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif	
			BLAS_3V(y, =, x, +, y, * creal(b))
		}
		else if (a == -1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_3V(y, = -, x, +, y, * creal(b))
		}
		else if (cimag(a) == 0.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_3V(y, =, x, * creal(a) +, y, * creal(b))
		}
		else
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_3V(y, =, x, * a +, y, * creal(b))
		}
	}
	else if (a == 1.0)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		BLAS_3V(y, =, x, + b *, y, )
	}
	else if (a == -1.0)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		BLAS_3V(y, = -, x, + b *, y, )
	}
	else if (cimag(a) == 0.0)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		BLAS_3V(y, =, x, * creal(a) +, y, * b)
	}
	else
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		BLAS_3V(y, =, x, * a +, y, * b)
	}
}

void blas_zaxpby(int n, zomplex a, const zomplex* restrict x, zomplex b, zomplex* restrict y)
{
	if (a == 0.0)
		blas_zscal(n, b, y);
	else if (b == 1.0)
		blas_zaxpy(n, a, x, y);
	else if (b == 0.0)
	{
		if (a == 1.0)
			blas_zcopy(n, x, y);
		else if (a == -1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_2V(y, = -, x, )
		}
		else if (zimag(a) == 0.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_2V(y, =, x, * zreal(a))
		}
		else
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_2V(y, =, x, * a)
		}
	}
	else if (b == -1.0)
	{
		if (a == 1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif	
			BLAS_3V(y, =, x, -, y, )
		}
		else if (a == -1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_3V(y, = -, x, -, y, )
		}
		else if (zimag(a) == 0.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_3V(y, =, x, * zreal(a) -, y, )
		}
		else
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_3V(y, =, x, * a -, y, )
		}
	}
	else if (zimag(b) == 0.0)
	{
		if (a == 1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif	
			BLAS_3V(y, =, x, +, y, * zreal(b))
		}
		else if (a == -1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_3V(y, = -, x, +, y, * zreal(b))
		}
		else if (zimag(a) == 0.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_3V(y, =, x, * zreal(a) +, y, * zreal(b))
		}
		else
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_3V(y, =, x, * a +, y, * zreal(b))
		}
	}
	else if (a == 1.0)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		BLAS_3V(y, =, x, + b *, y, )
	}
	else if (a == -1.0)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		BLAS_3V(y, = -, x, + b *, y, )
	}
	else if (zimag(a) == 0.0)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		BLAS_3V(y, =, x, * zreal(a) +, y, * b)
	}
	else
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		BLAS_3V(y, =, x, * a +, y, * b)
	}
}

void blas_saxpbypz(int n, float a, const float* restrict x, float b, const float* restrict y, float* restrict z)
{
	if (a == 0.0)
		blas_saxpy(n, b, y, z);
	else if (b == 0.0)
		blas_saxpy(n, a, x, z);
	else if (a == 1.0)
	{
		if (b == 1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_3V(z, +=, x, +, y, )
		}
		else if (b == -1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_3V(z, +=, x, -, y, )
		}
		else
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_3V(z, +=, x, + b *, y, )
		}
	}
	else if (a == -1.0)
	{
		if (b == 1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_3V(z, += -, x, +, y, )
		}
		else if (b == -1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_3V(z, += -, x, -, y, )
		}
		else
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_3V(z, += -, x, + b *, y, )
		}
	}
	else if (b == 1.0)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		BLAS_3V(z, += a *, x, +, y, )
	}
	else if (b == -1.0)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		BLAS_3V(z, += a *, x, -, y, )
	}
	else
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		BLAS_3V(z, += a *, x, + b *, y, )
	}
}

void blas_daxpbypz(int n, double a, const double* restrict x, double b, const double* restrict y, double* restrict z)
{
	if (a == 0.0)
		blas_daxpy(n, b, y, z);
	else if (b == 0.0)
		blas_daxpy(n, a, x, z);
	else if (a == 1.0)
	{
		if (b == 1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_3V(z, +=, x, +, y, )
		}
		else if (b == -1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_3V(z, +=, x, -, y, )
		}
		else
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_3V(z, +=, x, + b *, y, )
		}
	}
	else if (a == -1.0)
	{
		if (b == 1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_3V(z, += -, x, +, y, )
		}
		else if (b == -1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_3V(z, += -, x, -, y, )
		}
		else
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_3V(z, += -, x, + b *, y, )
		}
	}
	else if (b == 1.0)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		BLAS_3V(z, += a *, x, +, y, )
	}
	else if (b == -1.0)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		BLAS_3V(z, += a *, x, -, y, )
	}
	else
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		BLAS_3V(z, += a *, x, + b *, y, )
	}
}

void blas_caxpbypz(int n, complex a, const complex* restrict x, complex b, const complex* restrict y, complex* restrict z)
{
	if (a == 0.0)
		blas_caxpy(n, b, y, z);
	else if (b == 0.0)
		blas_caxpy(n, a, x, z);
	else if (a == 1.0)
	{
		if (b == 1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_3V(z, +=, x, +, y, )
		}
		else if (b == -1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_3V(z, +=, x, -, y, )
		}
		else if (cimag(b) == 0.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_3V(z, +=, x, +, y, * creal(b))
		}
		else
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_3V(z, +=, x, +, y, * b)
		}
	}
	else if (a == -1.0)
	{
		if (b == 1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_3V(z, += -, x, +, y, )
		}
		else if (b == -1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_3V(z, += -, x, -, y, )
		}
		else if (cimag(b) == 0.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_3V(z, += -, x, +, y, * creal(b))
		}
		else
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_3V(z, += -, x, +, y, * b)
		}
	}
	else if (cimag(a) == 0.0)
	{
		if (b == 1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_3V(z, +=, x, * creal(a) +, y, )
		}
		else if (b == -1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_3V(z, +=, x, * creal(a) -, y, )
		}
		else if (cimag(b) == 0.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_3V(z, +=, x, * creal(a) +, y, * creal(b))
		}
		else
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_3V(z, +=, x, * creal(a) +, y, * b)
		}
	}
	else if (b == 1.0)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		BLAS_3V(z, +=, x, * a +, y, )
	}
	else if (b == -1.0)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		BLAS_3V(z, +=, x, * a -, y, )
	}
	else if (cimag(b) == 0.0)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		BLAS_3V(z, +=, x, * a +, y, * creal(b))
	}
	else
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		BLAS_3V(z, +=, x, * a +, y, * b)
	}
}

void blas_zaxpbypz(int n, zomplex a, const zomplex* restrict x, zomplex b, const zomplex* restrict y, zomplex* restrict z)
{
	if (a == 0.0)
		blas_zaxpy(n, b, y, z);
	else if (b == 0.0)
		blas_zaxpy(n, a, x, z);
	else if (a == 1.0)
	{
		if (b == 1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_3V(z, +=, x, +, y, )
		}
		else if (b == -1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_3V(z, +=, x, -, y, )
		}
		else if (zimag(b) == 0.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_3V(z, +=, x, +, y, * zreal(b))
		}
		else
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_3V(z, +=, x, +, y, * b)
		}
	}
	else if (a == -1.0)
	{
		if (b == 1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_3V(z, += -, x, +, y, )
		}
		else if (b == -1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_3V(z, += -, x, -, y, )
		}
		else if (zimag(b) == 0.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_3V(z, += -, x, +, y, * zreal(b))
		}
		else
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_3V(z, += -, x, +, y, * b)
		}
	}
	else if (zimag(a) == 0.0)
	{
		if (b == 1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_3V(z, +=, x, * zreal(a) +, y, )
		}
		else if (b == -1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_3V(z, +=, x, * zreal(a) -, y, )
		}
		else if (zimag(b) == 0.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_3V(z, +=, x, * zreal(a) +, y, * zreal(b))
		}
		else
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_3V(z, +=, x, * zreal(a) +, y, * b)
		}
	}
	else if (b == 1.0)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		BLAS_3V(z, +=, x, * a +, y, )
	}
	else if (b == -1.0)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		BLAS_3V(z, +=, x, * a -, y, )
	}
	else if (zimag(b) == 0.0)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		BLAS_3V(z, +=, x, * a +, y, * zreal(b))
	}
	else
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		BLAS_3V(z, +=, x, * a +, y, * b)
	}
}

void blas_saxpbypcz(int n, float a, const float* restrict x, float b, const float* restrict y, float c, float* restrict z)
{
	if (c == 1.0)
		blas_saxpbypz(n, a, x, b, y, z);
	else if (a == 0.0)
		blas_saxpby(n, b, y, c, z);
	else if (b == 0.0)
		blas_saxpby(n, a, x, c, z);
	else if (c == 0.0)
	{
		if (a == 1.0)
		{
			if (b == 1.0)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_3V(z, =, x, +, y, )
			}
			else if (b == -1.0)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_3V(z, =, x, -, y, )
			}
			else
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_3V(z, =, x, + b *, y, )
			}
		}
		else if (a == -1.0)
		{
			if (b == 1.0)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_3V(z, = -, x, +, y, )
			}
			else if (b == -1.0)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_3V(z, = -, x, -, y, )
			}
			else
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_3V(z, = -, x, + b *, y, )
			}
		}
		else if (b == 1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_3V(z, = a *, x, +, y, )
		}
		else if (b == -1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_3V(z, = a *, x, -, y, )
		}
		else
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_3V(z, = a *, x, + b *, y, )
		}
	}
	else if (c == -1.0)
	{
		if (a == 1.0)
		{
			if (b == 1.0)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_4V(z, =, x, +, y, -, z, )
			}
			else if (b == -1.0)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_4V(z, =, x, -, y, -, z, )
			}
			else
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_4V(z, =, x, + b *, y, -, z, )
			}
		}
		else if (a == -1.0)
		{
			if (b == 1.0)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_4V(z, = -, x, +, y, -, z, )
			}
			else if (b == -1.0)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_4V(z, = -, x, -, y, -, z, )
			}
			else
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_4V(z, = -, x, + b *, y, -, z, )
			}
		}
		else if (b == 1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_4V(z, = a *, x, +, y, -, z, )
		}
		else if (b == -1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_4V(z, = a *, x, -, y, -, z, )
		}
		else
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_4V(z, = a *, x, + b *, y, -, z, )
		}
	}
	else if (a == 1.0)
	{
		if (b == 1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_4V(z, =, x, +, y, + c *, z, )
		}
		else if (b == -1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_4V(z, =, x, -, y, + c *, z, )
		}
		else
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_4V(z, =, x, + b *, y, + c *, z, )
		}
	}
	else if (a == -1.0)
	{
		if (b == 1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_4V(z, = -, x, +, y, + c *, z, )
		}
		else if (b == -1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_4V(z, = -, x, -, y, + c *, z, )
		}
		else
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_4V(z, = -, x, + b *, y, + c *, z, )
		}
	}
	else if (b == 1.0)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		BLAS_4V(z, = a *, x, +, y, + c *, z, )
	}
	else if (b == -1.0)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		BLAS_4V(z, = a *, x, -, y, + c *, z, )
	}
	else
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		BLAS_4V(z, = a *, x, + b *, y, + c *, z, )
	}

}

void blas_daxpbypcz(int n, double a, const double* restrict x, double b, const double* restrict y, double c, double* restrict z)
{
	if (c == 1.0)
		blas_daxpbypz(n, a, x, b, y, z);
	else if (a == 0.0)
		blas_daxpby(n, b, y, c, z);
	else if (b == 0.0)
		blas_daxpby(n, a, x, c, z);
	else if (c == 0.0)
	{
		if (a == 1.0)
		{
			if (b == 1.0)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_3V(z, =, x, +, y, )
			}
			else if (b == -1.0)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_3V(z, =, x, -, y, )
			}
			else
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_3V(z, =, x, + b *, y, )
			}
		}
		else if (a == -1.0)
		{
			if (b == 1.0)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_3V(z, = -, x, +, y, )
			}
			else if (b == -1.0)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_3V(z, = -, x, -, y, )
			}
			else
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_3V(z, = -, x, + b *, y, )
			}
		}
		else if (b == 1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_3V(z, = a *, x, +, y, )
		}
		else if (b == -1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_3V(z, = a *, x, -, y, )
		}
		else
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_3V(z, = a *, x, + b *, y, )
		}
	}
	else if (c == -1.0)
	{
		if (a == 1.0)
		{
			if (b == 1.0)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_4V(z, =, x, +, y, -, z, )
			}
			else if (b == -1.0)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_4V(z, =, x, -, y, -, z, )
			}
			else
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_4V(z, =, x, + b *, y, -, z, )
			}
		}
		else if (a == -1.0)
		{
			if (b == 1.0)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_4V(z, = -, x, +, y, -, z, )
			}
			else if (b == -1.0)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_4V(z, = -, x, -, y, -, z, )
			}
			else
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_4V(z, = -, x, + b *, y, -, z, )
			}
		}
		else if (b == 1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_4V(z, = a *, x, +, y, -, z, )
		}
		else if (b == -1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_4V(z, = a *, x, -, y, -, z, )
		}
		else
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_4V(z, = a *, x, + b *, y, -, z, )
		}
	}
	else if (a == 1.0)
	{
		if (b == 1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_4V(z, =, x, +, y, + c *, z, )
		}
		else if (b == -1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_4V(z, =, x, -, y, + c *, z, )
		}
		else
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_4V(z, =, x, + b *, y, + c *, z, )
		}
	}
	else if (a == -1.0)
	{
		if (b == 1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_4V(z, = -, x, +, y, + c *, z, )
		}
		else if (b == -1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_4V(z, = -, x, -, y, + c *, z, )
		}
		else
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_4V(z, = -, x, + b *, y, + c *, z, )
		}
	}
	else if (b == 1.0)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		BLAS_4V(z, = a *, x, +, y, + c *, z, )
	}
	else if (b == -1.0)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		BLAS_4V(z, = a *, x, -, y, + c *, z, )
	}
	else
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		BLAS_4V(z, = a *, x, + b *, y, + c *, z, )
	}

}

void blas_caxpbypcz(int n, complex a, const complex* restrict x, complex b, const complex* restrict y, complex c, complex* restrict z)
{
	if (c == 1.0)
		blas_caxpbypz(n, a, x, b, y, z);
	else if (a == 0.0)
		blas_caxpby(n, b, y, c, z);
	else if (b == 0.0)
		blas_caxpby(n, a, x, c, z);
	else if (c == 0.0)
	{
		if (a == 1.0)
		{
			if (b == 1.0)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_3V(z, =, x, +, y, )
			}
			else if (b == -1.0)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_3V(z, =, x, -, y, )
			}
			else if (cimag(b) == 0.0)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_3V(z, =, x, +, y, * creal(b))
			}
			else
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_3V(z, =, x, +, y, * b)
			}
		}
		else if (a == -1.0)
		{
			if (b == 1.0)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_3V(z, = -, x, +, y, )
			}
			else if (b == -1.0)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_3V(z, = -, x, -, y, )
			}
			else if (cimag(b) == 0.0)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_3V(z, = -, x, +, y, * creal(b))
			}
			else
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_3V(z, = -, x, +, y, * b)
			}
		}
		else if (cimag(a) == 0.0)
		{
			if (b == 1.0)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_3V(z, =, x, * creal(a) +, y, )
			}
			else if (b == -1.0)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_3V(z, =, x, * creal(a) -, y, )
			}
			else if (cimag(b) == 0.0)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_3V(z, =, x, * creal(a) +, y, * creal(b))
			}
			else
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_3V(z, =, x, * creal(a) +, y, * b)
			}
		}
		else if (b == 1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_3V(z, =, x, * a +, y, )
		}
		else if (b == -1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_3V(z, =, x, * a -, y, )
		}
		else if (cimag(b) == 0.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_3V(z, =, x, * a +, y, * creal(b))
		}
		else
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_3V(z, =, x, * a +, y, * b)
		}
	}
	else if (c == -1.0)
	{
		if (a == 1.0)
		{
			if (b == 1.0)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_4V(z, =, x, +, y, -, z, )
			}
			else if (b == -1.0)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_4V(z, =, x, -, y, -, z, )
			}
			else if (cimag(b) == 0.0)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_4V(z, =, x, +, y, * creal(b) -, z, )
			}
			else
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_4V(z, =, x, +, y, * b -, z, )
			}
		}
		else if (a == -1.0)
		{
			if (b == 1.0)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_4V(z, = -, x, +, y, -, z, )
			}
			else if (b == -1.0)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_4V(z, = -, x, -, y, -, z, )
			}
			else if (cimag(b) == 0.0)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_4V(z, = -, x, +, y, * creal(b) -, z, )
			}
			else
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_4V(z, = -, x, +, y, * b -, z, )
			}
		}
		else if (cimag(a) == 0.0)
		{
			if (b == 1.0)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_4V(z, =, x, * creal(a) +, y, -, z, )
			}
			else if (b == -1.0)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_4V(z, =, x, * creal(a) -, y, -, z, )
			}
			else if (cimag(b) == 0.0)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_4V(z, =, x, * creal(a) +, y, * creal(b) -, z, )
			}
			else
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_4V(z, =, x, * creal(a) +, y, * b -, z, )
			}
		}
		else if (b == 1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_4V(z, =, x, * a +, y, -, z, )
		}
		else if (b == -1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_4V(z, =, x, * a -, y, -, z, )
		}
		else if (cimag(b) == 0.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_4V(z, =, x, * a +, y, * creal(b) -, z, )
		}
		else
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_4V(z, =, x, * a +, y, * b -, z, )
		}
	}
	else if (cimag(c) == 0.0)
	{
		if (a == 1.0)
		{
			if (b == 1.0)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_4V(z, =, x, +, y, +, z, * creal(c))
			}
			else if (b == -1.0)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_4V(z, =, x, -, y, +, z, * creal(c))
			}
			else if (cimag(b) == 0.0)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_4V(z, =, x, +, y, * creal(b) +, z, * creal(c))
			}
			else
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_4V(z, =, x, +, y, * b +, z, * creal(c))
			}
		}
		else if (a == -1.0)
		{
			if (b == 1.0)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_4V(z, = -, x, +, y, +, z, * creal(c))
			}
			else if (b == -1.0)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_4V(z, = -, x, -, y, +, z, * creal(c))
			}
			else if (cimag(b) == 0.0)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_4V(z, = -, x, +, y, * creal(b) +, z, * creal(c))
			}
			else
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_4V(z, = -, x, +, y, * b +, z, * creal(c))
			}
		}
		else if (cimag(a) == 0.0)
		{
			if (b == 1.0)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_4V(z, =, x, * creal(a) +, y, +, z, * creal(c))
			}
			else if (b == -1.0)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_4V(z, =, x, * creal(a) -, y, +, z, * creal(c))
			}
			else if (cimag(b) == 0.0)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_4V(z, =, x, * creal(a) +, y, * creal(b) +, z, * creal(c))
			}
			else
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_4V(z, =, x, * creal(a) +, y, * b +, z, * creal(c))
			}
		}
		else if (b == 1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_4V(z, =, x, * a +, y, +, z, * creal(c))
		}
		else if (b == -1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_4V(z, =, x, * a -, y, +, z, * creal(c))
		}
		else if (cimag(b) == 0.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_4V(z, =, x, * a +, y, * creal(b) +, z, * creal(c))
		}
		else
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_4V(z, =, x, * a +, y, * b +, z, * creal(c))
		}
	}
	else if (a == 1.0)
	{
		if (b == 1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_4V(z, =, x, +, y, +, z, * c)
		}
		else if (b == -1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_4V(z, =, x, -, y, +, z, * c)
		}
		else if (cimag(b) == 0.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_4V(z, =, x, +, y, * creal(b) +, z, * c)
		}
		else
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_4V(z, =, x, +, y, * b +, z, * c)
		}
	}
	else if (a == -1.0)
	{
		if (b == 1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_4V(z, = -, x, +, y, +, z, * c)
		}
		else if (b == -1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_4V(z, = -, x, -, y, +, z, * c)
		}
		else if (cimag(b) == 0.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_4V(z, = -, x, +, y, * creal(b) +, z, * c)
		}
		else
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_4V(z, = -, x, +, y, * b +, z, * c)
		}
	}
	else if (cimag(a) == 0.0)
	{
		if (b == 1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_4V(z, =, x, * creal(a) +, y, +, z, * c)
		}
		else if (b == -1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_4V(z, =, x, * creal(a) -, y, +, z, * c)
		}
		else if (cimag(b) == 0.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_4V(z, =, x, * creal(a) +, y, * creal(b) +, z, * c)
		}
		else
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_4V(z, =, x, * creal(a) +, y, * b +, z, * c)
		}
	}
	else if (b == 1.0)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		BLAS_4V(z, =, x, * a +, y, +, z, * c)
	}
	else if (b == -1.0)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		BLAS_4V(z, =, x, * a -, y, +, z, * c)
	}
	else if (cimag(b) == 0.0)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		BLAS_4V(z, =, x, * a +, y, * creal(b) +, z, * c)
	}
	else
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		BLAS_4V(z, =, x, * a +, y, * b +, z, * c)
	}
}

void blas_zaxpbypcz(int n, zomplex a, const zomplex* restrict x, zomplex b, const zomplex* restrict y, zomplex c, zomplex* restrict z)
{
	if (c == 1.0)
		blas_zaxpbypz(n, a, x, b, y, z);
	else if (a == 0.0)
		blas_zaxpby(n, b, y, c, z);
	else if (b == 0.0)
		blas_zaxpby(n, a, x, c, z);
	else if (c == 0.0)
	{
		if (a == 1.0)
		{
			if (b == 1.0)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_3V(z, =, x, +, y, )
			}
			else if (b == -1.0)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_3V(z, =, x, -, y, )
			}
			else if (zimag(b) == 0.0)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_3V(z, =, x, +, y, * zreal(b))
			}
			else
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_3V(z, =, x, +, y, * b)
			}
		}
		else if (a == -1.0)
		{
			if (b == 1.0)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_3V(z, = -, x, +, y, )
			}
			else if (b == -1.0)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_3V(z, = -, x, -, y, )
			}
			else if (zimag(b) == 0.0)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_3V(z, = -, x, +, y, * zreal(b))
			}
			else
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_3V(z, = -, x, +, y, * b)
			}
		}
		else if (zimag(a) == 0.0)
		{
			if (b == 1.0)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_3V(z, =, x, * zreal(a) +, y, )
			}
			else if (b == -1.0)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_3V(z, =, x, * zreal(a) -, y, )
			}
			else if (zimag(b) == 0.0)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_3V(z, =, x, * zreal(a) +, y, * zreal(b))
			}
			else
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_3V(z, =, x, * zreal(a) +, y, * b)
			}
		}
		else if (b == 1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_3V(z, =, x, * a +, y, )
		}
		else if (b == -1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_3V(z, =, x, * a -, y, )
		}
		else if (zimag(b) == 0.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_3V(z, =, x, * a +, y, * zreal(b))
		}
		else
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_3V(z, =, x, * a +, y, * b)
		}
	}
	else if (c == -1.0)
	{
		if (a == 1.0)
		{
			if (b == 1.0)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_4V(z, =, x, +, y, -, z, )
			}
			else if (b == -1.0)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_4V(z, =, x, -, y, -, z, )
			}
			else if (zimag(b) == 0.0)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_4V(z, =, x, +, y, * zreal(b) -, z, )
			}
			else
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_4V(z, =, x, +, y, * b -, z, )
			}
		}
		else if (a == -1.0)
		{
			if (b == 1.0)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_4V(z, = -, x, +, y, -, z, )
			}
			else if (b == -1.0)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_4V(z, = -, x, -, y, -, z, )
			}
			else if (zimag(b) == 0.0)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_4V(z, = -, x, +, y, * zreal(b) -, z, )
			}
			else
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_4V(z, = -, x, +, y, * b -, z, )
			}
		}
		else if (zimag(a) == 0.0)
		{
			if (b == 1.0)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_4V(z, =, x, * zreal(a) +, y, -, z, )
			}
			else if (b == -1.0)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_4V(z, =, x, * zreal(a) -, y, -, z, )
			}
			else if (zimag(b) == 0.0)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_4V(z, =, x, * zreal(a) +, y, * zreal(b) -, z, )
			}
			else
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_4V(z, =, x, * zreal(a) +, y, * b -, z, )
			}
		}
		else if (b == 1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_4V(z, =, x, * a +, y, -, z, )
		}
		else if (b == -1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_4V(z, =, x, * a -, y, -, z, )
		}
		else if (zimag(b) == 0.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_4V(z, =, x, * a +, y, * zreal(b) -, z, )
		}
		else
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_4V(z, =, x, * a +, y, * b -, z, )
		}
	}
	else if (zimag(c) == 0.0)
	{
		if (a == 1.0)
		{
			if (b == 1.0)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_4V(z, =, x, +, y, +, z, * zreal(c))
			}
			else if (b == -1.0)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_4V(z, =, x, -, y, +, z, * zreal(c))
			}
			else if (zimag(b) == 0.0)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_4V(z, =, x, +, y, * zreal(b) +, z, * zreal(c))
			}
			else
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_4V(z, =, x, +, y, * b +, z, * zreal(c))
			}
		}
		else if (a == -1.0)
		{
			if (b == 1.0)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_4V(z, = -, x, +, y, +, z, * zreal(c))
			}
			else if (b == -1.0)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_4V(z, = -, x, -, y, +, z, * zreal(c))
			}
			else if (zimag(b) == 0.0)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_4V(z, = -, x, +, y, * zreal(b) +, z, * zreal(c))
			}
			else
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_4V(z, = -, x, +, y, * b +, z, * zreal(c))
			}
		}
		else if (zimag(a) == 0.0)
		{
			if (b == 1.0)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_4V(z, =, x, * zreal(a) +, y, +, z, * zreal(c))
			}
			else if (b == -1.0)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_4V(z, =, x, * zreal(a) -, y, +, z, * zreal(c))
			}
			else if (zimag(b) == 0.0)
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_4V(z, =, x, * zreal(a) +, y, * zreal(b) +, z, * zreal(c))
			}
			else
			{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
				BLAS_4V(z, =, x, * zreal(a) +, y, * b +, z, * zreal(c))
			}
		}
		else if (b == 1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_4V(z, =, x, * a +, y, +, z, * zreal(c))
		}
		else if (b == -1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_4V(z, =, x, * a -, y, +, z, * zreal(c))
		}
		else if (zimag(b) == 0.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_4V(z, =, x, * a +, y, * zreal(b) +, z, * zreal(c))
		}
		else
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_4V(z, =, x, * a +, y, * b +, z, * zreal(c))
		}
	}
	else if (a == 1.0)
	{
		if (b == 1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_4V(z, =, x, +, y, +, z, * c)
		}
		else if (b == -1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_4V(z, =, x, -, y, +, z, * c)
		}
		else if (zimag(b) == 0.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_4V(z, =, x, +, y, * zreal(b) +, z, * c)
		}
		else
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_4V(z, =, x, +, y, * b +, z, * c)
		}
	}
	else if (a == -1.0)
	{
		if (b == 1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_4V(z, = -, x, +, y, +, z, * c)
		}
		else if (b == -1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_4V(z, = -, x, -, y, +, z, * c)
		}
		else if (zimag(b) == 0.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_4V(z, = -, x, +, y, * zreal(b) +, z, * c)
		}
		else
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_4V(z, = -, x, +, y, * b +, z, * c)
		}
	}
	else if (zimag(a) == 0.0)
	{
		if (b == 1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_4V(z, =, x, * zreal(a) +, y, +, z, * c)
		}
		else if (b == -1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_4V(z, =, x, * zreal(a) -, y, +, z, * c)
		}
		else if (zimag(b) == 0.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_4V(z, =, x, * zreal(a) +, y, * zreal(b) +, z, * c)
		}
		else
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			BLAS_4V(z, =, x, * zreal(a) +, y, * b +, z, * c)
		}
	}
	else if (b == 1.0)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		BLAS_4V(z, =, x, * a +, y, +, z, * c)
	}
	else if (b == -1.0)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		BLAS_4V(z, =, x, * a -, y, +, z, * c)
	}
	else if (zimag(b) == 0.0)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		BLAS_4V(z, =, x, * a +, y, * zreal(b) +, z, * c)
	}
	else
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		BLAS_4V(z, =, x, * a +, y, * b +, z, * c)
	}
}

float blas_sdot(int n, const float* x, const float* y)
{
	float result = 0.0;

	if (x == y)
	{
#ifdef BLAS_UNROLL
#define ACCUMULATION(k) + x[i + k] * x[i + k]
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for reduction(+:result)
#endif
		for (int i = 0; i <= n - BLAS_UNROLL; i += BLAS_UNROLL)
			result += UNROLL_REPEAT(BLAS_UNROLL, ACCUMULATION);
		for (int i = n / BLAS_UNROLL * BLAS_UNROLL; i < n; ++i)
#undef ACCUMULATION
#else
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for reduction(+:result)
#endif
		for (int i = 0; i < n; ++i)
#endif
			result += x[i] * x[i];
	}
	else
	{
#ifdef BLAS_UNROLL
#define ACCUMULATION(k) + x[i + k] * y[i + k]
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for reduction(+:result)
#endif
		for (int i = 0; i <= n - BLAS_UNROLL; i += BLAS_UNROLL)
			result += UNROLL_REPEAT(BLAS_UNROLL, ACCUMULATION);
		for (int i = n / BLAS_UNROLL * BLAS_UNROLL; i < n; ++i)
#undef ACCUMULATION
#else
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for reduction(+:result)
#endif
		for (int i = 0; i < n; ++i)
#endif
			result += x[i] * y[i];
	}

	return result;
}

double blas_ddot(int n, const double* x, const double* y)
{
	double result = 0.0;

	if (x == y)
	{
#ifdef BLAS_UNROLL
#define ACCUMULATION(k) + x[i + k] * x[i + k]
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for reduction(+:result)
#endif
		for (int i = 0; i <= n - BLAS_UNROLL; i += BLAS_UNROLL)
			result += UNROLL_REPEAT(BLAS_UNROLL, ACCUMULATION);
		for (int i = n / BLAS_UNROLL * BLAS_UNROLL; i < n; ++i)
#undef ACCUMULATION
#else
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for reduction(+:result)
#endif
		for (int i = 0; i < n; ++i)
#endif
			result += x[i] * x[i];
	}
	else
	{
#ifdef BLAS_UNROLL
#define ACCUMULATION(k) + x[i + k] * y[i + k]
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for reduction(+:result)
#endif
		for (int i = 0; i <= n - BLAS_UNROLL; i += BLAS_UNROLL)
			result += UNROLL_REPEAT(BLAS_UNROLL, ACCUMULATION);
		for (int i = n / BLAS_UNROLL * BLAS_UNROLL; i < n; ++i)
#undef ACCUMULATION
#else
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for reduction(+:result)
#endif
		for (int i = 0; i < n; ++i)
#endif
			result += x[i] * y[i];
	}

	return result;
}

complex blas_cdotc(int n, const complex* x, const complex* y)
{
	int nthd = 1;
#ifdef YHAMG_USE_OPENMP
	nthd = omp_get_max_threads();
#endif

	complex result = 0.0;
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
	for (int t = 0; t < nthd; ++t)
	{
		int begin = t * n / nthd;
		int end = (t + 1) * n / nthd;
		
		complex temp = 0.0;

		if (x == y)
		{
#ifdef BLAS_UNROLL
#define ACCUMULATION(k) + creal(x[i + k]) * creal(x[i + k]) + cimag(x[i + k]) * cimag(x[i + k])
			int i;
			for (i = begin; i <= end - BLAS_UNROLL; i += BLAS_UNROLL)
				temp += UNROLL_REPEAT(BLAS_UNROLL, ACCUMULATION);
			for ( ; i < end; ++i)
#undef ACCUMULATION
#else
			for (int i = begin; i < end; ++i)
#endif
				temp += creal(x[i]) * creal(x[i]) + cimag(x[i]) * cimag(x[i]);
		}
		else
		{
#ifdef BLAS_UNROLL
#define ACCUMULATION(k) + cconj(x[i + k]) * y[i + k]
			int i;
			for (i = begin; i <= end - BLAS_UNROLL; i += BLAS_UNROLL)
				temp += UNROLL_REPEAT(BLAS_UNROLL, ACCUMULATION);
			for ( ; i < end; ++i)
#undef ACCUMULATION
#else
			for (int i = begin; i < end; ++i)
#endif
				temp += cconj(x[i]) * y[i];
		}

#ifdef YHAMG_USE_OPENMP
#pragma omp critical
#endif
		result += temp;
	}

	return result;
}

zomplex blas_zdotc(int n, const zomplex* x, const zomplex* y)
{
	int nthd = 1;
#ifdef YHAMG_USE_OPENMP
	nthd = omp_get_max_threads();
#endif

	zomplex result = 0.0;
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
	for (int t = 0; t < nthd; ++t)
	{
		int begin = t * n / nthd;
		int end = (t + 1) * n / nthd;
		
		zomplex temp = 0.0;

		if (x == y)
		{
#ifdef BLAS_UNROLL
#define ACCUMULATION(k) + zreal(x[i + k]) * zreal(x[i + k]) + zimag(x[i + k]) * zimag(x[i + k])
			int i;
			for (i = begin; i <= end - BLAS_UNROLL; i += BLAS_UNROLL)
				temp += UNROLL_REPEAT(BLAS_UNROLL, ACCUMULATION);
			for ( ; i < end; ++i)
#undef ACCUMULATION
#else
			for (int i = begin; i < end; ++i)
#endif
				temp += zreal(x[i]) * zreal(x[i]) + zimag(x[i]) * zimag(x[i]);
		}
		else
		{
#ifdef BLAS_UNROLL
#define ACCUMULATION(k) + zconj(x[i + k]) * y[i + k]
			int i;
			for (i = begin; i <= end - BLAS_UNROLL; i += BLAS_UNROLL)
				temp += UNROLL_REPEAT(BLAS_UNROLL, ACCUMULATION);
			for ( ; i < end; ++i)
#undef ACCUMULATION
#else
			for (int i = begin; i < end; ++i)
#endif
				temp += zconj(x[i]) * y[i];
		}

#ifdef YHAMG_USE_OPENMP
#pragma omp critical
#endif
		result += temp;
	}

	return result;
}

complex blas_cdotu(int n, const complex* x, const complex* y)
{
	int nthd = 1;
#ifdef YHAMG_USE_OPENMP
	nthd = omp_get_max_threads();
#endif

	complex result = 0.0;
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
	for (int t = 0; t < nthd; ++t)
	{
		int begin = t * n / nthd;
		int end = (t + 1) * n / nthd;
		
		complex temp = 0.0;

		if (x == y)
		{
#ifdef BLAS_UNROLL
#define ACCUMULATION(k) + x[i + k] * x[i + k]
			int i;
			for (i = begin; i <= end - BLAS_UNROLL; i += BLAS_UNROLL)
				temp += UNROLL_REPEAT(BLAS_UNROLL, ACCUMULATION);
			for ( ; i < end; ++i)
#undef ACCUMULATION
#else
			for (int i = begin; i < end; ++i)
#endif
				temp += x[i] * x[i];
		}
		else
		{
#ifdef BLAS_UNROLL
#define ACCUMULATION(k) + x[i + k] * y[i + k]
			int i;
			for (i = begin; i <= end - BLAS_UNROLL; i += BLAS_UNROLL)
				temp += UNROLL_REPEAT(BLAS_UNROLL, ACCUMULATION);
			for ( ; i < end; ++i)
#undef ACCUMULATION
#else
			for (int i = begin; i < end; ++i)
#endif
				temp += x[i] * y[i];
		}

#ifdef YHAMG_USE_OPENMP
#pragma omp critical
#endif
		result += temp;
	}

	return result;
}

zomplex blas_zdotu(int n, const zomplex* x, const zomplex* y)
{
	int nthd = 1;
#ifdef YHAMG_USE_OPENMP
	nthd = omp_get_max_threads();
#endif

	zomplex result = 0.0;
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
	for (int t = 0; t < nthd; ++t)
	{
		int begin = t * n / nthd;
		int end = (t + 1) * n / nthd;
		
		zomplex temp = 0.0;

		if (x == y)
		{
#ifdef BLAS_UNROLL
#define ACCUMULATION(k) + x[i + k] * x[i + k]
			int i;
			for (i = begin; i <= end - BLAS_UNROLL; i += BLAS_UNROLL)
				temp += UNROLL_REPEAT(BLAS_UNROLL, ACCUMULATION);
			for ( ; i < end; ++i)
#undef ACCUMULATION
#else
			for (int i = begin; i < end; ++i)
#endif
				temp += x[i] * x[i];
		}
		else
		{
#ifdef BLAS_UNROLL
#define ACCUMULATION(k) + x[i + k] * y[i + k]
			int i;
			for (i = begin; i <= end - BLAS_UNROLL; i += BLAS_UNROLL)
				temp += UNROLL_REPEAT(BLAS_UNROLL, ACCUMULATION);
			for ( ; i < end; ++i)
#undef ACCUMULATION
#else
			for (int i = begin; i < end; ++i)
#endif
				temp += x[i] * y[i];
		}

#ifdef YHAMG_USE_OPENMP
#pragma omp critical
#endif
		result += temp;
	}

	return result;
}

}