/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef BLAS_H
#define BLAS_H

#include "complex.hpp"

namespace YHAMG
{

void blas_sfill(int n, float a, float* x);
void blas_dfill(int n, double a, double* x);
void blas_cfill(int n, complex a, complex* x);
void blas_zfill(int n, zomplex a, zomplex* x);

void blas_sscal(int n, float a, float* x);
void blas_dscal(int n, double a, double* x);
void blas_cscal(int n, complex a, complex* x);
void blas_zscal(int n, zomplex a, zomplex* x);

void blas_scopy(int n, const float* restrict x, float* restrict y);
void blas_dcopy(int n, const double* restrict x, double* restrict y);
void blas_ccopy(int n, const complex* restrict x, complex* restrict y);
void blas_zcopy(int n, const zomplex* restrict x, zomplex* restrict y);

void blas_saxpy(int n, float a, const float* restrict x, float* restrict y);
void blas_daxpy(int n, double a, const double* restrict x, double* restrict y);
void blas_caxpy(int n, complex a, const complex* restrict x, complex* restrict y);
void blas_zaxpy(int n, zomplex a, const zomplex* restrict x, zomplex* restrict y);

void blas_saxpby(int n, float a, const float* restrict x, float b, float* restrict y);
void blas_daxpby(int n, double a, const double* restrict x, double b, double* restrict y);
void blas_caxpby(int n, complex a, const complex* restrict x, complex b, complex* restrict y);
void blas_zaxpby(int n, zomplex a, const zomplex* restrict x, zomplex b, zomplex* restrict y);

void blas_saxpbypz(int n, float a, const float* restrict x, float b, const float* restrict y, float* restrict z);
void blas_daxpbypz(int n, double a, const double* restrict x, double b, const double* restrict y, double* restrict z);
void blas_caxpbypz(int n, complex a, const complex* restrict x, complex b, const complex* restrict y, complex* restrict z);
void blas_zaxpbypz(int n, zomplex a, const zomplex* restrict x, zomplex b, const zomplex* restrict y, zomplex* restrict z);

void blas_saxpbypcz(int n, float a, const float* restrict x, float b, const float* restrict y, float c, float* restrict z);
void blas_daxpbypcz(int n, double a, const double* restrict x, double b, const double* restrict y, double c, double* restrict z);
void blas_caxpbypcz(int n, complex a, const complex* restrict x, complex b, const complex* restrict y, complex c, complex* restrict z);
void blas_zaxpbypcz(int n, zomplex a, const zomplex* restrict x, zomplex b, const zomplex* restrict y, zomplex c, zomplex* restrict z);

float blas_sdot(int n, const float* x, const float* y);
double blas_ddot(int n, const double* x, const double* y);
complex blas_cdotc(int n, const complex* x, const complex* y);
zomplex blas_zdotc(int n, const zomplex* x, const zomplex* y);
complex blas_cdotu(int n, const complex* x, const complex* y);
zomplex blas_zdotu(int n, const zomplex* x, const zomplex* y);

}

#endif
