/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <mpi.h>
#include "random.hpp"

namespace YHAMG
{

uint64_t seed()
{
	int comm_rank;
	MPI_Comm_rank(MPI_COMM_WORLD, &comm_rank);
	return comm_rank + 1;
}

uint64_t random()
{
	static uint64_t k1 = seed();
	static uint64_t k2 = 12345;

	uint64_t k3 = k1;
	const uint64_t k4 = k2;
	k1 = k4;
	k3 ^= (k3 << 23);
	k2 = k3 ^ k4 ^ (k3 >> 17) ^ (k4 >> 26);
	return k2 + k4;
}

}
