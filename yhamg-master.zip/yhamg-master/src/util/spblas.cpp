/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "unroll.hpp"
#include "blas.hpp"
#include "spblas.hpp"

namespace YHAMG
{

#define SPBLAS(Y, Op, i, Ap, Ai, Av, X) \
	for (int spblas_index = Ap[i]; spblas_index < Ap[i + 1]; ++spblas_index) \
		Y Op ## = Av[spblas_index] * X[Ai[spblas_index]];

#define SPBLAS_R(Y, Op, i, Ap, Ai, Av, X) \
	for (int spblas_index = Ap[i + 1] - 1; spblas_index >= Ap[i]; --spblas_index) \
		Y Op ## = Av[spblas_index] * X[Ai[spblas_index]];

void spblas_scsrmv(int n, float a, const int* restrict Ap, const int* restrict Ai, const float* restrict Av, const float* restrict x, float b, float* restrict y)
{
	if (a == 0.0)
		blas_sscal(n, b, y);
	if (a == 1.0)
	{
		if (b == 0.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				float temp = 0.0;
				SPBLAS(temp, +, i, Ap, Ai, Av, x)
				y[i] = temp;
			}
		}
		else if (b == 1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				float temp = y[i];
				SPBLAS(temp, +, i, Ap, Ai, Av, x)
				y[i] = temp;
			}
		}
		else if (b == -1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				float temp = -y[i];
				SPBLAS(temp, +, i, Ap, Ai, Av, x)
				y[i] = temp;
			}
		}
		else
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				float temp = b * y[i];
				SPBLAS(temp, +, i, Ap, Ai, Av, x)
				y[i] = temp;
			}
		}
	}
	else if (a == -1.0)
	{
		if (b == 0.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				float temp = 0.0;
				SPBLAS(temp, -, i, Ap, Ai, Av, x)
				y[i] = temp;
			}
		}
		else if (b == 1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				float temp = y[i];
				SPBLAS(temp, -, i, Ap, Ai, Av, x)
				y[i] = temp;
			}
		}
		else if (b == -1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				float temp = -y[i];
				SPBLAS(temp, -, i, Ap, Ai, Av, x)
				y[i] = temp;
			}
		}
		else
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				float temp = b * y[i];
				SPBLAS(temp, -, i, Ap, Ai, Av, x)
				y[i] = temp;
			}
		}
	}
	else if (b == 0.0)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		for (int i = 0; i < n; ++i)
		{
			float temp = 0.0;
			SPBLAS(temp, +, i, Ap, Ai, Av, x)
			y[i] = a * temp;
		}
	}
	else if (b == 1.0)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		for (int i = 0; i < n; ++i)
		{
			float temp = 0.0;
			SPBLAS(temp, +, i, Ap, Ai, Av, x)
			y[i] += a * temp;
		}
	}
	else if (b == -1.0)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		for (int i = 0; i < n; ++i)
		{
			float temp = 0.0;
			SPBLAS(temp, +, i, Ap, Ai, Av, x)
			y[i] = -y[i] + a * temp;
		}
	}
	else
	{
		float c = b / a;
		if (c == 1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				float temp = y[i];
				SPBLAS(temp, +, i, Ap, Ai, Av, x)
				y[i] = a * temp;
			}
		}
		else if (c == -1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				float temp = -y[i];
				SPBLAS(temp, +, i, Ap, Ai, Av, x)
				y[i] = a * temp;
			}
		}
		else
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				float temp = c * y[i];
				SPBLAS(temp, +, i, Ap, Ai, Av, x)
				y[i] = a * temp;
			}
		}
	}
}

void spblas_dcsrmv(int n, double a, const int* restrict Ap, const int* restrict Ai, const double* restrict Av, const double* restrict x, double b, double* restrict y)
{
	if (a == 0.0)
		blas_dscal(n, b, y);
	if (a == 1.0)
	{
		if (b == 0.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				double temp = 0.0;
				SPBLAS(temp, +, i, Ap, Ai, Av, x)
				y[i] = temp;
			}
		}
		else if (b == 1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				double temp = y[i];
				SPBLAS(temp, +, i, Ap, Ai, Av, x)
				y[i] = temp;
			}
		}
		else if (b == -1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				double temp = -y[i];
				SPBLAS(temp, +, i, Ap, Ai, Av, x)
				y[i] = temp;
			}
		}
		else
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				double temp = b * y[i];
				SPBLAS(temp, +, i, Ap, Ai, Av, x)
				y[i] = temp;
			}
		}
	}
	else if (a == -1.0)
	{
		if (b == 0.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				double temp = 0.0;
				SPBLAS(temp, -, i, Ap, Ai, Av, x)
				y[i] = temp;
			}
		}
		else if (b == 1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				double temp = y[i];
				SPBLAS(temp, -, i, Ap, Ai, Av, x)
				y[i] = temp;
			}
		}
		else if (b == -1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				double temp = -y[i];
				SPBLAS(temp, -, i, Ap, Ai, Av, x)
				y[i] = temp;
			}
		}
		else
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				double temp = b * y[i];
				SPBLAS(temp, -, i, Ap, Ai, Av, x)
				y[i] = temp;
			}
		}
	}
	else if (b == 0.0)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		for (int i = 0; i < n; ++i)
		{
			double temp = 0.0;
			SPBLAS(temp, +, i, Ap, Ai, Av, x)
			y[i] = a * temp;
		}
	}
	else if (b == 1.0)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		for (int i = 0; i < n; ++i)
		{
			double temp = 0.0;
			SPBLAS(temp, +, i, Ap, Ai, Av, x)
			y[i] += a * temp;
		}
	}
	else if (b == -1.0)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		for (int i = 0; i < n; ++i)
		{
			double temp = 0.0;
			SPBLAS(temp, +, i, Ap, Ai, Av, x)
			y[i] = -y[i] + a * temp;
		}
	}
	else
	{
		double c = b / a;
		if (c == 1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				double temp = y[i];
				SPBLAS(temp, +, i, Ap, Ai, Av, x)
				y[i] = a * temp;
			}
		}
		else if (c == -1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				double temp = -y[i];
				SPBLAS(temp, +, i, Ap, Ai, Av, x)
				y[i] = a * temp;
			}
		}
		else
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				double temp = c * y[i];
				SPBLAS(temp, +, i, Ap, Ai, Av, x)
				y[i] = a * temp;
			}
		}
	}
}

void spblas_ccsrmv(int n, complex a, const int* restrict Ap, const int* restrict Ai, const complex* restrict Av, const complex* restrict x, complex b, complex* restrict y)
{
	if (a == 0.0)
		blas_cscal(n, b, y);
	if (a == 1.0)
	{
		if (b == 0.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				complex temp = 0.0;
				SPBLAS(temp, +, i, Ap, Ai, Av, x)
				y[i] = temp;
			}
		}
		else if (b == 1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				complex temp = y[i];
				SPBLAS(temp, +, i, Ap, Ai, Av, x)
				y[i] = temp;
			}
		}
		else if (b == -1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				complex temp = -y[i];
				SPBLAS(temp, +, i, Ap, Ai, Av, x)
				y[i] = temp;
			}
		}
		else
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				complex temp = b * y[i];
				SPBLAS(temp, +, i, Ap, Ai, Av, x)
				y[i] = temp;
			}
		}
	}
	else if (a == -1.0)
	{
		if (b == 0.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				complex temp = 0.0;
				SPBLAS(temp, -, i, Ap, Ai, Av, x)
				y[i] = temp;
			}
		}
		else if (b == 1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				complex temp = y[i];
				SPBLAS(temp, -, i, Ap, Ai, Av, x)
				y[i] = temp;
			}
		}
		else if (b == -1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				complex temp = -y[i];
				SPBLAS(temp, -, i, Ap, Ai, Av, x)
				y[i] = temp;
			}
		}
		else
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				complex temp = b * y[i];
				SPBLAS(temp, -, i, Ap, Ai, Av, x)
				y[i] = temp;
			}
		}
	}
	else if (b == 0.0)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		for (int i = 0; i < n; ++i)
		{
			complex temp = 0.0;
			SPBLAS(temp, +, i, Ap, Ai, Av, x)
			y[i] = a * temp;
		}
	}
	else if (b == 1.0)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		for (int i = 0; i < n; ++i)
		{
			complex temp = 0.0;
			SPBLAS(temp, +, i, Ap, Ai, Av, x)
			y[i] += a * temp;
		}
	}
	else if (b == -1.0)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		for (int i = 0; i < n; ++i)
		{
			complex temp = 0.0;
			SPBLAS(temp, +, i, Ap, Ai, Av, x)
			y[i] = -y[i] + a * temp;
		}
	}
	else
	{
		complex c = b / a;
		if (c == 1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				complex temp = y[i];
				SPBLAS(temp, +, i, Ap, Ai, Av, x)
				y[i] = a * temp;
			}
		}
		else if (c == -1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				complex temp = -y[i];
				SPBLAS(temp, +, i, Ap, Ai, Av, x)
				y[i] = a * temp;
			}
		}
		else
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				complex temp = c * y[i];
				SPBLAS(temp, +, i, Ap, Ai, Av, x)
				y[i] = a * temp;
			}
		}
	}
}

void spblas_zcsrmv(int n, zomplex a, const int* restrict Ap, const int* restrict Ai, const zomplex* restrict Av, const zomplex* restrict x, zomplex b, zomplex* restrict y)
{
	if (a == 0.0)
		blas_zscal(n, b, y);
	if (a == 1.0)
	{
		if (b == 0.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				zomplex temp = 0.0;
				SPBLAS(temp, +, i, Ap, Ai, Av, x)
				y[i] = temp;
			}
		}
		else if (b == 1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				zomplex temp = y[i];
				SPBLAS(temp, +, i, Ap, Ai, Av, x)
				y[i] = temp;
			}
		}
		else if (b == -1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				zomplex temp = -y[i];
				SPBLAS(temp, +, i, Ap, Ai, Av, x)
				y[i] = temp;
			}
		}
		else
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				zomplex temp = b * y[i];
				SPBLAS(temp, +, i, Ap, Ai, Av, x)
				y[i] = temp;
			}
		}
	}
	else if (a == -1.0)
	{
		if (b == 0.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				zomplex temp = 0.0;
				SPBLAS(temp, -, i, Ap, Ai, Av, x)
				y[i] = temp;
			}
		}
		else if (b == 1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				zomplex temp = y[i];
				SPBLAS(temp, -, i, Ap, Ai, Av, x)
				y[i] = temp;
			}
		}
		else if (b == -1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				zomplex temp = -y[i];
				SPBLAS(temp, -, i, Ap, Ai, Av, x)
				y[i] = temp;
			}
		}
		else
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				zomplex temp = b * y[i];
				SPBLAS(temp, -, i, Ap, Ai, Av, x)
				y[i] = temp;
			}
		}
	}
	else if (b == 0.0)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		for (int i = 0; i < n; ++i)
		{
			zomplex temp = 0.0;
			SPBLAS(temp, +, i, Ap, Ai, Av, x)
			y[i] = a * temp;
		}
	}
	else if (b == 1.0)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		for (int i = 0; i < n; ++i)
		{
			zomplex temp = 0.0;
			SPBLAS(temp, +, i, Ap, Ai, Av, x)
			y[i] += a * temp;
		}
	}
	else if (b == -1.0)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		for (int i = 0; i < n; ++i)
		{
			zomplex temp = 0.0;
			SPBLAS(temp, +, i, Ap, Ai, Av, x)
			y[i] = -y[i] + a * temp;
		}
	}
	else
	{
		zomplex c = b / a;
		if (c == 1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				zomplex temp = y[i];
				SPBLAS(temp, +, i, Ap, Ai, Av, x)
				y[i] = a * temp;
			}
		}
		else if (c == -1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				zomplex temp = -y[i];
				SPBLAS(temp, +, i, Ap, Ai, Av, x)
				y[i] = a * temp;
			}
		}
		else
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				zomplex temp = c * y[i];
				SPBLAS(temp, +, i, Ap, Ai, Av, x)
				y[i] = a * temp;
			}
		}
	}
}

void spblas_scsrtrsv(int n, const float* restrict drcp, const int* restrict Ap, const int* restrict Ai, const float* restrict Av, float* restrict x)
{
	int uplo = 0;
	while (uplo < n)
	{
		if (Ap[0] < Ap[uplo + 1])
		{
			uplo = Ai[Ap[0]] < uplo;
			break;
		}
		++uplo;
	}

	if (uplo)
	{
		if (drcp)
		{
			for (int i = 0; i < n; ++i)
			{
				float temp = x[i];
				SPBLAS(temp, -, i, Ap, Ai, Av, x)
				x[i] = temp * drcp[i];
			}
		}
		else
		{
			for (int i = 0; i < n; ++i)
			{
				float temp = x[i];
				SPBLAS(temp, -, i, Ap, Ai, Av, x)
				x[i] = temp;
			}
		}
	}
	else
	{
		if (drcp)
		{
			for (int i = n - 1; i >= 0; --i)
			{
				float temp = x[i];
				SPBLAS_R(temp, -, i, Ap, Ai, Av, x)
				x[i] = temp * drcp[i];
			}
		}
		else
		{
			for (int i = n - 1; i >= 0; --i)
			{
				float temp = x[i];
				SPBLAS_R(temp, -, i, Ap, Ai, Av, x)
				x[i] = temp;
			}
		}
	}
}

void spblas_dcsrtrsv(int n, const double* restrict drcp, const int* restrict Ap, const int* restrict Ai, const double* restrict Av, double* restrict x)
{
	int uplo = 0;
	while (uplo < n)
	{
		if (Ap[0] < Ap[uplo + 1])
		{
			uplo = Ai[Ap[0]] < uplo;
			break;
		}
		++uplo;
	}

	if (uplo)
	{
		if (drcp)
		{
			for (int i = 0; i < n; ++i)
			{
				double temp = x[i];
				SPBLAS(temp, -, i, Ap, Ai, Av, x)
				x[i] = temp * drcp[i];
			}
		}
		else
		{
			for (int i = 0; i < n; ++i)
			{
				double temp = x[i];
				SPBLAS(temp, -, i, Ap, Ai, Av, x)
				x[i] = temp;
			}
		}
	}
	else
	{
		if (drcp)
		{
			for (int i = n - 1; i >= 0; --i)
			{
				double temp = x[i];
				SPBLAS_R(temp, -, i, Ap, Ai, Av, x)
				x[i] = temp * drcp[i];
			}
		}
		else
		{
			for (int i = n - 1; i >= 0; --i)
			{
				double temp = x[i];
				SPBLAS_R(temp, -, i, Ap, Ai, Av, x)
				x[i] = temp;
			}
		}
	}
}

void spblas_ccsrtrsv(int n, const complex* restrict drcp, const int* restrict Ap, const int* restrict Ai, const complex* restrict Av, complex* restrict x)
{
	int uplo = 0;
	while (uplo < n)
	{
		if (Ap[0] < Ap[uplo + 1])
		{
			uplo = Ai[Ap[0]] < uplo;
			break;
		}
		++uplo;
	}

	if (uplo)
	{
		if (drcp)
		{
			for (int i = 0; i < n; ++i)
			{
				complex temp = x[i];
				SPBLAS(temp, -, i, Ap, Ai, Av, x)
				x[i] = temp * drcp[i];
			}
		}
		else
		{
			for (int i = 0; i < n; ++i)
			{
				complex temp = x[i];
				SPBLAS(temp, -, i, Ap, Ai, Av, x)
				x[i] = temp;
			}
		}
	}
	else
	{
		if (drcp)
		{
			for (int i = n - 1; i >= 0; --i)
			{
				complex temp = x[i];
				SPBLAS_R(temp, -, i, Ap, Ai, Av, x)
				x[i] = temp * drcp[i];
			}
		}
		else
		{
			for (int i = n - 1; i >= 0; --i)
			{
				complex temp = x[i];
				SPBLAS_R(temp, -, i, Ap, Ai, Av, x)
				x[i] = temp;
			}
		}
	}
}

void spblas_zcsrtrsv(int n, const zomplex* restrict drcp, const int* restrict Ap, const int* restrict Ai, const zomplex* restrict Av, zomplex* restrict x)
{
	int uplo = 0;
	while (uplo < n)
	{
		if (Ap[0] < Ap[uplo + 1])
		{
			uplo = Ai[Ap[0]] < uplo;
			break;
		}
		++uplo;
	}

	if (uplo)
	{
		if (drcp)
		{
			for (int i = 0; i < n; ++i)
			{
				zomplex temp = x[i];
				SPBLAS(temp, -, i, Ap, Ai, Av, x)
				x[i] = temp * drcp[i];
			}
		}
		else
		{
			for (int i = 0; i < n; ++i)
			{
				zomplex temp = x[i];
				SPBLAS(temp, -, i, Ap, Ai, Av, x)
				x[i] = temp;
			}
		}
	}
	else
	{
		if (drcp)
		{
			for (int i = n - 1; i >= 0; --i)
			{
				zomplex temp = x[i];
				SPBLAS_R(temp, -, i, Ap, Ai, Av, x)
				x[i] = temp * drcp[i];
			}
		}
		else
		{
			for (int i = n - 1; i >= 0; --i)
			{
				zomplex temp = x[i];
				SPBLAS_R(temp, -, i, Ap, Ai, Av, x)
				x[i] = temp;
			}
		}
	}
}

void spblas_scsrmm(int n, int m, float a, const int* restrict Ap, const int* restrict Ai, const float* restrict Av, int ldx, const float* restrict x, float b, int ldy, float* restrict y)
{
	if (a == 0.0)
	{
		for (int j = 0; j < m; ++j)
			blas_sscal(n, b, y + j * ldy);
	}
	if (a == 1.0)
	{
		if (b == 0.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				for (int j = 0; j < m; ++j)
				{
					const float* restrict _x = x + j * ldx;
					float* restrict _y = y + j * ldy;
					float temp = 0.0;
					SPBLAS(temp, +, i, Ap, Ai, Av, _x)
					_y[i] = temp;
				}
			}
		}
		else if (b == 1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				for (int j = 0; j < m; ++j)
				{
					const float* restrict _x = x + j * ldx;
					float* restrict _y = y + j * ldy;
					float temp = _y[i];
					SPBLAS(temp, +, i, Ap, Ai, Av, _x)
					_y[i] = temp;
				}
			}
		}
		else if (b == -1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				for (int j = 0; j < m; ++j)
				{
					const float* restrict _x = x + j * ldx;
					float* restrict _y = y + j * ldy;
					float temp = -_y[i];
					SPBLAS(temp, +, i, Ap, Ai, Av, _x)
					_y[i] = temp;
				}
			}
		}
		else
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				for (int j = 0; j < m; ++j)
				{
					const float* restrict _x = x + j * ldx;
					float* restrict _y = y + j * ldy;
					float temp = b * _y[i];
					SPBLAS(temp, +, i, Ap, Ai, Av, _x)
					_y[i] = temp;
				}
			}
		}
	}
	else if (a == -1.0)
	{
		if (b == 0.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				for (int j = 0; j < m; ++j)
				{
					const float* restrict _x = x + j * ldx;
					float* restrict _y = y + j * ldy;
					float temp = 0.0;
					SPBLAS(temp, -, i, Ap, Ai, Av, _x)
					_y[i] = temp;
				}
			}
		}
		else if (b == 1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				for (int j = 0; j < m; ++j)
				{
					const float* restrict _x = x + j * ldx;
					float* restrict _y = y + j * ldy;
					float temp = _y[i];
					SPBLAS(temp, -, i, Ap, Ai, Av, _x)
					_y[i] = temp;
				}
			}
		}
		else if (b == -1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				for (int j = 0; j < m; ++j)
				{
					const float* restrict _x = x + j * ldx;
					float* restrict _y = y + j * ldy;
					float temp = -_y[i];
					SPBLAS(temp, -, i, Ap, Ai, Av, _x)
					_y[i] = temp;
				}
			}
		}
		else
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				for (int j = 0; j < m; ++j)
				{
					const float* restrict _x = x + j * ldx;
					float* restrict _y = y + j * ldy;
					float temp = b * _y[i];
					SPBLAS(temp, -, i, Ap, Ai, Av, _x)
					_y[i] = temp;
				}
			}
		}
	}
	else if (b == 0.0)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		for (int i = 0; i < n; ++i)
		{
			for (int j = 0; j < m; ++j)
			{
				const float* restrict _x = x + j * ldx;
				float* restrict _y = y + j * ldy;
				float temp = 0.0;
				SPBLAS(temp, +, i, Ap, Ai, Av, _x)
				_y[i] = a * temp;
			}
		}
	}
	else if (b == 1.0)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		for (int i = 0; i < n; ++i)
		{
			for (int j = 0; j < m; ++j)
			{
				const float* restrict _x = x + j * ldx;
				float* restrict _y = y + j * ldy;
				float temp = 0.0;
				SPBLAS(temp, +, i, Ap, Ai, Av, _x)
				_y[i] += a * temp;
			}
		}
	}
	else if (b == -1.0)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		for (int i = 0; i < n; ++i)
		{
			for (int j = 0; j < m; ++j)
			{
				const float* restrict _x = x + j * ldx;
				float* restrict _y = y + j * ldy;
				float temp = 0.0;
				SPBLAS(temp, +, i, Ap, Ai, Av, _x)
				_y[i] = -_y[i] + a * temp;
			}
		}
	}
	else
	{
		float c = b / a;
		if (c == 1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				for (int j = 0; j < m; ++j)
				{
					const float* restrict _x = x + j * ldx;
					float* restrict _y = y + j * ldy;
					float temp = _y[i];
					SPBLAS(temp, +, i, Ap, Ai, Av, _x)
					_y[i] = a * temp;
				}
			}
		}
		else if (c == -1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				for (int j = 0; j < m; ++j)
				{
					const float* restrict _x = x + j * ldx;
					float* restrict _y = y + j * ldy;
					float temp = -_y[i];
					SPBLAS(temp, +, i, Ap, Ai, Av, _x)
					_y[i] = a * temp;
				}
			}
		}
		else
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				for (int j = 0; j < m; ++j)
				{
					const float* restrict _x = x + j * ldx;
					float* restrict _y = y + j * ldy;
					float temp = c * _y[i];
					SPBLAS(temp, +, i, Ap, Ai, Av, _x)
					_y[i] = a * temp;
				}
			}
		}
	}
}

void spblas_dcsrmm(int n, int m, double a, const int* restrict Ap, const int* restrict Ai, const double* restrict Av, int ldx, const double* restrict x, double b, int ldy, double* restrict y)
{
	if (a == 0.0)
	{
		for (int j = 0; j < m; ++j)
			blas_dscal(n, b, y + j * ldy);
	}
	if (a == 1.0)
	{
		if (b == 0.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				for (int j = 0; j < m; ++j)
				{
					const double* restrict _x = x + j * ldx;
					double* restrict _y = y + j * ldy;
					double temp = 0.0;
					SPBLAS(temp, +, i, Ap, Ai, Av, _x)
					_y[i] = temp;
				}
			}
		}
		else if (b == 1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				for (int j = 0; j < m; ++j)
				{
					const double* restrict _x = x + j * ldx;
					double* restrict _y = y + j * ldy;
					double temp = _y[i];
					SPBLAS(temp, +, i, Ap, Ai, Av, _x)
					_y[i] = temp;
				}
			}
		}
		else if (b == -1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				for (int j = 0; j < m; ++j)
				{
					const double* restrict _x = x + j * ldx;
					double* restrict _y = y + j * ldy;
					double temp = -_y[i];
					SPBLAS(temp, +, i, Ap, Ai, Av, _x)
					_y[i] = temp;
				}
			}
		}
		else
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				for (int j = 0; j < m; ++j)
				{
					const double* restrict _x = x + j * ldx;
					double* restrict _y = y + j * ldy;
					double temp = b * _y[i];
					SPBLAS(temp, +, i, Ap, Ai, Av, _x)
					_y[i] = temp;
				}
			}
		}
	}
	else if (a == -1.0)
	{
		if (b == 0.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				for (int j = 0; j < m; ++j)
				{
					const double* restrict _x = x + j * ldx;
					double* restrict _y = y + j * ldy;
					double temp = 0.0;
					SPBLAS(temp, -, i, Ap, Ai, Av, _x)
					_y[i] = temp;
				}
			}
		}
		else if (b == 1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				for (int j = 0; j < m; ++j)
				{
					const double* restrict _x = x + j * ldx;
					double* restrict _y = y + j * ldy;
					double temp = _y[i];
					SPBLAS(temp, -, i, Ap, Ai, Av, _x)
					_y[i] = temp;
				}
			}
		}
		else if (b == -1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				for (int j = 0; j < m; ++j)
				{
					const double* restrict _x = x + j * ldx;
					double* restrict _y = y + j * ldy;
					double temp = -_y[i];
					SPBLAS(temp, -, i, Ap, Ai, Av, _x)
					_y[i] = temp;
				}
			}
		}
		else
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				for (int j = 0; j < m; ++j)
				{
					const double* restrict _x = x + j * ldx;
					double* restrict _y = y + j * ldy;
					double temp = b * _y[i];
					SPBLAS(temp, -, i, Ap, Ai, Av, _x)
					_y[i] = temp;
				}
			}
		}
	}
	else if (b == 0.0)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		for (int i = 0; i < n; ++i)
		{
			for (int j = 0; j < m; ++j)
			{
				const double* restrict _x = x + j * ldx;
				double* restrict _y = y + j * ldy;
				double temp = 0.0;
				SPBLAS(temp, +, i, Ap, Ai, Av, _x)
				_y[i] = a * temp;
			}
		}
	}
	else if (b == 1.0)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		for (int i = 0; i < n; ++i)
		{
			for (int j = 0; j < m; ++j)
			{
				const double* restrict _x = x + j * ldx;
				double* restrict _y = y + j * ldy;
				double temp = 0.0;
				SPBLAS(temp, +, i, Ap, Ai, Av, _x)
				_y[i] += a * temp;
			}
		}
	}
	else if (b == -1.0)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		for (int i = 0; i < n; ++i)
		{
			for (int j = 0; j < m; ++j)
			{
				const double* restrict _x = x + j * ldx;
				double* restrict _y = y + j * ldy;
				double temp = 0.0;
				SPBLAS(temp, +, i, Ap, Ai, Av, _x)
				_y[i] = -_y[i] + a * temp;
			}
		}
	}
	else
	{
		double c = b / a;
		if (c == 1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				for (int j = 0; j < m; ++j)
				{
					const double* restrict _x = x + j * ldx;
					double* restrict _y = y + j * ldy;
					double temp = _y[i];
					SPBLAS(temp, +, i, Ap, Ai, Av, _x)
					_y[i] = a * temp;
				}
			}
		}
		else if (c == -1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				for (int j = 0; j < m; ++j)
				{
					const double* restrict _x = x + j * ldx;
					double* restrict _y = y + j * ldy;
					double temp = -_y[i];
					SPBLAS(temp, +, i, Ap, Ai, Av, _x)
					_y[i] = a * temp;
				}
			}
		}
		else
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				for (int j = 0; j < m; ++j)
				{
					const double* restrict _x = x + j * ldx;
					double* restrict _y = y + j * ldy;
					double temp = c * _y[i];
					SPBLAS(temp, +, i, Ap, Ai, Av, _x)
					_y[i] = a * temp;
				}
			}
		}
	}
}

void spblas_ccsrmm(int n, int m, complex a, const int* restrict Ap, const int* restrict Ai, const complex* restrict Av, int ldx, const complex* restrict x, complex b, int ldy, complex* restrict y)
{
	if (a == 0.0)
	{
		for (int j = 0; j < m; ++j)
			blas_cscal(n, b, y + j * ldy);
	}
	if (a == 1.0)
	{
		if (b == 0.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				for (int j = 0; j < m; ++j)
				{
					const complex* restrict _x = x + j * ldx;
					complex* restrict _y = y + j * ldy;
					complex temp = 0.0;
					SPBLAS(temp, +, i, Ap, Ai, Av, _x)
					_y[i] = temp;
				}
			}
		}
		else if (b == 1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				for (int j = 0; j < m; ++j)
				{
					const complex* restrict _x = x + j * ldx;
					complex* restrict _y = y + j * ldy;
					complex temp = _y[i];
					SPBLAS(temp, +, i, Ap, Ai, Av, _x)
					_y[i] = temp;
				}
			}
		}
		else if (b == -1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				for (int j = 0; j < m; ++j)
				{
					const complex* restrict _x = x + j * ldx;
					complex* restrict _y = y + j * ldy;
					complex temp = -_y[i];
					SPBLAS(temp, +, i, Ap, Ai, Av, _x)
					_y[i] = temp;
				}
			}
		}
		else
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				for (int j = 0; j < m; ++j)
				{
					const complex* restrict _x = x + j * ldx;
					complex* restrict _y = y + j * ldy;
					complex temp = b * _y[i];
					SPBLAS(temp, +, i, Ap, Ai, Av, _x)
					_y[i] = temp;
				}
			}
		}
	}
	else if (a == -1.0)
	{
		if (b == 0.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				for (int j = 0; j < m; ++j)
				{
					const complex* restrict _x = x + j * ldx;
					complex* restrict _y = y + j * ldy;
					complex temp = 0.0;
					SPBLAS(temp, -, i, Ap, Ai, Av, _x)
					_y[i] = temp;
				}
			}
		}
		else if (b == 1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				for (int j = 0; j < m; ++j)
				{
					const complex* restrict _x = x + j * ldx;
					complex* restrict _y = y + j * ldy;
					complex temp = _y[i];
					SPBLAS(temp, -, i, Ap, Ai, Av, _x)
					_y[i] = temp;
				}
			}
		}
		else if (b == -1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				for (int j = 0; j < m; ++j)
				{
					const complex* restrict _x = x + j * ldx;
					complex* restrict _y = y + j * ldy;
					complex temp = -_y[i];
					SPBLAS(temp, -, i, Ap, Ai, Av, _x)
					_y[i] = temp;
				}
			}
		}
		else
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				for (int j = 0; j < m; ++j)
				{
					const complex* restrict _x = x + j * ldx;
					complex* restrict _y = y + j * ldy;
					complex temp = b * _y[i];
					SPBLAS(temp, -, i, Ap, Ai, Av, _x)
					_y[i] = temp;
				}
			}
		}
	}
	else if (b == 0.0)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		for (int i = 0; i < n; ++i)
		{
			for (int j = 0; j < m; ++j)
			{
				const complex* restrict _x = x + j * ldx;
				complex* restrict _y = y + j * ldy;
				complex temp = 0.0;
				SPBLAS(temp, +, i, Ap, Ai, Av, _x)
				_y[i] = a * temp;
			}
		}
	}
	else if (b == 1.0)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		for (int i = 0; i < n; ++i)
		{
			for (int j = 0; j < m; ++j)
			{
				const complex* restrict _x = x + j * ldx;
				complex* restrict _y = y + j * ldy;
				complex temp = 0.0;
				SPBLAS(temp, +, i, Ap, Ai, Av, _x)
				_y[i] += a * temp;
			}
		}
	}
	else if (b == -1.0)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		for (int i = 0; i < n; ++i)
		{
			for (int j = 0; j < m; ++j)
			{
				const complex* restrict _x = x + j * ldx;
				complex* restrict _y = y + j * ldy;
				complex temp = 0.0;
				SPBLAS(temp, +, i, Ap, Ai, Av, _x)
				_y[i] = -_y[i] + a * temp;
			}
		}
	}
	else
	{
		complex c = b / a;
		if (c == 1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				for (int j = 0; j < m; ++j)
				{
					const complex* restrict _x = x + j * ldx;
					complex* restrict _y = y + j * ldy;
					complex temp = _y[i];
					SPBLAS(temp, +, i, Ap, Ai, Av, _x)
					_y[i] = a * temp;
				}
			}
		}
		else if (c == -1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				for (int j = 0; j < m; ++j)
				{
					const complex* restrict _x = x + j * ldx;
					complex* restrict _y = y + j * ldy;
					complex temp = -_y[i];
					SPBLAS(temp, +, i, Ap, Ai, Av, _x)
					_y[i] = a * temp;
				}
			}
		}
		else
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				for (int j = 0; j < m; ++j)
				{
					const complex* restrict _x = x + j * ldx;
					complex* restrict _y = y + j * ldy;
					complex temp = c * _y[i];
					SPBLAS(temp, +, i, Ap, Ai, Av, _x)
					_y[i] = a * temp;
				}
			}
		}
	}
}

void spblas_zcsrmm(int n, int m, zomplex a, const int* restrict Ap, const int* restrict Ai, const zomplex* restrict Av, int ldx, const zomplex* restrict x, zomplex b, int ldy, zomplex* restrict y)
{
	if (a == 0.0)
	{
		for (int j = 0; j < m; ++j)
			blas_zscal(n, b, y + j * ldy);
	}
	if (a == 1.0)
	{
		if (b == 0.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				for (int j = 0; j < m; ++j)
				{
					const zomplex* restrict _x = x + j * ldx;
					zomplex* restrict _y = y + j * ldy;
					zomplex temp = 0.0;
					SPBLAS(temp, +, i, Ap, Ai, Av, _x)
					_y[i] = temp;
				}
			}
		}
		else if (b == 1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				for (int j = 0; j < m; ++j)
				{
					const zomplex* restrict _x = x + j * ldx;
					zomplex* restrict _y = y + j * ldy;
					zomplex temp = _y[i];
					SPBLAS(temp, +, i, Ap, Ai, Av, _x)
					_y[i] = temp;
				}
			}
		}
		else if (b == -1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				for (int j = 0; j < m; ++j)
				{
					const zomplex* restrict _x = x + j * ldx;
					zomplex* restrict _y = y + j * ldy;
					zomplex temp = -_y[i];
					SPBLAS(temp, +, i, Ap, Ai, Av, _x)
					_y[i] = temp;
				}
			}
		}
		else
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				for (int j = 0; j < m; ++j)
				{
					const zomplex* restrict _x = x + j * ldx;
					zomplex* restrict _y = y + j * ldy;
					zomplex temp = b * _y[i];
					SPBLAS(temp, +, i, Ap, Ai, Av, _x)
					_y[i] = temp;
				}
			}
		}
	}
	else if (a == -1.0)
	{
		if (b == 0.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				for (int j = 0; j < m; ++j)
				{
					const zomplex* restrict _x = x + j * ldx;
					zomplex* restrict _y = y + j * ldy;
					zomplex temp = 0.0;
					SPBLAS(temp, -, i, Ap, Ai, Av, _x)
					_y[i] = temp;
				}
			}
		}
		else if (b == 1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				for (int j = 0; j < m; ++j)
				{
					const zomplex* restrict _x = x + j * ldx;
					zomplex* restrict _y = y + j * ldy;
					zomplex temp = _y[i];
					SPBLAS(temp, -, i, Ap, Ai, Av, _x)
					_y[i] = temp;
				}
			}
		}
		else if (b == -1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				for (int j = 0; j < m; ++j)
				{
					const zomplex* restrict _x = x + j * ldx;
					zomplex* restrict _y = y + j * ldy;
					zomplex temp = -_y[i];
					SPBLAS(temp, -, i, Ap, Ai, Av, _x)
					_y[i] = temp;
				}
			}
		}
		else
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				for (int j = 0; j < m; ++j)
				{
					const zomplex* restrict _x = x + j * ldx;
					zomplex* restrict _y = y + j * ldy;
					zomplex temp = b * _y[i];
					SPBLAS(temp, -, i, Ap, Ai, Av, _x)
					_y[i] = temp;
				}
			}
		}
	}
	else if (b == 0.0)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		for (int i = 0; i < n; ++i)
		{
			for (int j = 0; j < m; ++j)
			{
				const zomplex* restrict _x = x + j * ldx;
				zomplex* restrict _y = y + j * ldy;
				zomplex temp = 0.0;
				SPBLAS(temp, +, i, Ap, Ai, Av, _x)
				_y[i] = a * temp;
			}
		}
	}
	else if (b == 1.0)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		for (int i = 0; i < n; ++i)
		{
			for (int j = 0; j < m; ++j)
			{
				const zomplex* restrict _x = x + j * ldx;
				zomplex* restrict _y = y + j * ldy;
				zomplex temp = 0.0;
				SPBLAS(temp, +, i, Ap, Ai, Av, _x)
				_y[i] += a * temp;
			}
		}
	}
	else if (b == -1.0)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		for (int i = 0; i < n; ++i)
		{
			for (int j = 0; j < m; ++j)
			{
				const zomplex* restrict _x = x + j * ldx;
				zomplex* restrict _y = y + j * ldy;
				zomplex temp = 0.0;
				SPBLAS(temp, +, i, Ap, Ai, Av, _x)
				_y[i] = -_y[i] + a * temp;
			}
		}
	}
	else
	{
		zomplex c = b / a;
		if (c == 1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				for (int j = 0; j < m; ++j)
				{
					const zomplex* restrict _x = x + j * ldx;
					zomplex* restrict _y = y + j * ldy;
					zomplex temp = _y[i];
					SPBLAS(temp, +, i, Ap, Ai, Av, _x)
					_y[i] = a * temp;
				}
			}
		}
		else if (c == -1.0)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				for (int j = 0; j < m; ++j)
				{
					const zomplex* restrict _x = x + j * ldx;
					zomplex* restrict _y = y + j * ldy;
					zomplex temp = -_y[i];
					SPBLAS(temp, +, i, Ap, Ai, Av, _x)
					_y[i] = a * temp;
				}
			}
		}
		else
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				for (int j = 0; j < m; ++j)
				{
					const zomplex* restrict _x = x + j * ldx;
					zomplex* restrict _y = y + j * ldy;
					zomplex temp = c * _y[i];
					SPBLAS(temp, +, i, Ap, Ai, Av, _x)
					_y[i] = a * temp;
				}
			}
		}
	}
}

void spblas_scsrtrsm(int n, int m, const float* restrict drcp, const int* restrict Ap, const int* restrict Ai, const float* restrict Av, int ldx, float* restrict x)
{
	int uplo = 0;
	while (uplo < n)
	{
		if (Ap[0] < Ap[uplo + 1])
		{
			uplo = Ai[Ap[0]] < uplo;
			break;
		}
		++uplo;
	}

	if (uplo)
	{
		if (drcp)
		{
			for (int i = 0; i < n; ++i)
			{
				for (int j = 0; j < m; ++j)
				{
					float* restrict _x = x + j * ldx;
					float temp = _x[i];
					SPBLAS(temp, -, i, Ap, Ai, Av, _x)
					_x[i] = temp * drcp[i];
				}
			}
		}
		else
		{
			for (int i = 0; i < n; ++i)
			{
				for (int j = 0; j < m; ++j)
				{
					float* restrict _x = x + j * ldx;
					float temp = _x[i];
					SPBLAS(temp, -, i, Ap, Ai, Av, _x)
					_x[i] = temp;
				}
			}
		}
	}
	else
	{
		if (drcp)
		{
			for (int i = n - 1; i >= 0; --i)
			{
				for (int j = 0; j < m; ++j)
				{
					float* restrict _x = x + j * ldx;
					float temp = _x[i];
					SPBLAS_R(temp, -, i, Ap, Ai, Av, _x)
					_x[i] = temp * drcp[i];
				}
			}
		}
		else
		{
			for (int i = n - 1; i >= 0; --i)
			{
				for (int j = 0; j < m; ++j)
				{
					float* restrict _x = x + j * ldx;
					float temp = _x[i];
					SPBLAS_R(temp, -, i, Ap, Ai, Av, _x)
					_x[i] = temp;
				}
			}
		}
	}
}

}