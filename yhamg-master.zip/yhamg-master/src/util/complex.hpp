/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef COMPLEX_H
#define COMPLEX_H

#include <cmath>

namespace YHAMG
{

struct complex
{
	float real;
	float imag;

	complex(float re = 0.0, float im = 0.0)
		: real(re),
		imag(im)
	{
	}

	complex(const complex &a)
		: real(a.real),
		imag(a.imag)
	{
	}

	complex operator+() const
	{
		return *this;
	}

	complex operator-() const
	{
		return complex(-real, -imag);
	}

	complex operator+(const float& a) const
	{
		return complex(real + a, imag);
	}

	complex operator-(const float& a) const
	{
		return complex(real - a, imag);
	}

	complex operator*(const float& a) const
	{
		return complex(real * a, imag * a);
	}

	complex operator/(const float& a) const
	{
		return complex(real / a, imag / a);
	}

	complex operator+(const complex& a) const
	{
		return complex(real + a.real, imag + a.imag);
	}

	complex operator-(const complex& a) const
	{
		return complex(real - a.real, imag - a.imag);
	}

	complex operator*(const complex& a) const
	{
		return complex(real * a.real - imag * a.imag, real * a.imag + imag * a.real);
	}

	complex operator/(const complex& a) const
	{
		float denom = 1.0 / (a.real * a.real + a.imag * a.imag);
		return complex((real * a.real + imag * a.imag) * denom, (-real * a.imag + imag * a.real) * denom);
	}

	complex& operator+=(const float& a)
	{
		real += a;
		return *this;
	}

	complex& operator-=(const float& a)
	{
		real -= a;
		return *this;
	}

	complex& operator*=(const float& a)
	{
		real *= a;
		imag *= a;
		return *this;
	}

	complex& operator/=(const float& a)
	{
		real /= a;
		imag /= a;
		return *this;
	}
	
	complex& operator+=(const complex& a)
	{
		real += a.real;
		imag += a.imag;
		return *this;
	}

	complex& operator-=(const complex& a)
	{
		real -= a.real;
		imag -= a.imag;
		return *this;
	}

	complex& operator*=(const complex& a)
	{
		float temp = real * a.real - imag * a.imag;
		imag = real * a.imag + imag * a.real;
		real = temp;
		return *this;
	}

	complex& operator/=(const complex& a)
	{
		float denom = 1.0 / (a.real * a.real + a.imag * a.imag);
		float temp = (real * a.real + imag * a.imag) * denom;
		imag = (-real * a.imag + imag * a.real) * denom;
		real = temp;
		return *this;
	}

	bool operator==(const float& a) const
	{
		return real == a && imag == 0;
	}

	bool operator!=(const float& a) const
	{
		return real != a || imag != 0;
	}

	bool operator==(const complex& a) const
	{
		return real == a.real && imag == a.imag;
	}

	bool operator!=(const complex& a) const
	{
		return real != a.real || imag != a.imag;
	}

	complex& operator=(const float& a)
	{
		real = a;
		imag = 0.0;
		return *this;
	}

	complex& operator=(const complex& a)
	{
		real = a.real;
		imag = a.imag;
		return *this;
	}
};

static inline float creal(const complex a)
{
	return a.real;
}

static inline float cimag(const complex a)
{
	return a.imag;
}

static inline float cabs(const complex a)
{
	return sqrt(a.real * a.real + a.imag * a.imag);
}

static inline complex cconj(const complex a)
{
	return complex(a.real, -a.imag);
}

static inline complex csqrt(const complex a)
{
	if (a.real > 0)
	{
		float temp = sqrt(0.5 * (cabs(a) + a.real));
		return complex(temp, 0.5 * a.imag / temp);
	}
	else
	{
		float temp = sqrt(0.5 * (cabs(a) - a.real));
		if (a.imag >= 0)
			return complex(0.5 * a.imag / temp, temp);
		return complex(-0.5 * a.imag / temp, -temp);
	}
}

struct zomplex
{
	double real;
	double imag;

	zomplex(double re = 0.0, double im = 0.0)
		: real(re),
		imag(im)
	{
	}

	zomplex(const zomplex &a)
		: real(a.real),
		imag(a.imag)
	{
	}

	zomplex operator+() const
	{
		return *this;
	}

	zomplex operator-() const
	{
		return zomplex(-real, -imag);
	}

	zomplex operator+(const double& a) const
	{
		return zomplex(real + a, imag);
	}

	zomplex operator-(const double& a) const
	{
		return zomplex(real - a, imag);
	}

	zomplex operator*(const double& a) const
	{
		return zomplex(real * a, imag * a);
	}

	zomplex operator/(const double& a) const
	{
		return zomplex(real / a, imag / a);
	}

	zomplex operator+(const zomplex& a) const
	{
		return zomplex(real + a.real, imag + a.imag);
	}

	zomplex operator-(const zomplex& a) const
	{
		return zomplex(real - a.real, imag - a.imag);
	}

	zomplex operator*(const zomplex& a) const
	{
		return zomplex(real * a.real - imag * a.imag, real * a.imag + imag * a.real);
	}

	zomplex operator/(const zomplex& a) const
	{
		double denom = 1.0 / (a.real * a.real + a.imag * a.imag);
		return zomplex((real * a.real + imag * a.imag) * denom, (-real * a.imag + imag * a.real) * denom);
	}

	zomplex& operator+=(const double& a)
	{
		real += a;
		return *this;
	}

	zomplex& operator-=(const double& a)
	{
		real -= a;
		return *this;
	}

	zomplex& operator*=(const double& a)
	{
		real *= a;
		imag *= a;
		return *this;
	}

	zomplex& operator/=(const double& a)
	{
		real /= a;
		imag /= a;
		return *this;
	}
	
	zomplex& operator+=(const zomplex& a)
	{
		real += a.real;
		imag += a.imag;
		return *this;
	}

	zomplex& operator-=(const zomplex& a)
	{
		real -= a.real;
		imag -= a.imag;
		return *this;
	}

	zomplex& operator*=(const zomplex& a)
	{
		double temp = real * a.real - imag * a.imag;
		imag = real * a.imag + imag * a.real;
		real = temp;
		return *this;
	}

	zomplex& operator/=(const zomplex& a)
	{
		double denom = 1.0 / (a.real * a.real + a.imag * a.imag);
		double temp = (real * a.real + imag * a.imag) * denom;
		imag = (-real * a.imag + imag * a.real) * denom;
		real = temp;
		return *this;
	}

	bool operator==(const double& a) const
	{
		return real == a && imag == 0;
	}

	bool operator!=(const double& a) const
	{
		return real != a || imag != 0;
	}

	bool operator==(const zomplex& a) const
	{
		return real == a.real && imag == a.imag;
	}

	bool operator!=(const zomplex& a) const
	{
		return real != a.real || imag != a.imag;
	}

	zomplex& operator=(const double& a)
	{
		real = a;
		imag = 0.0;
		return *this;
	}

	zomplex& operator=(const zomplex& a)
	{
		real = a.real;
		imag = a.imag;
		return *this;
	}
};

static inline double zreal(const zomplex a)
{
	return a.real;
}

static inline double zimag(const zomplex a)
{
	return a.imag;
}

static inline double zabs(const zomplex a)
{
	return sqrt(a.real * a.real + a.imag * a.imag);
}

static inline zomplex zconj(const zomplex a)
{
	return zomplex(a.real, -a.imag);
}

static inline zomplex zsqrt(const zomplex a)
{
	if (a.real > 0)
	{
		double temp = sqrt(0.5 * (zabs(a) + a.real));
		return zomplex(temp, 0.5 * a.imag / temp);
	}
	else
	{
		double temp = sqrt(0.5 * (zabs(a) - a.real));
		if (a.imag >= 0)
			return zomplex(0.5 * a.imag / temp, temp);
		return zomplex(-0.5 * a.imag / temp, -temp);
	}
}

}

#endif