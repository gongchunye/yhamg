/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef SPBLAS_H
#define SPBLAS_H

#include "complex.hpp"

namespace YHAMG
{

void spblas_scsrmv(int n, float a, const int* restrict Ap, const int* restrict Ai, const float* restrict Av, const float* restrict x, float b, float* restrict y);
void spblas_dcsrmv(int n, double a, const int* restrict Ap, const int* restrict Ai, const double* restrict Av, const double* restrict x, double b, double* restrict y);
void spblas_ccsrmv(int n, complex a, const int* restrict Ap, const int* restrict Ai, const complex* restrict Av, const complex* restrict x, complex b, complex* restrict y);
void spblas_zcsrmv(int n, zomplex a, const int* restrict Ap, const int* restrict Ai, const zomplex* restrict Av, const zomplex* restrict x, zomplex b, zomplex* restrict y);

void spblas_scsrtrsv(int n, const float* restrict drcp, const int* restrict Ap, const int* restrict Ai, const float* restrict Av, float* restrict x);
void spblas_dcsrtrsv(int n, const double* restrict drcp, const int* restrict Ap, const int* restrict Ai, const double* restrict Av, double* restrict x);
void spblas_ccsrtrsv(int n, const complex* restrict drcp, const int* restrict Ap, const int* restrict Ai, const complex* restrict Av, complex* restrict x);
void spblas_zcsrtrsv(int n, const zomplex* restrict drcp, const int* restrict Ap, const int* restrict Ai, const zomplex* restrict Av, zomplex* restrict x);

void spblas_scsrmm(int n, int m, float a, const int* restrict Ap, const int* restrict Ai, const float* restrict Av, int ldx, const float* restrict x, float b, int ldy, float* restrict y);
void spblas_dcsrmm(int n, int m, double a, const int* restrict Ap, const int* restrict Ai, const double* restrict Av, int ldx, const double* restrict x, double b, int ldy, double* restrict y);
void spblas_ccsrmm(int n, int m, complex a, const int* restrict Ap, const int* restrict Ai, const complex* restrict Av, int ldx, const complex* restrict x, complex b, int ldy, complex* restrict y);
void spblas_zcsrmm(int n, int m, zomplex a, const int* restrict Ap, const int* restrict Ai, const zomplex* restrict Av, int ldx, const zomplex* restrict x, zomplex b, int ldy, zomplex* restrict y);

void spblas_scsrtrsm(int n, int m, const float* restrict drcp, const int* restrict Ap, const int* restrict Ai, const float* restrict Av, int ldx, float* restrict x);
void spblas_dcsrtrsm(int n, int m, const double* restrict drcp, const int* restrict Ap, const int* restrict Ai, const double* restrict Av, int ldx, double* restrict x);
void spblas_ccsrtrsm(int n, int m, const complex* restrict drcp, const int* restrict Ap, const int* restrict Ai, const complex* restrict Av, int ldx, complex* restrict x);
void spblas_zcsrtrsm(int n, int m, const zomplex* restrict drcp, const int* restrict Ap, const int* restrict Ai, const zomplex* restrict Av, int ldx, zomplex* restrict x);

}

#endif
