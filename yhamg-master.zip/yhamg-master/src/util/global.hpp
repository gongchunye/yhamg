/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef GLOBAL_H
#define GLOBAL_H

#include <stdint.h>

namespace YHAMG
{

struct global
{
	unsigned int indl;
	unsigned int from;
	
	global(unsigned int _indl, unsigned int _from = 0)
	: indl(_indl),
	from(_from)
	{
	}

	global(uint64_t indg = 0)
	: indl(indg & 0xffffffff),
	from(indg >> 32)
	{
	}
	
	operator uint64_t() const
	{
		return (uint64_t)from << 32 | (uint64_t)indl;
	}
	
	bool operator<(const global& a) const
	{
		return from == a.from ? indl < a.indl : from < a.from;
	}
};

static inline unsigned int local(global indg)
{
	return indg.indl;
}

static inline unsigned int owner(global indg)
{
	return indg.from;
}

}

#endif