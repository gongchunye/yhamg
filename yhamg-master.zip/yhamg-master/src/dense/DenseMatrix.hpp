/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef DenseMatrix_H
#define DenseMatrix_H

#include "COOMatrix.hpp"
#include "CSRMatrix.hpp"
#include "BSRMatrix.hpp"

namespace YHAMG
{

struct DenseMatrix : public Operator
{
	int ref;
	int size[2];
	double* values;

	DenseMatrix();
	DenseMatrix(int n, int m, double* values, int ref);
	DenseMatrix(const DenseMatrix& A);
	DenseMatrix(DenseMatrix&& A);
	DenseMatrix(const COOMatrix& A);
	DenseMatrix(const CSRMatrix& A);
	DenseMatrix(const BSRMatrix& A);
	~DenseMatrix();
	DenseMatrix& operator=(const DenseMatrix& A);
	DenseMatrix& operator=(DenseMatrix&& A);
	DenseMatrix& operator=(const COOMatrix& A);
	DenseMatrix& operator=(const CSRMatrix& A);
	DenseMatrix& operator=(const BSRMatrix& A);
	double& operator()(int i, int j) const;

	void Free();
	void Resize(int n, int m);
	void Refer(const DenseMatrix& A);
	int InSize() const;
	int OutSize() const;
	void Apply(const Vector& x, const Vector& y) const;
	void Apply(const MultiVector& X, const MultiVector& Y) const;
};

}

#endif
