/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "blas.hpp"
#include "DenseMatrix.hpp"

namespace YHAMG
{

DenseMatrix::DenseMatrix()
	: ref(0),
	size{0, 0},
	values(0)
{
}

DenseMatrix::DenseMatrix(int n, int m, double* _values, int _ref)
	: ref(_ref),
	size{n, m},
	values(_values)
{
}

DenseMatrix::DenseMatrix(const DenseMatrix& A)
	: ref(0),
	size{A.size[0], A.size[1]},
	values(new double[A.size[0] * A.size[1]])
{
	blas_dcopy(size[0] * size[1], A.values, values);
}

DenseMatrix::DenseMatrix(DenseMatrix&& A)
	: ref(A.ref),
	size{A.size[0], A.size[1]},
	values(A.values)
{
	A.ref = 1;
}


DenseMatrix::DenseMatrix(const COOMatrix& A)
	: ref(0),
	size{A.size[0], A.size[1]},
	values(new double[A.size[0] * A.size[1]])
{
	int nnz = A.nnz;
	int* Ai = A.rowind;
	int* Aj = A.colind;
	double* Av = A.values;

	blas_dfill(size[0] * size[1], 0.0, values);

	for (int j = 0; j < nnz; ++j)
		values[Ai[j] + Aj[j] * size[0]] = Av[j];
}

DenseMatrix::DenseMatrix(const CSRMatrix& A)
	: ref(0),
	size{A.size[0], A.size[1]},
	values(new double[A.size[0] * A.size[1]])
{
	int* Ap = A.rowptr;
	int* Ai = A.colind;
	double* Av = A.values;

	blas_dfill(size[0] * size[1], 0.0, values);

	for (int i = 0; i < size[0]; ++i)
		for (int j = Ap[i]; j < Ap[i + 1]; ++j)
			values[i + Ai[j] * size[0]] = Av[j];
}

DenseMatrix::DenseMatrix(const BSRMatrix& A)
	: ref(0),
	size{A.size[0] * A.bsize, A.size[1] * A.bsize},
	values(new double[A.size[0] * A.size[1] * A.bsize * A.bsize])
{
	int bsize = A.bsize;
	int bnnz = bsize * bsize;
	int* Ap = A.rowptr;
	int* Ai = A.colind;
	double* Av = A.values;

	blas_dfill(size[0] * size[1], 0.0, values);

	for (int i = 0; i < size[0]; ++i)
		for (int j = Ap[i]; j < Ap[i + 1]; ++j)
			for (int ii = 0; ii < bsize; ++ii)
				for (int jj = 0; jj < bsize; ++jj)
					values[i * bsize + ii + (Ai[j] * bsize + jj) * size[0]] = Av[j * bnnz + ii + jj * bsize];
}

DenseMatrix::~DenseMatrix()
{
	if (!ref && values) delete[] values;
}

DenseMatrix& DenseMatrix::operator=(const DenseMatrix& A)
{
	ref = 0;
	size[0] = A.size[0];
	size[1] = A.size[1];
	values = new double[size[0] * size[1]];

	blas_dcopy(size[0] * size[1], A.values, values);

	return *this;
}

DenseMatrix& DenseMatrix::operator=(DenseMatrix&& A)
{
	ref = A.ref;
	size[0] = A.size[0];
	size[1] = A.size[1];
	values = A.values;
	A.ref = 1;
	return *this;
}

DenseMatrix& DenseMatrix::operator=(const COOMatrix& A)
{
	ref = 0;
	size[0] = A.size[0];
	size[1] = A.size[1];
	values = new double[size[0] * size[1]];

	blas_dfill(size[0] * size[1], 0.0, values);

	int nnz = A.nnz;
	int* Ai = A.rowind;
	int* Aj = A.colind;
	double* Av = A.values;

	for (int j = 0; j < nnz; ++j)
		values[Ai[j] + Aj[j] * size[0]] = Av[j];

	return *this;
}

DenseMatrix& DenseMatrix::operator=(const CSRMatrix& A)
{
	ref = 0;
	size[0] = A.size[0];
	size[1] = A.size[1];
	values = new double[size[0] * size[1]];

	blas_dfill(size[0] * size[1], 0.0, values);

	int* Ap = A.rowptr;
	int* Ai = A.colind;
	double* Av = A.values;

	for (int i = 0; i < size[0]; ++i)
		for (int j = Ap[i]; j < Ap[i + 1]; ++j)
			values[i + Ai[j] * size[0]] = Av[j];

	return *this;
}

DenseMatrix& DenseMatrix::operator=(const BSRMatrix& A)
{
	ref = 0;
	size[0] = A.size[0] * A.bsize;
	size[1] = A.size[1] * A.bsize;
	values = new double[size[0] * size[1]];

	blas_dfill(size[0] * size[1], 0.0, values);
	
	int bsize = A.bsize;
	int bnnz = bsize * bsize;
	int* Ap = A.rowptr;
	int* Ai = A.colind;
	double* Av = A.values;

	for (int i = 0; i < size[0]; ++i)
		for (int j = Ap[i]; j < Ap[i + 1]; ++j)
			for (int ii = 0; ii < bsize; ++ii)
				for (int jj = 0; jj < bsize; ++jj)
					values[i * bsize + ii + (Ai[j] * bsize + jj) * size[0]] = Av[j * bnnz + ii + jj * bsize];

	return *this;
}

double& DenseMatrix::operator()(int i, int j) const
{
	return values[i + j * size[0]];
}

void DenseMatrix::Free()
{
	if (!ref && values) delete[] values;
	ref = 0;
	size[0] = 0;
	size[1] = 0;
	values = 0;
}

void DenseMatrix::Resize(int n, int m)
{
	if (!ref && values) delete[] values;
	ref = 0;
	size[0] = n;
	size[1] = m;
	values = new double[n * m];
}

void DenseMatrix::Refer(const DenseMatrix& A)
{
	ref = 1;
	size[0] = A.size[0];
	size[1] = A.size[1];
	values = A.values;
}

int DenseMatrix::InSize() const
{
	return size[1];
}

int DenseMatrix::OutSize() const
{
	return size[0];
}

void DenseMatrix::Apply(const Vector& x, const Vector& y) const
{
	double* xv = x.values;
	double* yv = y.values;
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
	for (int i = 0; i < size[0]; ++i)
	{
		double temp = 0.0;
		for (int j = 0; j < size[1]; ++i)
			temp += values[i + j * size[0]] * xv[j];
		yv[i] = temp;
	}
}

void DenseMatrix::Apply(const MultiVector& X, const MultiVector& Y) const
{
	int nx = X.size;
	int ny = Y.size;
	int m = X.nvec;
	double* Xv = X.values;
	double* Yv = Y.values;
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
	for (int i = 0; i < size[0]; ++i)
	{
		for (int k = 0; k < m; ++k)
		{
			double temp = 0.0;
			for (int j = 0; j < size[1]; ++i)
				temp += values[i + j * size[0]] * Xv[j + k * nx];
			Yv[i + k * ny] = temp;
		}
	}
}

}