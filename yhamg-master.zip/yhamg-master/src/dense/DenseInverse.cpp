/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "blas.hpp"
#include "DenseInverse.hpp"

#ifdef YHAMG_USE_LAPACKE
#include <lapacke.h>
#endif

namespace YHAMG
{

DenseInverse::DenseInverse(const DenseMatrix& A)
	: size(A.size[0]),
	piv(new int[A.size[0]]),
	LU(new double[A.size[0] * A.size[0]])
{
	blas_dcopy(size * size, A.values, LU);

#ifdef YHAMG_USE_LAPACKE
	LAPACKE_dgetrf(LAPACK_COL_MAJOR, size, size, LU, size, piv);
#endif
}

DenseInverse::~DenseInverse()
{
	if (piv) delete[] piv;
	if (LU) delete[] LU;
}

void DenseInverse::Free()
{
	if (piv) delete[] piv;
	if (LU) delete[] LU;
	size = 0;
	piv = 0;
	LU = 0;
}

int DenseInverse::InSize() const
{
	return size;
}

int DenseInverse::OutSize() const
{
	return size;
}

void DenseInverse::Apply(const Vector& x, const Vector& y) const
{
	y.Copy(x);
#ifdef YHAMG_USE_LAPACKE
	LAPACKE_dgetrs(LAPACK_COL_MAJOR, 'N', size, 1, LU, size, piv, y.values, size);
#endif
}

void DenseInverse::Apply(const MultiVector& X, const MultiVector& Y) const
{
	int m = X.nvec;
	int nx = X.size;
	int ny = Y.size;
	double* Xv = X.values;
	double* Yv = Y.values;
	for (int j = 0; j < m; ++j)
		for (int i = 0; i < size; ++i)
			Yv[i + j * ny] = Xv[i + j * nx];
#ifdef YHAMG_USE_LAPACKE
	LAPACKE_dgetrs(LAPACK_COL_MAJOR, 'N', size, m, LU, size, piv, Yv, ny);
#endif
}

}