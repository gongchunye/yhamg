/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "ParOperatorZero.hpp"

namespace YHAMG
{

ParOperatorZero::ParOperatorZero(MPI_Comm comm, int n)
	: ParOperator(comm),
	size{n, n}
{
}

ParOperatorZero::ParOperatorZero(MPI_Comm comm, int n, int m)
	: ParOperator(comm),
	size{n, m}
{
}

int ParOperatorZero::InSize() const
{
	return size[1];
}

int ParOperatorZero::OutSize() const
{
	return size[0];
}

void ParOperatorZero::Apply(const ParVector& x, const ParVector& y) const
{
	double* yv = y.local.values;
	for (int i = 0; i < size[0]; ++i)
		yv[i] = 0.0;
}

}