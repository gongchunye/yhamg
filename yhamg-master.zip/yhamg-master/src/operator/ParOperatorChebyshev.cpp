/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <cmath>
#include "ParOperatorChebyshev.hpp"

namespace YHAMG
{

static double LargestEigenvalueEstimate(const ParOperator& A, int iteration)
{
	MPI_Comm comm = A.comm;
	int n = A.OutSize();

	ParVector x(comm), y(comm);
	x.Resize(n);
	y.Resize(n);

	y.FillRandom();

	for (int k = 0; k < iteration; ++k)
	{
		ParVecAXPBY(1.0 / sqrt(ParVecDot(y, y)), y, 0.0, x);
		A.Apply(x, y);
	}

	return ParVecDot(x, y);
}

ParOperatorChebyshev::ParOperatorChebyshev(int _order, double _eigen_ratio, const ParOperator& _A)
	: ParOperator(_A.comm),
	lambda(1.1 * LargestEigenvalueEstimate(_A, 10)),
	order(_order),
	eigen_ratio(_eigen_ratio), 
	A(&_A),
	z(_A.comm, _A.OutSize()),
	r(_A.comm, _A.OutSize())
{
}

int ParOperatorChebyshev::InSize() const
{
	return A->InSize();
}

int ParOperatorChebyshev::OutSize() const
{
	return A->OutSize();
}

void ParOperatorChebyshev::Apply(const ParVector& b, const ParVector& x) const
{
	double alpha = lambda;
	double beta  = lambda * eigen_ratio;

	double theta, delta, sigma, rho, rho1;

	r.Copy(b);
	theta = 2.0 / (beta + alpha);
	delta = 2.0 / (beta - alpha);
	sigma = delta / theta;
	rho = 1.0 / sigma;
	
	for (int k = 0; k < order; ++k)
	{
		if (k == 0)
		{
			ParVecAXPBY(theta, r, 0.0, z);
			ParVecAXPBY(1.0, z, 0.0, x);
		}
		else
		{
			A->Apply(x, r);
			ParVecAXPBY(1.0, b, -1.0, r);
			rho = 1.0 / (2.0 * sigma - rho1);
			ParVecAXPBY(2.0 * rho * delta, r, rho * rho1, z);
			x.AddScaled(1.0, z);
		}

		rho1 = rho;
	}
}

void ParOperatorChebyshev::Apply(const ParMultiVector& B, const ParMultiVector& X) const
{
	int m = X.local.nvec;
	ParMultiVector Z(comm, m, A->OutSize());
	ParMultiVector R(comm, m, A->OutSize());
	
	double alpha = lambda;
	double beta  = lambda * eigen_ratio;
	double theta, delta, sigma, rho, rho1;

	for (int j = 0; j < m; ++j)
		R(j).Copy(B(j));
	
	theta = (beta + alpha) * 0.5;
	delta = 2.0 / (beta - alpha);
	sigma = theta * delta;
	rho = 1.0 / sigma;
	
	for (int k = 0; k < order; ++k)
	{
		if (k == 0)
		{
			for (int j = 0; j < m; ++j)
				ParVecAXPBY(1.0 / theta, R(j), 0.0, Z(j));
			for (int j = 0; j < m; ++j)
				ParVecAXPBY(1.0, Z(j), 0.0, X(j));
		}
		else
		{
			A->Apply(X, R);
			for (int j = 0; j < m; ++j)
				ParVecAXPBY(1.0, B(j), -1.0, R(j));
			rho = 1.0 / (2.0 * sigma - rho1);
			for (int j = 0; j < m; ++j)
				ParVecAXPBY(2.0 * rho * delta, R(j), rho * rho1, Z(j));
			for (int j = 0; j < m; ++j)
				X(j).AddScaled(1.0, Z(j));
		}

		rho1 = rho;
	}
	
}

}