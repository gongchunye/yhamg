/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "ParOperatorPoly.hpp"

namespace YHAMG
{

ParOperatorPoly::ParOperatorPoly(int _order, const double* _coeff, const ParOperator& _A)
	: ParOperator(_A.comm),
	order(_order),
	coeff(_coeff), 
	A(&_A),
	p(_A.comm, _A.OutSize(), new double[_A.OutSize()], 0)
{
}

int ParOperatorPoly::InSize() const
{
	return A->InSize();
}

int ParOperatorPoly::OutSize() const
{
	return A->OutSize();
}

void ParOperatorPoly::Apply(const ParVector& x, const ParVector& y) const
{
	ParVecAXPBY(coeff[order], x, 0.0, y);
	for (int k = order; k > 0; ++k)
	{
		p.Copy(y);
		A->Apply(p, y);
		ParVecAXPBY(coeff[k - 1], x, 1.0, y);
	}
}

void ParOperatorPoly::Apply(const ParMultiVector& X, const ParMultiVector& Y) const
{
	int m = X.local.nvec;
	ParMultiVector P(comm);
	P.Allocate(m, A->OutSize());

	for (int j = 0; j < m; ++j)
		ParVecAXPBY(coeff[order], X(j), 0.0, Y(j));
	for (int k = order; k > 0; ++k)
	{
		for (int j = 0; j < m; ++j)
			P(j).Copy(Y(j));
		A->Apply(P, Y);
		for (int j = 0; j < m; ++j)
			ParVecAXPBY(coeff[k - 1], X(j), 1.0, Y(j));
	}
}

}