/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef ParOperatorCompound_H
#define ParOperatorCompound_H

#include "ParOperator.hpp"

namespace YHAMG
{

class ParOperatorCompound : public ParOperator
{
private:
	const ParOperator* A;
	const ParOperator* B;
	const ParOperator* C;
	double alpha;
	double beta;
	double gamma;
	ParVector p;
	ParVector q;

public:	
	ParOperatorCompound(double beta, const ParOperator& C, double gamma = 0.0);	
	ParOperatorCompound(double alpha, const ParOperator& B, double beta, const ParOperator& C, double gamma = 0.0);
	ParOperatorCompound(double alpha, const ParOperator& A, const ParOperator& B, double gamma = 0.0);
	ParOperatorCompound(double alpha, const ParOperator& A, const ParOperator& B, double beta, const ParOperator& C, double gamma = 0.0);
	int InSize() const;
	int OutSize() const;
	void Apply(const ParVector& x, const ParVector& y) const;
	void Apply(const ParMultiVector& X, const ParMultiVector& Y) const;
};

}

#endif