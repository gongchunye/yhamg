/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "ParOperatorDiag.hpp"

namespace YHAMG
{

ParOperatorDiag::ParOperatorDiag(const ParVector& _D)
	: D(&_D)
{
}

int ParOperatorDiag::InSize() const
{
	return D->local.size;
}

int ParOperatorDiag::OutSize() const
{
	return D->local.size;
}

void ParOperatorDiag::Apply(const ParVector& x, const ParVector& y) const
{
	y.Copy(x);
	ParVecElemMul(*D, y);
}

}