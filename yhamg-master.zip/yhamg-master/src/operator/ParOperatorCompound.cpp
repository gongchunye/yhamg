/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "ParOperatorCompound.hpp"

namespace YHAMG
{

ParOperatorCompound::ParOperatorCompound(double _beta, const ParOperator& _C, double _gamma)
	: ParOperator(_C.comm),
	A(0),
	B(0),
	C(&_C),
	alpha(0.0),
	beta(_beta),
	gamma(_gamma)
{
}

ParOperatorCompound::ParOperatorCompound(double _alpha, const ParOperator& _B, double _beta, const ParOperator& _C, double _gamma)
	: ParOperator(_B.comm),
	A(0),
	B(&_B),
	C(&_C),
	alpha(_alpha),
	beta(_beta),
	gamma(_gamma),
	p(_B.comm, _B.OutSize(), new double[_B.OutSize()], 0)
{
}

ParOperatorCompound::ParOperatorCompound(double _alpha, const ParOperator& _A, const ParOperator& _B, double _gamma)
	: ParOperator(_A.comm),
	A(&_A),
	B(&_B),
	C(0),
	alpha(_alpha),
	beta(0.0),
	gamma(_gamma),
	p(_B.comm, _B.OutSize(), new double[_B.OutSize()], 0)
{
}

ParOperatorCompound::ParOperatorCompound(double _alpha, const ParOperator& _A, const ParOperator& _B, double _beta, const ParOperator& _C, double _gamma)
	: ParOperator(_A.comm),
	A(&_A),
	B(&_B),
	C(&_C),
	alpha(_alpha),
	beta(_beta),
	gamma(_gamma),
	p(_A.comm, _A.OutSize(), new double[_A.OutSize()], 0),
	q(_B.comm, _B.OutSize(), new double[_B.OutSize()], 0)
{
}

int ParOperatorCompound::InSize() const
{
	if (C) return C->InSize();
	if (B) return B->InSize();
	return 0;
}

int ParOperatorCompound::OutSize() const
{
	if (C) return C->OutSize();
	if (A) return A->OutSize();
	if (B) return B->OutSize();
	return 0;
}

void ParOperatorCompound::Apply(const ParVector& x, const ParVector& y) const
{
	if (alpha == 0 || !B)
	{
		if (beta == 0 || !C)
			ParVecAXPBY(gamma, x, 0.0, y);
		else
		{
			C->Apply(x, y);
			ParVecAXPBY(gamma, x, beta, y);
		}
	}
	else
	{
		if (beta == 0 || !C)
		{	
			if (A)
			{
				B->Apply(x, p);
				A->Apply(p, y);
			}
			else
				B->Apply(x, y);
			
			ParVecAXPBY(gamma, x, alpha, y);
		}
		else
		{
			if (A)
			{
				B->Apply(x, q);
				A->Apply(q, p);
			}
			else
				B->Apply(x, p);
			
			C->Apply(x, y);
			ParVecAXPBYPCZ(alpha, p, gamma, x, beta, y);
		}
	}
}

void ParOperatorCompound::Apply(const ParMultiVector& X, const ParMultiVector& Y) const
{
	int m = X.local.nvec;

	if (alpha == 0 || !B)
	{
		if (beta == 0 || !C)
		{
			for (int j = 0; j < m; ++j)
				ParVecAXPBY(gamma, X(j), 0.0, Y(j));
		}
		else
		{
			C->Apply(X, Y);
			for (int j = 0; j < m; ++j)
				ParVecAXPBY(gamma, X(j), beta, Y(j));
		}
	}
	else
	{
		if (beta == 0 || !C)
		{
			if (A)
			{
				ParMultiVector P(comm);
				P.Allocate(m, B->OutSize());
				B->Apply(X, P);
				A->Apply(P, Y);
			}
			else
				B->Apply(X, Y);

			for (int j = 0; j < m; ++j)
				ParVecAXPBY(gamma, X(j), alpha, Y(j));
		}
		else
		{
			ParMultiVector P(comm);

			if (A)
			{
				ParMultiVector Q(comm);
				P.Allocate(m, A->OutSize());
				Q.Allocate(m, B->OutSize());
				B->Apply(X, Q);
				A->Apply(Q, P);
			}
			else
			{
				P.Allocate(m, B->OutSize());
				B->Apply(X, P);
			}

			C->Apply(X, Y);

			for (int j = 0; j < m; ++j)
				ParVecAXPBYPCZ(alpha, P(j), gamma, X(j), beta, Y(j));
		}
	}
}

}