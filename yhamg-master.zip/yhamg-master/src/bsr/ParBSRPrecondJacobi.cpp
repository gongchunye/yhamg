/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "BSRUnroll.hpp"
#include "ParBSRPrecondJacobi.hpp"

namespace YHAMG
{

ParBSRPrecondJacobi::ParBSRPrecondJacobi()
	: size(0),
	bsize(0),
	D_LU(0)
{
}

ParBSRPrecondJacobi::~ParBSRPrecondJacobi()
{
	if (D_LU) delete[] D_LU;
}

void ParBSRPrecondJacobi::Free()
{
	if (D_LU) delete[] D_LU;
	size = 0;
	bsize = 0;
	D_LU = 0;
}

void ParBSRPrecondJacobi::Setup(const ParBSRMatrix& A, int REUSE)
{
	if (!REUSE)
	{
		comm = A.comm;
		if (D_LU) delete D_LU;
		size = A.local.size[0];
		bsize = A.local.bsize;
		D_LU = new double[size * bsize * bsize];
	}

	int bnnz = bsize * bsize;
	int* Ap = A.local.rowptr;
	int* Ai = A.local.colind;
	double* Av = A.local.values;

#define BSR_UNROLL_SEGMENT(N) \
	for (int i = 0; i < size; ++i) \
	{ \
		for (int j = Ap[i]; j < Ap[i + 1]; ++j) \
		{ \
			if (Ai[j] == i) \
			{ \
				BSRBlockCopy_UNROLL(N, Av + j * N * N, D_LU + i * N * N); \
				BSRBlockLUFactorize_UNROLL(N, D_LU + i * N * N); \
				break; \
			} \
		} \
	}

#ifdef BSR_UNROLL_1
	if (bsize == 1)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		BSR_UNROLL_SEGMENT(1)
	}
	else
#endif
#ifdef BSR_UNROLL_2
	if (bsize == 2)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		BSR_UNROLL_SEGMENT(2)
	}
	else
#endif
#ifdef BSR_UNROLL_3
	if (bsize == 3)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		BSR_UNROLL_SEGMENT(3)
	}
	else
#endif
#ifdef BSR_UNROLL_4
	if (bsize == 4)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		BSR_UNROLL_SEGMENT(4)
	}
	else
#endif
#ifdef BSR_UNROLL_5
	if (bsize == 5)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		BSR_UNROLL_SEGMENT(5)
	}
	else
#endif
#ifdef BSR_UNROLL_6
	if (bsize == 6)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		BSR_UNROLL_SEGMENT(6)
	}
	else
#endif
#ifdef BSR_UNROLL_7
	if (bsize == 7)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		BSR_UNROLL_SEGMENT(7)
	}
	else
#endif
#ifdef BSR_UNROLL_8
	if (bsize == 8)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		BSR_UNROLL_SEGMENT(8)
	}
	else
#endif
#undef BSR_UNROLL_SEGMENT
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		for (int i = 0; i < size; ++i)
		{
			for (int j = Ap[i]; j < Ap[i + 1]; ++j)
			{
				if (Ai[j] == i)
				{
					BSRBlockCopy(bsize, Av + j * bnnz, D_LU + i * bnnz);
					BSRBlockLUFactorize(bsize, D_LU + i * bnnz);
					break;
				}
			}
		}
	}
}

int ParBSRPrecondJacobi::InSize() const
{
	return size * bsize;
}

int ParBSRPrecondJacobi::OutSize() const
{
	return size * bsize;
}

void ParBSRPrecondJacobi::Apply(const ParVector& b, const ParVector& x) const
{
	int bnnz = bsize * bsize;

	double* xv = x.local.values;
	double* bv = b.local.values;

#define BSR_UNROLL_SEGMENT(N) \
	for (int i = 0; i < size; ++i) \
	{ \
		VecBlockCopy_UNROLL(N, bv + i * N, xv + i * N); \
		BSRBlockLUVecSolve_UNROLL(N, D_LU + i * N * N, xv + i * N); \
	}

#ifdef BSR_UNROLL_1
	if (bsize == 1)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		BSR_UNROLL_SEGMENT(1)
	}
	else
#endif
#ifdef BSR_UNROLL_2
	if (bsize == 2)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		BSR_UNROLL_SEGMENT(2)
	}
	else
#endif
#ifdef BSR_UNROLL_3
	if (bsize == 3)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		BSR_UNROLL_SEGMENT(3)
	}
	else
#endif
#ifdef BSR_UNROLL_4
	if (bsize == 4)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		BSR_UNROLL_SEGMENT(4)
	}
	else
#endif
#ifdef BSR_UNROLL_5
	if (bsize == 5)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		BSR_UNROLL_SEGMENT(5)
	}
	else
#endif
#ifdef BSR_UNROLL_6
	if (bsize == 6)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		BSR_UNROLL_SEGMENT(6)
	}
	else
#endif
#ifdef BSR_UNROLL_7
	if (bsize == 7)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		BSR_UNROLL_SEGMENT(7)
	}
	else
#endif
#ifdef BSR_UNROLL_8
	if (bsize == 8)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		BSR_UNROLL_SEGMENT(8)
	}
	else
#endif
#undef BSR_UNROLL_SEGMENT
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		for (int i = 0; i < size; ++i)
		{
			VecBlockCopy(bsize, bv + i * bsize, xv + i * bsize);
			BSRBlockLUVecSolve(bsize, D_LU + i * bnnz, xv + i * bsize);
		}
	}
}

}