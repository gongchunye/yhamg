/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef BSRMatrix_H
#define BSRMatrix_H

#include "Operator.hpp"
#include "CSRMatrix.hpp"

namespace YHAMG
{

struct BSRMatrix : public Operator
{
	bool ref;
	int size[2];
	int bsize;

	int* rowptr;
	int* colind;
	double* values;

	BSRMatrix();
	BSRMatrix(int n, int m, int bsize, int* rowptr, int* colind, double* values, int ref);
	BSRMatrix(const BSRMatrix& A);
	BSRMatrix(int bsize, const CSRMatrix& A);
	BSRMatrix(BSRMatrix&& A);
	~BSRMatrix();
	BSRMatrix& operator=(const BSRMatrix& A);
	BSRMatrix& operator=(BSRMatrix&& A);

	void Free();
	void Refer(const BSRMatrix& A);
	int InSize() const;
	int OutSize() const;
	void Apply(const Vector& x, const Vector& y) const;
};

void CSRToBSR(int bsize, const CSRMatrix& A, BSRMatrix& B);
void BSRDiag(const BSRMatrix& A, const Vector& D);
void BSREliminZeros(const BSRMatrix& A);
void BSRScale(double alpha, const BSRMatrix& A);
void BSRScaleRows(const Vector& x, const BSRMatrix& A);
void BSRScaleCols(const Vector& x, const BSRMatrix& A);
void BSRMatAdd(const BSRMatrix& A, const BSRMatrix& B, BSRMatrix& C);
void BSRMatMul(const BSRMatrix& A, const BSRMatrix& B, BSRMatrix& C);
void BSRMatVec(double alpha, const BSRMatrix& A, const Vector& x, double beta, const Vector& y);
void BSRTrans(const BSRMatrix& A, BSRMatrix& B);
void CSRMultBSR(const CSRMatrix& A, const BSRMatrix& B, BSRMatrix& C);
void BSRMultCSR(const BSRMatrix& A, const CSRMatrix& B, BSRMatrix& C);
void CSRMatBlockVec(int bsize, double alpha, const CSRMatrix& A, const Vector& x, double beta, const Vector& y);

static inline void VecBlockFill(int bsize, double a, double* x)
{
	for (int i = 0; i < bsize; ++i)
		x[i] = a;
}

static inline void VecBlockScale(int bsize, double a, double* x)
{
	for (int i = 0; i < bsize; ++i)
		x[i] *= a;
}

static inline void VecBlockCopy(int bsize, const double* restrict x, double* restrict y)
{
	for (int i = 0; i < bsize; ++i)
		y[i] = x[i];
}

static inline void VecBlockAdd(int bsize, const double* restrict x, double* restrict y)
{
	for (int i = 0; i < bsize; ++i)
		y[i] += x[i];
}

static inline void VecBlockSub(int bsize, const double* restrict x, double* restrict y)
{
	for (int i = 0; i < bsize; ++i)
		y[i] -= x[i];
}

static inline void VecBlockScaleAdd(int bsize, double a, const double* restrict x, double* restrict y)
{
	for (int i = 0; i < bsize; ++i)
		y[i] += a * x[i];
}

static inline void BSRBlockFill(int bsize, double a, double* A)
{
	int bnnz = bsize * bsize;
	for (int i = 0; i < bnnz; ++i)
		A[i] = a;
}

static inline void BSRBlockScale(int bsize, double a, double* A)
{
	int bnnz = bsize * bsize;
	for (int i = 0; i < bnnz; ++i)
		A[i] *= a;
}

static inline void BSRBlockCopy(int bsize, const double* restrict A, double* restrict B)
{
	int bnnz = bsize * bsize;
	for (int i = 0; i < bnnz; ++i)
		B[i] = A[i];
}

static inline void BSRBlockTranspose(int bsize, const double* restrict A, double* restrict B)
{
	for (int i = 0; i < bsize; ++i)
		for (int j = 0; j < bsize; ++j)
			B[i + j * bsize] = A[i * bsize + j];
}

static inline void BSRBlockAdd(int bsize, const double* restrict A, double* restrict B)
{
	int bnnz = bsize * bsize;
	for (int i = 0; i < bnnz; ++i)
		B[i] += A[i];
}

static inline void BSRBlockSub(int bsize, const double* restrict A, double* restrict B)
{
	int bnnz = bsize * bsize;
	for (int i = 0; i < bnnz; ++i)
		B[i] -= A[i];
}

static inline void BSRBlockScaleAdd(int bsize, double a, const double* restrict A, double* restrict B)
{
	int bnnz = bsize * bsize;
	for (int i = 0; i < bnnz; ++i)
		B[i] += a * A[i];
}

static inline void BSRBlockMatVec(int bsize, const double* restrict A, const double* restrict x, double* restrict y)
{
	for (int i = 0; i < bsize; ++i)
	{
		double temp = 0.0;
		for (int j = 0; j < bsize; ++j)
			temp += A[i + j * bsize] * x[j];
		y[i] = temp;
	}
}

static inline void BSRBlockMatVecAdd(int bsize, const double* restrict A, const double* restrict x, double* restrict y)
{
	for (int i = 0; i < bsize; ++i)
	{
		double temp = y[i];
		for (int j = 0; j < bsize; ++j)
			temp += A[i + j * bsize] * x[j];
		y[i] = temp;
	}
}

static inline void BSRBlockMatVecSub(int bsize, const double* restrict A, const double* restrict x, double* restrict y)
{
	for (int i = 0; i < bsize; ++i)
	{
		double temp = y[i];
		for (int j = 0; j < bsize; ++j)
			temp -= A[i + j * bsize] * x[j];
		y[i] = temp;
	}
}

static inline void BSRBlockMatMul(int bsize, const double* restrict A, const double* restrict B, double* restrict C)
{
	for (int j = 0; j < bsize; ++j)
	{
		for (int i = 0; i < bsize; ++i)
		{
			double temp = 0.0;
			for (int k = 0; k < bsize; ++k)
				temp += A[i + k * bsize] * B[k + j * bsize];
			C[i + j * bsize] = temp;
		}
	}
}

static inline void BSRBlockMatMulAdd(int bsize, const double* restrict A, const double* restrict B, double* restrict C)
{
	for (int j = 0; j < bsize; ++j)
	{
		for (int i = 0; i < bsize; ++i)
		{
			double temp = C[i + j * bsize];
			for (int k = 0; k < bsize; ++k)
				temp += A[i + k * bsize] * B[k + j * bsize];
			C[i + j * bsize] = temp;
		}
	}
}

static inline void BSRBlockMatMulSub(int bsize, const double* restrict A, const double* restrict B, double* restrict C)
{
	for (int j = 0; j < bsize; ++j)
	{
		for (int i = 0; i < bsize; ++i)
		{
			double temp = C[i + j * bsize];
			for (int k = 0; k < bsize; ++k)
				temp -= A[i + k * bsize] * B[k + j * bsize];
			C[i + j * bsize] = temp;
		}
	}
}

static inline void BSRBlockLUFactorize(int bsize, double* LU)
{
	for (int k = 0; k < bsize; ++k)
	{
		double pivot = 1.0 / LU[k + k * bsize];
		LU[k + k * bsize] = pivot;
		for (int i = k + 1; i < bsize; ++i)
		{
			double factor = LU[i + k * bsize] * pivot;
			LU[i + k * bsize] = factor;
			for (int j = k + 1; j < bsize; ++j)
				LU[i + j * bsize] -= factor * LU[k + j * bsize];
		}
	}
}

static inline void BSRBlockLUVecSolve(int bsize, const double* restrict LU, double* restrict x)
{
	for (int i = 1; i < bsize; ++i)
	{
		double temp = x[i];
		for (int k = 0; k < i; ++k)
			temp -= x[k] * LU[i + k * bsize];
		x[i] = temp;
	}

	for (int i = bsize - 1; i >= 0; --i)
	{
		double temp = x[i];
		for (int k = bsize - 1; k > i; --k)
			temp -= x[k] * LU[i + k * bsize];
		x[i] = temp * LU[i + i * bsize];
	}
}

static inline void BSRBlockLUMatSolve(int bsize, const double* restrict LU, double* restrict X)
{
	for (int j = 0; j < bsize; ++j)
	{
		for (int i = 1; i < bsize; ++i)
		{
			double temp = X[i + j * bsize];
			for (int k = 0; k < i; ++k)
				temp -= X[k + j * bsize] * LU[i + k * bsize];
			X[i + j * bsize] = temp;
		}
	}
	
	for (int j = bsize - 1; j >= 0; --j)
	{
		for (int i = bsize - 1; i >= 0; --i)
		{
			double temp = X[i + j * bsize];
			for (int k = bsize - 1; k > i; --k)
				temp -= X[k + j * bsize] * LU[i + k * bsize];
			X[i + j * bsize] = temp * LU[i + i * bsize];
		}
	}
}

static inline void BSRBlockMatLUSolve(int bsize, const double* restrict LU, double* restrict X)
{
	for (int j = 0; j < bsize; ++j)
	{
		X[j] *= LU[0];
		for (int i = 1; i < bsize; ++i)
		{
			double temp = X[j + i * bsize];
			for (int k = 0; k < i; ++k)
				temp -= X[j + k * bsize] * LU[k + i * bsize];
			X[j + i * bsize] = temp * LU[i + i * bsize];
		}
	}

	for (int j = bsize - 1; j >= 0; --j)
	{
		for (int i = bsize - 2; i >= 0; --i)
		{
			double temp = X[j + i * bsize];
			for (int k = bsize - 1; k > i; --k)
				temp -= X[j + k * bsize] * LU[k + i * bsize];
			X[j + i * bsize] = temp;
		}
	}
}

static inline double BSRBlockSum(int bsize, const double* A)
{
	int bnnz = bsize * bsize;
	double result = 0.0;
	for (int i = 0; i < bnnz; ++i)
		result += A[i];
	return result;
}

static inline void BSRBlockDiagonal(int bsize, const double* A, double* x)
{
	for (int i = 0; i < bsize; ++i)
		x[i] = A[i + i * bsize];
}

static inline bool BSRBlockAllZero(int bsize, const double* A)
{
	int bnnz = bsize * bsize;
	for (int i = 0; i < bnnz; ++i)
		if (A[i] != 0.0) return 0;
	return 1;
}

static inline void BSRBlockScaleRows(int bsize, const double* x, double* A)
{
	for (int j = 0; j < bsize; ++j)
		for (int i = 0; i < bsize; ++i)
			A[i + j * bsize] *= x[i];
}

static inline void BSRBlockScaleCols(int bsize, const double* x, double* A)
{
	for (int j = 0; j < bsize; ++j)
		for (int i = 0; i < bsize; ++i)
			A[i + j * bsize] *= x[j];
}

}

#endif
