/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "BSRUnroll.hpp"
#include "ParBSRPrecondBJSOR.hpp"

#ifdef YHAMG_USE_OPENMP
#include <omp.h>
#endif

namespace YHAMG
{

ParBSRPrecondBJSOR::ParBSRPrecondBJSOR(int relaxation_type, double relaxation_factor)
	: nthd(0),
	D_LU(0),
	RelaxationType(relaxation_type),
	RelaxationFactor(relaxation_factor)
{
}


ParBSRPrecondBJSOR::~ParBSRPrecondBJSOR()
{
	if (D_LU) delete D_LU;
}

void ParBSRPrecondBJSOR::Free()
{
	if (D_LU) delete D_LU;
	L.Free();
	U.Free();
	nthd = 0;
	D_LU = 0;
}

void ParBSRPrecondBJSOR::Setup(const ParBSRMatrix& A, int REUSE)
{
	int n = A.local.size[0];
	int bsize = A.local.bsize;
	int bnnz = bsize * bsize; 
	int* Ap = A.local.rowptr;
	int* Ai = A.local.colind;
	double* Av = A.local.values;

	if (!REUSE)
	{
		Free();

		comm = A.comm;

		D_LU = new double[n * bnnz];

		nthd = 1;
#ifdef USE_ONED_PARTITION
		nthd = omp_get_max_threads();
#endif

		int* Lp = new int[n + 1];
		int* Up = new int[n + 1];

		Lp[0] = 0;
		Up[0] = 0;
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		for (int t = 0; t < nthd; ++t)
		{
			int begin = t * n / nthd;
			int end = (t + 1) * n / nthd;

			for (int i = begin; i < end; ++i)
			{
				int cntl = 0;
				int cntu = 0;

				for (int j = Ap[i]; j < Ap[i + 1]; ++j)
				{
					int jcol = Ai[j];

					if (jcol >= begin && jcol < i) 
						++cntl;
					else if (jcol < end && jcol > i)
						++cntu;
				}

				Lp[i + 1] = cntl;
				Up[i + 1] = cntu;
			}
		}

		for (int i = 0; i < n;++i)
			Lp[i + 1] += Lp[i];
		for (int i = 0; i < n;++i)
			Up[i + 1] += Up[i];

		int* Li = new int[Lp[n]];
		double* Lv = new double[Lp[n] * bnnz];
		int* Ui = new int[Up[n]];
		double* Uv = new double[Up[n] * bnnz];

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		for (int t = 0; t < nthd; ++t)
		{
			int begin = t * n / nthd;
			int end = (t + 1) * n / nthd;

#define BSR_UNROLL_SEGMENT(N) \
	for (int i = begin; i < end; ++i) \
	{ \
		for (int j = Ap[i], k = Lp[i], r = Up[i]; j < Ap[i + 1]; ++j) \
		{ \
			int jcol = Ai[j]; \
			if (jcol >= begin && jcol < i) \
			{ \
				Li[k] = jcol; \
				BSRBlockCopy_UNROLL(N, Av + j * N * N, Lv + k * N * N); \
				++k; \
			} \
			else if (jcol < end && jcol > i) \
			{ \
				Ui[r] = jcol; \
				BSRBlockCopy_UNROLL(N, Av + j * N * N, Uv + r * N * N); \
				++r; \
			} \
			else if (jcol == i) \
			{ \
				BSRBlockCopy_UNROLL(N, Av + j * N * N, D_LU + i * N * N); \
				BSRBlockLUFactorize_UNROLL(N, D_LU + i * N * N); \
			} \
		} \
	}

#ifdef BSR_UNROLL_1
			if (bsize == 1) { BSR_UNROLL_SEGMENT(1) } else
#endif
#ifdef BSR_UNROLL_2
			if (bsize == 2) { BSR_UNROLL_SEGMENT(2) } else
#endif
#ifdef BSR_UNROLL_3
			if (bsize == 3) { BSR_UNROLL_SEGMENT(3) } else
#endif
#ifdef BSR_UNROLL_4
			if (bsize == 4) { BSR_UNROLL_SEGMENT(4) } else
#endif
#ifdef BSR_UNROLL_5
			if (bsize == 5) { BSR_UNROLL_SEGMENT(5) } else
#endif
#ifdef BSR_UNROLL_6
			if (bsize == 6) { BSR_UNROLL_SEGMENT(6) } else
#endif
#ifdef BSR_UNROLL_7
			if (bsize == 7) { BSR_UNROLL_SEGMENT(7) } else
#endif
#ifdef BSR_UNROLL_8
			if (bsize == 8) { BSR_UNROLL_SEGMENT(8) } else
#endif
#undef BSR_UNROLL_SEGMENT
			{
				for (int i = begin; i < end; ++i)
				{
					for (int j = Ap[i], k = Lp[i], r = Up[i]; j < Ap[i + 1]; ++j)
					{
						int jcol = Ai[j];

						if (jcol >= begin && jcol < i)
						{
							Li[k] = jcol;
							BSRBlockCopy(bsize, Av + j * bnnz, Lv + k * bnnz);
							++k;
						}
						else if (jcol < end && jcol > i)
						{
							Ui[r] = jcol;
							BSRBlockCopy(bsize, Av + j * bnnz, Uv + r * bnnz);
							++r;
						}
						else if (jcol == i)
						{
							BSRBlockCopy(bsize, Av + j * bnnz, D_LU + i * bnnz);
							BSRBlockLUFactorize(bsize, D_LU + i * bnnz);
						}
					}
				}
			}
		}

		L.size[0] = n;
		L.size[1] = n;
		L.bsize = bsize;
		L.rowptr = Lp;
		L.colind = Li;
		L.values = Lv;
		U.size[0] = n;
		U.size[1] = n;
		U.bsize = bsize;
		U.rowptr = Up;
		U.colind = Ui;
		U.values = Uv;
	}
	else
	{
		int* Lp = L.rowptr;
		int* Li = L.colind;
		double* Lv = L.values;
		int* Up = U.rowptr;
		int* Ui = U.colind;
		double* Uv = U.values;
		
		int* w = new int[n];

		for (int i = 0; i < n; ++i)
			w[i] = -1;

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		for (int t = 0; t < nthd; ++t)
		{
			int begin = t * n / nthd;
			int end = (t + 1) * n / nthd;

#define BSR_UNROLL_SEGMENT(N) \
	for (int i = begin; i < end; ++i) \
	{ \
		int j0 = Ap[i]; \
		for (int j = Ap[i]; j < Ap[i + 1]; ++j) \
			if (Ai[j] >= begin && Ai[j] < end) w[Ai[j]] = j; \
		if (w[i] >= j0) \
		{ \
				BSRBlockCopy_UNROLL(N, Av + w[i] * N * N, D_LU + i * N * N); \
				BSRBlockLUFactorize_UNROLL(N, D_LU + i * N * N); \
		} \
		for (int j = Lp[i]; j < Lp[i + 1]; ++j) \
			if (w[Li[j]] >= j0) BSRBlockCopy_UNROLL(N, Av + w[Li[j]] * N * N, Lv + j * N * N); \
		for (int j = Up[i]; j < Up[i + 1]; ++j) \
			if (w[Ui[j]] >= j0) BSRBlockCopy_UNROLL(N, Av + w[Ui[j]] * N * N, Uv + j * N * N); \
	}

#ifdef BSR_UNROLL_1
			if (bsize == 1) { BSR_UNROLL_SEGMENT(1) } else
#endif
#ifdef BSR_UNROLL_2
			if (bsize == 2) { BSR_UNROLL_SEGMENT(2) } else
#endif
#ifdef BSR_UNROLL_3
			if (bsize == 3) { BSR_UNROLL_SEGMENT(3) } else
#endif
#ifdef BSR_UNROLL_4
			if (bsize == 4) { BSR_UNROLL_SEGMENT(4) } else
#endif
#ifdef BSR_UNROLL_5
			if (bsize == 5) { BSR_UNROLL_SEGMENT(5) } else
#endif
#ifdef BSR_UNROLL_6
			if (bsize == 6) { BSR_UNROLL_SEGMENT(6) } else
#endif
#ifdef BSR_UNROLL_7
			if (bsize == 7) { BSR_UNROLL_SEGMENT(7) } else
#endif
#ifdef BSR_UNROLL_8
			if (bsize == 8) { BSR_UNROLL_SEGMENT(8) } else
#endif
#undef BSR_UNROLL_SEGMENT
			{
				for (int i = begin; i < end; ++i)
				{
					int j0 = Ap[i];

					for (int j = Ap[i]; j < Ap[i + 1]; ++j)
						if (Ai[j] >= begin && Ai[j] < end) w[Ai[j]] = j;

					if (w[i] >= j0)
					{
						BSRBlockCopy(bsize, Av + w[i] * bnnz, D_LU + i * bnnz);
						BSRBlockLUFactorize(bsize, D_LU + i * bnnz);
					}

					for (int j = Lp[i]; j < Lp[i + 1]; ++j)
						if (w[Li[j]] >= j0) BSRBlockCopy(bsize, Av + w[Li[j]] * bnnz, Lv + j * bnnz);
					for (int j = Up[i]; j < Up[i + 1]; ++j)
						if (w[Ui[j]] >= j0) BSRBlockCopy(bsize, Av + w[Ui[j]] * bnnz, Uv + j * bnnz);
				}
			}
		}
		
		delete[] w;	
	}
}

int ParBSRPrecondBJSOR::InSize() const
{
	return L.size[0] * L.bsize;
}

int ParBSRPrecondBJSOR::OutSize() const
{
	return L.size[0] * L.bsize;
}

void ParBSRPrecondBJSOR::Apply(const ParVector& b, const ParVector& x) const
{
	int relaxation_type = RelaxationType;
	double omega = RelaxationFactor;
	
	int n = L.size[0];
	int bsize = L.bsize;
	int bnnz = bsize * bsize;
	int* Lp = L.rowptr;
	int* Li = L.colind;
	double* Lv = L.values;
	int* Up = U.rowptr;
	int* Ui = U.colind;
	double* Uv = U.values;
	double* bv = b.local.values;
	double* xv = x.local.values;

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
	for (int t = 0; t < nthd; ++t)
	{
		int begin = t * n / nthd;
		int end = (t + 1) * n / nthd;

#define BSR_UNROLL_SEGMENT(N) \
	if (relaxation_type == 0 || relaxation_type == 2) \
	{ \
		if (omega == 1.0) \
		{ \
			for (int i = begin; i < end; ++i) \
			{ \
				VecBlockCopy_UNROLL(N, bv + i * N, xv + i * N); \
				for (int j = Lp[i]; j < Lp[i + 1]; ++j) \
					BSRBlockMatVecSub_UNROLL(N, Lv + j * N * N, xv + Li[j] * N, xv + i * N); \
				BSRBlockLUVecSolve_UNROLL(N, D_LU + i * N * N, xv + i * N); \
			} \
		} \
		else \
		{ \
			for (int i = begin; i < end; ++i) \
			{ \
				double temp[N]; \
				VecBlockFill_UNROLL(N, 0.0, temp); \
				for (int j = Lp[i]; j < Lp[i + 1]; ++j) \
					BSRBlockMatVecSub_UNROLL(N, Lv + j * N * N, xv + Li[j] * N, temp); \
				VecBlockCopy_UNROLL(N, bv + i * N, xv + i * N); \
				VecBlockScaleAdd_UNROLL(N, omega, temp, xv + i * N); \
				BSRBlockLUVecSolve_UNROLL(N, D_LU + i * N * N, xv + i * N); \
			} \
		} \
	} \
	if (relaxation_type == 1) \
	{ \
		if (omega == 1.0) \
		{ \
			for (int i = end - 1; i >= begin; --i) \
			{ \
				VecBlockCopy_UNROLL(N, bv + i * N, xv + i * N); \
				for (int j = Up[i + 1] - 1; j >= Up[i]; --j) \
					BSRBlockMatVecSub_UNROLL(N, Uv + j * N * N, xv + Ui[j] * N, xv + i * N); \
				BSRBlockLUVecSolve_UNROLL(N, D_LU + i * N * N, xv + i * N); \
			} \
		} \
		else \
		{ \
			for (int i = end - 1; i >= begin; --i) \
			{ \
				double temp[N]; \
				VecBlockFill_UNROLL(N, 0.0, temp); \
				for (int j = Up[i + 1] - 1; j >= Up[i]; --j) \
					BSRBlockMatVecSub_UNROLL(N, Uv + j * N * N, xv + Ui[j] * N, temp); \
				VecBlockCopy_UNROLL(N, bv + i * N, xv + i * N); \
				VecBlockScaleAdd_UNROLL(N, omega, temp, xv + i * N); \
				BSRBlockLUVecSolve_UNROLL(N, D_LU + i * N * N, xv + i * N); \
			} \
		} \
	} \
	if (relaxation_type == 2) \
	{ \
		if (omega == 1.0) \
		{ \
			for (int i = end - 1; i >= begin; --i) \
			{ \
				double temp[N]; \
				VecBlockFill_UNROLL(N, 0.0, temp); \
				for (int j = Up[i + 1] - 1; j >= Up[i]; --j) \
					BSRBlockMatVecSub_UNROLL(N, Uv + j * N * N, xv + Ui[j] * N, temp); \
				BSRBlockLUVecSolve_UNROLL(N, D_LU + i * N * N, temp); \
				VecBlockAdd_UNROLL(N, temp, xv + i * N); \
			} \
		} \
		else \
		{ \
			for (int i = end - 1; i >= begin; --i) \
			{ \
				double temp[N]; \
				VecBlockFill_UNROLL(N, 0.0, temp); \
				for (int j = Up[i + 1] - 1; j >= Up[i]; --j) \
					BSRBlockMatVecSub_UNROLL(N, Uv + j * N * N, xv + Ui[j] * N, temp); \
				BSRBlockLUVecSolve_UNROLL(N, D_LU + i * N * N, temp); \
				VecBlockScaleAdd_UNROLL(N, omega, temp, xv + i * N); \
			} \
		} \
	}

#ifdef BSR_UNROLL_1
		if (bsize == 1) { BSR_UNROLL_SEGMENT(1) } else
#endif
#ifdef BSR_UNROLL_2
		if (bsize == 2) { BSR_UNROLL_SEGMENT(2) } else
#endif
#ifdef BSR_UNROLL_3
		if (bsize == 3) { BSR_UNROLL_SEGMENT(3) } else
#endif
#ifdef BSR_UNROLL_4
		if (bsize == 4) { BSR_UNROLL_SEGMENT(4) } else
#endif
#ifdef BSR_UNROLL_5
		if (bsize == 5) { BSR_UNROLL_SEGMENT(5) } else
#endif
#ifdef BSR_UNROLL_6
		if (bsize == 6) { BSR_UNROLL_SEGMENT(6) } else
#endif
#ifdef BSR_UNROLL_7
		if (bsize == 7) { BSR_UNROLL_SEGMENT(7) } else
#endif
#ifdef BSR_UNROLL_8
		if (bsize == 8) { BSR_UNROLL_SEGMENT(8) } else
#endif
#undef BSR_UNROLL_SEGMENT
		{
			if (relaxation_type == 0 || relaxation_type == 2)
			{
				if (omega == 1.0)
				{
					for (int i = begin; i < end; ++i)
					{
						VecBlockCopy(bsize, bv + i * bsize, xv + i * bsize);
						for (int j = Lp[i]; j < Lp[i + 1]; ++j)
							BSRBlockMatVecSub(bsize, Lv + j * bnnz, xv + Li[j] * bsize, xv + i * bsize);
						BSRBlockLUVecSolve(bsize, D_LU + i * bnnz, xv + i * bsize);
					}
				}
				else
				{
					double* temp = new double[bsize];
					for (int i = begin; i < end; ++i)
					{
						VecBlockFill(bsize, 0.0, temp);
						for (int j = Lp[i]; j < Lp[i + 1]; ++j)
							BSRBlockMatVecSub(bsize, Lv + j * bnnz, xv + Li[j] * bsize, temp);
						VecBlockCopy(bsize, bv + i * bsize, xv + i * bsize);
						VecBlockScaleAdd(bsize, omega, temp, xv + i * bsize);
						BSRBlockLUVecSolve(bsize, D_LU + i * bnnz, xv + i * bsize);
					}
					delete[] temp;
				}
			}

			if (relaxation_type == 1)
			{
				if (omega == 1.0)
				{
					for (int i = end - 1; i >= begin; --i)
					{
						VecBlockCopy(bsize, bv + i * bsize, xv + i * bsize);
						for (int j = Up[i + 1] - 1; j >= Up[i]; --j)
							BSRBlockMatVecSub(bsize, Uv + j * bnnz, xv + Ui[j] * bsize, xv + i * bsize);
						BSRBlockLUVecSolve(bsize, D_LU + i * bnnz, xv + i * bsize);
					}
				}
				else
				{
					double* temp = new double[bsize];
					for (int i = end - 1; i >= begin; --i)
					{
						VecBlockFill(bsize, 0.0, temp);
						for (int j = Up[i + 1] - 1; j >= Up[i]; --j)
							BSRBlockMatVecSub(bsize, Uv + j * bnnz, xv + Ui[j] * bsize, temp);
						VecBlockCopy(bsize, bv + i * bsize, xv + i * bsize);
						VecBlockScaleAdd(bsize, omega, temp, xv + i * bsize);
						BSRBlockLUVecSolve(bsize, D_LU + i * bnnz, xv + i * bsize);
					}
					delete[] temp;
				}
			}
			
			if (relaxation_type == 2)
			{
				if (omega == 1.0)
				{
					double* temp = new double[bsize];
					for (int i = end - 1; i >= begin; --i)
					{
						VecBlockFill(bsize, 0.0, temp);
						for (int j = Up[i + 1] - 1; j >= Up[i]; --j)
							BSRBlockMatVecSub(bsize, Uv + j * bnnz, xv + Ui[j] * bsize, temp);
						BSRBlockLUVecSolve(bsize, D_LU + i * bnnz, temp);
						VecBlockAdd(bsize, temp, xv + i * bsize);
					}
					delete[] temp;
				}
				else
				{
					double* temp = new double[bsize];
					for (int i = end - 1; i >= begin; --i)
					{
						VecBlockFill(bsize, 0.0, temp);
						for (int j = Up[i + 1] - 1; j >= Up[i]; --j)
							BSRBlockMatVecSub(bsize, Uv + j * bnnz, xv + Ui[j] * bsize, temp);
						BSRBlockLUVecSolve(bsize, D_LU + i * bnnz, temp);
						VecBlockScaleAdd(bsize, omega, temp, xv + i * bsize);
					}
					delete[] temp;
				}
			}
		}
	}
}

}