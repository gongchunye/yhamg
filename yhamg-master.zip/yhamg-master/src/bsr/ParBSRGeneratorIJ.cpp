/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <map>
#include "ParBSRGeneratorIJ.hpp"

namespace YHAMG
{

ParBSRGeneratorIJ::ParBSRGeneratorIJ(MPI_Comm comm)
	: ParBSRGenerator(comm),
	size{0, 0},
	bsize(0),
	rowptr(0),
	colind(0),
	values(0),
	pattern_symmetry(0)
{
}

ParBSRGeneratorIJ::ParBSRGeneratorIJ(MPI_Comm comm, int n, int m, int _bsize, const int* _rowptr, const global* _colind, const double* _values, int _pattern_symmetry)
	: ParBSRGenerator(comm),
	size{n, m},
	bsize(_bsize),
	rowptr(_rowptr),
	colind(_colind),
	values(_values),
	pattern_symmetry(_pattern_symmetry)
{
}

void ParBSRGeneratorIJ::operator()(ParBSRMatrix& A) const
{
	int comm_size;
	int comm_rank;
	MPI_Comm_size(comm, &comm_size);
	MPI_Comm_rank(comm, &comm_rank);

	int bnnz = bsize * bsize;

	int* local_rowptr = new int[size[0] + 1];
	int* exter_rowptr = new int[size[0] + 1];

	char* recv_marks = new char[comm_size];
	for (int r = 0; r < comm_size; ++r)
		recv_marks[r] = 0;

	local_rowptr[0] = 0;
	exter_rowptr[0] = 0;

	for (int i = 0, cntloc = 0, cntext = 0; i < size[0]; local_rowptr[++i] = cntloc, exter_rowptr[i] = cntext)
		for (int j = rowptr[i]; j < rowptr[i + 1]; ++j)
			++(owner(colind[j]) == comm_rank ? cntloc : cntext);

	int* local_colind = new int[local_rowptr[size[0]]];
	double* local_values = new double[local_rowptr[size[0]] * bnnz];
	int* exter_colind = new int[exter_rowptr[size[0]]];
	int* exter_colfrom = new int[exter_rowptr[size[0]]];
	double* exter_values = new double[exter_rowptr[size[0]] * bnnz];

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
	for (int i = 0; i < size[0]; ++i)
	{
		for (int j = rowptr[i], k = local_rowptr[i], t = exter_rowptr[i]; j < rowptr[i + 1]; ++j)
		{
			int jcol = local(colind[j]);
			int jfrom = owner(colind[j]);
			double jval = values[j];

			if (jfrom == comm_rank)
			{
				local_colind[k] = jcol;
				BSRBlockCopy(bsize, values + j * bnnz, local_values + k * bnnz);
				++k;
			}
			else
			{
				exter_colind[t] = jcol;
				exter_colfrom[t] = jfrom;
				BSRBlockCopy(bsize, values + j * bnnz, exter_values + t * bnnz);
				++t;
				recv_marks[jfrom] = 1;
			}
		}
	}

	int num_neighbors = 0;
	std::map<int, int> neighbor_map;

	if (pattern_symmetry)
	{
		for (int r = 0; r < comm_size; ++r)
			if (recv_marks[r]) neighbor_map.insert(std::pair<int, int>(r, num_neighbors++));
	}
	else
	{
		char* send_marks = new char[comm_size];

		MPI_Alltoall(recv_marks, 1, MPI_CHAR, send_marks, 1, MPI_CHAR, comm);

		for (int r = 0; r < comm_size; ++r)
			if (recv_marks[r] || send_marks[r]) neighbor_map.insert(std::pair<int, int>(r, num_neighbors++));

		delete[] send_marks;
	}

	std::map<int, int>* recvmap = new std::map<int, int>[num_neighbors];
	for (int i = 0; i < size[0]; ++i)
	{
		for (int j = exter_rowptr[i]; j < exter_rowptr[i + 1]; ++j)
		{
			int jfrom = neighbor_map[exter_colfrom[j]];
			exter_colfrom[j] = jfrom;
			std::pair<std::map<int, int>::iterator, bool> ret = recvmap[jfrom].insert(std::pair<int, int>(exter_colind[j], recvmap[jfrom].size()));
			exter_colind[j] = ret.first->second;
		}
	}

	int* neighbor_ranks = new int[num_neighbors];
	for (std::map<int, int>::iterator iter = neighbor_map.begin(); iter != neighbor_map.end(); ++iter)
		neighbor_ranks[iter->second] = iter->first;

	int* recvptr = new int[num_neighbors + 1];
	recvptr[0] = 0;
	for (int r = 0; r < num_neighbors; ++r)
		recvptr[r + 1] = recvptr[r] + recvmap[r].size();

	int* recvind = new int[recvptr[num_neighbors]];
	for (int r = 0; r < num_neighbors; ++r)
		for (std::map<int, int>::iterator iter = recvmap[r].begin(); iter != recvmap[r].end(); ++iter)
			recvind[recvptr[r] + iter->second] = iter->first;

	for (int j = 0; j < exter_rowptr[size[0]]; ++j)
		exter_colind[j] += recvptr[exter_colfrom[j]];

	delete[] recvmap;
	delete[] exter_colfrom;
	delete[] recv_marks;

	A.Free();

	A.comm = comm;

	A.local.size[0] = size[0];
	A.local.size[1] = size[1];
	A.local.bsize = bsize;
	A.local.rowptr = local_rowptr;
	A.local.colind = local_colind;
	A.local.values = local_values;

	A.exter.size[0] = size[0];
	A.exter.size[1] = recvptr[num_neighbors];
	A.exter.bsize = bsize;
	A.exter.rowptr = exter_rowptr;
	A.exter.colind = exter_colind;
	A.exter.values = exter_values;

	A.nnb = num_neighbors;
	A.nbrank = neighbor_ranks;

	A.recvptr = recvptr;
	A.recvind = recvind;
}

}