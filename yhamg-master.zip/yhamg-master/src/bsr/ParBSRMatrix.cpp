/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


#include <set>
#include <map>
#include <stdlib.h>
#include "BSRUnroll.hpp"
#include "ParBSRMatrix.hpp"

#define MPI_TAG 100

namespace YHAMG
{

ParBSRMatrix::ParBSRMatrix(MPI_Comm comm)
	: ParOperator(comm),
	nnb(0),
	nbrank(0),
	recvptr(0),
	recvind(0),
	sendptr(0),
	sendind(0),
	sendbuf(0)
{
}

ParBSRMatrix::ParBSRMatrix(MPI_Comm comm, int local_rows, int local_cols, int exter_cols, int _bsize,
	int* local_rowptr, int* local_colind, double* local_values, int local_ref, 
	int* exter_rowptr, int* exter_colind, double* exter_values, int exter_ref,
	int _nnb, int* _nbrank, int* _recvptr, int* _recvind)
	: ParOperator(comm),
	local(local_rows, local_cols, _bsize, local_rowptr, local_colind, local_values, local_ref),
	exter(local_rows, exter_cols, _bsize, exter_rowptr, exter_colind, exter_values, exter_ref),
	nnb(_nnb),
	nbrank(_nbrank),
	recvptr(_recvptr),
	recvind(_recvind),
	sendptr(0),
	sendind(0),
	sendbuf(0)
{
}

ParBSRMatrix::ParBSRMatrix(const BSRMatrix& A)
	: ParOperator(MPI_COMM_SELF),
	local(A),
	exter(A.size[0], 0, A.bsize, new int[A.size[0] + 1], 0, 0, 0),
	nnb(0),
	nbrank(0),
	recvptr(new int[1]),
	recvind(0),
	sendptr(0),
	sendind(0),
	sendbuf(0)
{
	for (int i = 0; i <= A.size[0]; ++i)
		exter.rowptr[i] = 0;
	recvptr[0] = 0;
}

ParBSRMatrix::ParBSRMatrix(const ParBSRMatrix& A)
	: ParOperator(A.comm),
	local(A.local),
	exter(A.exter),
	nnb(A.nnb),
	nbrank(new int[A.nnb]),
	recvptr(new int[A.nnb + 1]),
	recvind(new int[A.exter.size[1]]),
	sendptr(0),
	sendind(0),
	sendbuf(0)
{
	for (int r = 0; r < nnb; ++r)
		nbrank[r] = A.nbrank[r];
	for (int r = 0; r <= nnb; ++r)
		recvptr[r] = A.recvptr[r];
	for (int i = 0; i < exter.size[1]; ++i)
		recvind[i] = A.recvind[i];
}

ParBSRMatrix::ParBSRMatrix(int bsize, const ParCSRMatrix& A)
	: ParBSRMatrix()
{
	ParCSRToBSR(bsize, A, *this);
}

ParBSRMatrix::ParBSRMatrix(ParBSRMatrix&& A)
	: ParOperator(A.comm),
	local(A.local.size[0], A.local.size[1], A.local.bsize, A.local.rowptr, A.local.colind, A.local.values, A.local.ref),
	exter(A.exter.size[0], A.exter.size[1], A.exter.bsize, A.exter.rowptr, A.exter.colind, A.exter.values, A.exter.ref),
	nnb(A.nnb),
	nbrank(A.nbrank),
	recvptr(A.recvptr),
	recvind(A.recvind),
	sendptr(A.sendptr),
	sendind(A.sendind),
	sendbuf(A.sendbuf),
	recvx(A.recvx.size, A.recvx.values, A.recvx.ref)
{
	A.local.ref = 1;
	A.exter.ref = 1;
	A.nbrank = 0;
	A.recvptr = 0;
	A.recvind = 0;
	A.sendptr = 0;
	A.sendind = 0;
	A.sendbuf = 0;
	A.recvx.ref = 1;
}

ParBSRMatrix::~ParBSRMatrix()
{
	if (nbrank) delete[] nbrank;
	if (recvptr) delete[] recvptr;
	if (recvind) delete[] recvind;
	if (sendptr) delete[] sendptr;
	if (sendind) delete[] sendind;
	if (sendbuf) delete[] sendbuf;
}

ParBSRMatrix& ParBSRMatrix::operator=(const ParBSRMatrix& A)
{
	Free();

	comm = A.comm;
	local = A.local;
	exter = A.exter;
	nnb = A.nnb;

	nbrank = new int[nnb];
	recvptr = new int[nnb + 1];
	recvind = new int[exter.size[1]];

	for (int r = 0; r < nnb; ++r)
		nbrank[r] = A.nbrank[r];
	for (int r = 0; r <= nnb; ++r)
		recvptr[r] = A.recvptr[r];
	for (int i = 0; i < exter.size[1]; ++i)
		recvind[i] = A.recvind[i];
	
	return *this;
}

ParBSRMatrix& ParBSRMatrix::operator=(ParBSRMatrix&& A)
{
	Free();

	comm = A.comm;
	local.ref = A.local.ref;
	local.size[0] = A.local.size[0];
	local.size[1] = A.local.size[1];
	local.bsize = A.local.bsize;
	local.rowptr = A.local.rowptr;
	local.colind = A.local.colind;
	local.values = A.local.values;
	exter.ref = A.exter.ref;
	exter.size[0] = A.exter.size[0];
	exter.size[1] = A.exter.size[1];
	exter.bsize = A.exter.bsize;
	exter.rowptr = A.exter.rowptr;
	exter.colind = A.exter.colind;
	exter.values = A.exter.values;
	nnb = A.nnb;
	nbrank = A.nbrank;
	recvptr = A.recvptr;
	recvind = A.recvind;
	sendptr = A.sendptr;
	sendind = A.sendind;
	sendbuf = A.sendbuf;
	recvx.ref = A.recvx.ref;
	recvx.size = A.recvx.size;
	recvx.values = A.recvx.values;

	A.local.ref = 1;
	A.exter.ref = 1;
	A.nbrank = 0;
	A.recvptr = 0;
	A.recvind = 0;
	A.sendptr = 0;
	A.sendind = 0;
	A.sendbuf = 0;
	A.recvx.ref = 1;

	return *this;
}

void ParBSRMatrix::Free()
{
	if (nbrank) delete[] nbrank;
	if (recvptr) delete[] recvptr;
	if (recvind) delete[] recvind;
	if (sendptr) delete[] sendptr;
	if (sendind) delete[] sendind;
	if (sendbuf) delete[] sendbuf;

	local.Free();
	exter.Free();
	nnb = 0;
	nbrank = 0;
	recvptr = 0;
	recvind = 0;
	sendptr = 0;
	sendind = 0;
	sendbuf = 0;
	recvx.Free();
}

void ParBSRMatrix::Refer(const ParBSRMatrix& A)
{
	Free();

	comm = A.comm;
	local.Refer(A.local);
	exter.Refer(A.exter);
	nnb = A.nnb;

	nbrank = new int[nnb];
	recvptr = new int[nnb + 1];
	recvind = new int[exter.size[1]];

	for (int r = 0; r < nnb; ++r)
		nbrank[r] = A.nbrank[r];
	for (int r = 0; r <= nnb; ++r)
		recvptr[r] = A.recvptr[r];
	for (int i = 0; i < exter.size[1]; ++i)
		recvind[i] = A.recvind[i];
}

void ParBSRMatrix::ExchangeHalo(const ParVector& x) const
{
	int bsize = local.bsize;

	double* x_local_values = x.local.values;
	double* x_recv_values = recvx.values;

	MPI_Request* recvreq = new MPI_Request[nnb];
	MPI_Request* sendreq = new MPI_Request[nnb];
	MPI_Status status;

	for (int r = 0; r < nnb; ++r)
		if (recvptr[r + 1] > recvptr[r])
			MPI_Irecv(x_recv_values + recvptr[r] * bsize, (recvptr[r + 1] - recvptr[r]) * bsize, MPI_DOUBLE, nbrank[r], MPI_TAG, comm, recvreq + r);

	for (int r = 0; r < nnb; ++r)
	{
		if (sendptr[r + 1] > sendptr[r])
		{
			for (int i = sendptr[r]; i < sendptr[r + 1]; ++i)
				VecBlockCopy(bsize, x_local_values + sendind[i] * bsize, sendbuf + i * bsize);
			MPI_Isend(sendbuf + sendptr[r] * bsize, (sendptr[r + 1] - sendptr[r]) * bsize, MPI_DOUBLE, nbrank[r], MPI_TAG, comm, sendreq + r);
		}
	}

	for (int r = 0; r < nnb; ++r)
		if (recvptr[r + 1] > recvptr[r])
			MPI_Wait(recvreq + r, &status);

	for (int r = 0; r < nnb; ++r)
		if (sendptr[r + 1] > sendptr[r])
			MPI_Wait(sendreq + r, &status);

	delete[] recvreq;
	delete[] sendreq;
}

void ParBSRMatrix::SetupHalo()
{
	if (sendptr) delete[] sendptr;
	if (sendind) delete[] sendind;
	if (sendbuf) delete[] sendbuf;

	int bsize = local.bsize;
	
	recvx.Resize(exter.size[1] * bsize);

	MPI_Request* recvreq = new MPI_Request[nnb];
	MPI_Request* sendreq = new MPI_Request[nnb];
	MPI_Status status;

	sendptr = new int[nnb + 1];

	sendptr[0] = 0;
	for (int r = 0; r < nnb; ++r)
		MPI_Irecv(sendptr + r + 1, 1, MPI_INT, nbrank[r], MPI_TAG, comm, recvreq + r);

	for (int r = 0; r < nnb; ++r)
	{
		int cnt = recvptr[r + 1] - recvptr[r];
		MPI_Send(&cnt, 1, MPI_INT, nbrank[r], MPI_TAG, comm);
	}

	for (int r = 0; r < nnb; ++r)
		MPI_Wait(recvreq + r, &status);

	for (int r = 0; r < nnb; ++r)
		sendptr[r + 1] += sendptr[r];

	int _nnb = 0;

	for (int r = 0; r < nnb; ++r)
	{
		if (sendptr[r + 1] > sendptr[r] || recvptr[r + 1] > recvptr[r])
		{
			nbrank[_nnb++] = nbrank[r];
			sendptr[_nnb] = sendptr[r + 1];
			recvptr[_nnb] = recvptr[r + 1];
		}
	}

	nnb = _nnb;

	sendind = new int[sendptr[nnb]];
	sendbuf = new double[sendptr[nnb] * bsize];

	for (int r = 0; r < nnb; ++r)
		if (sendptr[r + 1] > sendptr[r])
			MPI_Irecv(sendind + sendptr[r], sendptr[r + 1] - sendptr[r], MPI_INT, nbrank[r], MPI_TAG, comm, recvreq + r);

	for (int r = 0; r < nnb; ++r)
		if (recvptr[r + 1] > recvptr[r])
			MPI_Isend(recvind + recvptr[r], recvptr[r + 1] - recvptr[r], MPI_INT, nbrank[r], MPI_TAG, comm, sendreq + r);

	for (int r = 0; r < nnb; ++r)
		if (sendptr[r + 1] > sendptr[r])
			MPI_Wait(recvreq + r, &status);

	for (int r = 0; r < nnb; ++r)
		if (recvptr[r + 1] > recvptr[r])
			MPI_Wait(sendreq + r, &status);

	delete[] recvreq;
	delete[] sendreq;
}

int ParBSRMatrix::InSize() const
{
	return local.size[1] * local.bsize;
}

int ParBSRMatrix::OutSize() const
{
	return local.size[0] * local.bsize;
}

void ParBSRMatrix::Apply(const ParVector& x, const ParVector& y) const
{
	ParBSRMatVec(1.0, *this, x, 0.0, y);
}

void ParCSRToBSR(int bsize, const ParCSRMatrix& A, ParBSRMatrix& B)
{
	MPI_Comm comm = A.comm;

	int n = A.local.size[0];
	int nb = (n - 1) / bsize + 1;
	int bnnz = bsize * bsize;

	int* A_exter_rowptr = A.exter.rowptr;
	int* A_exter_colind = A.exter.colind;
	double* A_exter_values = A.exter.values;

	int nnb = A.nnb;
	int* A_nbrank = A.nbrank;

	int* B_nbrank = new int[nnb];
	for (int r = 0; r < nnb; ++r)
		B_nbrank[r] = A_nbrank[r];

	int* A_recvptr = A.recvptr;
	int* A_recvind = A.recvind;

	int* A_recvfrom = new int[A.exter.size[1]];
	for (int r = 0; r < nnb; ++r)
		for (int i = A_recvptr[r]; i < A_recvptr[r + 1]; ++i)
			A_recvfrom[i] = r;

	int B_recvcnt = 0;
	int* B_recvptr = new int[nnb + 1];
	B_recvptr[0] = 0;
	std::map<int, int>* recvmap = new std::map<int, int>[nnb];
	for (int r = 0; r < nnb; B_recvcnt += recvmap[r].size(), B_recvptr[++r] = B_recvcnt)
		for (int i = A_recvptr[r]; i < A_recvptr[r + 1]; ++i)
			recvmap[r].insert(std::pair<int, int>(A_recvind[i] / bsize, B_recvcnt + recvmap[r].size()));

	int* B_recvind = new int[B_recvcnt];

	for (int r = 0; r < nnb; ++r)
		for (std::map<int, int>::iterator iter = recvmap[r].begin(); iter != recvmap[r].end(); ++iter)
			B_recvind[iter->second] = iter->first;

	int* B_exter_rowptr = new int[nb + 1];

	B_exter_rowptr[0] = 0;
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel
#endif
	{
		int* y = new int[B_recvcnt];
		for (int i = 0; i < B_recvcnt; ++i)
			y[i] = -1;
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
		for (int i = 0; i < nb; ++i)
		{
			int cnt = 0;
			for (int ii = 0; ii < bsize; ++ii)
			{
				int ia = i * bsize + ii;
				if (ia >= n) break;
				for (int j = A_exter_rowptr[ia]; j < A_exter_rowptr[ia + 1]; ++j)
				{
					int jcol = A_exter_colind[j];
					int jfrom = A_recvfrom[jcol];
					int jcolb = recvmap[jfrom][A_recvind[jcol] / bsize];
					if (y[jcolb] != i)
					{
						y[jcolb] = i;
						++cnt;
					}
				}
			}
			B_exter_rowptr[i + 1] = cnt;
		}
		delete[] y;
	}

	for (int i = 0; i < nb; ++i)
		B_exter_rowptr[i + 1] += B_exter_rowptr[i];

	int* B_exter_indices = new int[B_exter_rowptr[nb]];
	double* B_exter_values = new double[B_exter_rowptr[nb] * bnnz];

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel
#endif
	{
		int* y = new int[B_recvcnt];
		for (int i = 0; i < B_recvcnt; ++i)
			y[i] = -1;
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
		for (int i = 0; i < nb; ++i)
		{
			for (int ii = 0, r = B_exter_rowptr[i], r0 = B_exter_rowptr[i]; ii < bsize; ++ii)
			{
				int ia = i * bsize + ii;
				if (ia >= n) break;
				for (int j = A_exter_rowptr[ia]; j < A_exter_rowptr[ia + 1]; ++j)
				{
					int jcol = A_exter_colind[j];
					int jfrom = A_recvfrom[jcol];
					int jj = A_recvind[jcol] % bsize;
					int jcolb = recvmap[jfrom][A_recvind[jcol] / bsize];
					double jval = A_exter_values[j];
					if (y[jcolb] < r0)
					{
						y[jcolb] = r;
						B_exter_indices[r] = jcolb;
						BSRBlockFill(bsize, 0.0, B_exter_values + r * bnnz);
						++r;
					}
					B_exter_values[y[jcolb] * bnnz + ii + jj * bsize] = jval;
				}
			}
		}
		delete[] y;
	}

	delete[] recvmap;
	delete[] A_recvfrom;

	BSRMatrix B_local;
	CSRToBSR(bsize, A.local, B_local);

	B_local.ref = 1;

	B.Free();

	B.comm = comm;
	B.local.size[0] = B_local.size[0];
	B.local.size[1] = B_local.size[1];
	B.local.bsize = B_local.bsize;
	B.local.rowptr = B_local.rowptr;
	B.local.colind = B_local.colind;
	B.local.values = B_local.values;
	B.exter.size[0] = nb;
	B.exter.size[1] = B_recvcnt;
	B.exter.bsize = bsize;
	B.exter.rowptr = B_exter_rowptr;
	B.exter.colind = B_exter_indices;
	B.exter.values = B_exter_values;
	B.nnb = nnb;
	B.nbrank = B_nbrank;
	B.recvptr = B_recvptr;
	B.recvind = B_recvind;
}

void ParBSRDiag(const ParBSRMatrix& A, const ParVector& D)
{
	BSRDiag(A.local, D.local);
}

void ParBSREliminZeros(const ParBSRMatrix& A)
{
	BSREliminZeros(A.local);
	BSREliminZeros(A.exter);
}

void ParBSRScale(double alpha, const ParBSRMatrix& A)
{
	BSRScale(alpha, A.local);
	BSRScale(alpha, A.exter);
}

void ParBSRScaleRows(const ParVector& x, const ParBSRMatrix& A)
{
	BSRScaleRows(x.local, A.local);
	BSRScaleRows(x.local, A.exter);
}

void ParBSRScaleCols(const ParVector& x, const ParBSRMatrix& A)
{
	int bsize = A.local.bsize;

	MPI_Comm comm = A.comm;
	int nnb = A.nnb;
	int* nbrank = A.nbrank;
	int* recvptr = A.recvptr;
	int* sendptr = A.sendptr;
	int* sendind = A.sendind;
	double* sendbuf = A.sendbuf;

	double* x_local_values = x.local.values;
	double* x_recv_values = A.recvx.values;

	MPI_Request* recvreq = new MPI_Request[nnb];
	MPI_Request* sendreq = new MPI_Request[nnb];
	MPI_Status status;

	for (int r = 0; r < nnb; ++r)
		if (recvptr[r + 1] > recvptr[r])
			MPI_Irecv(x_recv_values + recvptr[r] * bsize, (recvptr[r + 1] - recvptr[r]) * bsize, MPI_DOUBLE, nbrank[r], MPI_TAG, comm, recvreq + r);

	for (int r = 0; r < nnb; ++r)
	{
		if (sendptr[r + 1] > sendptr[r])
		{
			for (int i = sendptr[r]; i < sendptr[r + 1]; ++i)
				VecBlockCopy(bsize, x_local_values + sendind[i] * bsize, sendbuf + i * bsize);
			MPI_Isend(sendbuf + sendptr[r] * bsize, (sendptr[r + 1] - sendptr[r]) * bsize, MPI_DOUBLE, nbrank[r], MPI_TAG, comm, sendreq + r);
		}
	}

	BSRScaleCols(x.local, A.local);

	for (int r = 0; r < nnb; ++r)
		if (recvptr[r + 1] > recvptr[r])
			MPI_Wait(recvreq + r, &status);

	BSRScaleCols(A.recvx, A.exter);

	for (int r = 0; r < nnb; ++r)
		if (sendptr[r + 1] > sendptr[r])
			MPI_Wait(sendreq + r, &status);

	delete[] recvreq;
	delete[] sendreq;
}

void ParBSRMatAdd(const ParBSRMatrix& A, const ParBSRMatrix& B, ParBSRMatrix& C)
{
	MPI_Comm comm = A.comm;

	int comm_rank;
	MPI_Comm_rank(comm, &comm_rank);

	int n = A.local.size[0];
	int m = A.local.size[1];
	int bsize = A.local.bsize;
	int bnnz = bsize * bsize;

	int* A_exter_rowptr = A.exter.rowptr;
	int* A_exter_colind = A.exter.colind;
	double* A_exter_values = A.exter.values;

	int A_nnb = A.nnb;
	int* A_nbrank = A.nbrank;

	int* A_recvptr = A.recvptr;
	int* A_recvind = A.recvind;

	int* B_exter_rowptr = B.exter.rowptr;
	int* B_exter_colind = B.exter.colind;
	double* B_exter_values = B.exter.values;

	int B_nnb = B.nnb;
	int* B_nbrank = B.nbrank;

	int* B_recvptr = B.recvptr;
	int* B_recvind = B.recvind;

	std::map<int, int> nbmap;
	for (int r = 0; r < A_nnb; ++r)
		nbmap.insert(std::pair<int, int>(A_nbrank[r], r));
	for (int r = 0; r < B_nnb; ++r)
		nbmap.insert(std::pair<int, int>(B_nbrank[r], nbmap.size()));

	int C_nnb = nbmap.size();
	int* C_nbrank = new int[C_nnb];
	for (std::map<int, int>::iterator iter = nbmap.begin(); iter != nbmap.end(); ++iter)
		C_nbrank[iter->second] = iter->first;

	std::map<int, int>* recvmap = new std::map<int, int>[C_nnb];
	for (int r = 0; r < A_nnb; ++r)
		for (int i = A_recvptr[r], j = 0; i < A_recvptr[r + 1]; ++i, ++j)
			recvmap[r].insert(std::pair<int, int>(A_recvind[i], j));

	int* w = new int[A_recvptr[A_nnb]];
	int* v = new int[B_recvptr[B_nnb]];

	for (int r = 0; r < B_nnb; ++r)
	{
		int _r = nbmap[B_nbrank[r]];
		for (int i = B_recvptr[r]; i < B_recvptr[r + 1]; ++i)
		{
			std::pair<std::map<int, int>::iterator, bool> ret = recvmap[_r].insert(std::pair<int, int>(B_recvind[i], recvmap[_r].size()));
			v[i] = ret.first->second;
		}
	}

	int* C_recvptr = new int[C_nnb];
	C_recvptr[0] = 0;
	for (int r = 0; r < C_nnb; ++r)
		C_recvptr[r + 1] = C_recvptr[r] + recvmap[r].size();

	int* C_recvind = new int[C_recvptr[C_nnb]];
	for (int r = 0; r < C_nnb; ++r)
	{
		int i0 = C_recvptr[r];
		for (std::map<int, int>::iterator iter = recvmap[r].begin(); iter != recvmap[r].end(); ++iter)
			C_recvind[i0 + iter->second] = iter->first;
	}

	for (int r = 0; r < B_nnb; ++r)
	{
		int _r = nbmap[B_nbrank[r]];
		for (int i = B_recvptr[r], i0 = C_recvptr[_r]; i < B_recvptr[r + 1]; ++i)
			v[i] += i0;
	}

	for (int r = 0; r < A_nnb; ++r)
		for (int i = A_recvptr[r], k = C_recvptr[r] - A_recvptr[r]; i < A_recvptr[r + 1]; ++i)
			w[i] = i + k;

	int* _A_exter_colind = new int[A_exter_rowptr[n]];
	int* _B_exter_colind = new int[B_exter_rowptr[n]];

	for (int j = 0; j < A_exter_rowptr[n]; ++j)
		_A_exter_colind[j] = w[A_exter_colind[j]];
	for (int j = 0; j < B_exter_rowptr[n]; ++j)
		_B_exter_colind[j] = v[B_exter_colind[j]];

	delete[] w;
	delete[] v;
	delete[] recvmap;
	
	BSRMatrix A_local, _A_exter, B_local, _B_exter, C_local, C_exter;

	A_local.Refer(A.local);
	B_local.Refer(B.local);

	_A_exter.size[0] = n;
	_A_exter.size[1] = C_recvptr[C_nnb];
	_A_exter.bsize = bsize;
	_A_exter.rowptr = A_exter_rowptr;
	_A_exter.colind = _A_exter_colind;
	_A_exter.values = A_exter_values;
	_A_exter.ref = 1;

	_B_exter.size[0] = n;
	_B_exter.size[1] = C_recvptr[C_nnb];
	_B_exter.bsize = bsize;
	_B_exter.rowptr = B_exter_rowptr;
	_B_exter.colind = _B_exter_colind;
	_B_exter.values = B_exter_values;
	_B_exter.ref = 1;

	BSRMatAdd(A_local, B_local, C_local);
	BSRMatAdd(_A_exter, _B_exter, C_exter);

	C_local.ref = 1;
	C_exter.ref = 1;

	delete[] _A_exter_colind;
	delete[] _B_exter_colind;

	C.Free();

	C.comm = comm;

	C.local.size[0] = C_local.size[0];
	C.local.size[1] = C_local.size[1];
	C.local.bsize = C_local.bsize;
	C.local.rowptr = C_local.rowptr;
	C.local.colind = C_local.colind;
	C.local.values = C_local.values;

	C.exter.size[0] = C_exter.size[0];
	C.exter.size[1] = C_exter.size[1];
	C.exter.bsize = C_exter.bsize;
	C.exter.rowptr = C_exter.rowptr;
	C.exter.colind = C_exter.colind;
	C.exter.values = C_exter.values;

	C.nnb = C_nnb;
	C.nbrank = C_nbrank;
	C.recvptr = C_recvptr;
	C.recvind = C_recvind;
}

void ParBSRMatMul(const ParBSRMatrix& A, const ParBSRMatrix& B, ParBSRMatrix& C)
{
	MPI_Comm comm = A.comm;

	int comm_rank;
	MPI_Comm_rank(comm, &comm_rank);

	int nnb = A.nnb;
	int* nbrank = A.nbrank;

	int* recvptr = A.recvptr;
	int* sendptr = A.sendptr;
	int* sendind = A.sendind;

	int n = A.local.size[0];
	int m = B.local.size[1];

	int bsize = A.local.bsize;
	int bnnz = bsize * bsize;

	int* A_local_rowptr = A.local.rowptr;
	int* A_local_colind = A.local.colind;
	double* A_local_values = A.local.values;

	int* A_exter_rowptr = A.exter.rowptr;
	int* A_exter_colind = A.exter.colind;
	double* A_exter_values = A.exter.values;

	int* B_local_rowptr = B.local.rowptr;
	int* B_local_colind = B.local.colind;
	double* B_local_values = B.local.values;

	int* B_exter_rowptr = B.exter.rowptr;
	int* B_exter_colind = B.exter.colind;
	double* B_exter_values = B.exter.values;

	int B_nnb = B.nnb;
	int* B_nbrank = B.nbrank;
	int* B_recvptr = B.recvptr;
	int* B_recvind = B.recvind;

	int* B_recvfrom = new int[B.exter.size[1]];
	for (int r = 0; r < B_nnb; ++r)
		for (int i = B_recvptr[r]; i < B_recvptr[r + 1]; ++i)
			B_recvfrom[i] = r;

	std::map<int, int> nbmap;
	for (int r = 0; r < B_nnb; ++r)
		nbmap.insert(std::pair<int, int>(B_nbrank[r], r));
	for (int r = 0; r < nnb; ++r)
		nbmap.insert(std::pair<int, int>(nbrank[r], nbmap.size()));

	int C_nnb = nbmap.size();
	int* C_nbrank = new int[C_nnb];
	for (std::map<int, int>::iterator iter = nbmap.begin(); iter != nbmap.end(); ++iter)
		C_nbrank[iter->second] = iter->first;

	std::set<int>* nbset = new std::set<int>[C_nnb];

	for (int r = 0; r < nnb; ++r)
	{
		int _r = nbmap[nbrank[r]];
		for (int i = sendptr[r]; i < sendptr[r + 1]; ++i)
		{
			int irow = sendind[i];
			for (int j = B_exter_rowptr[irow]; j < B_exter_rowptr[irow + 1]; ++j)
			{
				int jfrom = B_recvfrom[B_exter_colind[j]];
				if (jfrom != _r)
				{
					nbset[_r].insert(B_nbrank[jfrom]);
					nbset[jfrom].insert(nbrank[r]);
				}
			}
		}
	}

	int** recvnbset = new int* [C_nnb];
	int** sendnbset = new int* [C_nnb];

	MPI_Request* recvreq = new MPI_Request[C_nnb];
	MPI_Request* sendreq = new MPI_Request[C_nnb];
	MPI_Status status;

	for (int r = 0; r < C_nnb; ++r)
	{
		sendnbset[r] = new int[nbset[r].size()];
		int i = 0;
		for (std::set<int>::iterator iter = nbset[r].begin(); iter != nbset[r].end(); ++iter)
			sendnbset[r][i++] = *iter;
		MPI_Isend(sendnbset[r], nbset[r].size(), MPI_INT, C_nbrank[r], MPI_TAG, comm, sendreq + r);
	}

	for (int r = 0; r < C_nnb; ++r)
	{
		int cnt;
		MPI_Probe(C_nbrank[r], MPI_TAG, comm, &status);
		MPI_Get_count(&status, MPI_INT, &cnt);
		recvnbset[r] = new int[cnt];
		MPI_Recv(recvnbset[r], cnt, MPI_INT, C_nbrank[r], MPI_TAG, comm, &status);
		for (int i = 0; i < cnt; ++i)
			nbmap.insert(std::pair<int, int>(recvnbset[r][i], nbmap.size()));
		delete[] recvnbset[r];
	}

	for (int r = 0; r < C_nnb; ++r)
	{
		MPI_Wait(sendreq + r, &status);
		delete[] sendnbset[r];
	}

	delete[] nbset;
	delete[] C_nbrank;
	delete[] recvnbset;
	delete[] sendnbset;

	C_nnb = nbmap.size();
	C_nbrank = new int[C_nnb];
	for (std::map<int, int>::iterator iter = nbmap.begin(); iter != nbmap.end(); ++iter)
		C_nbrank[iter->second] = iter->first;

	int* sendbufsize = new int[nnb];
	int* recvbufsize = new int[nnb];

	for (int r = 0; r < nnb; ++r)
		if (recvptr[r + 1] > recvptr[r])
			MPI_Irecv(recvbufsize + r, 1, MPI_INT, nbrank[r], MPI_TAG, comm, recvreq + r);

	for (int r = 0; r < nnb; ++r)
	{
		if (sendptr[r + 1] > sendptr[r])
		{
			int nrow = sendptr[r + 1] - sendptr[r];
			int nnz = 0;
			for (int i = sendptr[r]; i < sendptr[r + 1]; ++i)
				nnz += B_local_rowptr[sendind[i] + 1] - B_local_rowptr[sendind[i]] + B_exter_rowptr[sendind[i] + 1] - B_exter_rowptr[sendind[i]];
			sendbufsize[r] = (nrow + 2 * nnz) * sizeof(int) + nnz * bnnz * sizeof(double);
			MPI_Send(sendbufsize + r, 1, MPI_INT, nbrank[r], MPI_TAG, comm);
		}
	}

	for (int r = 0; r < nnb; ++r)
		if (recvptr[r + 1] > recvptr[r])
			MPI_Wait(recvreq + r, &status);

	char** recvbuf = new char* [nnb];
	char** sendbuf = new char* [nnb];
	
	for (int r = 0; r < nnb; ++r)
	{
		if (recvptr[r + 1] > recvptr[r])
		{
			recvbuf[r] = (char*)malloc(recvbufsize[r]);
			MPI_Irecv(recvbuf[r], recvbufsize[r], MPI_PACKED, nbrank[r], MPI_TAG, comm, recvreq + r);
		}
	}

	for (int r = 0; r < nnb; ++r)
	{
		if (sendptr[r + 1] > sendptr[r])
		{
			sendbuf[r] = (char*)malloc(sendbufsize[r]);

			int position = 0;
			for (int i = sendptr[r]; i < sendptr[r + 1]; ++i)
			{
				int irow = sendind[i];
				int length = B_local_rowptr[irow + 1] - B_local_rowptr[irow] + B_exter_rowptr[irow + 1] - B_exter_rowptr[irow];

				int* colfrom = new int[length];
				int* colind = new int[length];
				double* values = new double[length * bnnz];

				int j = 0;
				for (int k = B_local_rowptr[irow]; k < B_local_rowptr[irow + 1]; ++k, ++j)
				{
					colfrom[j] = comm_rank;
					colind[j] = B_local_colind[k];
					BSRBlockCopy(bsize, B_local_values + k * bnnz, values + j * bnnz);
				}
				for (int k = B_exter_rowptr[irow]; k < B_exter_rowptr[irow + 1]; ++k, ++j)
				{
					int kcol = B_exter_colind[k];
					colfrom[j] = B_nbrank[B_recvfrom[kcol]];
					colind[j] = B_recvind[kcol];
					BSRBlockCopy(bsize, B_exter_values + k * bnnz, values + j * bnnz);
				}

				MPI_Pack(&length, 1, MPI_INT, sendbuf[r], sendbufsize[r], &position, comm);
				MPI_Pack(colfrom, length, MPI_INT, sendbuf[r], sendbufsize[r], &position, comm);
				MPI_Pack(colind, length, MPI_INT, sendbuf[r], sendbufsize[r], &position, comm);
				MPI_Pack(values, length * bnnz, MPI_DOUBLE, sendbuf[r], sendbufsize[r], &position, comm);

				delete[] colfrom;
				delete[] colind;
				delete[] values;
			}

			MPI_Isend(sendbuf[r], sendbufsize[r], MPI_PACKED, nbrank[r], MPI_TAG, comm, sendreq + r);
		}
	}

	std::map<int, int>* recvmap = new std::map<int, int>[C_nnb];
	for (int r = 0; r < B_nnb; ++r)
		for (int i = B_recvptr[r], j = 0; i < B_recvptr[r + 1]; ++i, ++j)
			recvmap[r].insert(std::pair<int, int>(B_recvind[i], j));

	int B_recvnnz = 0;
	for (int r = 0; r < nnb; ++r)
	{
		if (recvptr[r + 1] > recvptr[r])
		{
			int nrow = recvptr[r + 1] - recvptr[r];
			int nnz = (recvbufsize[r] - nrow * sizeof(int)) / (2 * sizeof(int) + bnnz * sizeof(double));
			B_recvnnz += nnz;
		}
	}

	int* B_recvloc_rowptr = new int[A.exter.size[1] + 1];
	int* B_recvloc_colind = new int[B_recvnnz];
	double* B_recvloc_values = new double[B_recvnnz * bnnz];
	int* B_recvext_rowptr = new int[A.exter.size[1] + 1];
	int* B_recvext_colind = new int[B_recvnnz];
	double* B_recvext_values = new double[B_recvnnz * bnnz];
	int* B_recvext_colfrom = new int[B_recvnnz];

	B_recvloc_rowptr[0] = 0;
	B_recvext_rowptr[0] = 0;
	for (int r = 0; r < nnb; ++r)
	{
		if (recvptr[r + 1] > recvptr[r])
		{
			MPI_Wait(recvreq + r, &status);

			int position = 0;
			for (int i = recvptr[r], k = B_recvloc_rowptr[i], t = B_recvext_rowptr[i]; i < recvptr[r + 1]; B_recvloc_rowptr[++i] = k, B_recvext_rowptr[i] = t)
			{
				int length;
				MPI_Unpack(recvbuf[r], recvbufsize[r], &position, &length, 1, MPI_INT, comm);

				int* colfrom = new int[length];
				int* colind = new int[length];
				double* values = new double[length * bnnz];

				MPI_Unpack(recvbuf[r], recvbufsize[r], &position, colfrom, length, MPI_INT, comm);
				MPI_Unpack(recvbuf[r], recvbufsize[r], &position, colind, length, MPI_INT, comm);
				MPI_Unpack(recvbuf[r], recvbufsize[r], &position, values, length * bnnz, MPI_DOUBLE, comm);

				for (int j = 0; j < length; ++j)
				{
					if (colfrom[j] == comm_rank)
					{
						B_recvloc_colind[k] = colind[j];
						BSRBlockCopy(bsize, values + j * bnnz, B_recvloc_values + k * bnnz);
						++k;
					}
					else
					{
						int jfrom = nbmap[colfrom[j]];
						B_recvext_colfrom[t] = jfrom;
						std::pair<std::map<int, int>::iterator, bool> ret = recvmap[jfrom].insert(std::pair<int, int>(colind[j], recvmap[jfrom].size()));
						B_recvext_colind[t] = ret.first->second;
						BSRBlockCopy(bsize, values + j * bnnz, B_recvext_values + t * bnnz);
						++t;
					}
				}

				delete[] colfrom;
				delete[] colind;
				delete[] values;
			}
			
			free(recvbuf[r]);
		}
	}

	for (int r = 0; r < nnb; ++r)
	{
		if (sendptr[r + 1] > sendptr[r])
		{
			MPI_Wait(sendreq + r, &status);
			free(sendbuf[r]);
		}
	}

	delete[] recvbufsize;
	delete[] recvbuf;
	delete[] recvreq;
	delete[] sendbufsize;
	delete[] sendbuf;
	delete[] sendreq;

	int* C_recvptr = new int[C_nnb + 1];
	C_recvptr[0] = 0;
	for (int r = 0; r < C_nnb; ++r)
		C_recvptr[r + 1] = C_recvptr[r] + recvmap[r].size();

	int C_recvcnt = C_recvptr[C_nnb];
	int* C_recvind = new int[C_recvcnt];
	for (int r = 0; r < C_nnb; ++r)
		for (std::map<int, int>::iterator iter = recvmap[r].begin(); iter != recvmap[r].end(); ++iter)
			C_recvind[C_recvptr[r] + iter->second] = iter->first;

	for (int j = 0; j < B_recvext_rowptr[A.exter.size[1]]; ++j)
		B_recvext_colind[j] += C_recvptr[B_recvext_colfrom[j]];

	int* _B_exter_colind = new int[B_exter_rowptr[B.exter.size[0]]];

	for (int j = 0; j < B_exter_rowptr[B.exter.size[0]]; ++j)
	{
		int r = B_recvfrom[B_exter_colind[j]];
		_B_exter_colind[j] = B_exter_colind[j] - B_recvptr[r] + C_recvptr[r];
	}

	delete[] recvmap;
	delete[] B_recvfrom;
	delete[] B_recvext_colfrom;

	int* C_local_rowptr = new int[n + 1];
	int* C_exter_rowptr = new int[n + 1];
	C_local_rowptr[0] = 0;
	C_exter_rowptr[0] = 0;
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel
#endif
	{
		int* w = new int[m];
		int* v = new int[C_recvcnt];
		for (int i = 0; i < m; ++i)
			w[i] = -1;
		for (int i = 0; i < C_recvcnt; ++i)
			v[i] = -1;
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
		for (int i = 0; i < n; ++i)
		{
			int cntloc = 0;
			int cntext = 0;

			for (int k = A_local_rowptr[i]; k < A_local_rowptr[i + 1]; ++k)
			{
				int kcol = A_local_colind[k];

				for (int j = B_local_rowptr[kcol]; j < B_local_rowptr[kcol + 1]; ++j)
				{
					int jcol = B_local_colind[j];
					if (w[jcol] != i)
					{
						w[jcol] = i;
						++cntloc;
					}
				}

				for (int j = B_exter_rowptr[kcol]; j < B_exter_rowptr[kcol + 1]; ++j)
				{
					int jcol = _B_exter_colind[j];
					if (v[jcol] != i)
					{
						v[jcol] = i;
						++cntext;
					}
				}
			}

			for (int k = A_exter_rowptr[i]; k < A_exter_rowptr[i + 1]; ++k)
			{
				int kcol = A_exter_colind[k];

				for (int j = B_recvloc_rowptr[kcol]; j < B_recvloc_rowptr[kcol + 1]; ++j)
				{
					int jcol = B_recvloc_colind[j];
					if (w[jcol] != i)
					{
						w[jcol] = i;
						++cntloc;
					}
				}

				for (int j = B_recvext_rowptr[kcol]; j < B_recvext_rowptr[kcol + 1]; ++j)
				{
					int jcol = B_recvext_colind[j];
					if (v[jcol] != i)
					{
						v[jcol] = i;
						++cntext;
					}
				}
			}

			C_local_rowptr[i + 1] = cntloc;
			C_exter_rowptr[i + 1] = cntext;
		}

		delete[] w;
		delete[] v;
	}

	for (int i = 0; i < n; ++i)
		C_local_rowptr[i + 1] += C_local_rowptr[i];
	for (int i = 0; i < n; ++i)
		C_exter_rowptr[i + 1] += C_exter_rowptr[i];

	int* C_local_colind = new int[C_local_rowptr[n]];
	double* C_local_values = new double[C_local_rowptr[n]];
	int* C_exter_colind = new int[C_exter_rowptr[n]];
	double* C_exter_values = new double[C_exter_rowptr[n]];

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel
#endif
	{
		int* w = new int[m];
		int* v = new int[C_recvcnt];
		for (int i = 0; i < m; ++i)
			w[i] = -1;
		for (int i = 0; i < C_recvcnt; ++i)
			v[i] = -1;

#define BSR_UNROLL_SEGMENT(N) \
	for (int i = 0; i < n; ++i) \
	{ \
		int r = C_local_rowptr[i]; \
		int r0 = C_local_rowptr[i]; \
		int t = C_exter_rowptr[i]; \
		int t0 = C_exter_rowptr[i]; \
		for (int k = A_local_rowptr[i]; k < A_local_rowptr[i + 1]; ++k) \
		{ \
			int kcol = A_local_colind[k]; \
			for (int j = B_local_rowptr[kcol]; j < B_local_rowptr[kcol + 1]; ++j) \
			{ \
				int jcol = B_local_colind[j]; \
				if (w[jcol] < r0) \
				{ \
					w[jcol] = r; \
					C_local_colind[r] = jcol; \
					BSRBlockMatMul_UNROLL(N, A_local_values + k * N * N, B_local_values + j * N * N, C_local_values + r * N * N); \
					++r; \
				} \
				else \
					BSRBlockMatMulAdd_UNROLL(N, A_local_values + k * N * N, B_local_values + j * N * N, C_local_values + w[jcol] * N * N); \
			} \
			for (int j = B_exter_rowptr[kcol]; j < B_exter_rowptr[kcol + 1]; ++j) \
			{ \
				int jcol = _B_exter_colind[j]; \
				if (v[jcol] < t0) \
				{ \
					v[jcol] = t; \
					C_exter_colind[t] = jcol; \
					BSRBlockMatMul_UNROLL(N, A_local_values + k * N * N, B_exter_values + j * N * N, C_exter_values + t * N * N); \
					++t; \
				} \
				else \
					BSRBlockMatMulAdd_UNROLL(N, A_local_values + k * N * N, B_exter_values + j * N * N, C_exter_values + v[jcol] * N * N); \
			} \
		} \
		for (int k = A_exter_rowptr[i]; k < A_exter_rowptr[i + 1]; ++k) \
		{ \
			int kcol = A_exter_colind[k]; \
			for (int j = B_recvloc_rowptr[kcol]; j < B_recvloc_rowptr[kcol + 1]; ++j) \
			{ \
				int jcol = B_recvloc_colind[j]; \
				if (w[jcol] < r0) \
				{ \
					w[jcol] = r; \
					C_local_colind[r] = jcol; \
					BSRBlockMatMul_UNROLL(N, A_exter_values + k * N * N, B_recvloc_values + j * N * N, C_local_values + r * N * N); \
					++r; \
				} \
				else \
					BSRBlockMatMulAdd_UNROLL(N, A_exter_values + k * N * N, B_recvloc_values + j * N * N, C_local_values + w[jcol] * N * N); \
			} \
			for (int j = B_recvext_rowptr[kcol]; j < B_recvext_rowptr[kcol + 1]; ++j) \
			{ \
				int jcol = B_recvext_colind[j]; \
				if (v[jcol] < t0) \
				{ \
					v[jcol] = t; \
					C_exter_colind[t] = jcol; \
					BSRBlockMatMul_UNROLL(N, A_exter_values + k * N * N, B_recvext_values + j * N * N, C_exter_values + t * N * N); \
					++t; \
				} \
				else \
					BSRBlockMatMulAdd_UNROLL(N, A_exter_values + k * N * N, B_recvext_values + j * N * N, C_exter_values + v[jcol] * N * N); \
			} \
		} \
	}

#ifdef BSR_UNROLL_1
		if (bsize == 1)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
			BSR_UNROLL_SEGMENT(1)
		}
		else
#endif
#ifdef BSR_UNROLL_2
		if (bsize == 2)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
			BSR_UNROLL_SEGMENT(2)
		}
		else
#endif
#ifdef BSR_UNROLL_3
		if (bsize == 3)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
			BSR_UNROLL_SEGMENT(3)
		}
		else
#endif
#ifdef BSR_UNROLL_4
		if (bsize == 4)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
			BSR_UNROLL_SEGMENT(4)
		}
		else
#endif
#ifdef BSR_UNROLL_5
		if (bsize == 5)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
			BSR_UNROLL_SEGMENT(5)
		}
		else
#endif
#ifdef BSR_UNROLL_6
		if (bsize == 6)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
			BSR_UNROLL_SEGMENT(6)
		}
		else
#endif
#ifdef BSR_UNROLL_7
		if (bsize == 7)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
			BSR_UNROLL_SEGMENT(7)
		}
		else
#endif
#ifdef BSR_UNROLL_8
		if (bsize == 8)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
			BSR_UNROLL_SEGMENT(8)
		}
		else
#endif
#undef BSR_UNROLL_SEGMENT
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				int r = C_local_rowptr[i];
				int r0 = C_local_rowptr[i];
				int t = C_exter_rowptr[i];
				int t0 = C_exter_rowptr[i];

				for (int k = A_local_rowptr[i]; k < A_local_rowptr[i + 1]; ++k)
				{
					int kcol = A_local_colind[k];

					for (int j = B_local_rowptr[kcol]; j < B_local_rowptr[kcol + 1]; ++j)
					{
						int jcol = B_local_colind[j];

						if (w[jcol] < r0)
						{
							w[jcol] = r;
							C_local_colind[r] = jcol;
							BSRBlockMatMul(bsize, A_local_values + k * bnnz, B_local_values + j * bnnz, C_local_values + r * bnnz);
							++r;
						}
						else
							BSRBlockMatMulAdd(bsize, A_local_values + k * bnnz, B_local_values + j * bnnz, C_local_values + w[jcol] * bnnz);
					}

					for (int j = B_exter_rowptr[kcol]; j < B_exter_rowptr[kcol + 1]; ++j)
					{
						int jcol = _B_exter_colind[j];

						if (v[jcol] < t0)
						{
							v[jcol] = t;
							C_exter_colind[t] = jcol;
							BSRBlockMatMul(bsize, A_local_values + k * bnnz, B_exter_values + j * bnnz, C_exter_values + t * bnnz);
							++t;
						}
						else
							BSRBlockMatMulAdd(bsize, A_local_values + k * bnnz, B_exter_values + j * bnnz, C_exter_values + v[jcol] * bnnz);
					}
				}

				for (int k = A_exter_rowptr[i]; k < A_exter_rowptr[i + 1]; ++k)
				{
					int kcol = A_exter_colind[k];

					for (int j = B_recvloc_rowptr[kcol]; j < B_recvloc_rowptr[kcol + 1]; ++j)
					{
						int jcol = B_recvloc_colind[j];

						if (w[jcol] < r0)
						{
							w[jcol] = r;
							C_local_colind[r] = jcol;
							BSRBlockMatMul(bsize, A_exter_values + k * bnnz, B_recvloc_values + j * bnnz, C_local_values + r * bnnz);
							++r;
						}
						else
							BSRBlockMatMulAdd(bsize, A_exter_values + k * bnnz, B_recvloc_values + j * bnnz, C_local_values + w[jcol] * bnnz);
					}
					
					for (int j = B_recvext_rowptr[kcol]; j < B_recvext_rowptr[kcol + 1]; ++j)
					{
						int jcol = B_recvext_colind[j];

						if (v[jcol] < t0)
						{
							v[jcol] = t;
							C_exter_colind[t] = jcol;
							BSRBlockMatMul(bsize, A_exter_values + k * bnnz, B_recvext_values + j * bnnz, C_exter_values + t * bnnz);
							++t;
						}
						else
							BSRBlockMatMulAdd(bsize, A_exter_values + k * bnnz, B_recvext_values + j * bnnz, C_exter_values + v[jcol] * bnnz);
					}					
				}
			}
		}

		delete[] w;
		delete[] v;
	}

	delete[] _B_exter_colind;

	int* v = new int[C_recvcnt];
	for (int i = 0; i < C_recvcnt; ++i)
		v[i] = -1;

	for (int j = C_exter_rowptr[0]; j < C_exter_rowptr[n]; ++j)
		v[C_exter_colind[j]] = 1;

	for (int r = 0, k = 0, i = 0; r < C_nnb; C_recvptr[++r] = k)
	{
		for ( ; i < C_recvptr[r + 1]; ++i)
		{
			if (v[i] == 1)
			{
				v[i] = k;
				C_recvind[k++] = C_recvind[i];
			}
		}
	}

	for (int j = C_exter_rowptr[0]; j < C_exter_rowptr[n]; ++j)
		C_exter_colind[j] = v[C_exter_colind[j]];

	C_recvcnt = C_recvptr[C_nnb];

	delete[] v;

	C.Free();

	C.comm = comm;

	C.local.size[0] = n;
	C.local.size[1] = m;
	C.local.bsize = bsize;
	C.local.rowptr = C_local_rowptr;
	C.local.colind = C_local_colind;
	C.local.values = C_local_values;

	C.exter.size[0] = n;
	C.exter.size[1] = C_recvcnt;
	C.exter.bsize = bsize;
	C.exter.rowptr = C_exter_rowptr;
	C.exter.colind = C_exter_colind;
	C.exter.values = C_exter_values;

	C.nnb = C_nnb;
	C.nbrank = C_nbrank;
	C.recvptr = C_recvptr;
	C.recvind = C_recvind;
}

void ParBSRMatVec(double alpha, const ParBSRMatrix& A, const ParVector& x, double beta, const ParVector& y)
{
	int bsize = A.local.bsize;

	MPI_Comm comm = A.comm;
	int nnb = A.nnb;
	int* nbrank = A.nbrank;
	int* recvptr = A.recvptr;
	int* sendptr = A.sendptr;
	int* sendind = A.sendind;
	double* sendbuf = A.sendbuf;

	double* x_local_values = x.local.values;
	double* y_local_values = y.local.values;

	double* x_recv_values = A.recvx.values;

	MPI_Request* recvreq = new MPI_Request[nnb];
	MPI_Request* sendreq = new MPI_Request[nnb];
	MPI_Status status;

	for (int r = 0; r < nnb; ++r)
		if (recvptr[r + 1] > recvptr[r])
			MPI_Irecv(x_recv_values + recvptr[r] * bsize, (recvptr[r + 1] - recvptr[r]) * bsize, MPI_DOUBLE, nbrank[r], MPI_TAG, comm, recvreq + r);

	for (int r = 0; r < nnb; ++r)
	{
		if (sendptr[r + 1] > sendptr[r])
		{
			for (int i = sendptr[r]; i < sendptr[r + 1]; ++i)
				VecBlockCopy(bsize, x_local_values + sendind[i] * bsize, sendbuf + i * bsize);
			MPI_Isend(sendbuf + sendptr[r] * bsize, (sendptr[r + 1] - sendptr[r]) * bsize, MPI_DOUBLE, nbrank[r], MPI_TAG, comm, sendreq + r);
		}
	}

	BSRMatVec(alpha, A.local, x.local, beta, y.local);

	for (int r = 0; r < nnb; ++r)
		if (recvptr[r + 1] > recvptr[r])
			MPI_Wait(recvreq + r, &status);

	BSRMatVec(alpha, A.exter, A.recvx, 1.0, y.local);

	for (int r = 0; r < nnb; ++r)
		if (sendptr[r + 1] > sendptr[r])
			MPI_Wait(sendreq + r, &status);

	delete[] recvreq;
	delete[] sendreq;
}

void ParBSRTrans(const ParBSRMatrix& A, ParBSRMatrix& B)
{
	MPI_Comm comm = A.comm;

	int n = A.local.size[0];
	int m = A.local.size[1];
	int bsize = A.local.bsize;
	int bnnz = bsize * bsize;

	int nnb = A.nnb;
	int* nbrank = A.nbrank;
	int* recvptr = A.recvptr;
	int* sendptr = A.sendptr;
	int* sendind = A.sendind;

	BSRMatrix A_exter_T;
	BSRTrans(A.exter, A_exter_T);

	int* A_exter_T_rowptr = A_exter_T.rowptr;
	int* A_exter_T_colind = A_exter_T.colind;
	double* A_exter_T_values = A_exter_T.values;

	MPI_Request* sendreq = new MPI_Request[nnb];
	MPI_Request* recvreq = new MPI_Request[nnb];
	MPI_Status status;

	int* sendbufsize = new int[nnb];
	int* recvbufsize = new int[nnb];

	for (int r = 0; r < nnb; ++r)
		if (sendptr[r + 1] > sendptr[r])
			MPI_Irecv(recvbufsize + r, 1, MPI_INT, nbrank[r], MPI_TAG, comm, recvreq + r);

	for (int r = 0; r < nnb; ++r)
	{
		if (recvptr[r + 1] > recvptr[r])
		{
			int nrow = recvptr[r + 1] - recvptr[r];
			int nnz = A_exter_T_rowptr[recvptr[r + 1]] - A_exter_T_rowptr[recvptr[r]];
			sendbufsize[r] = (1 + nrow + nnz) * sizeof(int) + nnz * bnnz * sizeof(double);
			MPI_Send(sendbufsize + r, 1, MPI_INT, nbrank[r], MPI_TAG, comm);
		}
	}

	for (int r = 0; r < nnb; ++r)
		if (sendptr[r + 1] > sendptr[r])
			MPI_Wait(recvreq + r, &status);

	char** sendbuf = new char* [nnb];
	char** recvbuf = new char* [nnb];

	for (int r = 0; r < nnb; ++r)
	{
		if (sendptr[r + 1] > sendptr[r])
		{
			recvbuf[r] = (char*)malloc(recvbufsize[r]);
			MPI_Irecv(recvbuf[r], recvbufsize[r], MPI_PACKED, nbrank[r], MPI_TAG, comm, recvreq + r);
		}
	}

	for (int r = 0; r < nnb; ++r)
	{
		if (recvptr[r + 1] > recvptr[r])
		{
			int nrow = recvptr[r + 1] - recvptr[r];
			int starting_row = recvptr[r];
			int nnz = A_exter_T_rowptr[recvptr[r + 1]] - A_exter_T_rowptr[recvptr[r]];
			sendbuf[r] = (char*)malloc(sendbufsize[r]);

			int position = 0;
			MPI_Pack(A_exter_T_rowptr + starting_row, nrow + 1, MPI_INT, sendbuf[r], sendbufsize[r], &position, comm);
			MPI_Pack(A_exter_T_colind + A_exter_T_rowptr[starting_row], nnz, MPI_INT, sendbuf[r], sendbufsize[r], &position, comm);
			MPI_Pack(A_exter_T_values + A_exter_T_rowptr[starting_row] * bnnz, nnz * bnnz, MPI_DOUBLE, sendbuf[r], sendbufsize[r], &position, comm);

			MPI_Isend(sendbuf[r], sendbufsize[r], MPI_PACKED, nbrank[r], MPI_TAG, comm, sendreq + r);
		}
	}

	int* B_exter_rowptr = new int[m + 1];
	for (int i = 0; i <= m; ++i)
		B_exter_rowptr[i] = 0;
	
	int* B_recvptr = new int[nnb + 1];
	B_recvptr[0] = 0;

	BSRMatrix* A_recvloc_T = new BSRMatrix[nnb];
	std::map<int, int> *recvmap = new std::map<int, int>[nnb];

	for (int r = 0, cnt = 0; r < nnb; B_recvptr[++r] = cnt)
	{
		if (sendptr[r + 1] > sendptr[r])
		{
			MPI_Wait(recvreq + r, &status);

			int nrow = sendptr[r + 1] - sendptr[r];
			int starting_row = sendptr[r];
			int nnz = (recvbufsize[r] - (nrow + 1) * sizeof(int)) / (sizeof(int) + bnnz * sizeof(double));

			int* rowptr = new int[nrow + 1];
			int* colind = new int[nnz];
			double* values = new double[nnz * bnnz];

			int position = 0;
			MPI_Unpack(recvbuf[r], recvbufsize[r], &position, rowptr, nrow + 1, MPI_INT, comm);
			MPI_Unpack(recvbuf[r], recvbufsize[r], &position, colind, nnz, MPI_INT, comm);
			MPI_Unpack(recvbuf[r], recvbufsize[r], &position, values, nnz * bnnz, MPI_DOUBLE, comm);

			for (int i = 0, t = rowptr[0]; i <= nrow; ++i)
				rowptr[i] -= t;

			for (int i = 0; i < nrow; ++i)
				B_exter_rowptr[sendind[starting_row + i]] += rowptr[i + 1] - rowptr[i];

			for (int j = 0; j < nnz; ++j)
			{
				std::pair<std::map<int, int>::iterator, bool> ret =
					recvmap[r].insert(std::pair<int, int>(colind[j], cnt + recvmap[r].size()));
				colind[j] = ret.first->second;
			}

			cnt += recvmap[r].size();

			A_recvloc_T[r].size[0] = nrow;
			A_recvloc_T[r].size[1] = recvmap[r].size();
			A_recvloc_T[r].bsize = bsize;
			A_recvloc_T[r].rowptr = rowptr;
			A_recvloc_T[r].colind = colind;
			A_recvloc_T[r].values = values;

			free(recvbuf[r]);
		}
	}

	for (int r = 0; r < nnb; ++r)
	{
		if (recvptr[r + 1] > recvptr[r])
		{
			MPI_Wait(sendreq + r, &status);
			free(sendbuf[r]);
		}
	}

	delete[] recvbufsize;
	delete[] sendbufsize;
	delete[] recvbuf;
	delete[] recvreq;
	delete[] sendbuf;
	delete[] sendreq;

	int* B_recvind = new int[B_recvptr[nnb]];
	for (int r = 0; r < nnb; ++r)
	{
		if (sendptr[r + 1] > sendptr[r])
		{
			for (std::map<int, int>::iterator iter = recvmap[r].begin(); iter != recvmap[r].end(); ++iter)
				B_recvind[iter->second] = iter->first;
		}
	}

	for (int i = 0; i < m; ++i)
		B_exter_rowptr[i + 1] += B_exter_rowptr[i];

	int* B_exter_colind = new int[B_exter_rowptr[m]];
	double* B_exter_values = new double[B_exter_rowptr[m] * bnnz];

	for (int r = nnb - 1; r >= 0; --r)
	{
		if (sendptr[r + 1] > sendptr[r])
		{
			int starting_row = sendptr[r];
			int nrow = A_recvloc_T[r].size[0];
			int* rowptr = A_recvloc_T[r].rowptr;
			int* colind = A_recvloc_T[r].colind;
			double* values = A_recvloc_T[r].values;

			for (int i = nrow - 1; i >= 0; --i)
			{
				int k = B_exter_rowptr[sendind[starting_row + i]];
				for (int j = rowptr[i + 1] - 1; j >= rowptr[i]; --j)
				{
					B_exter_colind[--k] = colind[j];
					BSRBlockCopy(bsize, values + j * bnnz, B_exter_values + k * bnnz);
				}
				B_exter_rowptr[sendind[starting_row + i]] = k;
			}
		}
	}

	delete[] A_recvloc_T;

	int* B_nbrank = new int[nnb];
	for (int r = 0; r < nnb; ++r)
		B_nbrank[r] = nbrank[r];

	B.Free();

	BSRTrans(A.local, B.local);

	B.comm = comm;
	B.exter.size[0] = m;
	B.exter.size[1] = B_recvptr[nnb];
	B.exter.bsize = bsize;
	B.exter.rowptr = B_exter_rowptr;
	B.exter.colind = B_exter_colind;
	B.exter.values = B_exter_values;
	B.nnb = nnb;
	B.nbrank = B_nbrank;
	B.recvptr = B_recvptr;
	B.recvind = B_recvind;
}

void ParCSRMultBSR(const ParCSRMatrix& A, const ParBSRMatrix& B, ParBSRMatrix& C)
{
	MPI_Comm comm = A.comm;

	int comm_rank;
	MPI_Comm_rank(comm, &comm_rank);

	int nnb = A.nnb;
	int* nbrank = A.nbrank;

	int* recvptr = A.recvptr;
	int* sendptr = A.sendptr;
	int* sendind = A.sendind;

	int n = A.local.size[0];
	int m = B.local.size[1];

	int bsize = B.local.bsize;
	int bnnz = bsize * bsize;

	int* A_local_rowptr = A.local.rowptr;
	int* A_local_colind = A.local.colind;
	double* A_local_values = A.local.values;

	int* A_exter_rowptr = A.exter.rowptr;
	int* A_exter_colind = A.exter.colind;
	double* A_exter_values = A.exter.values;

	int* B_local_rowptr = B.local.rowptr;
	int* B_local_colind = B.local.colind;
	double* B_local_values = B.local.values;

	int* B_exter_rowptr = B.exter.rowptr;
	int* B_exter_colind = B.exter.colind;
	double* B_exter_values = B.exter.values;

	int B_nnb = B.nnb;
	int* B_nbrank = B.nbrank;
	int* B_recvptr = B.recvptr;
	int* B_recvind = B.recvind;

	int* B_recvfrom = new int[B.exter.size[1]];
	for (int r = 0; r < B_nnb; ++r)
		for (int i = B_recvptr[r]; i < B_recvptr[r + 1]; ++i)
			B_recvfrom[i] = r;

	std::map<int, int> nbmap;
	for (int r = 0; r < B_nnb; ++r)
		nbmap.insert(std::pair<int, int>(B_nbrank[r], r));
	for (int r = 0; r < nnb; ++r)
		nbmap.insert(std::pair<int, int>(nbrank[r], nbmap.size()));

	int C_nnb = nbmap.size();
	int* C_nbrank = new int[C_nnb];
	for (std::map<int, int>::iterator iter = nbmap.begin(); iter != nbmap.end(); ++iter)
		C_nbrank[iter->second] = iter->first;

	std::set<int>* nbset = new std::set<int>[C_nnb];

	for (int r = 0; r < nnb; ++r)
	{
		int _r = nbmap[nbrank[r]];
		for (int i = sendptr[r]; i < sendptr[r + 1]; ++i)
		{
			int irow = sendind[i];
			for (int j = B_exter_rowptr[irow]; j < B_exter_rowptr[irow + 1]; ++j)
			{
				int jfrom = B_recvfrom[B_exter_colind[j]];
				if (jfrom != _r)
				{
					nbset[_r].insert(B_nbrank[jfrom]);
					nbset[jfrom].insert(nbrank[r]);
				}
			}
		}
	}

	int** recvnbset = new int* [C_nnb];
	int** sendnbset = new int* [C_nnb];

	MPI_Request* recvreq = new MPI_Request[C_nnb];
	MPI_Request* sendreq = new MPI_Request[C_nnb];
	MPI_Status status;

	for (int r = 0; r < C_nnb; ++r)
	{
		sendnbset[r] = new int[nbset[r].size()];
		int i = 0;
		for (std::set<int>::iterator iter = nbset[r].begin(); iter != nbset[r].end(); ++iter)
			sendnbset[r][i++] = *iter;
		MPI_Isend(sendnbset[r], nbset[r].size(), MPI_INT, C_nbrank[r], MPI_TAG, comm, sendreq + r);
	}

	for (int r = 0; r < C_nnb; ++r)
	{
		int cnt;
		MPI_Probe(C_nbrank[r], MPI_TAG, comm, &status);
		MPI_Get_count(&status, MPI_INT, &cnt);
		recvnbset[r] = new int[cnt];
		MPI_Recv(recvnbset[r], cnt, MPI_INT, C_nbrank[r], MPI_TAG, comm, &status);
		for (int i = 0; i < cnt; ++i)
			nbmap.insert(std::pair<int, int>(recvnbset[r][i], nbmap.size()));
		delete[] recvnbset[r];
	}

	for (int r = 0; r < C_nnb; ++r)
	{
		MPI_Wait(sendreq + r, &status);
		delete[] sendnbset[r];
	}

	delete[] nbset;
	delete[] C_nbrank;
	delete[] recvnbset;
	delete[] sendnbset;

	C_nnb = nbmap.size();
	C_nbrank = new int[C_nnb];
	for (std::map<int, int>::iterator iter = nbmap.begin(); iter != nbmap.end(); ++iter)
		C_nbrank[iter->second] = iter->first;

	int* sendbufsize = new int[nnb];
	int* recvbufsize = new int[nnb];

	for (int r = 0; r < nnb; ++r)
		if (recvptr[r + 1] > recvptr[r])
			MPI_Irecv(recvbufsize + r, 1, MPI_INT, nbrank[r], MPI_TAG, comm, recvreq + r);

	for (int r = 0; r < nnb; ++r)
	{
		if (sendptr[r + 1] > sendptr[r])
		{
			int nrow = sendptr[r + 1] - sendptr[r];
			int nnz = 0;
			for (int i = sendptr[r]; i < sendptr[r + 1]; ++i)
				nnz += B_local_rowptr[sendind[i] + 1] - B_local_rowptr[sendind[i]] + B_exter_rowptr[sendind[i] + 1] - B_exter_rowptr[sendind[i]];
			sendbufsize[r] = (nrow + 2 * nnz) * sizeof(int) + nnz * bnnz * sizeof(double);
			MPI_Send(sendbufsize + r, 1, MPI_INT, nbrank[r], MPI_TAG, comm);
		}
	}

	for (int r = 0; r < nnb; ++r)
		if (recvptr[r + 1] > recvptr[r])
			MPI_Wait(recvreq + r, &status);

	char** recvbuf = new char* [nnb];
	char** sendbuf = new char* [nnb];
	
	for (int r = 0; r < nnb; ++r)
	{
		if (recvptr[r + 1] > recvptr[r])
		{
			recvbuf[r] = (char*)malloc(recvbufsize[r]);
			MPI_Irecv(recvbuf[r], recvbufsize[r], MPI_PACKED, nbrank[r], MPI_TAG, comm, recvreq + r);
		}
	}

	for (int r = 0; r < nnb; ++r)
	{
		if (sendptr[r + 1] > sendptr[r])
		{
			sendbuf[r] = (char*)malloc(sendbufsize[r]);

			int position = 0;
			for (int i = sendptr[r]; i < sendptr[r + 1]; ++i)
			{
				int irow = sendind[i];
				int length = B_local_rowptr[irow + 1] - B_local_rowptr[irow] + B_exter_rowptr[irow + 1] - B_exter_rowptr[irow];

				int* colfrom = new int[length];
				int* colind = new int[length];
				double* values = new double[length * bnnz];

				int j = 0;
				for (int k = B_local_rowptr[irow]; k < B_local_rowptr[irow + 1]; ++k, ++j)
				{
					colfrom[j] = comm_rank;
					colind[j] = B_local_colind[k];
					BSRBlockCopy(bsize, B_local_values + k * bnnz, values + j * bnnz);
				}
				for (int k = B_exter_rowptr[irow]; k < B_exter_rowptr[irow + 1]; ++k, ++j)
				{
					int kcol = B_exter_colind[k];
					colfrom[j] = B_nbrank[B_recvfrom[kcol]];
					colind[j] = B_recvind[kcol];
					BSRBlockCopy(bsize, B_exter_values + k * bnnz, values + j * bnnz);
				}

				MPI_Pack(&length, 1, MPI_INT, sendbuf[r], sendbufsize[r], &position, comm);
				MPI_Pack(colfrom, length, MPI_INT, sendbuf[r], sendbufsize[r], &position, comm);
				MPI_Pack(colind, length, MPI_INT, sendbuf[r], sendbufsize[r], &position, comm);
				MPI_Pack(values, length * bnnz, MPI_DOUBLE, sendbuf[r], sendbufsize[r], &position, comm);

				delete[] colfrom;
				delete[] colind;
				delete[] values;
			}

			MPI_Isend(sendbuf[r], sendbufsize[r], MPI_PACKED, nbrank[r], MPI_TAG, comm, sendreq + r);
		}
	}

	std::map<int, int>* recvmap = new std::map<int, int>[C_nnb];
	for (int r = 0; r < B_nnb; ++r)
		for (int i = B_recvptr[r], j = 0; i < B_recvptr[r + 1]; ++i, ++j)
			recvmap[r].insert(std::pair<int, int>(B_recvind[i], j));

	int B_recvnnz = 0;
	for (int r = 0; r < nnb; ++r)
	{
		if (recvptr[r + 1] > recvptr[r])
		{
			int nrow = recvptr[r + 1] - recvptr[r];
			int nnz = (recvbufsize[r] - nrow * sizeof(int)) / (2 * sizeof(int) + bnnz * sizeof(double));
			B_recvnnz += nnz;
		}
	}

	int* B_recvloc_rowptr = new int[A.exter.size[1] + 1];
	int* B_recvloc_colind = new int[B_recvnnz];
	double* B_recvloc_values = new double[B_recvnnz * bnnz];
	int* B_recvext_rowptr = new int[A.exter.size[1] + 1];
	int* B_recvext_colind = new int[B_recvnnz];
	double* B_recvext_values = new double[B_recvnnz * bnnz];
	int* B_recvext_colfrom = new int[B_recvnnz];

	B_recvloc_rowptr[0] = 0;
	B_recvext_rowptr[0] = 0;
	for (int r = 0; r < nnb; ++r)
	{
		if (recvptr[r + 1] > recvptr[r])
		{
			MPI_Wait(recvreq + r, &status);

			int position = 0;
			for (int i = recvptr[r], k = B_recvloc_rowptr[i], t = B_recvext_rowptr[i]; i < recvptr[r + 1]; B_recvloc_rowptr[++i] = k, B_recvext_rowptr[i] = t)
			{
				int length;
				MPI_Unpack(recvbuf[r], recvbufsize[r], &position, &length, 1, MPI_INT, comm);

				int* colfrom = new int[length];
				int* colind = new int[length];
				double* values = new double[length * bnnz];

				MPI_Unpack(recvbuf[r], recvbufsize[r], &position, colfrom, length, MPI_INT, comm);
				MPI_Unpack(recvbuf[r], recvbufsize[r], &position, colind, length, MPI_INT, comm);
				MPI_Unpack(recvbuf[r], recvbufsize[r], &position, values, length * bnnz, MPI_DOUBLE, comm);

				for (int j = 0; j < length; ++j)
				{
					if (colfrom[j] == comm_rank)
					{
						B_recvloc_colind[k] = colind[j];
						BSRBlockCopy(bsize, values + j * bnnz, B_recvloc_values + k * bnnz);
						++k;
					}
					else
					{
						int jfrom = nbmap[colfrom[j]];
						B_recvext_colfrom[t] = jfrom;
						std::pair<std::map<int, int>::iterator, bool> ret = recvmap[jfrom].insert(std::pair<int, int>(colind[j], recvmap[jfrom].size()));
						B_recvext_colind[t] = ret.first->second;
						BSRBlockCopy(bsize, values + j * bnnz, B_recvext_values + t * bnnz);
						++t;
					}
				}

				delete[] colfrom;
				delete[] colind;
				delete[] values;
			}
			
			free(recvbuf[r]);
		}
	}

	for (int r = 0; r < nnb; ++r)
	{
		if (sendptr[r + 1] > sendptr[r])
		{
			MPI_Wait(sendreq + r, &status);
			free(sendbuf[r]);
		}
	}

	delete[] recvbufsize;
	delete[] recvbuf;
	delete[] recvreq;
	delete[] sendbufsize;
	delete[] sendbuf;
	delete[] sendreq;

	int* C_recvptr = new int[C_nnb + 1];
	C_recvptr[0] = 0;
	for (int r = 0; r < C_nnb; ++r)
		C_recvptr[r + 1] = C_recvptr[r] + recvmap[r].size();

	int C_recvcnt = C_recvptr[C_nnb];
	int* C_recvind = new int[C_recvcnt];
	for (int r = 0; r < C_nnb; ++r)
		for (std::map<int, int>::iterator iter = recvmap[r].begin(); iter != recvmap[r].end(); ++iter)
			C_recvind[C_recvptr[r] + iter->second] = iter->first;

	for (int j = 0; j < B_recvext_rowptr[A.exter.size[1]]; ++j)
		B_recvext_colind[j] += C_recvptr[B_recvext_colfrom[j]];

	int* _B_exter_colind = new int[B_exter_rowptr[B.exter.size[0]]];

	for (int j = 0; j < B_exter_rowptr[B.exter.size[0]]; ++j)
	{
		int r = B_recvfrom[B_exter_colind[j]];
		_B_exter_colind[j] = B_exter_colind[j] - B_recvptr[r] + C_recvptr[r];
	}

	delete[] recvmap;
	delete[] B_recvfrom;
	delete[] B_recvext_colfrom;

	int* C_local_rowptr = new int[n + 1];
	int* C_exter_rowptr = new int[n + 1];

	C_local_rowptr[0] = 0;
	C_exter_rowptr[0] = 0;

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel
#endif
	{
		int* w = new int[m];
		int* v = new int[C_recvcnt];

		for (int i = 0; i < m; ++i)
			w[i] = -1;
		for (int i = 0; i < C_recvcnt; ++i)
			v[i] = -1;

#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
		for (int i = 0; i < n; ++i)
		{
			int cntloc = 0;
			int cntext = 0;

			for (int k = A_local_rowptr[i]; k < A_local_rowptr[i + 1]; ++k)
			{
				int kcol = A_local_colind[k];

				for (int j = B_local_rowptr[kcol]; j < B_local_rowptr[kcol + 1]; ++j)
				{
					int jcol = B_local_colind[j];
					if (w[jcol] != i)
					{
						w[jcol] = i;
						++cntloc;
					}
				}

				for (int j = B_exter_rowptr[kcol]; j < B_exter_rowptr[kcol + 1]; ++j)
				{
					int jcol = _B_exter_colind[j];
					if (v[jcol] != i)
					{
						v[jcol] = i;
						++cntext;
					}
				}
			}

			for (int k = A_exter_rowptr[i]; k < A_exter_rowptr[i + 1]; ++k)
			{
				int kcol = A_exter_colind[k];

				for (int j = B_recvloc_rowptr[kcol]; j < B_recvloc_rowptr[kcol + 1]; ++j)
				{
					int jcol = B_recvloc_colind[j];
					if (w[jcol] != i)
					{
						w[jcol] = i;
						++cntloc;
					}
				}

				for (int j = B_recvext_rowptr[kcol]; j < B_recvext_rowptr[kcol + 1]; ++j)
				{
					int jcol = B_recvext_colind[j];
					if (v[jcol] != i)
					{
						v[jcol] = i;
						++cntext;
					}
				}
			}

			C_local_rowptr[i + 1] = cntloc;
			C_exter_rowptr[i + 1] = cntext;
		}

		delete[] w;
		delete[] v;
	}

	for (int i = 0; i < n; ++i)
		C_local_rowptr[i + 1] += C_local_rowptr[i];
	for (int i = 0; i < n; ++i)
		C_exter_rowptr[i + 1] += C_exter_rowptr[i];

	int* C_local_colind = new int[C_local_rowptr[n]];
	double* C_local_values = new double[C_local_rowptr[n] * bnnz];
	int* C_exter_colind = new int[C_exter_rowptr[n]];
	double* C_exter_values = new double[C_exter_rowptr[n] * bnnz];

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel
#endif
	{
		int* w = new int[m];
		int* v = new int[C_recvcnt];

		for (int i = 0; i < m; ++i)
			w[i] = -1;
		for (int i = 0; i < C_recvcnt; ++i)
			v[i] = -1;

#define BSR_UNROLL_SEGMENT(N) \
	for (int i = 0; i < n; ++i) \
	{ \
		int r = C_local_rowptr[i]; \
		int r0 = C_local_rowptr[i]; \
		int t = C_exter_rowptr[i]; \
		int t0 = C_exter_rowptr[i]; \
		for (int k = A_local_rowptr[i]; k < A_local_rowptr[i + 1]; ++k) \
		{ \
			int kcol = A_local_colind[k]; \
			for (int j = B_local_rowptr[kcol]; j < B_local_rowptr[kcol + 1]; ++j) \
			{ \
				int jcol = B_local_colind[j]; \
				if (w[jcol] < r0) \
				{ \
					w[jcol] = r; \
					C_local_colind[r] = jcol; \
					BSRBlockCopy_UNROLL(N, B_local_values + j * N *  N, C_local_values + r * N *  N); \
					BSRBlockScale_UNROLL(N, A_local_values[k], C_local_values + r * N *  N); \
					++r; \
				} \
				else \
					BSRBlockScaleAdd_UNROLL(N, A_local_values[k], B_local_values + j * N *  N, C_local_values + w[jcol] * N *  N); \
			} \
			for (int j = B_exter_rowptr[kcol]; j < B_exter_rowptr[kcol + 1]; ++j) \
			{ \
				int jcol = _B_exter_colind[j]; \
				if (v[jcol] < t0) \
				{ \
					v[jcol] = t; \
					C_exter_colind[t] = jcol; \
					BSRBlockCopy_UNROLL(N, B_exter_values + j * N *  N, C_exter_values + t * N *  N); \
					BSRBlockScale_UNROLL(N, A_local_values[k], C_exter_values + t * N *  N); \
					++t; \
				} \
				else \
					BSRBlockScaleAdd_UNROLL(N, A_local_values[k], B_exter_values + j * N *  N, C_exter_values + v[jcol] * N *  N); \
			} \
		} \
		for (int k = A_exter_rowptr[i]; k < A_exter_rowptr[i + 1]; ++k) \
		{ \
			int kcol = A_exter_colind[k]; \
			for (int j = B_recvloc_rowptr[kcol]; j < B_recvloc_rowptr[kcol + 1]; ++j) \
			{ \
				int jcol = B_recvloc_colind[j]; \
				if (w[jcol] < r0) \
				{ \
					w[jcol] = r; \
					C_local_colind[r] = jcol; \
					BSRBlockCopy_UNROLL(N, B_recvloc_values + j * N *  N, C_local_values + r * N *  N); \
					BSRBlockScale_UNROLL(N, A_exter_values[k], C_local_values + r * N *  N); \
					++r; \
				} \
				else \
					BSRBlockScaleAdd_UNROLL(N, A_exter_values[k], B_recvloc_values + j * N *  N, C_local_values + w[jcol] * N *  N); \
			} \
			for (int j = B_recvext_rowptr[kcol]; j < B_recvext_rowptr[kcol + 1]; ++j) \
			{ \
				int jcol = B_recvext_colind[j]; \
				if (v[jcol] < t0) \
				{ \
					v[jcol] = t; \
					C_exter_colind[t] = jcol; \
					BSRBlockCopy_UNROLL(N, B_recvext_values + j * N *  N, C_exter_values + t * N *  N); \
					BSRBlockScale_UNROLL(N, A_exter_values[k], C_exter_values + t * N *  N); \
					++t; \
				} \
				else \
					BSRBlockScaleAdd_UNROLL(N, A_exter_values[k], B_recvext_values + j * N *  N, C_exter_values + v[jcol] * N *  N); \
			} \
		} \
	}

#ifdef BSR_UNROLL_1
		if (bsize == 1)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
			BSR_UNROLL_SEGMENT(1)
		}
		else
#endif
#ifdef BSR_UNROLL_2
		if (bsize == 2)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
			BSR_UNROLL_SEGMENT(2)
		}
		else
#endif
#ifdef BSR_UNROLL_3
		if (bsize == 3)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
			BSR_UNROLL_SEGMENT(3)
		}
		else
#endif
#ifdef BSR_UNROLL_4
		if (bsize == 4)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
			BSR_UNROLL_SEGMENT(4)
		}
		else
#endif
#ifdef BSR_UNROLL_5
		if (bsize == 5)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
			BSR_UNROLL_SEGMENT(5)
		}
	else
#endif
#ifdef BSR_UNROLL_6
		if (bsize == 6)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
			BSR_UNROLL_SEGMENT(6)
		}
		else
#endif
#ifdef BSR_UNROLL_7
		if (bsize == 7)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
			BSR_UNROLL_SEGMENT(7)
		}
		else
#endif
#ifdef BSR_UNROLL_8
		if (bsize == 8)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
			BSR_UNROLL_SEGMENT(8)
		}
		else
#endif
#undef BSR_UNROLL_SEGMENT
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				int r = C_local_rowptr[i];
				int r0 = C_local_rowptr[i];
				int t = C_exter_rowptr[i];
				int t0 = C_exter_rowptr[i];

				for (int k = A_local_rowptr[i]; k < A_local_rowptr[i + 1]; ++k)
				{
					int kcol = A_local_colind[k];

					for (int j = B_local_rowptr[kcol]; j < B_local_rowptr[kcol + 1]; ++j)
					{
						int jcol = B_local_colind[j];

						if (w[jcol] < r0)
						{
							w[jcol] = r;
							C_local_colind[r] = jcol;
							BSRBlockCopy(bsize, B_local_values + j * bnnz, C_local_values + r * bnnz);
							BSRBlockScale(bsize, A_local_values[k], C_local_values + r * bnnz);
							++r;
						}
						else
							BSRBlockScaleAdd(bsize, A_local_values[k], B_local_values + j * bnnz, C_local_values + w[jcol] * bnnz);
					}

					for (int j = B_exter_rowptr[kcol]; j < B_exter_rowptr[kcol + 1]; ++j)
					{
						int jcol = _B_exter_colind[j];

						if (v[jcol] < t0)
						{
							v[jcol] = t;
							C_exter_colind[t] = jcol;
							BSRBlockCopy(bsize, B_exter_values + j * bnnz, C_exter_values + t * bnnz);
							BSRBlockScale(bsize, A_local_values[k], C_exter_values + t * bnnz);
							++t;
						}
						else
							BSRBlockScaleAdd(bsize, A_local_values[k], B_exter_values + j * bnnz, C_exter_values + v[jcol] * bnnz);
					}
				}

				for (int k = A_exter_rowptr[i]; k < A_exter_rowptr[i + 1]; ++k)
				{
					int kcol = A_exter_colind[k];

					for (int j = B_recvloc_rowptr[kcol]; j < B_recvloc_rowptr[kcol + 1]; ++j)
					{
						int jcol = B_recvloc_colind[j];
						
						if (w[jcol] < r0)
						{
							w[jcol] = r;
							C_local_colind[r] = jcol;
							BSRBlockCopy(bsize, B_recvloc_values + j * bnnz, C_local_values + r * bnnz);
							BSRBlockScale(bsize, A_exter_values[k], C_local_values + r * bnnz);
							++r;
						}
						else
							BSRBlockScaleAdd(bsize, A_exter_values[k], B_recvloc_values + j * bnnz, C_local_values + w[jcol] * bnnz);
					}

					for (int j = B_recvext_rowptr[kcol]; j < B_recvext_rowptr[kcol + 1]; ++j)
					{
						int jcol = B_recvext_colind[j];

						if (v[jcol] < t0)
						{
							v[jcol] = t;
							C_exter_colind[t] = jcol;
							BSRBlockCopy(bsize, B_recvext_values + j * bnnz, C_exter_values + t * bnnz);
							BSRBlockScale(bsize, A_exter_values[k], C_exter_values + t * bnnz);
							++t;
						}
						else
							BSRBlockScaleAdd(bsize, A_exter_values[k], B_recvext_values + j * bnnz, C_exter_values + v[jcol] * bnnz);
					}
				}
			}
		}

		delete[] w;
		delete[] v;
	}

	delete[] _B_exter_colind;

	int* v = new int[C_recvcnt];
	for (int i = 0; i < C_recvcnt; ++i)
		v[i] = -1;

	for (int j = C_exter_rowptr[0]; j < C_exter_rowptr[n]; ++j)
		v[C_exter_colind[j]] = 1;

	for (int r = 0, k = 0, i = 0; r < C_nnb; C_recvptr[++r] = k)
	{
		for ( ; i < C_recvptr[r + 1]; ++i)
		{
			if (v[i] == 1)
			{
				v[i] = k;
				C_recvind[k++] = C_recvind[i];
			}
		}
	}

	for (int j = C_exter_rowptr[0]; j < C_exter_rowptr[n]; ++j)
		C_exter_colind[j] = v[C_exter_colind[j]];

	C_recvcnt = C_recvptr[C_nnb];

	delete[] v;

	C.Free();

	C.comm = comm;

	C.local.size[0] = n;
	C.local.size[1] = m;
	C.local.bsize = bsize;
	C.local.rowptr = C_local_rowptr;
	C.local.colind = C_local_colind;
	C.local.values = C_local_values;

	C.exter.size[0] = n;
	C.exter.size[1] = C_recvcnt;
	C.exter.bsize = bsize;
	C.exter.rowptr = C_exter_rowptr;
	C.exter.colind = C_exter_colind;
	C.exter.values = C_exter_values;

	C.nnb = C_nnb;
	C.nbrank = C_nbrank;
	C.recvptr = C_recvptr;
	C.recvind = C_recvind;
}

void ParBSRMultCSR(const ParBSRMatrix& A, const ParCSRMatrix& B, ParBSRMatrix& C)
{
	MPI_Comm comm = A.comm;

	int comm_rank;
	MPI_Comm_rank(comm, &comm_rank);

	int nnb = A.nnb;
	int* nbrank = A.nbrank;

	int* recvptr = A.recvptr;
	int* sendptr = A.sendptr;
	int* sendind = A.sendind;

	int n = A.local.size[0];
	int m = B.local.size[1];

	int bsize = A.local.bsize;
	int bnnz = bsize * bsize;

	int* A_local_rowptr = A.local.rowptr;
	int* A_local_colind = A.local.colind;
	double* A_local_values = A.local.values;

	int* A_exter_rowptr = A.exter.rowptr;
	int* A_exter_colind = A.exter.colind;
	double* A_exter_values = A.exter.values;

	int* B_local_rowptr = B.local.rowptr;
	int* B_local_colind = B.local.colind;
	double* B_local_values = B.local.values;

	int* B_exter_rowptr = B.exter.rowptr;
	int* B_exter_colind = B.exter.colind;
	double* B_exter_values = B.exter.values;

	int B_nnb = B.nnb;
	int* B_nbrank = B.nbrank;
	int* B_recvptr = B.recvptr;
	int* B_recvind = B.recvind;

	int* B_recvfrom = new int[B.exter.size[1]];
	for (int r = 0; r < B_nnb; ++r)
		for (int i = B_recvptr[r]; i < B_recvptr[r + 1]; ++i)
			B_recvfrom[i] = r;

	std::map<int, int> nbmap;
	for (int r = 0; r < B_nnb; ++r)
		nbmap.insert(std::pair<int, int>(B_nbrank[r], r));
	for (int r = 0; r < nnb; ++r)
		nbmap.insert(std::pair<int, int>(nbrank[r], nbmap.size()));

	int C_nnb = nbmap.size();
	int* C_nbrank = new int[C_nnb];
	for (std::map<int, int>::iterator iter = nbmap.begin(); iter != nbmap.end(); ++iter)
		C_nbrank[iter->second] = iter->first;

	std::set<int>* nbset = new std::set<int>[C_nnb];

	for (int r = 0; r < nnb; ++r)
	{
		int _r = nbmap[nbrank[r]];
		for (int i = sendptr[r]; i < sendptr[r + 1]; ++i)
		{
			int irow = sendind[i];
			for (int j = B_exter_rowptr[irow]; j < B_exter_rowptr[irow + 1]; ++j)
			{
				int jfrom = B_recvfrom[B_exter_colind[j]];
				if (jfrom != _r)
				{
					nbset[_r].insert(B_nbrank[jfrom]);
					nbset[jfrom].insert(nbrank[r]);
				}
			}
		}
	}

	int** recvnbset = new int* [C_nnb];
	int** sendnbset = new int* [C_nnb];

	MPI_Request* recvreq = new MPI_Request[C_nnb];
	MPI_Request* sendreq = new MPI_Request[C_nnb];
	MPI_Status status;

	for (int r = 0; r < C_nnb; ++r)
	{
		sendnbset[r] = new int[nbset[r].size()];
		int i = 0;
		for (std::set<int>::iterator iter = nbset[r].begin(); iter != nbset[r].end(); ++iter)
			sendnbset[r][i++] = *iter;
		MPI_Isend(sendnbset[r], nbset[r].size(), MPI_INT, C_nbrank[r], MPI_TAG, comm, sendreq + r);
	}

	for (int r = 0; r < C_nnb; ++r)
	{
		int cnt;
		MPI_Probe(C_nbrank[r], MPI_TAG, comm, &status);
		MPI_Get_count(&status, MPI_INT, &cnt);
		recvnbset[r] = new int[cnt];
		MPI_Recv(recvnbset[r], cnt, MPI_INT, C_nbrank[r], MPI_TAG, comm, &status);
		for (int i = 0; i < cnt; ++i)
			nbmap.insert(std::pair<int, int>(recvnbset[r][i], nbmap.size()));
		delete[] recvnbset[r];
	}

	for (int r = 0; r < C_nnb; ++r)
	{
		MPI_Wait(sendreq + r, &status);
		delete[] sendnbset[r];
	}

	delete[] nbset;
	delete[] C_nbrank;
	delete[] recvnbset;
	delete[] sendnbset;

	C_nnb = nbmap.size();
	C_nbrank = new int[C_nnb];
	for (std::map<int, int>::iterator iter = nbmap.begin(); iter != nbmap.end(); ++iter)
		C_nbrank[iter->second] = iter->first;

	int* sendbufsize = new int[nnb];
	int* recvbufsize = new int[nnb];

	for (int r = 0; r < nnb; ++r)
		if (recvptr[r + 1] > recvptr[r])
			MPI_Irecv(recvbufsize + r, 1, MPI_INT, nbrank[r], MPI_TAG, comm, recvreq + r);

	for (int r = 0; r < nnb; ++r)
	{
		if (sendptr[r + 1] > sendptr[r])
		{
			int nrow = sendptr[r + 1] - sendptr[r];
			int nnz = 0;
			for (int i = sendptr[r]; i < sendptr[r + 1]; ++i)
				nnz += B_local_rowptr[sendind[i] + 1] - B_local_rowptr[sendind[i]] + B_exter_rowptr[sendind[i] + 1] - B_exter_rowptr[sendind[i]];
			sendbufsize[r] = (nrow + 2 * nnz) * sizeof(int) + nnz * sizeof(double);
			MPI_Send(sendbufsize + r, 1, MPI_INT, nbrank[r], MPI_TAG, comm);
		}
	}

	for (int r = 0; r < nnb; ++r)
		if (recvptr[r + 1] > recvptr[r])
			MPI_Wait(recvreq + r, &status);

	char** recvbuf = new char* [nnb];
	char** sendbuf = new char* [nnb];
	
	for (int r = 0; r < nnb; ++r)
	{
		if (recvptr[r + 1] > recvptr[r])
		{
			recvbuf[r] = (char*)malloc(recvbufsize[r]);
			MPI_Irecv(recvbuf[r], recvbufsize[r], MPI_PACKED, nbrank[r], MPI_TAG, comm, recvreq + r);
		}
	}

	for (int r = 0; r < nnb; ++r)
	{
		if (sendptr[r + 1] > sendptr[r])
		{
			sendbuf[r] = (char*)malloc(sendbufsize[r]);

			int position = 0;
			for (int i = sendptr[r]; i < sendptr[r + 1]; ++i)
			{
				int irow = sendind[i];
				int length = B_local_rowptr[irow + 1] - B_local_rowptr[irow] + B_exter_rowptr[irow + 1] - B_exter_rowptr[irow];

				int* colfrom = new int[length];
				int* colind = new int[length];
				double* values = new double[length];

				int j = 0;
				for (int k = B_local_rowptr[irow]; k < B_local_rowptr[irow + 1]; ++k, ++j)
				{
					colfrom[j] = comm_rank;
					colind[j] = B_local_colind[k];
					values[j] = B_local_values[k];
				}
				for (int k = B_exter_rowptr[irow]; k < B_exter_rowptr[irow + 1]; ++k, ++j)
				{
					int kcol = B_exter_colind[k];
					colfrom[j] = B_nbrank[B_recvfrom[kcol]];
					colind[j] = B_recvind[kcol];
					values[j] = B_exter_values[k];
				}

				MPI_Pack(&length, 1, MPI_INT, sendbuf[r], sendbufsize[r], &position, comm);
				MPI_Pack(colfrom, length, MPI_INT, sendbuf[r], sendbufsize[r], &position, comm);
				MPI_Pack(colind, length, MPI_INT, sendbuf[r], sendbufsize[r], &position, comm);
				MPI_Pack(values, length, MPI_DOUBLE, sendbuf[r], sendbufsize[r], &position, comm);

				delete[] colfrom;
				delete[] colind;
				delete[] values;
			}

			MPI_Isend(sendbuf[r], sendbufsize[r], MPI_PACKED, nbrank[r], MPI_TAG, comm, sendreq + r);
		}
	}

	std::map<int, int>* recvmap = new std::map<int, int>[C_nnb];
	for (int r = 0; r < B_nnb; ++r)
		for (int i = B_recvptr[r], j = 0; i < B_recvptr[r + 1]; ++i, ++j)
			recvmap[r].insert(std::pair<int, int>(B_recvind[i], j));

	int B_recvnnz = 0;
	for (int r = 0; r < nnb; ++r)
	{
		if (recvptr[r + 1] > recvptr[r])
		{
			int nrow = recvptr[r + 1] - recvptr[r];
			int nnz = (recvbufsize[r] - nrow * sizeof(int)) / (2 * sizeof(int) + sizeof(double));
			B_recvnnz += nnz;
		}
	}

	int* B_recvloc_rowptr = new int[A.exter.size[1] + 1];
	int* B_recvloc_colind = new int[B_recvnnz];
	double* B_recvloc_values = new double[B_recvnnz];
	int* B_recvext_rowptr = new int[A.exter.size[1] + 1];
	int* B_recvext_colind = new int[B_recvnnz];
	double* B_recvext_values = new double[B_recvnnz];
	int* B_recvext_colfrom = new int[B_recvnnz];

	B_recvloc_rowptr[0] = 0;
	B_recvext_rowptr[0] = 0;
	for (int r = 0; r < nnb; ++r)
	{
		if (recvptr[r + 1] > recvptr[r])
		{
			MPI_Wait(recvreq + r, &status);

			int position = 0;
			for (int i = recvptr[r], k = B_recvloc_rowptr[i], t = B_recvext_rowptr[i]; i < recvptr[r + 1]; B_recvloc_rowptr[++i] = k, B_recvext_rowptr[i] = t)
			{
				int length;
				MPI_Unpack(recvbuf[r], recvbufsize[r], &position, &length, 1, MPI_INT, comm);

				int* colfrom = new int[length];
				int* colind = new int[length];
				double* values = new double[length];

				MPI_Unpack(recvbuf[r], recvbufsize[r], &position, colfrom, length, MPI_INT, comm);
				MPI_Unpack(recvbuf[r], recvbufsize[r], &position, colind, length, MPI_INT, comm);
				MPI_Unpack(recvbuf[r], recvbufsize[r], &position, values, length, MPI_DOUBLE, comm);

				for (int j = 0; j < length; ++j)
				{
					if (colfrom[j] == comm_rank)
					{
						B_recvloc_colind[k] = colind[j];
						B_recvloc_values[k++] = values[j];
					}
					else
					{
						int jfrom = nbmap[colfrom[j]];
						B_recvext_colfrom[t] = jfrom;
						std::pair<std::map<int, int>::iterator, bool> ret = recvmap[jfrom].insert(std::pair<int, int>(colind[j], recvmap[jfrom].size()));
						B_recvext_colind[t] = ret.first->second;
						B_recvext_values[t++] = values[j];
					}
				}

				delete[] colfrom;
				delete[] colind;
				delete[] values;
			}
			
			free(recvbuf[r]);
		}
	}

	for (int r = 0; r < nnb; ++r)
	{
		if (sendptr[r + 1] > sendptr[r])
		{
			MPI_Wait(sendreq + r, &status);
			free(sendbuf[r]);
		}
	}

	delete[] recvbufsize;
	delete[] recvbuf;
	delete[] recvreq;
	delete[] sendbufsize;
	delete[] sendbuf;
	delete[] sendreq;

	int* C_recvptr = new int[C_nnb + 1];
	C_recvptr[0] = 0;
	for (int r = 0; r < C_nnb; ++r)
		C_recvptr[r + 1] = C_recvptr[r] + recvmap[r].size();

	int C_recvcnt = C_recvptr[C_nnb];
	int* C_recvind = new int[C_recvcnt];
	for (int r = 0; r < C_nnb; ++r)
		for (std::map<int, int>::iterator iter = recvmap[r].begin(); iter != recvmap[r].end(); ++iter)
			C_recvind[C_recvptr[r] + iter->second] = iter->first;

	for (int j = 0; j < B_recvext_rowptr[A.exter.size[1]]; ++j)
		B_recvext_colind[j] += C_recvptr[B_recvext_colfrom[j]];

	int* _B_exter_colind = new int[B_exter_rowptr[B.exter.size[0]]];

	for (int j = 0; j < B_exter_rowptr[B.exter.size[0]]; ++j)
	{
		int r = B_recvfrom[B_exter_colind[j]];
		_B_exter_colind[j] = B_exter_colind[j] - B_recvptr[r] + C_recvptr[r];
	}

	delete[] recvmap;
	delete[] B_recvfrom;
	delete[] B_recvext_colfrom;

	int* C_local_rowptr = new int[n + 1];
	int* C_exter_rowptr = new int[n + 1];

	C_local_rowptr[0] = 0;
	C_exter_rowptr[0] = 0;

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel
#endif
	{
		int* w = new int[m];
		int* v = new int[C_recvcnt];
		for (int i = 0; i < m; ++i)
			w[i] = -1;
		for (int i = 0; i < C_recvcnt; ++i)
			v[i] = -1;
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
		for (int i = 0; i < n; ++i)
		{
			int cntloc = 0;
			int cntext = 0;

			for (int k = A_local_rowptr[i]; k < A_local_rowptr[i + 1]; ++k)
			{
				int kcol = A_local_colind[k];

				for (int j = B_local_rowptr[kcol]; j < B_local_rowptr[kcol + 1]; ++j)
				{
					int jcol = B_local_colind[j];
					if (w[jcol] != i)
					{
						w[jcol] = i;
						++cntloc;
					}
				}

				for (int j = B_exter_rowptr[kcol]; j < B_exter_rowptr[kcol + 1]; ++j)
				{
					int jcol = _B_exter_colind[j];
					if (v[jcol] != i)
					{
						v[jcol] = i;
						++cntext;
					}
				}
			}

			for (int k = A_exter_rowptr[i]; k < A_exter_rowptr[i + 1]; ++k)
			{
				int kcol = A_exter_colind[k];

				for (int j = B_recvloc_rowptr[kcol]; j < B_recvloc_rowptr[kcol + 1]; ++j)
				{
					int jcol = B_recvloc_colind[j];
					if (w[jcol] != i)
					{
						w[jcol] = i;
						++cntloc;
					}
				}

				for (int j = B_recvext_rowptr[kcol]; j < B_recvext_rowptr[kcol + 1]; ++j)
				{
					int jcol = B_recvext_colind[j];
					if (v[jcol] != i)
					{
						v[jcol] = i;
						++cntext;
					}
				}
			}

			C_local_rowptr[i + 1] = cntloc;
			C_exter_rowptr[i + 1] = cntext;
		}

		delete[] w;
		delete[] v;
	}

	for (int i = 0; i < n; ++i)
		C_local_rowptr[i + 1] += C_local_rowptr[i];
	for (int i = 0; i < n; ++i)
		C_exter_rowptr[i + 1] += C_exter_rowptr[i];

	int* C_local_colind = new int[C_local_rowptr[n]];
	double* C_local_values = new double[C_local_rowptr[n] * bnnz];
	int* C_exter_colind = new int[C_exter_rowptr[n]];
	double* C_exter_values = new double[C_exter_rowptr[n] * bnnz];

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel
#endif
	{
		int* w = new int[m];
		int* v = new int[C_recvcnt];

		for (int i = 0; i < m; ++i)
			w[i] = -1;
		for (int i = 0; i < C_recvcnt; ++i)
			v[i] = -1;

#define BSR_UNROLL_SEGMENT(N) \
	for (int i = 0; i < n; ++i) \
	{ \
		int r = C_local_rowptr[i]; \
		int r0 = C_local_rowptr[i]; \
		int t = C_exter_rowptr[i]; \
		int t0 = C_exter_rowptr[i]; \
		for (int k = A_local_rowptr[i]; k < A_local_rowptr[i + 1]; ++k) \
		{ \
			int kcol = A_local_colind[k]; \
			for (int j = B_local_rowptr[kcol]; j < B_local_rowptr[kcol + 1]; ++j) \
			{ \
				int jcol = B_local_colind[j]; \
				if (w[jcol] < r0) \
				{ \
					w[jcol] = r; \
					C_local_colind[r] = jcol; \
					BSRBlockCopy_UNROLL(N, A_local_values + k * N * N, C_local_values + r * N * N); \
					BSRBlockScale_UNROLL(N, B_local_values[j], C_local_values + r * N * N); \
					++r; \
				} \
				else \
					BSRBlockScaleAdd_UNROLL(N, B_local_values[j], A_local_values + k * N * N, C_local_values + w[jcol] * N * N); \
			} \
			for (int j = B_exter_rowptr[kcol]; j < B_exter_rowptr[kcol + 1]; ++j) \
			{ \
				int jcol = _B_exter_colind[j]; \
				if (v[jcol] < t0) \
				{ \
					v[jcol] = t; \
					C_exter_colind[t] = jcol; \
					BSRBlockCopy_UNROLL(N, A_local_values + k * N * N, C_exter_values + t * N * N); \
					BSRBlockScale_UNROLL(N, B_exter_values[j], C_exter_values + t * N * N); \
					++t; \
				} \
				else \
					BSRBlockScaleAdd_UNROLL(N, B_exter_values[j], A_local_values + k * N * N, C_exter_values + v[jcol] * N * N); \
			} \
		} \
		for (int k = A_exter_rowptr[i]; k < A_exter_rowptr[i + 1]; ++k) \
		{ \
			int kcol = A_exter_colind[k]; \
			for (int j = B_recvloc_rowptr[kcol]; j < B_recvloc_rowptr[kcol + 1]; ++j) \
			{ \
				int jcol = B_recvloc_colind[j]; \
				if (w[jcol] < r0) \
				{ \
					w[jcol] = r; \
					C_local_colind[r] = jcol; \
					BSRBlockCopy_UNROLL(N, A_exter_values + k * N * N, C_local_values + r * N * N); \
					BSRBlockScale_UNROLL(N, B_recvloc_values[j], C_local_values + r * N * N); \
					++r; \
				} \
				else \
					BSRBlockScaleAdd_UNROLL(N, B_recvloc_values[j], A_exter_values + k * N * N, C_local_values + w[jcol] * N * N); \
			} \
			for (int j = B_recvext_rowptr[kcol]; j < B_recvext_rowptr[kcol + 1]; ++j) \
			{ \
				int jcol = B_recvext_colind[j]; \
				if (v[jcol] < t0) \
				{ \
					v[jcol] = t; \
					C_exter_colind[t] = jcol; \
					BSRBlockCopy_UNROLL(N, A_exter_values + k * N * N, C_exter_values + t * N * N); \
					BSRBlockScale_UNROLL(N, B_recvext_values[j], C_exter_values + t * N * N); \
					++t; \
				} \
				else \
					BSRBlockScaleAdd_UNROLL(N, B_recvext_values[j], A_exter_values + k * N * N, C_exter_values + v[jcol] * N * N); \
			} \
		} \
	}

#ifdef BSR_UNROLL_1
		if (bsize == 1)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
			BSR_UNROLL_SEGMENT(1)
		}
		else
#endif
#ifdef BSR_UNROLL_2
		if (bsize == 2)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
			BSR_UNROLL_SEGMENT(2)
		}
		else
#endif
#ifdef BSR_UNROLL_3
		if (bsize == 3)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
			BSR_UNROLL_SEGMENT(3)
		}
		else
#endif
#ifdef BSR_UNROLL_4
		if (bsize == 4)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
			BSR_UNROLL_SEGMENT(4)
		}
		else
#endif
#ifdef BSR_UNROLL_5
		if (bsize == 5)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
			BSR_UNROLL_SEGMENT(5)
		}
	else
#endif
#ifdef BSR_UNROLL_6
		if (bsize == 6)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
			BSR_UNROLL_SEGMENT(6)
		}
		else
#endif
#ifdef BSR_UNROLL_7
		if (bsize == 7)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
			BSR_UNROLL_SEGMENT(7)
		}
		else
#endif
#ifdef BSR_UNROLL_8
		if (bsize == 8)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
			BSR_UNROLL_SEGMENT(8)
		}
		else
#endif
#undef BSR_UNROLL_SEGMENT
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				int r = C_local_rowptr[i];
				int r0 = C_local_rowptr[i];
				int t = C_exter_rowptr[i];
				int t0 = C_exter_rowptr[i];

				for (int k = A_local_rowptr[i]; k < A_local_rowptr[i + 1]; ++k)
				{
					int kcol = A_local_colind[k];

					for (int j = B_local_rowptr[kcol]; j < B_local_rowptr[kcol + 1]; ++j)
					{
						int jcol = B_local_colind[j];

						if (w[jcol] < r0)
						{
							w[jcol] = r;
							C_local_colind[r] = jcol;
							BSRBlockCopy(bsize, A_local_values + k * bnnz, C_local_values + r * bnnz);
							BSRBlockScale(bsize, B_local_values[j], C_local_values + r * bnnz);
							++r;
						}
						else
							BSRBlockScaleAdd(bsize, B_local_values[j], A_local_values + k * bnnz, C_local_values + w[jcol] * bnnz);
					}

					for (int j = B_exter_rowptr[kcol]; j < B_exter_rowptr[kcol + 1]; ++j)
					{
						int jcol = _B_exter_colind[j];

						if (v[jcol] < t0)
						{
							v[jcol] = t;
							C_exter_colind[t] = jcol;
							BSRBlockCopy(bsize, A_local_values + k * bnnz, C_exter_values + t * bnnz);
							BSRBlockScale(bsize, B_exter_values[j], C_exter_values + t * bnnz);
							++t;
						}
						else
							BSRBlockScaleAdd(bsize, B_exter_values[j], A_local_values + k * bnnz, C_exter_values + v[jcol] * bnnz);
					}
				}

				for (int k = A_exter_rowptr[i]; k < A_exter_rowptr[i + 1]; ++k)
				{
					int kcol = A_exter_colind[k];

					for (int j = B_recvloc_rowptr[kcol]; j < B_recvloc_rowptr[kcol + 1]; ++j)
					{
						int jcol = B_recvloc_colind[j];
						
						if (w[jcol] < r0)
						{
							w[jcol] = r;
							C_local_colind[r] = jcol;
							BSRBlockCopy(bsize, A_exter_values + k * bnnz, C_local_values + r * bnnz);
							BSRBlockScale(bsize, B_recvloc_values[j], C_local_values + r * bnnz);
							++r;
						}
						else
							BSRBlockScaleAdd(bsize, B_recvloc_values[j], A_exter_values + k * bnnz, C_local_values + w[jcol] * bnnz);
					}

					for (int j = B_recvext_rowptr[kcol]; j < B_recvext_rowptr[kcol + 1]; ++j)
					{
						int jcol = B_recvext_colind[j];

						if (v[jcol] < t0)
						{
							v[jcol] = t;
							C_exter_colind[t] = jcol;
							BSRBlockCopy(bsize, A_exter_values + k * bnnz, C_exter_values + t * bnnz);
							BSRBlockScale(bsize, B_recvext_values[j], C_exter_values + t * bnnz);
							++t;
						}
						else
							BSRBlockScaleAdd(bsize, B_recvext_values[j], A_exter_values + k * bnnz, C_exter_values + v[jcol] * bnnz);
					}
				}
			}
		}

		delete[] w;
		delete[] v;
	}

	delete[] _B_exter_colind;

	int* v = new int[C_recvcnt];
	for (int i = 0; i < C_recvcnt; ++i)
		v[i] = -1;

	for (int j = C_exter_rowptr[0]; j < C_exter_rowptr[n]; ++j)
		v[C_exter_colind[j]] = 1;

	for (int r = 0, k = 0, i = 0; r < C_nnb; C_recvptr[++r] = k)
	{
		for ( ; i < C_recvptr[r + 1]; ++i)
		{
			if (v[i] == 1)
			{
				v[i] = k;
				C_recvind[k++] = C_recvind[i];
			}
		}
	}

	for (int j = C_exter_rowptr[0]; j < C_exter_rowptr[n]; ++j)
		C_exter_colind[j] = v[C_exter_colind[j]];

	C_recvcnt = C_recvptr[C_nnb];

	delete[] v;

	C.Free();

	C.comm = comm;

	C.local.size[0] = n;
	C.local.size[1] = m;
	C.local.bsize = bsize;
	C.local.rowptr = C_local_rowptr;
	C.local.colind = C_local_colind;
	C.local.values = C_local_values;

	C.exter.size[0] = n;
	C.exter.size[1] = C_recvcnt;
	C.exter.bsize = bsize;
	C.exter.rowptr = C_exter_rowptr;
	C.exter.colind = C_exter_colind;
	C.exter.values = C_exter_values;

	C.nnb = C_nnb;
	C.nbrank = C_nbrank;
	C.recvptr = C_recvptr;
	C.recvind = C_recvind;
}

void ParCSRMatBlockVec(int bsize, double alpha, const ParCSRMatrix& A, const ParVector& x, double beta, const ParVector& y)
{
	int n = A.local.size[0];
	int recvcnt = A.exter.size[1];

	int* A_local_rowptr = A.local.rowptr;
	int* A_local_colind = A.local.colind;
	double* A_local_values = A.local.values;

	int* A_exter_rowptr = A.exter.rowptr;
	int* A_exter_colind = A.exter.colind;
	double* A_exter_values = A.exter.values;

	MPI_Comm comm = A.comm;
	int nnb = A.nnb;
	int* nbrank = A.nbrank;
	int* recvptr = A.recvptr;
	int* sendptr = A.sendptr;
	int* sendind = A.sendind;
	double* sendbuf = new double[sendptr[nnb] * bsize];

	double* x_local_values = x.local.values;
	double* y_local_values = y.local.values;

	Vector recvx;
	recvx.Resize(recvcnt * bsize);
	double* x_recv_values = recvx.values;

	MPI_Request* recvreq = new MPI_Request[nnb];
	MPI_Request* sendreq = new MPI_Request[nnb];
	MPI_Status status;

	for (int r = 0; r < nnb; ++r)
		if (recvptr[r + 1] > recvptr[r])
			MPI_Irecv(x_recv_values + recvptr[r] * bsize, (recvptr[r + 1] - recvptr[r]) * bsize, MPI_DOUBLE, nbrank[r], MPI_TAG, comm, recvreq + r);

	for (int r = 0; r < nnb; ++r)
	{
		if (sendptr[r + 1] > sendptr[r])
		{
			for (int i = sendptr[r]; i < sendptr[r + 1]; ++i)
				VecBlockCopy(bsize, x_local_values + sendind[i] * bsize, sendbuf + i * bsize);
			MPI_Isend(sendbuf + sendptr[r] * bsize, (sendptr[r + 1] - sendptr[r]) * bsize, MPI_DOUBLE, nbrank[r], MPI_TAG, comm, sendreq + r);
		}
	}
	
	CSRMatBlockVec(bsize, alpha, A.local, x.local, beta, y.local);

	for (int r = 0; r < nnb; ++r)
		if (recvptr[r + 1] > recvptr[r])
			MPI_Wait(recvreq + r, &status);

	CSRMatBlockVec(bsize, alpha, A.exter, recvx, 1.0, y.local);

	for (int r = 0; r < nnb; ++r)
		if (sendptr[r + 1] > sendptr[r])
			MPI_Wait(sendreq + r, &status);

	delete[] sendbuf;
	delete[] recvreq;
	delete[] sendreq;
}

}