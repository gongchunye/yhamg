/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "ParBSRGenerator27pt.hpp"

namespace YHAMG
{

ParBSRGenerator27pt::ParBSRGenerator27pt(MPI_Comm comm)
	: ParBSRGenerator(comm),
	nx(0),
	ny(0),
	nz(0),
	bx(0),
	by(0),
	bz(0),
	Px(0),
	Py(0),
	Pz(0)
{
}

ParBSRGenerator27pt::ParBSRGenerator27pt(MPI_Comm comm, int _nx, int _ny, int _nz, int _bx, int _by, int _bz, int _Px, int _Py, int _Pz)
	: ParBSRGenerator(comm),
	nx(_nx),
	ny(_ny),
	nz(_nz),
	bx(_bx),
	by(_by),
	bz(_bz),
	Px(_Px),
	Py(_Py),
	Pz(_Pz)
{
}

static inline int sub2ind(int nx, int ny, int nz, int ix, int iy, int iz)
{
	return ix * ny * nz + iy * nz + iz;
}

static inline void ind2sub(int nx, int ny, int nz, int i, int& ix, int& iy, int& iz)
{
	ix = i / (ny * nz);
	iy = i / nz - ix * ny;
	iz = i - ix * ny * nz - iy * nz;
}

void ParBSRGenerator27pt::operator()(ParBSRMatrix& A) const
{
	int comm_rank;
	MPI_Comm_rank(comm, &comm_rank);

	double c = 1.0;
	double b = -1.0;
	if (nx * Px * bx > 1) b *= 3;
	if (ny * Py * bx > 1) b *= 3;
	if (nz * Pz * bx > 1) b *= 3;
	b += 1.0;

	int size = nx * ny * nz;
	int bsize = bx * by * bz;
	int bnnz = bsize * bsize;

	int* local_rowptr = new int[size + 1];

	local_rowptr[0] = 0;
	for (int ix = 0; ix < nx; ++ix)
	{
		for (int iy = 0; iy < ny; ++iy)
		{
			for (int iz = 0; iz < nz; ++iz)
			{
				int cnt = 1;
				if (ix > 0)
				{
					++cnt;
					if (iy > 0)
					{
						++cnt;
						if (iz > 0) ++cnt;
						if (iz < nz - 1) ++cnt;
					}
					if (iy < ny - 1)
					{
						++cnt;
						if (iz > 0) ++cnt;
						if (iz < nz - 1) ++cnt;
					}
					if (iz > 0) ++cnt;
					if (iz < nz - 1) ++cnt;
				}

				if (ix < nx - 1)
				{
					++cnt;
					if (iy > 0)
					{
						++cnt;
						if (iz > 0) ++cnt;
						if (iz < nz - 1) ++cnt;
					}
					if (iy < ny - 1)
					{
						++cnt;
						if (iz > 0) ++cnt;
						if (iz < nz - 1) ++cnt;
					}
					if (iz > 0) ++cnt;
					if (iz < nz - 1) ++cnt;
				}

				if (iy > 0)
				{
					++cnt;
					if (iz > 0) ++cnt;
					if (iz < nz - 1) ++cnt;
				}

				if (iy < ny - 1)
				{
					++cnt;
					if (iz > 0) ++cnt;
					if (iz < nz - 1) ++cnt;
				}

				if (iz > 0) ++cnt;
				if (iz < nz - 1) ++cnt;

				local_rowptr[sub2ind(nx, ny, nz, ix, iy, iz) + 1] = cnt;
			}
		}
	}

	for (int i = 0; i < size; ++i)
		local_rowptr[i + 1] += local_rowptr[i];

	int* local_colind = new int[local_rowptr[size]];
	double* local_values = new double[local_rowptr[size] * bnnz];

	for (int ix = 0; ix < nx; ++ix)
	{
		for (int iy = 0; iy < ny; ++iy)
		{
			for (int iz = 0; iz < nz; ++iz)
			{
				int j = local_rowptr[sub2ind(nx, ny, nz, ix, iy, iz)];

				if (ix > 0)
				{
					if (iy > 0)
					{
						if (iz > 0)
						{
							local_colind[j] = sub2ind(nx, ny, nz, ix - 1, iy - 1, iz - 1);
							BSRBlockFill(bsize, 0.0, local_values + j * bnnz);
							local_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, by - 1, bz - 1) * bsize + sub2ind(bx, by, bz, 0, 0, 0)] = c;
							++j;
						}

						local_colind[j] = sub2ind(nx, ny, nz, ix - 1, iy - 1, iz);
						BSRBlockFill(bsize, 0.0, local_values + j * bnnz);

						for (int jz = 0; jz < bz; ++jz)
						{
							if (jz > 0)
								local_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, by - 1, jz - 1) * bsize + sub2ind(bx, by, bz, 0, 0, jz)] = c;
							local_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, by - 1, jz) * bsize + sub2ind(bx, by, bz, 0, 0, jz)] = c;
							if (jz < bz - 1)
								local_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, by - 1, jz + 1) * bsize + sub2ind(bx, by, bz, 0, 0, jz)] = c;
						}

						++j;

						if (iz < nz - 1)
						{
							local_colind[j] = sub2ind(nx, ny, nz, ix - 1, iy - 1, iz + 1);
							BSRBlockFill(bsize, 0.0, local_values + j * bnnz);
							local_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, by - 1, 0) * bsize + sub2ind(bx, by, bz, 0, 0, bz - 1)] = c;
							++j;
						}
					}

					if (iz > 0)
					{
						local_colind[j] = sub2ind(nx, ny, nz, ix - 1, iy, iz - 1);
						BSRBlockFill(bsize, 0.0, local_values + j * bnnz);
			
						for (int jy = 0; jy < by; ++jy)
						{
							if (jy > 0)
								local_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, jy - 1, bz - 1) * bsize + sub2ind(bx, by, bz, 0, jy, 0)] = c;
							local_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, jy, bz - 1) * bsize + sub2ind(bx, by, bz, 0, jy, 0)] = c;
							if (jy < by - 1)
								local_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, jy + 1, bz - 1) * bsize + sub2ind(bx, by, bz, 0, jy, 0)] = c;
						}

						++j;
					}

					local_colind[j] = sub2ind(nx, ny, nz, ix - 1, iy, iz);
					BSRBlockFill(bsize, 0.0, local_values + j * bnnz);

					for (int jy = 0; jy < by; ++jy)
					{
						for (int jz = 0; jz < bz; ++jz)
						{
							if (jy > 0)
							{
								if (jz > 0)
									local_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, jy - 1, jz - 1) * bsize + sub2ind(bx, by, bz, 0, jy, jz)] = c;
								local_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, jy - 1, jz) * bsize + sub2ind(bx, by, bz, 0, jy, jz)] = c;
								if (jz < bz - 1)
									local_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, jy - 1, jz + 1) * bsize + sub2ind(bx, by, bz, 0, jy, jz)] = c;
							}
							if (jz > 0)
								local_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, jy, jz - 1) * bsize + sub2ind(bx, by, bz, 0, jy, jz)] = c;
							local_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, jy, jz) * bsize + sub2ind(bx, by, bz, 0, jy, jz)] = c;
							if (jz < bz - 1)
								local_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, jy, jz + 1) * bsize + sub2ind(bx, by, bz, 0, jy, jz)] = c;
							if (jy < by - 1)
							{
								if (jz > 0)
									local_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, jy + 1, jz - 1) * bsize + sub2ind(bx, by, bz, 0, jy, jz)] = c;
								local_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, jy + 1, jz) * bsize + sub2ind(bx, by, bz, 0, jy, jz)] = c;
								if (jz < bz - 1)
									local_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, jy + 1, jz + 1) * bsize + sub2ind(bx, by, bz, 0, jy, jz)] = c;
							}
						}
					}

					++j;

					if (iz < nz - 1)
					{
						local_colind[j] = sub2ind(nx, ny, nz, ix - 1, iy, iz + 1);
						BSRBlockFill(bsize, 0.0, local_values + j * bnnz);
			
						for (int jy = 0; jy < by; ++jy)
						{
							if (jy > 0)
								local_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, jy - 1, 0) * bsize + sub2ind(bx, by, bz, 0, jy, bz - 1)] = c;
							local_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, jy, 0) * bsize + sub2ind(bx, by, bz, 0, jy, bz - 1)] = c;
							if (jy < by - 1)
								local_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, jy + 1, 0) * bsize + sub2ind(bx, by, bz, 0, jy, bz - 1)] = c;
						}

						++j;
					}

					if (iy < ny - 1)
					{
						if (iz > 0)
						{
							local_colind[j] = sub2ind(nx, ny, nz, ix - 1, iy + 1, iz - 1);
							BSRBlockFill(bsize, 0.0, local_values + j * bnnz);
							local_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, 0, bz - 1) * bsize + sub2ind(bx, by, bz, 0, by - 1, 0)] = c;
							++j;
						}

						local_colind[j] = sub2ind(nx, ny, nz, ix - 1, iy + 1, iz);
						BSRBlockFill(bsize, 0.0, local_values + j * bnnz);

						for (int jz = 0; jz < bz; ++jz)
						{
							if (jz > 0)
								local_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, 0, jz - 1) * bsize + sub2ind(bx, by, bz, 0, by - 1, jz)] = c;
							local_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, 0, jz) * bsize + sub2ind(bx, by, bz, 0, by - 1, jz)] = c;
							if (jz < bz - 1)
								local_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, 0, jz + 1) * bsize + sub2ind(bx, by, bz, 0, by - 1, jz)] = c;
						}

						++j;

						if (iz < nz - 1)
						{
							local_colind[j] = sub2ind(nx, ny, nz, ix - 1, iy + 1, iz + 1);
							BSRBlockFill(bsize, 0.0, local_values + j * bnnz);
							local_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, 0, 0) * bsize + sub2ind(bx, by, bz, 0, by - 1, bz - 1)] = c;
							++j;
						}
					}
				}

				if (iy > 0)
				{
					if (iz > 0)
					{
						local_colind[j] = sub2ind(nx, ny, nz, ix, iy - 1, iz - 1);
						BSRBlockFill(bsize, 0.0, local_values + j * bnnz);

						for (int jx = 0; jx < bx; ++jx)
						{
							if (jx > 0)
								local_values[j * bnnz + sub2ind(bx, by, bz, jx - 1, by - 1, bz - 1) * bsize + sub2ind(bx, by, bz, jx, 0, 0)] = c;
							local_values[j * bnnz + sub2ind(bx, by, bz, jx, by - 1, bz - 1) * bsize + sub2ind(bx, by, bz, jx, 0, 0)] = c;
							if (jx < bx - 1)
								local_values[j * bnnz + sub2ind(bx, by, bz, jx + 1, by - 1, bz - 1) * bsize + sub2ind(bx, by, bz, jx, 0, 0)] = c;
						}

						++j;
					}

					local_colind[j] = sub2ind(nx, ny, nz, ix, iy - 1, iz);
					BSRBlockFill(bsize, 0.0, local_values + j * bnnz);

					for (int jx = 0; jx < bx; ++jx)
					{
						for (int jz = 0; jz < bz; ++jz)
						{
							if (jx > 0)
							{
								if (jz > 0)
									local_values[j * bnnz + sub2ind(bx, by, bz, jx - 1, by - 1, jz - 1) * bsize + sub2ind(bx, by, bz, jx, 0, jz)] = c;
								local_values[j * bnnz + sub2ind(bx, by, bz, jx - 1, by - 1, jz) * bsize + sub2ind(bx, by, bz, jx, 0, jz)] = c;
								if (jz < bz - 1)
									local_values[j * bnnz + sub2ind(bx, by, bz, jx - 1, by - 1, jz + 1) * bsize + sub2ind(bx, by, bz, jx, 0, jz)] = c;
							}
							if (jz > 0)
								local_values[j * bnnz + sub2ind(bx, by, bz, jx, by - 1, jz - 1) * bsize + sub2ind(bx, by, bz, jx, 0, jz)] = c;
							local_values[j * bnnz + sub2ind(bx, by, bz, jx, by - 1, jz) * bsize + sub2ind(bx, by, bz, jx, 0, jz)] = c;
							if (jz < bz - 1)
								local_values[j * bnnz + sub2ind(bx, by, bz, jx, by - 1, jz + 1) * bsize + sub2ind(bx, by, bz, jx, 0, jz)] = c;
							if (jx < bx - 1)
							{
								if (jz > 0)
									local_values[j * bnnz + sub2ind(bx, by, bz, jx + 1, by - 1, jz - 1) * bsize + sub2ind(bx, by, bz, jx, 0, jz)] = c;
								local_values[j * bnnz + sub2ind(bx, by, bz, jx + 1, by - 1, jz) * bsize + sub2ind(bx, by, bz, jx, 0, jz)] = c;
								if (jz < bz - 1)
									local_values[j * bnnz + sub2ind(bx, by, bz, jx + 1, by - 1, jz + 1) * bsize + sub2ind(bx, by, bz, jx, 0, jz)] = c;
							}
						}
					}

					++j;

					if (iz < nz - 1)
					{
						local_colind[j] = sub2ind(nx, ny, nz, ix, iy - 1, iz + 1);
						BSRBlockFill(bsize, 0.0, local_values + j * bnnz);

						for (int jx = 0; jx < bx; ++jx)
						{
							if (jx > 0)
								local_values[j * bnnz + sub2ind(bx, by, bz, jx - 1, by - 1, 0) * bsize + sub2ind(bx, by, bz, jx, 0, bz - 1)] = c;
							local_values[j * bnnz + sub2ind(bx, by, bz, jx, by - 1, 0) * bsize + sub2ind(bx, by, bz, jx, 0, bz - 1)] = c;
							if (jx < bx - 1)
								local_values[j * bnnz + sub2ind(bx, by, bz, jx + 1, by - 1, 0) * bsize + sub2ind(bx, by, bz, jx, 0, bz - 1)] = c;
						}

						++j;
					}
				}

				if (iz > 0)
				{
					local_colind[j] = sub2ind(nx, ny, nz, ix, iy, iz - 1);
					BSRBlockFill(bsize, 0.0, local_values + j * bnnz);

					for (int jx = 0; jx < bx; ++jx)
					{
						for (int jy = 0; jy < by; ++jy)
						{
							if (jx > 0)
							{
								if (jy > 0)
									local_values[j * bnnz + sub2ind(bx, by, bz, jx - 1, jy - 1, bz - 1) * bsize + sub2ind(bx, by, bz, jx, jy, 0)] = c;
								local_values[j * bnnz + sub2ind(bx, by, bz, jx - 1, jy, bz - 1) * bsize + sub2ind(bx, by, bz, jx, jy, 0)] = c;
								if (jy < by - 1)
									local_values[j * bnnz + sub2ind(bx, by, bz, jx - 1, jy + 1, bz - 1) * bsize + sub2ind(bx, by, bz, jx, jy, 0)] = c;
							}
							if (jy > 0)
								local_values[j * bnnz + sub2ind(bx, by, bz, jx, jy - 1, bz - 1) * bsize + sub2ind(bx, by, bz, jx, jy, 0)] = c;
							local_values[j * bnnz + sub2ind(bx, by, bz, jx, jy, bz - 1) * bsize + sub2ind(bx, by, bz, jx, jy, 0)] = c;
							if (jy < by - 1)
								local_values[j * bnnz + sub2ind(bx, by, bz, jx, jy + 1, bz - 1) * bsize + sub2ind(bx, by, bz, jx, jy, 0)] = c;
							if (jx < bx - 1)
							{
								if (jy > 0)
									local_values[j * bnnz + sub2ind(bx, by, bz, jx + 1, jy - 1, bz - 1) * bsize + sub2ind(bx, by, bz, jx, jy, 0)] = c;
								local_values[j * bnnz + sub2ind(bx, by, bz, jx + 1, jy, bz - 1) * bsize + sub2ind(bx, by, bz, jx, jy, 0)] = c;
								if (jy < by - 1)
									local_values[j * bnnz + sub2ind(bx, by, bz, jx + 1, jy + 1, bz - 1) * bsize + sub2ind(bx, by, bz, jx, jy, 0)] = c;
							}
						}
					}

					++j;
				}

				local_colind[j] = sub2ind(nx, ny, nz, ix, iy, iz);
				BSRBlockFill(bsize, 0.0, local_values + j * bnnz);

				for (int jx = 0; jx < bx; ++jx)
				{
					for (int jy = 0; jy < by; ++jy)
					{
						for (int jz = 0; jz < bz; ++jz)
						{
							if (jx > 0)
							{
								if (jy > 0)
								{
									if (jz > 0)
										local_values[j * bnnz + sub2ind(bx, by, bz, jx - 1, jy - 1, jz - 1) * bsize + sub2ind(bx, by, bz, jx, jy, jz)] = c;
									local_values[j * bnnz + sub2ind(bx, by, bz, jx - 1, jy - 1, jz) * bsize + sub2ind(bx, by, bz, jx, jy, jz)] = c;
									if (jz < bz - 1)
										local_values[j * bnnz + sub2ind(bx, by, bz, jx - 1, jy - 1, jz + 1) * bsize + sub2ind(bx, by, bz, jx, jy, jz)] = c;
								}
								if (jz > 0)
									local_values[j * bnnz + sub2ind(bx, by, bz, jx - 1, jy, jz - 1) * bsize + sub2ind(bx, by, bz, jx, jy, jz)] = c;
								local_values[j * bnnz + sub2ind(bx, by, bz, jx - 1, jy, jz) * bsize + sub2ind(bx, by, bz, jx, jy, jz)] = c;
								if (jz < bz - 1)
									local_values[j * bnnz + sub2ind(bx, by, bz, jx - 1, jy, jz + 1) * bsize + sub2ind(bx, by, bz, jx, jy, jz)] = c;
								if (jy < by - 1)
								{
									if (jz > 0)
										local_values[j * bnnz + sub2ind(bx, by, bz, jx - 1, jy + 1, jz - 1) * bsize + sub2ind(bx, by, bz, jx, jy, jz)] = c;
									local_values[j * bnnz + sub2ind(bx, by, bz, jx - 1, jy + 1, jz) * bsize + sub2ind(bx, by, bz, jx, jy, jz)] = c;
									if (jz < bz - 1)
										local_values[j * bnnz + sub2ind(bx, by, bz, jx - 1, jy + 1, jz + 1) * bsize + sub2ind(bx, by, bz, jx, jy, jz)] = c;
								}
							}

							if (jy > 0)
							{
								if (jz > 0)
									local_values[j * bnnz + sub2ind(bx, by, bz, jx, jy - 1, jz - 1) * bsize + sub2ind(bx, by, bz, jx, jy, jz)] = c;
								local_values[j * bnnz + sub2ind(bx, by, bz, jx, jy - 1, jz) * bsize + sub2ind(bx, by, bz, jx, jy, jz)] = c;
								if (jz < bz - 1)
									local_values[j * bnnz + sub2ind(bx, by, bz, jx, jy - 1, jz + 1) * bsize + sub2ind(bx, by, bz, jx, jy, jz)] = c;
							}
							if (jz > 0)
								local_values[j * bnnz + sub2ind(bx, by, bz, jx, jy, jz - 1) * bsize + sub2ind(bx, by, bz, jx, jy, jz)] = c;
							local_values[j * bnnz + sub2ind(bx, by, bz, jx, jy, jz) * bsize + sub2ind(bx, by, bz, jx, jy, jz)] = b;
							if (jz < bz - 1)
								local_values[j * bnnz + sub2ind(bx, by, bz, jx, jy, jz + 1) * bsize + sub2ind(bx, by, bz, jx, jy, jz)] = c;
							if (jy < by - 1)
							{
								if (jz > 0)
									local_values[j * bnnz + sub2ind(bx, by, bz, jx, jy + 1, jz - 1) * bsize + sub2ind(bx, by, bz, jx, jy, jz)] = c;
								local_values[j * bnnz + sub2ind(bx, by, bz, jx, jy + 1, jz) * bsize + sub2ind(bx, by, bz, jx, jy, jz)] = c;
								if (jz < bz - 1)
									local_values[j * bnnz + sub2ind(bx, by, bz, jx, jy + 1, jz + 1) * bsize + sub2ind(bx, by, bz, jx, jy, jz)] = c;
							}
							
							if (jx < bx - 1)
							{
								if (jy > 0)
								{
									if (jz > 0)
										local_values[j * bnnz + sub2ind(bx, by, bz, jx + 1, jy - 1, jz - 1) * bsize + sub2ind(bx, by, bz, jx, jy, jz)] = c;
									local_values[j * bnnz + sub2ind(bx, by, bz, jx + 1, jy - 1, jz) * bsize + sub2ind(bx, by, bz, jx, jy, jz)] = c;
									if (jz < bz - 1)
										local_values[j * bnnz + sub2ind(bx, by, bz, jx + 1, jy - 1, jz + 1) * bsize + sub2ind(bx, by, bz, jx, jy, jz)] = c;
								}
								if (jz > 0)
									local_values[j * bnnz + sub2ind(bx, by, bz, jx + 1, jy, jz - 1) * bsize + sub2ind(bx, by, bz, jx, jy, jz)] = c;
								local_values[j * bnnz + sub2ind(bx, by, bz, jx + 1, jy, jz) * bsize + sub2ind(bx, by, bz, jx, jy, jz)] = c;
								if (jz < bz - 1)
									local_values[j * bnnz + sub2ind(bx, by, bz, jx + 1, jy, jz + 1) * bsize + sub2ind(bx, by, bz, jx, jy, jz)] = c;
								if (jy < by - 1)
								{
									if (jz > 0)
										local_values[j * bnnz + sub2ind(bx, by, bz, jx + 1, jy + 1, jz - 1) * bsize + sub2ind(bx, by, bz, jx, jy, jz)] = c;
									local_values[j * bnnz + sub2ind(bx, by, bz, jx + 1, jy + 1, jz) * bsize + sub2ind(bx, by, bz, jx, jy, jz)] = c;
									if (jz < bz - 1)
										local_values[j * bnnz + sub2ind(bx, by, bz, jx + 1, jy + 1, jz + 1) * bsize + sub2ind(bx, by, bz, jx, jy, jz)] = c;
								}
							}
						}
					}
				}

				++j;

				if (iz < nz - 1)
				{
					local_colind[j] = sub2ind(nx, ny, nz, ix, iy, iz + 1);
					BSRBlockFill(bsize, 0.0, local_values + j * bnnz);

					for (int jx = 0; jx < bx; ++jx)
					{
						for (int jy = 0; jy < by; ++jy)
						{
							if (jx > 0)
							{
								if (jy > 0)
									local_values[j * bnnz + sub2ind(bx, by, bz, jx - 1, jy - 1, 0) * bsize + sub2ind(bx, by, bz, jx, jy, bz - 1)] = c;
								local_values[j * bnnz + sub2ind(bx, by, bz, jx - 1, jy, 0) * bsize + sub2ind(bx, by, bz, jx, jy, bz - 1)] = c;
								if (jy < by - 1)
									local_values[j * bnnz + sub2ind(bx, by, bz, jx - 1, jy + 1, 0) * bsize + sub2ind(bx, by, bz, jx, jy, bz - 1)] = c;
							}
							if (jy > 0)
								local_values[j * bnnz + sub2ind(bx, by, bz, jx, jy - 1, 0) * bsize + sub2ind(bx, by, bz, jx, jy, bz - 1)] = c;
							local_values[j * bnnz + sub2ind(bx, by, bz, jx, jy, 0) * bsize + sub2ind(bx, by, bz, jx, jy, bz - 1)] = c;
							if (jy < by - 1)
								local_values[j * bnnz + sub2ind(bx, by, bz, jx, jy + 1, 0) * bsize + sub2ind(bx, by, bz, jx, jy, bz - 1)] = c;
							if (jx < bx - 1)
							{
								if (jy > 0)
									local_values[j * bnnz + sub2ind(bx, by, bz, jx + 1, jy - 1, 0) * bsize + sub2ind(bx, by, bz, jx, jy, bz - 1)] = c;
								local_values[j * bnnz + sub2ind(bx, by, bz, jx + 1, jy, 0) * bsize + sub2ind(bx, by, bz, jx, jy, bz - 1)] = c;
								if (jy < by - 1)
									local_values[j * bnnz + sub2ind(bx, by, bz, jx + 1, jy + 1, 0) * bsize + sub2ind(bx, by, bz, jx, jy, bz - 1)] = c;
							}
						}
					}

					++j;
				}

				if (iy < ny - 1)
				{
					if (iz > 0)
					{
						local_colind[j] = sub2ind(nx, ny, nz, ix, iy + 1, iz - 1);
						BSRBlockFill(bsize, 0.0, local_values + j * bnnz);

						for (int jx = 0; jx < bx; ++jx)
						{
							if (jx > 0)
								local_values[j * bnnz + sub2ind(bx, by, bz, jx - 1, 0, bz - 1) * bsize + sub2ind(bx, by, bz, jx, by - 1, 0)] = c;
							local_values[j * bnnz + sub2ind(bx, by, bz, jx, 0, bz - 1) * bsize + sub2ind(bx, by, bz, jx, by - 1, 0)] = c;
							if (jx < bx - 1)
								local_values[j * bnnz + sub2ind(bx, by, bz, jx + 1, 0, bz - 1) * bsize + sub2ind(bx, by, bz, jx, by - 1, 0)] = c;
						}

						++j;
					}

					local_colind[j] = sub2ind(nx, ny, nz, ix, iy + 1, iz);
					BSRBlockFill(bsize, 0.0, local_values + j * bnnz);

					for (int jx = 0; jx < bx; ++jx)
					{
						for (int jz = 0; jz < bz; ++jz)
						{
							if (jx > 0)
							{
								if (jz > 0)
									local_values[j * bnnz + sub2ind(bx, by, bz, jx - 1, 0, jz - 1) * bsize + sub2ind(bx, by, bz, jx, by - 1, jz)] = c;
								local_values[j * bnnz + sub2ind(bx, by, bz, jx - 1, 0, jz) * bsize + sub2ind(bx, by, bz, jx, by - 1, jz)] = c;
								if (jz < bz - 1)
									local_values[j * bnnz + sub2ind(bx, by, bz, jx - 1, 0, jz + 1) * bsize + sub2ind(bx, by, bz, jx, by - 1, jz)] = c;
							}
							if (jz > 0)
								local_values[j * bnnz + sub2ind(bx, by, bz, jx, 0, jz - 1) * bsize + sub2ind(bx, by, bz, jx, by - 1, jz)] = c;
							local_values[j * bnnz + sub2ind(bx, by, bz, jx, 0, jz) * bsize + sub2ind(bx, by, bz, jx, by - 1, jz)] = c;
							if (jz < bz - 1)
								local_values[j * bnnz + sub2ind(bx, by, bz, jx, 0, jz + 1) * bsize + sub2ind(bx, by, bz, jx, by - 1, jz)] = c;
							if (jx < bx - 1)
							{
								if (jz > 0)
									local_values[j * bnnz + sub2ind(bx, by, bz, jx + 1, 0, jz - 1) * bsize + sub2ind(bx, by, bz, jx, by - 1, jz)] = c;
								local_values[j * bnnz + sub2ind(bx, by, bz, jx + 1, 0, jz) * bsize + sub2ind(bx, by, bz, jx, by - 1, jz)] = c;
								if (jz < bz - 1)
									local_values[j * bnnz + sub2ind(bx, by, bz, jx + 1, 0, jz + 1) * bsize + sub2ind(bx, by, bz, jx, by - 1, jz)] = c;
							}
						}
					}

					++j;

					if (iz < nz - 1)
					{
						local_colind[j] = sub2ind(nx, ny, nz, ix, iy + 1, iz + 1);
						BSRBlockFill(bsize, 0.0, local_values + j * bnnz);

						for (int jx = 0; jx < bx; ++jx)
						{
							if (jx > 0)
								local_values[j * bnnz + sub2ind(bx, by, bz, jx - 1, 0, 0) * bsize + sub2ind(bx, by, bz, jx, by - 1, bz - 1)] = c;
							local_values[j * bnnz + sub2ind(bx, by, bz, jx, 0, 0) * bsize + sub2ind(bx, by, bz, jx, by - 1, bz - 1)] = c;
							if (jx < bx - 1)
								local_values[j * bnnz + sub2ind(bx, by, bz, jx + 1, 0, 0) * bsize + sub2ind(bx, by, bz, jx, by - 1, bz - 1)] = c;
						}

						++j;
					}
				}

				if (ix < nx - 1)
				{
					if (iy > 0)
					{
						if (iz > 0)
						{
							local_colind[j] = sub2ind(nx, ny, nz, ix + 1, iy - 1, iz - 1);
							BSRBlockFill(bsize, 0.0, local_values + j * bnnz);
							local_values[j * bnnz + sub2ind(bx, by, bz, 0, by - 1, bz - 1) * bsize + sub2ind(bx, by, bz, bx - 1, 0, 0)] = c;
							++j;
						}

						local_colind[j] = sub2ind(nx, ny, nz, ix + 1, iy - 1, iz);
						BSRBlockFill(bsize, 0.0, local_values + j * bnnz);

						for (int jz = 0; jz < bz; ++jz)
						{
							if (jz > 0)
								local_values[j * bnnz + sub2ind(bx, by, bz, 0, by - 1, jz - 1) * bsize + sub2ind(bx, by, bz, bx - 1, 0, jz)] = c;
							local_values[j * bnnz + sub2ind(bx, by, bz, 0, by - 1, jz) * bsize + sub2ind(bx, by, bz, bx - 1, 0, jz)] = c;
							if (jz < bz - 1)
								local_values[j * bnnz + sub2ind(bx, by, bz, 0, by - 1, jz + 1) * bsize + sub2ind(bx, by, bz, bx - 1, 0, jz)] = c;
						}

						++j;

						if (iz < nz - 1)
						{
							local_colind[j] = sub2ind(nx, ny, nz, ix + 1, iy - 1, iz + 1);
							BSRBlockFill(bsize, 0.0, local_values + j * bnnz);
							local_values[j * bnnz + sub2ind(bx, by, bz, 0, by - 1, 0) * bsize + sub2ind(bx, by, bz, bx - 1, 0, bz - 1)] = c;
							++j;
						}
					}

					if (iz > 0)
					{
						local_colind[j] = sub2ind(nx, ny, nz, ix + 1, iy, iz - 1);
						BSRBlockFill(bsize, 0.0, local_values + j * bnnz);
			
						for (int jy = 0; jy < by; ++jy)
						{
							if (jy > 0)
								local_values[j * bnnz + sub2ind(bx, by, bz, 0, jy - 1, bz - 1) * bsize + sub2ind(bx, by, bz, bx - 1, jy, 0)] = c;
							local_values[j * bnnz + sub2ind(bx, by, bz, 0, jy, bz - 1) * bsize + sub2ind(bx, by, bz, bx - 1, jy, 0)] = c;
							if (jy < by - 1)
								local_values[j * bnnz + sub2ind(bx, by, bz, 0, jy + 1, bz - 1) * bsize + sub2ind(bx, by, bz, bx - 1, jy, 0)] = c;
						}

						++j;
					}

					local_colind[j] = sub2ind(nx, ny, nz, ix + 1, iy, iz);
					BSRBlockFill(bsize, 0.0, local_values + j * bnnz);

					for (int jy = 0; jy < by; ++jy)
					{
						for (int jz = 0; jz < bz; ++jz)
						{
							if (jy > 0)
							{
								if (jz > 0)
									local_values[j * bnnz + sub2ind(bx, by, bz, 0, jy - 1, jz - 1) * bsize + sub2ind(bx, by, bz, bx - 1, jy, jz)] = c;
								local_values[j * bnnz + sub2ind(bx, by, bz, 0, jy - 1, jz) * bsize + sub2ind(bx, by, bz, bx - 1, jy, jz)] = c;
								if (jz < bz - 1)
									local_values[j * bnnz + sub2ind(bx, by, bz, 0, jy - 1, jz + 1) * bsize + sub2ind(bx, by, bz, bx - 1, jy, jz)] = c;
							}
							if (jz > 0)
								local_values[j * bnnz + sub2ind(bx, by, bz, 0, jy, jz - 1) * bsize + sub2ind(bx, by, bz, bx - 1, jy, jz)] = c;
							local_values[j * bnnz + sub2ind(bx, by, bz, 0, jy, jz) * bsize + sub2ind(bx, by, bz, bx - 1, jy, jz)] = c;
							if (jz < bz - 1)
								local_values[j * bnnz + sub2ind(bx, by, bz, 0, jy, jz + 1) * bsize + sub2ind(bx, by, bz, bx - 1, jy, jz)] = c;
							if (jy < by - 1)
							{
								if (jz > 0)
									local_values[j * bnnz + sub2ind(bx, by, bz, 0, jy + 1, jz - 1) * bsize + sub2ind(bx, by, bz, bx - 1, jy, jz)] = c;
								local_values[j * bnnz + sub2ind(bx, by, bz, 0, jy + 1, jz) * bsize + sub2ind(bx, by, bz, bx - 1, jy, jz)] = c;
								if (jz < bz - 1)
									local_values[j * bnnz + sub2ind(bx, by, bz, 0, jy + 1, jz + 1) * bsize + sub2ind(bx, by, bz, bx - 1, jy, jz)] = c;
							}
						}
					}

					++j;

					if (iz < nz - 1)
					{
						local_colind[j] = sub2ind(nx, ny, nz, ix + 1, iy, iz + 1);
						BSRBlockFill(bsize, 0.0, local_values + j * bnnz);
			
						for (int jy = 0; jy < by; ++jy)
						{
							if (jy > 0)
								local_values[j * bnnz + sub2ind(bx, by, bz, 0, jy - 1, 0) * bsize + sub2ind(bx, by, bz, bx - 1, jy, bz - 1)] = c;
							local_values[j * bnnz + sub2ind(bx, by, bz, 0, jy, 0) * bsize + sub2ind(bx, by, bz, bx - 1, jy, bz - 1)] = c;
							if (jy < by - 1)
								local_values[j * bnnz + sub2ind(bx, by, bz, 0, jy + 1, 0) * bsize + sub2ind(bx, by, bz, bx - 1, jy, bz - 1)] = c;
						}

						++j;
					}

					if (iy < ny - 1)
					{
						if (iz > 0)
						{
							local_colind[j] = sub2ind(nx, ny, nz, ix + 1, iy + 1, iz - 1);
							BSRBlockFill(bsize, 0.0, local_values + j * bnnz);
							local_values[j * bnnz + sub2ind(bx, by, bz, 0, 0, bz - 1) * bsize + sub2ind(bx, by, bz, bx - 1, by - 1, 0)] = c;
							++j;
						}

						local_colind[j] = sub2ind(nx, ny, nz, ix + 1, iy + 1, iz);
						BSRBlockFill(bsize, 0.0, local_values + j * bnnz);

						for (int jz = 0; jz < bz; ++jz)
						{
							if (jz > 0)
								local_values[j * bnnz + sub2ind(bx, by, bz, 0, 0, jz - 1) * bsize + sub2ind(bx, by, bz, bx - 1, by - 1, jz)] = c;
							local_values[j * bnnz + sub2ind(bx, by, bz, 0, 0, jz) * bsize + sub2ind(bx, by, bz, bx - 1, by - 1, jz)] = c;
							if (jz < bz - 1)
								local_values[j * bnnz + sub2ind(bx, by, bz, 0, 0, jz + 1) * bsize + sub2ind(bx, by, bz, bx - 1, by - 1, jz)] = c;
						}

						++j;

						if (iz < nz - 1)
						{
							local_colind[j] = sub2ind(nx, ny, nz, ix + 1, iy + 1, iz + 1);
							BSRBlockFill(bsize, 0.0, local_values + j * bnnz);
							local_values[j * bnnz + sub2ind(bx, by, bz, 0, 0, 0) * bsize + sub2ind(bx, by, bz, bx - 1, by - 1, bz - 1)] = c;
							++j;
						}
					}
				}
			}
		}
	}

	int rx, ry, rz;
	ind2sub(Px, Py, Pz, comm_rank, rx, ry, rz);

	int* exter_rowptr = new int[size + 1];
	for (int i = 0; i <= size; ++i)
		exter_rowptr[i] = 0;

	int nnb = 0;
	int* nbrank = new int[26];
	int* recvptr = new int[27];

	recvptr[0] = 0;

	if (rx > 0)
	{
		if (ry > 0)
		{
			if (rz > 0)
			{
				++exter_rowptr[sub2ind(nx, ny, nz, 0, 0, 0)];
				nbrank[nnb++] = sub2ind(Px, Py, Pz, rx - 1, ry - 1, rz - 1);
				recvptr[nnb] = 1;
			}

			for (int iz = 0; iz < nz; ++iz)
			{
				if (iz > 0) ++exter_rowptr[sub2ind(nx, ny, nz, 0, 0, iz)];
				++exter_rowptr[sub2ind(nx, ny, nz, 0, 0, iz)];
				if (iz < nz - 1) ++exter_rowptr[sub2ind(nx, ny, nz, 0, 0, iz)];
			}
			nbrank[nnb++] = sub2ind(Px, Py, Pz, rx - 1, ry - 1, rz);
			recvptr[nnb] = nz;

			if (rz < Pz - 1)
			{
				++exter_rowptr[sub2ind(nx, ny, nz, 0, 0, nz - 1)];
				nbrank[nnb++] = sub2ind(Px, Py, Pz, rx - 1, ry - 1, rz + 1);
				recvptr[nnb] = 1;
			}
		}

		if (rz > 0)
		{
			for (int iy = 0; iy < ny; ++iy)
			{
				if (iy > 0) ++exter_rowptr[sub2ind(nx, ny, nz, 0, iy, 0)];
				++exter_rowptr[sub2ind(nx, ny, nz, 0, iy, 0)];
				if (iy < ny - 1) ++exter_rowptr[sub2ind(nx, ny, nz, 0, iy, 0)];
			}
			nbrank[nnb++] = sub2ind(Px, Py, Pz, rx - 1, ry, rz - 1);
			recvptr[nnb] = ny;
		}

		for (int iy = 0; iy < ny; ++iy)
		{
			for (int iz = 0; iz < nz; ++iz)
			{
				if (iy > 0)
				{
					if (iz > 0) ++exter_rowptr[sub2ind(nx, ny, nz, 0, iy, iz)];
					++exter_rowptr[sub2ind(nx, ny, nz, 0, iy, iz)];
					if (iz < nz - 1) ++exter_rowptr[sub2ind(nx, ny, nz, 0, iy, iz)];
				}
				if (iz > 0) ++exter_rowptr[sub2ind(nx, ny, nz, 0, iy, iz)];
				++exter_rowptr[sub2ind(nx, ny, nz, 0, iy, iz)];
				if (iz < nz - 1) ++exter_rowptr[sub2ind(nx, ny, nz, 0, iy, iz)];
				if (iy < ny - 1)
				{
					if (iz > 0) ++exter_rowptr[sub2ind(nx, ny, nz, 0, iy, iz)];
					++exter_rowptr[sub2ind(nx, ny, nz, 0, iy, iz)];
					if (iz < nz - 1) ++exter_rowptr[sub2ind(nx, ny, nz, 0, iy, iz)];
				}
			}
		}
		nbrank[nnb++] = sub2ind(Px, Py, Pz, rx - 1, ry, rz);
		recvptr[nnb] = ny * nz;

		if (rz < Pz - 1)
		{
			for (int iy = 0; iy < ny; ++iy)
			{
				if (iy > 0) ++exter_rowptr[sub2ind(nx, ny, nz, 0, iy, nz - 1)];
				++exter_rowptr[sub2ind(nx, ny, nz, 0, iy, nz - 1)];
				if (iy < ny - 1) ++exter_rowptr[sub2ind(nx, ny, nz, 0, iy, nz - 1)];
			}
			nbrank[nnb++] = sub2ind(Px, Py, Pz, rx - 1, ry, rz + 1);
			recvptr[nnb] = ny;
		}

		if (ry < Py - 1)
		{
			if (rz > 0)
			{
				++exter_rowptr[sub2ind(nx, ny, nz, 0, ny - 1, 0)];
				nbrank[nnb++] = sub2ind(Px, Py, Pz, rx - 1, ry + 1, rz - 1);
				recvptr[nnb] = 1;
			}

			for (int iz = 0; iz < nz; ++iz)
			{
				if (iz > 0) ++exter_rowptr[sub2ind(nx, ny, nz, 0, ny - 1, iz)];
				++exter_rowptr[sub2ind(nx, ny, nz, 0, ny - 1, iz)];
				if (iz < nz - 1) ++exter_rowptr[sub2ind(nx, ny, nz, 0, ny - 1, iz)];
			}
			nbrank[nnb++] = sub2ind(Px, Py, Pz, rx - 1, ry + 1, rz);
			recvptr[nnb] = nz;

			if (rz < Pz - 1)
			{
				++exter_rowptr[sub2ind(nx, ny, nz, 0, ny - 1, nz - 1)];
				nbrank[nnb++] = sub2ind(Px, Py, Pz, rx - 1, ry + 1, rz + 1);
				recvptr[nnb] = 1;
			}
		}
	}

	if (ry > 0)
	{
		if (rz > 0)
		{
			for (int ix = 0; ix < nx; ++ix)
			{
				if (ix > 0) ++exter_rowptr[sub2ind(nx, ny, nz, ix, 0, 0)];
				++exter_rowptr[sub2ind(nx, ny, nz, ix, 0, 0)];
				if (ix < nx - 1) ++exter_rowptr[sub2ind(nx, ny, nz, ix, 0, 0)];
			}
			nbrank[nnb++] = sub2ind(Px, Py, Pz, rx, ry - 1, rz - 1);
			recvptr[nnb] = nx;
		}

		for (int ix = 0; ix < nx; ++ix)
		{
			for (int iz = 0; iz < nz; ++iz)
			{
				if (ix > 0)
				{
					if (iz > 0) ++exter_rowptr[sub2ind(nx, ny, nz, ix, 0, iz)];
					++exter_rowptr[sub2ind(nx, ny, nz, ix, 0, iz)];
					if (iz < nz - 1) ++exter_rowptr[sub2ind(nx, ny, nz, ix, 0, iz)];
				}
				if (iz > 0) ++exter_rowptr[sub2ind(nx, ny, nz, ix, 0, iz)];
				++exter_rowptr[sub2ind(nx, ny, nz, ix, 0, iz)];
				if (iz < nz - 1) ++exter_rowptr[sub2ind(nx, ny, nz, ix, 0, iz)];
				if (ix < nx - 1)
				{
					if (iz > 0) ++exter_rowptr[sub2ind(nx, ny, nz, ix, 0, iz)];
					++exter_rowptr[sub2ind(nx, ny, nz, ix, 0, iz)];
					if (iz < nz - 1) ++exter_rowptr[sub2ind(nx, ny, nz, ix, 0, iz)];
				}
			}
		}
		nbrank[nnb++] = sub2ind(Px, Py, Pz, rx, ry - 1, rz);
		recvptr[nnb] = nx * nz;

		if (rz < Pz - 1)
		{
			for (int ix = 0; ix < nx; ++ix)
			{
				if (ix > 0) ++exter_rowptr[sub2ind(nx, ny, nz, ix, 0, nz - 1)];
				++exter_rowptr[sub2ind(nx, ny, nz, ix, 0, nz - 1)];
				if (ix < nx - 1) ++exter_rowptr[sub2ind(nx, ny, nz, ix, 0, nz - 1)];
			}
			nbrank[nnb++] = sub2ind(Px, Py, Pz, rx, ry - 1, rz + 1);
			recvptr[nnb] = nx;
		}
	}

	if (rz > 0)
	{
		for (int ix = 0; ix < nx; ++ix)
		{
			for (int iy = 0; iy < ny; ++iy)
			{
				if (ix > 0)
				{
					if (iy > 0) ++exter_rowptr[sub2ind(nx, ny, nz, ix, iy, 0)];
					++exter_rowptr[sub2ind(nx, ny, nz, ix, iy, 0)];
					if (iy < ny - 1) ++exter_rowptr[sub2ind(nx, ny, nz, ix, iy, 0)];
				}
				if (iy > 0) ++exter_rowptr[sub2ind(nx, ny, nz, ix, iy, 0)];
				++exter_rowptr[sub2ind(nx, ny, nz, ix, iy, 0)];
				if (iy < ny - 1) ++exter_rowptr[sub2ind(nx, ny, nz, ix, iy, 0)];
				if (ix < nx - 1)
				{
					if (iy > 0) ++exter_rowptr[sub2ind(nx, ny, nz, ix, iy, 0)];
					++exter_rowptr[sub2ind(nx, ny, nz, ix, iy, 0)];
					if (iy < ny - 1) ++exter_rowptr[sub2ind(nx, ny, nz, ix, iy, 0)];
				}
			}
		}
		nbrank[nnb++] = sub2ind(Px, Py, Pz, rx, ry, rz - 1);
		recvptr[nnb] = nx * ny;
	}

	if (rz < Pz - 1)
	{
		for (int ix = 0; ix < nx; ++ix)
		{
			for (int iy = 0; iy < ny; ++iy)
			{
				if (ix > 0)
				{
					if (iy > 0) ++exter_rowptr[sub2ind(nx, ny, nz, ix, iy, nz - 1)];
					++exter_rowptr[sub2ind(nx, ny, nz, ix, iy, nz - 1)];
					if (iy < ny - 1) ++exter_rowptr[sub2ind(nx, ny, nz, ix, iy, nz - 1)];
				}
				if (iy > 0) ++exter_rowptr[sub2ind(nx, ny, nz, ix, iy, nz - 1)];
				++exter_rowptr[sub2ind(nx, ny, nz, ix, iy, nz - 1)];
				if (iy < ny - 1) ++exter_rowptr[sub2ind(nx, ny, nz, ix, iy, nz - 1)];
				if (ix < nx - 1)
				{
					if (iy > 0) ++exter_rowptr[sub2ind(nx, ny, nz, ix, iy, nz - 1)];
					++exter_rowptr[sub2ind(nx, ny, nz, ix, iy, nz - 1)];
					if (iy < ny - 1) ++exter_rowptr[sub2ind(nx, ny, nz, ix, iy, nz - 1)];
				}
			}
		}
		nbrank[nnb++] = sub2ind(Px, Py, Pz, rx, ry, rz + 1);
		recvptr[nnb] = nx * ny;
	}

	if (ry < Py - 1)
	{
		if (rz > 0)
		{
			for (int ix = 0; ix < nx; ++ix)
			{
				if (ix > 0) ++exter_rowptr[sub2ind(nx, ny, nz, ix, ny - 1, 0)];
				++exter_rowptr[sub2ind(nx, ny, nz, ix, ny - 1, 0)];
				if (ix < nx - 1) ++exter_rowptr[sub2ind(nx, ny, nz, ix, ny - 1, 0)];
			}
			nbrank[nnb++] = sub2ind(Px, Py, Pz, rx, ry + 1, rz - 1);
			recvptr[nnb] = nx;
		}

		for (int ix = 0; ix < nx; ++ix)
		{
			for (int iz = 0; iz < nz; ++iz)
			{
				if (ix > 0)
				{
					if (iz > 0) ++exter_rowptr[sub2ind(nx, ny, nz, ix, ny - 1, iz)];
					++exter_rowptr[sub2ind(nx, ny, nz, ix, ny - 1, iz)];
					if (iz < nz - 1) ++exter_rowptr[sub2ind(nx, ny, nz, ix, ny - 1, iz)];
				}
				if (iz > 0) ++exter_rowptr[sub2ind(nx, ny, nz, ix, ny - 1, iz)];
				++exter_rowptr[sub2ind(nx, ny, nz, ix, ny - 1, iz)];
				if (iz < nz - 1) ++exter_rowptr[sub2ind(nx, ny, nz, ix, ny - 1, iz)];
				if (ix < nx - 1)
				{
					if (iz > 0) ++exter_rowptr[sub2ind(nx, ny, nz, ix, ny - 1, iz)];
					++exter_rowptr[sub2ind(nx, ny, nz, ix, ny - 1, iz)];
					if (iz < nz - 1) ++exter_rowptr[sub2ind(nx, ny, nz, ix, ny - 1, iz)];
				}
			}
		}
		nbrank[nnb++] = sub2ind(Px, Py, Pz, rx, ry + 1, rz);
		recvptr[nnb] = nx * nz;

		if (rz < Pz - 1)
		{
			for (int ix = 0; ix < nx; ++ix)
			{
				if (ix > 0) ++exter_rowptr[sub2ind(nx, ny, nz, ix, ny - 1, nz - 1)];
				++exter_rowptr[sub2ind(nx, ny, nz, ix, ny - 1, nz - 1)];
				if (ix < nx - 1) ++exter_rowptr[sub2ind(nx, ny, nz, ix, ny - 1, nz - 1)];
			}
			nbrank[nnb++] = sub2ind(Px, Py, Pz, rx, ry + 1, rz + 1);
			recvptr[nnb] = nx;
		}
	}

	if (rx < Px - 1)
	{
		if (ry > 0)
		{
			if (rz > 0)
			{
				++exter_rowptr[sub2ind(nx, ny, nz, nx - 1, 0, 0)];
				nbrank[nnb++] = sub2ind(Px, Py, Pz, rx + 1, ry - 1, rz - 1);
				recvptr[nnb] = 1;
			}

			for (int iz = 0; iz < nz; ++iz)
			{
				if (iz > 0) ++exter_rowptr[sub2ind(nx, ny, nz, nx - 1, 0, iz)];
				++exter_rowptr[sub2ind(nx, ny, nz, nx - 1, 0, iz)];
				if (iz < nz - 1) ++exter_rowptr[sub2ind(nx, ny, nz, nx - 1, 0, iz)];
			}
			nbrank[nnb++] = sub2ind(Px, Py, Pz, rx + 1, ry - 1, rz);
			recvptr[nnb] = nz;

			if (rz < Pz - 1)
			{
				++exter_rowptr[sub2ind(nx, ny, nz, nx - 1, 0, nz - 1) ];
				nbrank[nnb++] = sub2ind(Px, Py, Pz, rx + 1, ry - 1, rz + 1);
				recvptr[nnb] = 1;
			}
		}

		if (rz > 0)
		{
			for (int iy = 0; iy < ny; ++iy)
			{
				if (iy > 0) ++exter_rowptr[sub2ind(nx, ny, nz, nx - 1, iy, 0)];
				++exter_rowptr[sub2ind(nx, ny, nz, nx - 1, iy, 0)];
				if (iy < ny - 1) ++exter_rowptr[sub2ind(nx, ny, nz, nx - 1, iy, 0)];
			}
			nbrank[nnb++] = sub2ind(Px, Py, Pz, rx + 1, ry, rz - 1);
			recvptr[nnb] = ny;
		}

		for (int iy = 0; iy < ny; ++iy)
		{
			for (int iz = 0; iz < nz; ++iz)
			{
				if (iy > 0)
				{
					if (iz > 0) ++exter_rowptr[sub2ind(nx, ny, nz, nx - 1, iy, iz)];
					++exter_rowptr[sub2ind(nx, ny, nz, nx - 1, iy, iz)];
					if (iz < nz - 1) ++exter_rowptr[sub2ind(nx, ny, nz, nx - 1, iy, iz)];
				}
				if (iz > 0) ++exter_rowptr[sub2ind(nx, ny, nz, nx - 1, iy, iz)];
				++exter_rowptr[sub2ind(nx, ny, nz, nx - 1, iy, iz)];
				if (iz < nz - 1) ++exter_rowptr[sub2ind(nx, ny, nz, nx - 1, iy, iz)];
				if (iy < ny - 1)
				{
					if (iz > 0) ++exter_rowptr[sub2ind(nx, ny, nz, nx - 1, iy, iz)];
					++exter_rowptr[sub2ind(nx, ny, nz, nx - 1, iy, iz)];
					if (iz < nz - 1) ++exter_rowptr[sub2ind(nx, ny, nz, nx - 1, iy, iz)];
				}
			}
		}
		nbrank[nnb++] = sub2ind(Px, Py, Pz, rx + 1, ry, rz);
		recvptr[nnb] = ny * nz;

		if (rz < Pz - 1)
		{
			for (int iy = 0; iy < ny; ++iy)
			{
				if (iy > 0) ++exter_rowptr[sub2ind(nx, ny, nz, nx - 1, iy, nz - 1)];
				++exter_rowptr[sub2ind(nx, ny, nz, nx - 1, iy, nz - 1)];
				if (iy < ny - 1) ++exter_rowptr[sub2ind(nx, ny, nz, nx - 1, iy, nz - 1)];
			}
			nbrank[nnb++] = sub2ind(Px, Py, Pz, rx + 1, ry, rz + 1);
			recvptr[nnb] = ny;
		}

		if (ry < Py - 1)
		{
			if (rz > 0)
			{
				++exter_rowptr[sub2ind(nx, ny, nz, nx - 1, ny - 1, 0)];
				nbrank[nnb++] = sub2ind(Px, Py, Pz, rx + 1, ry + 1, rz - 1);
				recvptr[nnb] = 1;
			}

			for (int iz = 0; iz < nz; ++iz)
			{
				if (iz > 0) ++exter_rowptr[sub2ind(nx, ny, nz, nx - 1, ny - 1, iz)];
				++exter_rowptr[sub2ind(nx, ny, nz, nx - 1, ny - 1, iz)];
				if (iz < nz - 1) ++exter_rowptr[sub2ind(nx, ny, nz, nx - 1, ny - 1, iz)];
			}
			nbrank[nnb++] = sub2ind(Px, Py, Pz, rx + 1, ry + 1, rz);
			recvptr[nnb] = nz;

			if (rz < Pz - 1)
			{
				++exter_rowptr[sub2ind(nx, ny, nz, nx - 1, ny - 1, nz - 1)];
				nbrank[nnb++] = sub2ind(Px, Py, Pz, rx + 1, ry + 1, rz + 1);
				recvptr[nnb] = 1;
			}
		}
	}

	for (int i = 0; i < size; ++i)
		exter_rowptr[i + 1] += exter_rowptr[i];

	int* exter_colind = new int[exter_rowptr[size]];
	double* exter_values = new double[exter_rowptr[size] * bnnz];

	for (int r = 0; r < nnb; ++r)
		recvptr[r + 1] += recvptr[r];

	int* recvind = new int[recvptr[nnb]];

	int nbind = nnb;

	if (rx < Px - 1)
	{
		if (ry < Py - 1)
		{
			if (rz < Pz - 1)
			{
				int t = recvptr[nbind--];
				recvind[--t] = sub2ind(nx, ny, nz, 0, 0, 0);
				int j = --exter_rowptr[sub2ind(nx, ny, nz, nx - 1, ny - 1, nz - 1)];
				exter_colind[j] = t;
				BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
				exter_values[j * bnnz + sub2ind(bx, by, bz, 0, 0, 0) * bsize + sub2ind(bx, by, bz, bx - 1, by - 1, bz - 1)] = c;
			}

			int t = recvptr[nbind--];
			for (int iz = nz - 1; iz >= 0; --iz)
			{
				recvind[--t] = sub2ind(nx, ny, nz, 0, 0, iz);
				if (iz < nz - 1)
				{
					int j = --exter_rowptr[sub2ind(nx, ny, nz, nx - 1, ny - 1, iz)];
					exter_colind[j] = t + 1;
					BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
					exter_values[j * bnnz + sub2ind(bx, by, bz, 0, 0, 0) * bsize + sub2ind(bx, by, bz, bx - 1, by - 1, bz - 1)] = c;
				}
				int j = --exter_rowptr[sub2ind(nx, ny, nz, nx - 1, ny - 1, iz)];
				exter_colind[j] = t;
				BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
				for (int jz = 0; jz < bz; ++jz)
				{
					if (jz > 0)
						exter_values[j * bnnz + sub2ind(bx, by, bz, 0, 0, jz - 1) * bsize + sub2ind(bx, by, bz, bx - 1, by - 1, jz)] = c;
					exter_values[j * bnnz + sub2ind(bx, by, bz, 0, 0, jz) * bsize + sub2ind(bx, by, bz, bx - 1, by - 1, jz)] = c;
					if (jz < bz - 1)
						exter_values[j * bnnz + sub2ind(bx, by, bz, 0, 0, jz + 1) * bsize + sub2ind(bx, by, bz, bx - 1, by - 1, jz)] = c;
				}
				if (iz > 0)
				{
					int j = --exter_rowptr[sub2ind(nx, ny, nz, nx - 1, ny - 1, iz)];
					exter_colind[j] = t - 1;
					BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
					exter_values[j * bnnz + sub2ind(bx, by, bz, 0, 0, bz - 1) * bsize + sub2ind(bx, by, bz, bx - 1, by - 1, 0)] = c;
				}
			}

			if (rz > 0)
			{
				int t = recvptr[nbind--];
				recvind[--t] = sub2ind(nx, ny, nz, 0, 0, nz - 1);
				int j = --exter_rowptr[sub2ind(nx, ny, nz, nx - 1, ny - 1, 0)];
				exter_colind[j] = t;
				BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
				exter_values[j * bnnz + sub2ind(bx, by, bz, 0, 0, bz - 1) * bsize + sub2ind(bx, by, bz, bx - 1, by - 1, 0)] = c;
			}
		}

		if (rz < Pz - 1)
		{
			int t = recvptr[nbind--];
			for (int iy = ny - 1; iy >= 0; --iy)
			{
				recvind[--t] = sub2ind(nx, ny, nz, 0, iy, 0);
				if (iy < ny - 1)
				{
					int j = --exter_rowptr[sub2ind(nx, ny, nz, nx - 1, iy, nz - 1)];
					exter_colind[j] = t + 1;
					BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
					exter_values[j * bnnz + sub2ind(bx, by, bz, 0, 0, 0) * bsize + sub2ind(bx, by, bz, bx - 1, by - 1, bz - 1)] = c;
				}
				int j = --exter_rowptr[sub2ind(nx, ny, nz, nx - 1, iy, nz - 1)];
				exter_colind[j] = t;
				BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
				for (int jy = 0; jy < by; ++jy)
				{
					if (jy > 0)
						exter_values[j * bnnz + sub2ind(bx, by, bz, 0, jy - 1, 0) * bsize + sub2ind(bx, by, bz, bx - 1, jy, bz - 1)] = c;
					exter_values[j * bnnz + sub2ind(bx, by, bz, 0, jy, 0) * bsize + sub2ind(bx, by, bz, bx - 1, jy, bz - 1)] = c;
					if (jy < by - 1)
						exter_values[j * bnnz + sub2ind(bx, by, bz, 0, jy + 1, 0) * bsize + sub2ind(bx, by, bz, bx - 1, jy, bz - 1)] = c;
				}
				if (iy > 0)
				{
					int j = --exter_rowptr[sub2ind(nx, ny, nz, nx - 1, iy, nz - 1)];
					exter_colind[j] = t - 1;
					BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
					exter_values[j * bnnz + sub2ind(bx, by, bz, 0, by - 1, 0) * bsize + sub2ind(bx, by, bz, bx - 1, 0, bz - 1)] = c;
				}
			}
		}

		int t = recvptr[nbind--];
		for (int iy = ny - 1; iy >= 0; --iy)
		{
			for (int iz = nz - 1; iz >= 0; --iz)
			{
				recvind[--t] = sub2ind(nx, ny, nz, 0, iy, iz);
				if (iy < ny - 1)
				{
					if (iz < nz - 1)
					{
						int j = --exter_rowptr[sub2ind(nx, ny, nz, nx - 1, iy, iz)];
						exter_colind[j] = t + nz + 1;
						BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
						exter_values[j * bnnz + sub2ind(bx, by, bz, 0, 0, 0) * bsize + sub2ind(bx, by, bz, bx - 1, by - 1, bz - 1)] = c;
					}
					int j = --exter_rowptr[sub2ind(nx, ny, nz, nx - 1, iy, iz)];
					exter_colind[j] = t + nz;
					BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
					for (int jz = 0; jz < bz; ++jz)
					{
						if (jz > 0)
							exter_values[j * bnnz + sub2ind(bx, by, bz, 0, 0, jz - 1) * bsize + sub2ind(bx, by, bz, bx - 1, by - 1, jz)] = c;
						exter_values[j * bnnz + sub2ind(bx, by, bz, 0, 0, jz) * bsize + sub2ind(bx, by, bz, bx - 1, by - 1, jz)] = c;
						if (jz < bz - 1)
							exter_values[j * bnnz + sub2ind(bx, by, bz, 0, 0, jz + 1) * bsize + sub2ind(bx, by, bz, bx - 1, by - 1, jz)] = c;
					}
					if (iz > 0)
					{
						int j = --exter_rowptr[sub2ind(nx, ny, nz, nx - 1, iy, iz)];
						exter_colind[j] = t + nz - 1;
						BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
						exter_values[j * bnnz + sub2ind(bx, by, bz, 0, 0, bz - 1) * bsize + sub2ind(bx, by, bz, bx - 1, by - 1, 0)] = c;
					}
				}
				if (iz < nz - 1)
				{
					int j = --exter_rowptr[sub2ind(nx, ny, nz, nx - 1, iy, iz)];
					exter_colind[j] = t + 1;
					BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
					for (int jy = 0; jy < by; ++jy)
					{
						if (jy > 0)
							exter_values[j * bnnz + sub2ind(bx, by, bz, 0, jy - 1, 0) * bsize + sub2ind(bx, by, bz, bx - 1, jy, bz - 1)] = c;
						exter_values[j * bnnz + sub2ind(bx, by, bz, 0, jy, 0) * bsize + sub2ind(bx, by, bz, bx - 1, jy, bz - 1)] = c;
						if (jy < by - 1)
							exter_values[j * bnnz + sub2ind(bx, by, bz, 0, jy + 1, 0) * bsize + sub2ind(bx, by, bz, bx - 1, jy, bz - 1)] = c;
					}
				}
				int j = --exter_rowptr[sub2ind(nx, ny, nz, nx - 1, iy, iz)];
				exter_colind[j] = t;
				BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
				for (int jy = 0; jy < by; ++jy)
				{
					for (int jz = 0; jz < bz; ++jz)
					{
						if (jy > 0)
						{
							if (jz > 0)
								exter_values[j * bnnz + sub2ind(bx, by, bz, 0, jy - 1, jz - 1) * bsize + sub2ind(bx, by, bz, bx - 1, jy, jz)] = c;
							exter_values[j * bnnz + sub2ind(bx, by, bz, 0, jy - 1, jz) * bsize + sub2ind(bx, by, bz, bx - 1, jy, jz)] = c;
							if (jz < bz - 1)
								exter_values[j * bnnz + sub2ind(bx, by, bz, 0, jy - 1, jz + 1) * bsize + sub2ind(bx, by, bz, bx - 1, jy, jz)] = c;
						}
						if (jz > 0)
							exter_values[j * bnnz + sub2ind(bx, by, bz, 0, jy, jz - 1) * bsize + sub2ind(bx, by, bz, bx - 1, jy, jz)] = c;
						exter_values[j * bnnz + sub2ind(bx, by, bz, 0, jy, jz) * bsize + sub2ind(bx, by, bz, bx - 1, jy, jz)] = c;
						if (jz < bz - 1)
							exter_values[j * bnnz + sub2ind(bx, by, bz, 0, jy, jz + 1) * bsize + sub2ind(bx, by, bz, bx - 1, jy, jz)] = c;
						if (jy < by - 1)
						{
							if (jz > 0)
								exter_values[j * bnnz + sub2ind(bx, by, bz, 0, jy + 1, jz - 1) * bsize + sub2ind(bx, by, bz, bx - 1, jy, jz)] = c;
							exter_values[j * bnnz + sub2ind(bx, by, bz, 0, jy + 1, jz) * bsize + sub2ind(bx, by, bz, bx - 1, jy, jz)] = c;
							if (jz < bz - 1)
								exter_values[j * bnnz + sub2ind(bx, by, bz, 0, jy + 1, jz + 1) * bsize + sub2ind(bx, by, bz, bx - 1, jy, jz)] = c;
						}
					}
				}
				if (iz > 0)
				{
					int j = --exter_rowptr[sub2ind(nx, ny, nz, nx - 1, iy, iz)];
					exter_colind[j] = t - 1;
					BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
					for (int jy = 0; jy < by; ++jy)
					{
						if (jy > 0)
							exter_values[j * bnnz + sub2ind(bx, by, bz, 0, jy - 1, bz - 1) * bsize + sub2ind(bx, by, bz, bx - 1, jy, 0)] = c;
						exter_values[j * bnnz + sub2ind(bx, by, bz, 0, jy, bz - 1) * bsize + sub2ind(bx, by, bz, bx - 1, jy, 0)] = c;
						if (jy < by - 1)
							exter_values[j * bnnz + sub2ind(bx, by, bz, 0, jy + 1, bz - 1) * bsize + sub2ind(bx, by, bz, bx - 1, jy, 0)] = c;
					}
				}
				if (iy > 0)
				{
					if (iz < nz - 1)
					{
						int j = --exter_rowptr[sub2ind(nx, ny, nz, nx - 1, iy, iz)];
						exter_colind[j] = t - nz + 1;
						BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
						exter_values[j * bnnz + sub2ind(bx, by, bz, 0, by - 1, 0) * bsize + sub2ind(bx, by, bz, bx - 1, 0, bz - 1)] = c;
					}
					int j = --exter_rowptr[sub2ind(nx, ny, nz, nx - 1, iy, iz)];
					exter_colind[j] = t - nz;
					BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
					for (int jz = 0; jz < bz; ++jz)
					{
						if (jz > 0)
							exter_values[j * bnnz + sub2ind(bx, by, bz, 0, by - 1, jz - 1) * bsize + sub2ind(bx, by, bz, bx - 1, 0, jz)] = c;
						exter_values[j * bnnz + sub2ind(bx, by, bz, 0, by - 1, jz) * bsize + sub2ind(bx, by, bz, bx - 1, 0, jz)] = c;
						if (jz < bz - 1)
							exter_values[j * bnnz + sub2ind(bx, by, bz, 0, by - 1, jz + 1) * bsize + sub2ind(bx, by, bz, bx - 1, 0, jz)] = c;
					}
					if (iz > 0)
					{
						int j = --exter_rowptr[sub2ind(nx, ny, nz, nx - 1, iy, iz)];
						exter_colind[j] = t - nz - 1;
						BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
						exter_values[j * bnnz + sub2ind(bx, by, bz, 0, by - 1, bz - 1) * bsize + sub2ind(bx, by, bz, bx - 1, 0, 0)] = c;
					}
				}
			}
		}

		if (rz > 0)
		{
			int t = recvptr[nbind--];
			for (int iy = ny - 1; iy >= 0; --iy)
			{
				recvind[--t] = sub2ind(nx, ny, nz, 0, iy, nz - 1);
				if (iy < ny - 1)
				{
					int j = --exter_rowptr[sub2ind(nx, ny, nz, nx - 1, iy, 0)];
					exter_colind[j] = t + 1;
					BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
					exter_values[j * bnnz + sub2ind(bx, by, bz, 0, 0, bz - 1) * bsize + sub2ind(bx, by, bz, bx - 1, by - 1, 0)] = c;
				}
				int j = --exter_rowptr[sub2ind(nx, ny, nz, nx - 1, iy, 0)];
				exter_colind[j] = t;
				BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
				for (int jy = 0; jy < by; ++jy)
				{
					if (jy > 0)
						exter_values[j * bnnz + sub2ind(bx, by, bz, 0, jy - 1, bz - 1) * bsize + sub2ind(bx, by, bz, bx - 1, jy, 0)] = c;
					exter_values[j * bnnz + sub2ind(bx, by, bz, 0, jy, bz - 1) * bsize + sub2ind(bx, by, bz, bx - 1, jy, 0)] = c;
					if (jy < by - 1)
						exter_values[j * bnnz + sub2ind(bx, by, bz, 0, jy + 1, bz - 1) * bsize + sub2ind(bx, by, bz, bx - 1, jy, 0)] = c;
				}
				if (iy > 0)
				{
					int j = --exter_rowptr[sub2ind(nx, ny, nz, nx - 1, iy, 0)];
					exter_colind[j] = t - 1;
					BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
					exter_values[j * bnnz + sub2ind(bx, by, bz, 0, by - 1, bz - 1) * bsize + sub2ind(bx, by, bz, bx - 1, 0, 0)] = c;
				}
			}
		}

		if (ry > 0)
		{
			if (rz < Pz - 1)
			{
				int t = recvptr[nbind--];
				recvind[--t] = sub2ind(nx, ny, nz, 0, ny - 1, 0);
				int j = --exter_rowptr[sub2ind(nx, ny, nz, nx - 1, 0, nz - 1)];
				exter_colind[j] = t;
				BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
				exter_values[j * bnnz + sub2ind(bx, by, bz, 0, by - 1, 0) * bsize + sub2ind(bx, by, bz, bx - 1, 0, bz - 1)] = c;
			}

			int t = recvptr[nbind--];
			for (int iz = nz - 1; iz >= 0; --iz)
			{
				recvind[--t] = sub2ind(nx, ny, nz, 0, ny - 1, iz);
				if (iz < nz - 1)
				{
					int j = --exter_rowptr[sub2ind(nx, ny, nz, nx - 1, 0, iz)];
					exter_colind[j] = t + 1;
					BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
					exter_values[j * bnnz + sub2ind(bx, by, bz, 0, by - 1, 0) * bsize + sub2ind(bx, by, bz, bx - 1, 0, bz - 1)] = c;
				}
				int j = --exter_rowptr[sub2ind(nx, ny, nz, nx - 1, 0, iz)];
				exter_colind[j] = t;
				BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
				for (int jz = 0; jz < bz; ++jz)
				{
					if (jz > 0)
						exter_values[j * bnnz + sub2ind(bx, by, bz, 0, by - 1, jz - 1) * bsize + sub2ind(bx, by, bz, bx - 1, 0, jz)] = c;
					exter_values[j * bnnz + sub2ind(bx, by, bz, 0, by - 1, jz) * bsize + sub2ind(bx, by, bz, bx - 1, 0, jz)] = c;
					if (jz < bz - 1)
						exter_values[j * bnnz + sub2ind(bx, by, bz, 0, by - 1, jz + 1) * bsize + sub2ind(bx, by, bz, bx - 1, 0, jz)] = c;
				}
				if (iz > 0)
				{
					int j = --exter_rowptr[sub2ind(nx, ny, nz, nx - 1, 0, iz)];
					exter_colind[j] = t - 1;
					BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
					exter_values[j * bnnz + sub2ind(bx, by, bz, 0, by - 1, bz - 1) * bsize + sub2ind(bx, by, bz, bx - 1, 0, 0)] = c;
				}
			}

			if (rz > 0)
			{
				int t = recvptr[nbind--];
				recvind[--t] = sub2ind(nx, ny, nz, 0, ny - 1, nz - 1);
				int j = --exter_rowptr[sub2ind(nx, ny, nz, nx - 1, 0, 0)];
				exter_colind[j] = t;
				BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
				exter_values[j * bnnz + sub2ind(bx, by, bz, 0, by - 1, bz - 1) * bsize + sub2ind(bx, by, bz, bx - 1, 0, 0)] = c;
			}
		}
	}

	if (ry < Py - 1)
	{
		if (rz < Pz - 1)
		{
			int t = recvptr[nbind--];
			for (int ix = nx - 1; ix >= 0; --ix)
			{
				recvind[--t] = sub2ind(nx, ny, nz, ix, 0, 0);
				if (ix < nx - 1)
				{
					int j = --exter_rowptr[sub2ind(nx, ny, nz, ix, ny - 1, nz - 1)];
					exter_colind[j] = t + 1;
					BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
					exter_values[j * bnnz + sub2ind(bx, by, bz, 0, 0, 0) * bsize + sub2ind(bx, by, bz, bx - 1, by - 1, bz - 1)] = c;
				}
				int j = --exter_rowptr[sub2ind(nx, ny, nz, ix, ny - 1, nz - 1)];
				exter_colind[j] = t;
				BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
				for (int jx = 0; jx < bx; ++jx)
				{
					if (jx > 0)
						exter_values[j * bnnz + sub2ind(bx, by, bz, jx - 1, 0, 0) * bsize + sub2ind(bx, by, bz, jx, by - 1, bz - 1)] = c;
						exter_values[j * bnnz + sub2ind(bx, by, bz, jx, 0, 0) * bsize + sub2ind(bx, by, bz, jx, by - 1, bz - 1)] = c;
					if (jx < bx - 1)
						exter_values[j * bnnz + sub2ind(bx, by, bz, jx + 1, 0, 0) * bsize + sub2ind(bx, by, bz, jx, by - 1, bz - 1)] = c;
				}
				if (ix > 0)
				{
					int j = --exter_rowptr[sub2ind(nx, ny, nz, ix, ny - 1, nz - 1)];
					exter_colind[j] = t - 1;
					BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
					exter_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, 0, 0) * bsize + sub2ind(bx, by, bz, 0, by - 1, bz - 1)] = c;
				}
			}
		}

		int t = recvptr[nbind--];
		for (int ix = nx - 1; ix >= 0; --ix)
		{
			for (int iz = nz - 1; iz >= 0; --iz)
			{
				recvind[--t] = sub2ind(nx, ny, nz, ix, 0, iz);
				if (ix < nx - 1)
				{
					if (iz < nz - 1)
					{
						int j = --exter_rowptr[sub2ind(nx, ny, nz, ix, ny - 1, iz)];
						exter_colind[j] = t + nz + 1;
						BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
						exter_values[j * bnnz + sub2ind(bx, by, bz, 0, 0, 0) * bsize + sub2ind(bx, by, bz, bx - 1, by - 1, bz - 1)] = c;
					}
					int j = --exter_rowptr[sub2ind(nx, ny, nz, ix, ny - 1, iz)];
					exter_colind[j] = t + nz;
					BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
					for (int jz = 0; jz < bz; ++jz)
					{
						if (jz > 0)
							exter_values[j * bnnz + sub2ind(bx, by, bz, 0, 0, jz - 1) * bsize + sub2ind(bx, by, bz, bx - 1, by - 1, jz)] = c;
						exter_values[j * bnnz + sub2ind(bx, by, bz, 0, 0, jz) * bsize + sub2ind(bx, by, bz, bx - 1, by - 1, jz)] = c;
						if (jz < bz - 1)
							exter_values[j * bnnz + sub2ind(bx, by, bz, 0, 0, jz + 1) * bsize + sub2ind(bx, by, bz, bx - 1, by - 1, jz)] = c;
					}
					if (iz > 0)
					{
						int j = --exter_rowptr[sub2ind(nx, ny, nz, ix, ny - 1, iz)];
						exter_colind[j] = t + nz - 1;
						BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
						exter_values[j * bnnz + sub2ind(bx, by, bz, 0, 0, bz - 1) * bsize + sub2ind(bx, by, bz, bx - 1, by - 1, 0)] = c;
					}
				}
				if (iz < nz - 1)
				{
					int j = --exter_rowptr[sub2ind(nx, ny, nz, ix, ny - 1, iz)];
					exter_colind[j] = t + 1;
					BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
					for (int jx = 0; jx < bx; ++jx)
					{
						if (jx > 0)
							exter_values[j * bnnz + sub2ind(bx, by, bz, jx - 1, 0, 0) * bsize + sub2ind(bx, by, bz, jx, by - 1, bz - 1)] = c;
						exter_values[j * bnnz + sub2ind(bx, by, bz, jx, 0, 0) * bsize + sub2ind(bx, by, bz, jx, by - 1, bz - 1)] = c;
						if (jx < bx - 1)
							exter_values[j * bnnz + sub2ind(bx, by, bz, jx + 1, 0, 0) * bsize + sub2ind(bx, by, bz, jx, by - 1, bz - 1)] = c;
					}
				}
				int j = --exter_rowptr[sub2ind(nx, ny, nz, ix, ny - 1, iz)];
				exter_colind[j] = t;
				BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
				for (int jx = 0; jx < bx; ++jx)
				{
					for (int jz = 0; jz < bz; ++jz)
					{
						if (jx > 0)
						{
							if (jz > 0)
								exter_values[j * bnnz + sub2ind(bx, by, bz, jx - 1, 0, jz - 1) * bsize + sub2ind(bx, by, bz, jx, by - 1, jz)] = c;
							exter_values[j * bnnz + sub2ind(bx, by, bz, jx - 1, 0, jz) * bsize + sub2ind(bx, by, bz, jx, by - 1, jz)] = c;
							if (jz < bz - 1)
								exter_values[j * bnnz + sub2ind(bx, by, bz, jx - 1, 0, jz + 1) * bsize + sub2ind(bx, by, bz, jx, by - 1, jz)] = c;
						}
						if (jz > 0)
							exter_values[j * bnnz + sub2ind(bx, by, bz, jx, 0, jz - 1) * bsize + sub2ind(bx, by, bz, jx, by - 1, jz)] = c;
						exter_values[j * bnnz + sub2ind(bx, by, bz, jx, 0, jz) * bsize + sub2ind(bx, by, bz, jx, by - 1, jz)] = c;
						if (jz < bz - 1)
							exter_values[j * bnnz + sub2ind(bx, by, bz, jx, 0, jz + 1) * bsize + sub2ind(bx, by, bz, jx, by - 1, jz)] = c;
						if (jx < bx - 1)
						{
							if (jz > 0)
								exter_values[j * bnnz + sub2ind(bx, by, bz, jx + 1, 0, jz - 1) * bsize + sub2ind(bx, by, bz, jx, by - 1, jz)] = c;
							exter_values[j * bnnz + sub2ind(bx, by, bz, jx + 1, 0, jz) * bsize + sub2ind(bx, by, bz, jx, by - 1, jz)] = c;
							if (jz < bz - 1)
								exter_values[j * bnnz + sub2ind(bx, by, bz, jx + 1, 0, jz + 1) * bsize + sub2ind(bx, by, bz, jx, by - 1, jz)] = c;
						}
					}
				}
				if (iz > 0)
				{
					int j = --exter_rowptr[sub2ind(nx, ny, nz, ix, ny - 1, iz)];
					exter_colind[j] = t - 1;
					BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
					for (int jx = 0; jx < bx; ++jx)
					{
						if (jx > 0)
							exter_values[j * bnnz + sub2ind(bx, by, bz, jx - 1, 0, bz - 1) * bsize + sub2ind(bx, by, bz, jx, by - 1, 0)] = c;
						exter_values[j * bnnz + sub2ind(bx, by, bz, jx, 0, bz - 1) * bsize + sub2ind(bx, by, bz, jx, by - 1, 0)] = c;
						if (jx < bx - 1)
							exter_values[j * bnnz + sub2ind(bx, by, bz, jx + 1, 0, bz - 1) * bsize + sub2ind(bx, by, bz, jx, by - 1, 0)] = c;
					}
				}
				if (ix > 0)
				{
					if (iz < nz - 1)
					{
						int j = --exter_rowptr[sub2ind(nx, ny, nz, ix, ny - 1, iz)];
						exter_colind[j] = t - nz + 1;
						BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
						exter_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, 0, 0) * bsize + sub2ind(bx, by, bz, 0, by - 1, bz - 1)] = c;
					}
					int j = --exter_rowptr[sub2ind(nx, ny, nz, ix, ny - 1, iz)];
					exter_colind[j] = t - nz;
					BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
					for (int jz = 0; jz < bz; ++jz)
					{
						if (jz > 0)
							exter_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, 0, jz - 1) * bsize + sub2ind(bx, by, bz, 0, by - 1, jz)] = c;
						exter_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, 0, jz) * bsize + sub2ind(bx, by, bz, 0, by - 1, jz)] = c;
						if (jz < bz - 1)
							exter_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, 0, jz + 1) * bsize + sub2ind(bx, by, bz, 0, by - 1, jz)] = c;
					}
					if (iz > 0)
					{
						int j = --exter_rowptr[sub2ind(nx, ny, nz, ix, ny - 1, iz)];
						exter_colind[j] = t - nz - 1;
						BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
						exter_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, 0, bz - 1) * bsize + sub2ind(bx, by, bz, 0, by - 1, 0)] = c;
					}
				}
			}
		}

		if (rz > 0)
		{
			int t = recvptr[nbind--];
			for (int ix = nx - 1; ix >= 0; --ix)
			{
				recvind[--t] = sub2ind(nx, ny, nz, ix, 0, nz - 1);
				if (ix < nx - 1)
				{
					int j = --exter_rowptr[sub2ind(nx, ny, nz, ix, ny - 1, 0)];
					exter_colind[j] = t + 1;
					BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
					exter_values[j * bnnz + sub2ind(bx, by, bz, 0, 0, bz - 1) * bsize + sub2ind(bx, by, bz, bx - 1, by - 1, 0)] = c;
				}
				int j = --exter_rowptr[sub2ind(nx, ny, nz, ix, ny - 1, 0)];
				exter_colind[j] = t;
				BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
				for (int jx = 0; jx < bx; ++jx)
				{
					if (jx > 0)
						exter_values[j * bnnz + sub2ind(bx, by, bz, jx - 1, 0, bz - 1) * bsize + sub2ind(bx, by, bz, jx, by - 1, 0)] = c;
						exter_values[j * bnnz + sub2ind(bx, by, bz, jx, 0, bz - 1) * bsize + sub2ind(bx, by, bz, jx, by - 1, 0)] = c;
					if (jx < bx - 1)
						exter_values[j * bnnz + sub2ind(bx, by, bz, jx + 1, 0, bz - 1) * bsize + sub2ind(bx, by, bz, jx, by - 1, 0)] = c;
				}
				if (ix > 0)
				{
					int j = --exter_rowptr[sub2ind(nx, ny, nz, ix, ny - 1, 0)];
					exter_colind[j] = t - 1;
					BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
					exter_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, 0, bz - 1) * bsize + sub2ind(bx, by, bz, 0, by - 1, 0)] = c;
				}
			}
		}
	}

	if (rz < Pz - 1)
	{
		int t = recvptr[nbind--];
		for (int ix = nx - 1; ix >= 0; --ix)
		{
			for (int iy = ny - 1; iy >= 0; --iy)
			{
				recvind[--t] = sub2ind(nx, ny, nz, ix, iy, 0);
				if (ix < nx - 1)
				{
					if (iy < ny - 1)
					{
						int j = --exter_rowptr[sub2ind(nx, ny, nz, ix, iy, nz - 1)];
						exter_colind[j] = t + ny + 1;
						BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
						exter_values[j * bnnz + sub2ind(bx, by, bz, 0, 0, 0) * bsize + sub2ind(bx, by, bz, bx - 1, by - 1, bz - 1)] = c;
					}
					int j = --exter_rowptr[sub2ind(nx, ny, nz, ix, iy, nz - 1)];
					exter_colind[j] = t + ny;
					BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
					for (int jy = 0; jy < by; ++jy)
					{
						if (jy > 0)
							exter_values[j * bnnz + sub2ind(bx, by, bz, 0, jy - 1, 0) * bsize + sub2ind(bx, by, bz, bx - 1, jy, bz - 1)] = c;
						exter_values[j * bnnz + sub2ind(bx, by, bz, 0, jy, 0) * bsize + sub2ind(bx, by, bz, bx - 1, jy, bz - 1)] = c;
						if (jy < by - 1)
							exter_values[j * bnnz + sub2ind(bx, by, bz, 0, jy + 1, 0) * bsize + sub2ind(bx, by, bz, bx - 1, jy, bz - 1)] = c;
					}
					if (iy > 0)
					{
						int j = --exter_rowptr[sub2ind(nx, ny, nz, ix, iy, nz - 1)];
						exter_colind[j] = t + ny - 1;
						BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
						exter_values[j * bnnz + sub2ind(bx, by, bz, 0, by - 1, 0) * bsize + sub2ind(bx, by, bz, bx - 1, 0, bz - 1)] = c;
					}
				}
				if (iy < ny - 1)
				{
					int j = --exter_rowptr[sub2ind(nx, ny, nz, ix, iy, nz - 1)];
					exter_colind[j] = t + 1;
					BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
					for (int jx = 0; jx < bx; ++jx)
					{
						if (jx > 0)
							exter_values[j * bnnz + sub2ind(bx, by, bz, jx - 1, 0, 0) * bsize + sub2ind(bx, by, bz, jx, by - 1, bz - 1)] = c;
							exter_values[j * bnnz + sub2ind(bx, by, bz, jx, 0, 0) * bsize + sub2ind(bx, by, bz, jx, by - 1, bz - 1)] = c;
						if (jx < bx - 1)
							exter_values[j * bnnz + sub2ind(bx, by, bz, jx + 1, 0, 0) * bsize + sub2ind(bx, by, bz, jx, by - 1, bz - 1)] = c;
					}
				}
				int j = --exter_rowptr[sub2ind(nx, ny, nz, ix, iy, nz - 1)];
				exter_colind[j] = t;
				BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
				for (int jx = 0; jx < bx; ++jx)
				{
					for (int jy = 0; jy < by; ++jy)
					{
						if (jx > 0)
						{
							if (jy > 0)
								exter_values[j * bnnz + sub2ind(bx, by, bz, jx - 1, jy - 1, 0) * bsize + sub2ind(bx, by, bz, jx, jy, bz - 1)] = c;
							exter_values[j * bnnz + sub2ind(bx, by, bz, jx - 1, jy, 0) * bsize + sub2ind(bx, by, bz, jx, jy, bz - 1)] = c;
							if (jy < by - 1)
								exter_values[j * bnnz + sub2ind(bx, by, bz, jx - 1, jy + 1, 0) * bsize + sub2ind(bx, by, bz, jx, jy, bz - 1)] = c;
						}
						if (jy > 0)
							exter_values[j * bnnz + sub2ind(bx, by, bz, jx, jy - 1, 0) * bsize + sub2ind(bx, by, bz, jx, jy, bz - 1)] = c;
						exter_values[j * bnnz + sub2ind(bx, by, bz, jx, jy, 0) * bsize + sub2ind(bx, by, bz, jx, jy, bz - 1)] = c;
						if (jy < by - 1)
							exter_values[j * bnnz + sub2ind(bx, by, bz, jx, jy + 1, 0) * bsize + sub2ind(bx, by, bz, jx, jy, bz - 1)] = c;
						if (jx < bx - 1)
						{
							if (jy > 0)
								exter_values[j * bnnz + sub2ind(bx, by, bz, jx + 1, jy - 1, 0) * bsize + sub2ind(bx, by, bz, jx, jy, bz - 1)] = c;
							exter_values[j * bnnz + sub2ind(bx, by, bz, jx + 1, jy, 0) * bsize + sub2ind(bx, by, bz, jx, jy, bz - 1)] = c;
							if (jy < by - 1)
								exter_values[j * bnnz + sub2ind(bx, by, bz, jx + 1, jy + 1, 0) * bsize + sub2ind(bx, by, bz, jx, jy, bz - 1)] = c;
						}
					}
				}
				if (iy > 0)
				{
					int j = --exter_rowptr[sub2ind(nx, ny, nz, ix, iy, nz - 1)];
					exter_colind[j] = t - 1;
					BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
					for (int jx = 0; jx < bx; ++jx)
					{
						if (jx > 0)
							exter_values[j * bnnz + sub2ind(bx, by, bz, jx - 1, by - 1, 0) * bsize + sub2ind(bx, by, bz, jx, 0, bz - 1)] = c;
							exter_values[j * bnnz + sub2ind(bx, by, bz, jx, by - 1, 0) * bsize + sub2ind(bx, by, bz, jx, 0, bz - 1)] = c;
						if (jx < bx - 1)
							exter_values[j * bnnz + sub2ind(bx, by, bz, jx + 1, by - 1, 0) * bsize + sub2ind(bx, by, bz, jx, 0, bz - 1)] = c;
					}
				}
				if (ix > 0)
				{
					if (iy < ny - 1)
					{
						int j = --exter_rowptr[sub2ind(nx, ny, nz, ix, iy, nz - 1)];
						exter_colind[j] = t - ny + 1;
						BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
						exter_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, 0, 0) * bsize + sub2ind(bx, by, bz, 0, by - 1, bz - 1)] = c;
					}
					int j = --exter_rowptr[sub2ind(nx, ny, nz, ix, iy, nz - 1)];
					exter_colind[j] = t - ny;
					BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
					for (int jy = 0; jy < by; ++jy)
					{
						if (jy > 0)
							exter_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, jy - 1, 0) * bsize + sub2ind(bx, by, bz, 0, jy, bz - 1)] = c;
						exter_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, jy, 0) * bsize + sub2ind(bx, by, bz, 0, jy, bz - 1)] = c;
						if (jy < by - 1)
							exter_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, jy + 1, 0) * bsize + sub2ind(bx, by, bz, 0, jy, bz - 1)] = c;
					}
					if (iy > 0)
					{
						int j = --exter_rowptr[sub2ind(nx, ny, nz, ix, iy, nz - 1)];
						exter_colind[j] = t - ny - 1;
						BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
						exter_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, by - 1, 0) * bsize + sub2ind(bx, by, bz, 0, 0, bz - 1)] = c;
					}
				}
			}
		}
	}

	if (rz > 0)
	{
		int t = recvptr[nbind--];
		for (int ix = nx - 1; ix >= 0; --ix)
		{
			for (int iy = ny - 1; iy >= 0; --iy)
			{
				recvind[--t] = sub2ind(nx, ny, nz, ix, iy, nz - 1);
				if (ix < nx - 1)
				{
					if (iy < ny - 1)
					{
						int j = --exter_rowptr[sub2ind(nx, ny, nz, ix, iy, 0)];
						exter_colind[j] = t + ny + 1;
						BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
						exter_values[j * bnnz + sub2ind(bx, by, bz, 0, 0, bz - 1) * bsize + sub2ind(bx, by, bz, bx - 1, by - 1, 0)] = c;
					}
					int j = --exter_rowptr[sub2ind(nx, ny, nz, ix, iy, 0)];
					exter_colind[j] = t + ny;
					BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
					for (int jy = 0; jy < by; ++jy)
					{
						if (jy > 0)
							exter_values[j * bnnz + sub2ind(bx, by, bz, 0, jy - 1, bz - 1) * bsize + sub2ind(bx, by, bz, bx - 1, jy, 0)] = c;
						exter_values[j * bnnz + sub2ind(bx, by, bz, 0, jy, bz - 1) * bsize + sub2ind(bx, by, bz, bx - 1, jy, 0)] = c;
						if (jy < by - 1)
							exter_values[j * bnnz + sub2ind(bx, by, bz, 0, jy + 1, bz - 1) * bsize + sub2ind(bx, by, bz, bx - 1, jy, 0)] = c;
					}
					if (iy > 0)
					{
						int j = --exter_rowptr[sub2ind(nx, ny, nz, ix, iy, 0)];
						exter_colind[j] = t + ny - 1;
						BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
						exter_values[j * bnnz + sub2ind(bx, by, bz, 0, by - 1, bz - 1) * bsize + sub2ind(bx, by, bz, bx - 1, 0, 0)] = c;
					}
				}
				if (iy < ny - 1)
				{
					int j = --exter_rowptr[sub2ind(nx, ny, nz, ix, iy, 0)];
					exter_colind[j] = t + 1;
					BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
					for (int jx = 0; jx < bx; ++jx)
					{
						if (jx > 0)
							exter_values[j * bnnz + sub2ind(bx, by, bz, jx - 1, 0, bz - 1) * bsize + sub2ind(bx, by, bz, jx, by - 1, 0)] = c;
							exter_values[j * bnnz + sub2ind(bx, by, bz, jx, 0, bz - 1) * bsize + sub2ind(bx, by, bz, jx, by - 1, 0)] = c;
						if (jx < bx - 1)
							exter_values[j * bnnz + sub2ind(bx, by, bz, jx + 1, 0, bz - 1) * bsize + sub2ind(bx, by, bz, jx, by - 1, 0)] = c;
					}
				}
				int j = --exter_rowptr[sub2ind(nx, ny, nz, ix, iy, 0)];
				exter_colind[j] = t;
				BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
				for (int jx = 0; jx < bx; ++jx)
				{
					for (int jy = 0; jy < by; ++jy)
					{
						if (jx > 0)
						{
							if (jy > 0)
								exter_values[j * bnnz + sub2ind(bx, by, bz, jx - 1, jy - 1, bz - 1) * bsize + sub2ind(bx, by, bz, jx, jy, 0)] = c;
							exter_values[j * bnnz + sub2ind(bx, by, bz, jx - 1, jy, bz - 1) * bsize + sub2ind(bx, by, bz, jx, jy, 0)] = c;
							if (jy < by - 1)
								exter_values[j * bnnz + sub2ind(bx, by, bz, jx - 1, jy + 1, bz - 1) * bsize + sub2ind(bx, by, bz, jx, jy, 0)] = c;
						}
						if (jy > 0)
							exter_values[j * bnnz + sub2ind(bx, by, bz, jx, jy - 1, bz - 1) * bsize + sub2ind(bx, by, bz, jx, jy, 0)] = c;
						exter_values[j * bnnz + sub2ind(bx, by, bz, jx, jy, bz - 1) * bsize + sub2ind(bx, by, bz, jx, jy, 0)] = c;
						if (jy < by - 1)
							exter_values[j * bnnz + sub2ind(bx, by, bz, jx, jy + 1, bz - 1) * bsize + sub2ind(bx, by, bz, jx, jy, 0)] = c;
						if (jx < bx - 1)
						{
							if (jy > 0)
								exter_values[j * bnnz + sub2ind(bx, by, bz, jx + 1, jy - 1, bz - 1) * bsize + sub2ind(bx, by, bz, jx, jy, 0)] = c;
							exter_values[j * bnnz + sub2ind(bx, by, bz, jx + 1, jy, bz - 1) * bsize + sub2ind(bx, by, bz, jx, jy, 0)] = c;
							if (jy < by - 1)
								exter_values[j * bnnz + sub2ind(bx, by, bz, jx + 1, jy + 1, bz - 1) * bsize + sub2ind(bx, by, bz, jx, jy, 0)] = c;
						}
					}
				}
				if (iy > 0)
				{
					int j = --exter_rowptr[sub2ind(nx, ny, nz, ix, iy, 0)];
					exter_colind[j] = t - 1;
					BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
					for (int jx = 0; jx < bx; ++jx)
					{
						if (jx > 0)
							exter_values[j * bnnz + sub2ind(bx, by, bz, jx - 1, by - 1, bz - 1) * bsize + sub2ind(bx, by, bz, jx, 0, 0)] = c;
							exter_values[j * bnnz + sub2ind(bx, by, bz, jx, by - 1, bz - 1) * bsize + sub2ind(bx, by, bz, jx, 0, 0)] = c;
						if (jx < bx - 1)
							exter_values[j * bnnz + sub2ind(bx, by, bz, jx + 1, by - 1, bz - 1) * bsize + sub2ind(bx, by, bz, jx, 0, 0)] = c;
					}
				}
				if (ix > 0)
				{
					if (iy < ny - 1)
					{
						int j = --exter_rowptr[sub2ind(nx, ny, nz, ix, iy, 0)];
						exter_colind[j] = t - ny + 1;
						BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
						exter_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, 0, bz - 1) * bsize + sub2ind(bx, by, bz, 0, by - 1, 0)] = c;
					}
					int j = --exter_rowptr[sub2ind(nx, ny, nz, ix, iy, 0)];
					exter_colind[j] = t - ny;
					BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
					for (int jy = 0; jy < by; ++jy)
					{
						if (jy > 0)
							exter_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, jy - 1, bz - 1) * bsize + sub2ind(bx, by, bz, 0, jy, 0)] = c;
						exter_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, jy, bz - 1) * bsize + sub2ind(bx, by, bz, 0, jy, 0)] = c;
						if (jy < by - 1)
							exter_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, jy + 1, bz - 1) * bsize + sub2ind(bx, by, bz, 0, jy, 0)] = c;
					}
					if (iy > 0)
					{
						int j = --exter_rowptr[sub2ind(nx, ny, nz, ix, iy, 0)];
						exter_colind[j] = t - ny - 1;
						BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
						exter_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, by - 1, bz - 1) * bsize + sub2ind(bx, by, bz, 0, 0, 0)] = c;
					}
				}
			}
		}
	}

	if (ry > 0)
	{
		if (rz < Pz - 1)
		{
			int t = recvptr[nbind--];
			for (int ix = nx - 1; ix >= 0; --ix)
			{
				recvind[--t] = sub2ind(nx, ny, nz, ix, ny - 1, 0);
				if (ix < nx - 1)
				{
					int j = --exter_rowptr[sub2ind(nx, ny, nz, ix, 0, nz - 1)];
					exter_colind[j] = t + 1;
					BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
					exter_values[j * bnnz + sub2ind(bx, by, bz, 0, by - 1, 0) * bsize + sub2ind(bx, by, bz, bx - 1, 0, bz - 1)] = c;
				}
				int j = --exter_rowptr[sub2ind(nx, ny, nz, ix, 0, nz - 1)];
				exter_colind[j] = t;
				BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
				for (int jx = 0; jx < bx; ++jx)
				{
					if (jx > 0)
						exter_values[j * bnnz + sub2ind(bx, by, bz, jx - 1, by - 1, 0) * bsize + sub2ind(bx, by, bz, jx, 0, bz - 1)] = c;
						exter_values[j * bnnz + sub2ind(bx, by, bz, jx, by - 1, 0) * bsize + sub2ind(bx, by, bz, jx, 0, bz - 1)] = c;
					if (jx < bx - 1)
						exter_values[j * bnnz + sub2ind(bx, by, bz, jx + 1, by - 1, 0) * bsize + sub2ind(bx, by, bz, jx, 0, bz - 1)] = c;
				}
				if (ix > 0)
				{
					int j = --exter_rowptr[sub2ind(nx, ny, nz, ix, 0, nz - 1)];
					exter_colind[j] = t - 1;
					BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
					exter_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, by - 1, 0) * bsize + sub2ind(bx, by, bz, 0, 0, bz - 1)] = c;
				}
			}
		}

		int t = recvptr[nbind--];
		for (int ix = nx - 1; ix >= 0; --ix)
		{
			for (int iz = nz - 1; iz >= 0; --iz)
			{
				recvind[--t] = sub2ind(nx, ny, nz, ix, ny - 1, iz);
				if (ix < nx - 1)
				{
					if (iz < nz - 1)
					{
						int j = --exter_rowptr[sub2ind(nx, ny, nz, ix, 0, iz)];
						exter_colind[j] = t + nz + 1;
						BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
						exter_values[j * bnnz + sub2ind(bx, by, bz, 0, by - 1, 0) * bsize + sub2ind(bx, by, bz, bx - 1, 0, bz - 1)] = c;
					}
					int j = --exter_rowptr[sub2ind(nx, ny, nz, ix, 0, iz)];
					exter_colind[j] = t + nz;
					BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
					for (int jz = 0; jz < bz; ++jz)
					{
						if (jz > 0)
							exter_values[j * bnnz + sub2ind(bx, by, bz, 0, by - 1, jz - 1) * bsize + sub2ind(bx, by, bz, bx - 1, 0, jz)] = c;
						exter_values[j * bnnz + sub2ind(bx, by, bz, 0, by - 1, jz) * bsize + sub2ind(bx, by, bz, bx - 1, 0, jz)] = c;
						if (jz < bz - 1)
							exter_values[j * bnnz + sub2ind(bx, by, bz, 0, by - 1, jz + 1) * bsize + sub2ind(bx, by, bz, bx - 1, 0, jz)] = c;
					}
					if (iz > 0)
					{
						int j = --exter_rowptr[sub2ind(nx, ny, nz, ix, 0, iz)];
						exter_colind[j] = t + nz - 1;
						BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
						exter_values[j * bnnz + sub2ind(bx, by, bz, 0, by - 1, bz - 1) * bsize + sub2ind(bx, by, bz, bx - 1, 0, 0)] = c;
					}
				}
				if (iz < nz - 1)
				{
					int j = --exter_rowptr[sub2ind(nx, ny, nz, ix, 0, iz)];
					exter_colind[j] = t + 1;
					BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
					for (int jx = 0; jx < bx; ++jx)
					{
						if (jx > 0)
							exter_values[j * bnnz + sub2ind(bx, by, bz, jx - 1, by - 1, 0) * bsize + sub2ind(bx, by, bz, jx, 0, bz - 1)] = c;
						exter_values[j * bnnz + sub2ind(bx, by, bz, jx, by - 1, 0) * bsize + sub2ind(bx, by, bz, jx, 0, bz - 1)] = c;
						if (jx < bx - 1)
							exter_values[j * bnnz + sub2ind(bx, by, bz, jx + 1, by - 1, 0) * bsize + sub2ind(bx, by, bz, jx, 0, bz - 1)] = c;
					}
				}
				int j = --exter_rowptr[sub2ind(nx, ny, nz, ix, 0, iz)];
				exter_colind[j] = t;
				BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
				for (int jx = 0; jx < bx; ++jx)
				{
					for (int jz = 0; jz < bz; ++jz)
					{
						if (jx > 0)
						{
							if (jz > 0)
								exter_values[j * bnnz + sub2ind(bx, by, bz, jx - 1, by - 1, jz - 1) * bsize + sub2ind(bx, by, bz, jx, 0, jz)] = c;
							exter_values[j * bnnz + sub2ind(bx, by, bz, jx - 1, by - 1, jz) * bsize + sub2ind(bx, by, bz, jx, 0, jz)] = c;
							if (jz < bz - 1)
								exter_values[j * bnnz + sub2ind(bx, by, bz, jx - 1, by - 1, jz + 1) * bsize + sub2ind(bx, by, bz, jx, 0, jz)] = c;
						}
						if (jz > 0)
							exter_values[j * bnnz + sub2ind(bx, by, bz, jx, by - 1, jz - 1) * bsize + sub2ind(bx, by, bz, jx, 0, jz)] = c;
						exter_values[j * bnnz + sub2ind(bx, by, bz, jx, by - 1, jz) * bsize + sub2ind(bx, by, bz, jx, 0, jz)] = c;
						if (jz < bz - 1)
							exter_values[j * bnnz + sub2ind(bx, by, bz, jx, by - 1, jz + 1) * bsize + sub2ind(bx, by, bz, jx, 0, jz)] = c;
						if (jx < bx - 1)
						{
							if (jz > 0)
								exter_values[j * bnnz + sub2ind(bx, by, bz, jx + 1, by - 1, jz - 1) * bsize + sub2ind(bx, by, bz, jx, 0, jz)] = c;
							exter_values[j * bnnz + sub2ind(bx, by, bz, jx + 1, by - 1, jz) * bsize + sub2ind(bx, by, bz, jx, 0, jz)] = c;
							if (jz < bz - 1)
								exter_values[j * bnnz + sub2ind(bx, by, bz, jx + 1, by - 1, jz + 1) * bsize + sub2ind(bx, by, bz, jx, 0, jz)] = c;
						}
					}
				}
				if (iz > 0)
				{
					int j = --exter_rowptr[sub2ind(nx, ny, nz, ix, 0, iz)];
					exter_colind[j] = t - 1;
					BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
					for (int jx = 0; jx < bx; ++jx)
					{
						if (jx > 0)
							exter_values[j * bnnz + sub2ind(bx, by, bz, jx - 1, by - 1, bz - 1) * bsize + sub2ind(bx, by, bz, jx, 0, 0)] = c;
						exter_values[j * bnnz + sub2ind(bx, by, bz, jx, by - 1, bz - 1) * bsize + sub2ind(bx, by, bz, jx, 0, 0)] = c;
						if (jx < bx - 1)
							exter_values[j * bnnz + sub2ind(bx, by, bz, jx + 1, by - 1, bz - 1) * bsize + sub2ind(bx, by, bz, jx, 0, 0)] = c;
					}
				}
				if (ix > 0)
				{
					if (iz < nz - 1)
					{
						int j = --exter_rowptr[sub2ind(nx, ny, nz, ix, 0, iz)];
						exter_colind[j] = t - nz + 1;
						BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
						exter_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, by - 1, 0) * bsize + sub2ind(bx, by, bz, 0, 0, bz - 1)] = c;
					}
					int j = --exter_rowptr[sub2ind(nx, ny, nz, ix, 0, iz)];
					exter_colind[j] = t - nz;
					BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
					for (int jz = 0; jz < bz; ++jz)
					{
						if (jz > 0)
							exter_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, by - 1, jz - 1) * bsize + sub2ind(bx, by, bz, 0, 0, jz)] = c;
						exter_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, by - 1, jz) * bsize + sub2ind(bx, by, bz, 0, 0, jz)] = c;
						if (jz < bz - 1)
							exter_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, by - 1, jz + 1) * bsize + sub2ind(bx, by, bz, 0, 0, jz)] = c;
					}
					if (iz > 0)
					{
						int j = --exter_rowptr[sub2ind(nx, ny, nz, ix, 0, iz)];
						exter_colind[j] = t - nz - 1;
						BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
						exter_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, by - 1, bz - 1) * bsize + sub2ind(bx, by, bz, 0, 0, 0)] = c;
					}
				}
			}
		}

		if (rz > 0)
		{
			int t = recvptr[nbind--];
			for (int ix = nx - 1; ix >= 0; --ix)
			{
				recvind[--t] = sub2ind(nx, ny, nz, ix, ny - 1, nz - 1);
				if (ix < nx - 1)
				{
					int j = --exter_rowptr[sub2ind(nx, ny, nz, ix, 0, 0)];
					exter_colind[j] = t + 1;
					BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
					exter_values[j * bnnz + sub2ind(bx, by, bz, 0, by - 1, bz - 1) * bsize + sub2ind(bx, by, bz, bx - 1, 0, 0)] = c;
				}
				int j = --exter_rowptr[sub2ind(nx, ny, nz, ix, 0, 0)];
				exter_colind[j] = t;
				BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
				for (int jx = 0; jx < bx; ++jx)
				{
					if (jx > 0)
						exter_values[j * bnnz + sub2ind(bx, by, bz, jx - 1, by - 1, bz - 1) * bsize + sub2ind(bx, by, bz, jx, 0, 0)] = c;
						exter_values[j * bnnz + sub2ind(bx, by, bz, jx, by - 1, bz - 1) * bsize + sub2ind(bx, by, bz, jx, 0, 0)] = c;
					if (jx < bx - 1)
						exter_values[j * bnnz + sub2ind(bx, by, bz, jx + 1, by - 1, bz - 1) * bsize + sub2ind(bx, by, bz, jx, 0, 0)] = c;
				}
				if (ix > 0)
				{
					int j = --exter_rowptr[sub2ind(nx, ny, nz, ix, 0, 0)];
					exter_colind[j] = t - 1;
					BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
					exter_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, by - 1, bz - 1) * bsize + sub2ind(bx, by, bz, 0, 0, 0)] = c;
				}
			}
		}
	}

	if (rx > 0)
	{
		if (ry < Py - 1)
		{
			if (rz < Pz - 1)
			{
				int t = recvptr[nbind--];
				recvind[--t] = sub2ind(nx, ny, nz, nx - 1, 0, 0);
				int j = --exter_rowptr[sub2ind(nx, ny, nz, 0, ny - 1, nz - 1)];
				exter_colind[j] = t;
				BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
				exter_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, 0, 0) * bsize + sub2ind(bx, by, bz, 0, by - 1, bz - 1)] = c;
			}

			int t = recvptr[nbind--];
			for (int iz = nz - 1; iz >= 0; --iz)
			{
				recvind[--t] = sub2ind(nx, ny, nz, nx - 1, 0, iz);
				if (iz < nz - 1)
				{
					int j = --exter_rowptr[sub2ind(nx, ny, nz, 0, ny - 1, iz)];
					exter_colind[j] = t + 1;
					BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
					exter_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, 0, 0) * bsize + sub2ind(bx, by, bz, 0, by - 1, bz - 1)] = c;
				}
				int j = --exter_rowptr[sub2ind(nx, ny, nz, 0, ny - 1, iz)];
				exter_colind[j] = t;
				BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
				for (int jz = 0; jz < bz; ++jz)
				{
					if (jz > 0)
						exter_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, 0, jz - 1) * bsize + sub2ind(bx, by, bz, 0, by - 1, jz)] = c;
					exter_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, 0, jz) * bsize + sub2ind(bx, by, bz, 0, by - 1, jz)] = c;
					if (jz < bz - 1)
						exter_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, 0, jz + 1) * bsize + sub2ind(bx, by, bz, 0, by - 1, jz)] = c;
				}
				if (iz > 0)
				{
					int j = --exter_rowptr[sub2ind(nx, ny, nz, 0, ny - 1, iz)];
					exter_colind[j] = t - 1;
					BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
					exter_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, 0, bz - 1) * bsize + sub2ind(bx, by, bz, 0, by - 1, 0)] = c;
				}
			}

			if (rz > 0)
			{
				int t = recvptr[nbind--];
				recvind[--t] = sub2ind(nx, ny, nz, nx - 1, 0, nz - 1);
				int j = --exter_rowptr[sub2ind(nx, ny, nz, 0, ny - 1, 0)];
				exter_colind[j] = t;
				BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
				exter_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, 0, bz - 1) * bsize + sub2ind(bx, by, bz, 0, by - 1, 0)] = c;
			}
		}

		if (rz < Pz - 1)
		{
			int t = recvptr[nbind--];
			for (int iy = ny - 1; iy >= 0; --iy)
			{
				recvind[--t] = sub2ind(nx, ny, nz, nx - 1, iy, 0);
				if (iy < ny - 1)
				{
					int j = --exter_rowptr[sub2ind(nx, ny, nz, 0, iy, nz - 1)];
					exter_colind[j] = t + 1;
					BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
					exter_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, 0, 0) * bsize + sub2ind(bx, by, bz, 0, by - 1, bz - 1)] = c;
				}
				int j = --exter_rowptr[sub2ind(nx, ny, nz, 0, iy, nz - 1)];
				exter_colind[j] = t;
				BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
				for (int jy = 0; jy < by; ++jy)
				{
					if (jy > 0)
						exter_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, jy - 1, 0) * bsize + sub2ind(bx, by, bz, 0, jy, bz - 1)] = c;
					exter_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, jy, 0) * bsize + sub2ind(bx, by, bz, 0, jy, bz - 1)] = c;
					if (jy < by - 1)
						exter_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, jy + 1, 0) * bsize + sub2ind(bx, by, bz, 0, jy, bz - 1)] = c;
				}
				if (iy > 0)
				{
					int j = --exter_rowptr[sub2ind(nx, ny, nz, 0, iy, nz - 1)];
					exter_colind[j] = t - 1;
					BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
					exter_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, by - 1, 0) * bsize + sub2ind(bx, by, bz, 0, 0, bz - 1)] = c;
				}
			}
		}

		int t = recvptr[nbind--];
		for (int iy = ny - 1; iy >= 0; --iy)
		{
			for (int iz = nz - 1; iz >= 0; --iz)
			{
				recvind[--t] = sub2ind(nx, ny, nz, nx - 1, iy, iz);
				if (iy < ny - 1)
				{
					if (iz < nz - 1)
					{
						int j = --exter_rowptr[sub2ind(nx, ny, nz, 0, iy, iz)];
						exter_colind[j] = t + nz + 1;
						BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
						exter_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, 0, 0) * bsize + sub2ind(bx, by, bz, 0, by - 1, bz - 1)] = c;
					}
					int j = --exter_rowptr[sub2ind(nx, ny, nz, 0, iy, iz)];
					exter_colind[j] = t + nz;
					BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
					for (int jz = 0; jz < bz; ++jz)
					{
						if (jz > 0)
							exter_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, 0, jz - 1) * bsize + sub2ind(bx, by, bz, 0, by - 1, jz)] = c;
						exter_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, 0, jz) * bsize + sub2ind(bx, by, bz, 0, by - 1, jz)] = c;
						if (jz < bz - 1)
							exter_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, 0, jz + 1) * bsize + sub2ind(bx, by, bz, 0, by - 1, jz)] = c;
					}
					if (iz > 0)
					{
						int j = --exter_rowptr[sub2ind(nx, ny, nz, 0, iy, iz)];
						exter_colind[j] = t + nz - 1;
						BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
						exter_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, 0, bz - 1) * bsize + sub2ind(bx, by, bz, 0, by - 1, 0)] = c;
					}
				}
				if (iz < nz - 1)
				{
					int j = --exter_rowptr[sub2ind(nx, ny, nz, 0, iy, iz)];
					exter_colind[j] = t + 1;
					BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
					for (int jy = 0; jy < by; ++jy)
					{
						if (jy > 0)
							exter_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, jy - 1, 0) * bsize + sub2ind(bx, by, bz, 0, jy, bz - 1)] = c;
						exter_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, jy, 0) * bsize + sub2ind(bx, by, bz, 0, jy, bz - 1)] = c;
						if (jy < by - 1)
							exter_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, jy + 1, 0) * bsize + sub2ind(bx, by, bz, 0, jy, bz - 1)] = c;
					}
				}
				int j = --exter_rowptr[sub2ind(nx, ny, nz, 0, iy, iz)];
				exter_colind[j] = t;
				BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
				for (int jy = 0; jy < by; ++jy)
				{
					for (int jz = 0; jz < bz; ++jz)
					{
						if (jy > 0)
						{
							if (jz > 0)
								exter_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, jy - 1, jz - 1) * bsize + sub2ind(bx, by, bz, 0, jy, jz)] = c;
							exter_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, jy - 1, jz) * bsize + sub2ind(bx, by, bz, 0, jy, jz)] = c;
							if (jz < bz - 1)
								exter_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, jy - 1, jz + 1) * bsize + sub2ind(bx, by, bz, 0, jy, jz)] = c;
						}
						if (jz > 0)
							exter_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, jy, jz - 1) * bsize + sub2ind(bx, by, bz, 0, jy, jz)] = c;
						exter_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, jy, jz) * bsize + sub2ind(bx, by, bz, 0, jy, jz)] = c;
						if (jz < bz - 1)
							exter_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, jy, jz + 1) * bsize + sub2ind(bx, by, bz, 0, jy, jz)] = c;
						if (jy < by - 1)
						{
							if (jz > 0)
								exter_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, jy + 1, jz - 1) * bsize + sub2ind(bx, by, bz, 0, jy, jz)] = c;
							exter_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, jy + 1, jz) * bsize + sub2ind(bx, by, bz, 0, jy, jz)] = c;
							if (jz < bz - 1)
								exter_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, jy + 1, jz + 1) * bsize + sub2ind(bx, by, bz, 0, jy, jz)] = c;
						}
					}
				}
				if (iz > 0)
				{
					int j = --exter_rowptr[sub2ind(nx, ny, nz, 0, iy, iz)];
					exter_colind[j] = t - 1;
					BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
					for (int jy = 0; jy < by; ++jy)
					{
						if (jy > 0)
							exter_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, jy - 1, bz - 1) * bsize + sub2ind(bx, by, bz, 0, jy, 0)] = c;
						exter_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, jy, bz - 1) * bsize + sub2ind(bx, by, bz, 0, jy, 0)] = c;
						if (jy < by - 1)
							exter_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, jy + 1, bz - 1) * bsize + sub2ind(bx, by, bz, 0, jy, 0)] = c;
					}
				}
				if (iy > 0)
				{
					if (iz < nz - 1)
					{
						int j = --exter_rowptr[sub2ind(nx, ny, nz, 0, iy, iz)];
						exter_colind[j] = t - nz + 1;
						BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
						exter_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, by - 1, 0) * bsize + sub2ind(bx, by, bz, 0, 0, bz - 1)] = c;
					}
					int j = --exter_rowptr[sub2ind(nx, ny, nz, 0, iy, iz)];
					exter_colind[j] = t - nz;
					BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
					for (int jz = 0; jz < bz; ++jz)
					{
						if (jz > 0)
							exter_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, by - 1, jz - 1) * bsize + sub2ind(bx, by, bz, 0, 0, jz)] = c;
						exter_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, by - 1, jz) * bsize + sub2ind(bx, by, bz, 0, 0, jz)] = c;
						if (jz < bz - 1)
							exter_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, by - 1, jz + 1) * bsize + sub2ind(bx, by, bz, 0, 0, jz)] = c;
					}
					if (iz > 0)
					{
						int j = --exter_rowptr[sub2ind(nx, ny, nz, 0, iy, iz)];
						exter_colind[j] = t - nz - 1;
						BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
						exter_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, by - 1, bz - 1) * bsize + sub2ind(bx, by, bz, 0, 0, 0)] = c;
					}
				}
			}
		}

		if (rz > 0)
		{
			int t = recvptr[nbind--];
			for (int iy = ny - 1; iy >= 0; --iy)
			{
				recvind[--t] = sub2ind(nx, ny, nz, nx - 1, iy, nz - 1);
				if (iy < ny - 1)
				{
					int j = --exter_rowptr[sub2ind(nx, ny, nz, 0, iy, 0)];
					exter_colind[j] = t + 1;
					BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
					exter_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, 0, bz - 1) * bsize + sub2ind(bx, by, bz, 0, by - 1, 0)] = c;
				}
				int j = --exter_rowptr[sub2ind(nx, ny, nz, 0, iy, 0)];
				exter_colind[j] = t;
				BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
				for (int jy = 0; jy < by; ++jy)
				{
					if (jy > 0)
						exter_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, jy - 1, bz - 1) * bsize + sub2ind(bx, by, bz, 0, jy, 0)] = c;
					exter_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, jy, bz - 1) * bsize + sub2ind(bx, by, bz, 0, jy, 0)] = c;
					if (jy < by - 1)
						exter_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, jy + 1, bz - 1) * bsize + sub2ind(bx, by, bz, 0, jy, 0)] = c;
				}
				if (iy > 0)
				{
					int j = --exter_rowptr[sub2ind(nx, ny, nz, 0, iy, 0)];
					exter_colind[j] = t - 1;
					BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
					exter_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, by - 1, bz - 1) * bsize + sub2ind(bx, by, bz, 0, 0, 0)] = c;
				}
			}
		}

		if (ry > 0)
		{
			if (rz < Pz - 1)
			{
				int t = recvptr[nbind--];
				recvind[--t] = sub2ind(nx, ny, nz, nx - 1, ny - 1, 0);
				int j = --exter_rowptr[sub2ind(nx, ny, nz, 0, 0, nz - 1)];
				exter_colind[j] = t;
				BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
				exter_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, by - 1, 0) * bsize + sub2ind(bx, by, bz, 0, 0, bz - 1)] = c;
			}

			int t = recvptr[nbind--];
			for (int iz = nz - 1; iz >= 0; --iz)
			{
				recvind[--t] = sub2ind(nx, ny, nz, nx - 1, ny - 1, iz);
				if (iz < nz - 1)
				{
					int j = --exter_rowptr[sub2ind(nx, ny, nz, 0, 0, iz)];
					exter_colind[j] = t + 1;
					BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
					exter_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, by - 1, 0) * bsize + sub2ind(bx, by, bz, 0, 0, bz - 1)] = c;
				}
				int j = --exter_rowptr[sub2ind(nx, ny, nz, 0, 0, iz)];
				exter_colind[j] = t;
				BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
				for (int jz = 0; jz < bz; ++jz)
				{
					if (jz > 0)
						exter_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, by - 1, jz - 1) * bsize + sub2ind(bx, by, bz, 0, 0, jz)] = c;
					exter_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, by - 1, jz) * bsize + sub2ind(bx, by, bz, 0, 0, jz)] = c;
					if (jz < bz - 1)
						exter_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, by - 1, jz + 1) * bsize + sub2ind(bx, by, bz, 0, 0, jz)] = c;
				}
				if (iz > 0)
				{
					int j = --exter_rowptr[sub2ind(nx, ny, nz, 0, 0, iz)];
					exter_colind[j] = t - 1;
					BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
					exter_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, by - 1, bz - 1) * bsize + sub2ind(bx, by, bz, 0, 0, 0)] = c;
				}
			}

			if (rz > 0)
			{
				int t = recvptr[nbind--];
				recvind[--t] = sub2ind(nx, ny, nz, nx - 1, ny - 1, nz - 1);
				int j = --exter_rowptr[sub2ind(nx, ny, nz, 0, 0, 0)];
				exter_colind[j] = t;
				BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);
				exter_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, by - 1, bz - 1) * bsize + sub2ind(bx, by, bz, 0, 0, 0)] = c;
			}
		}
	}

	A.Free();
	A.comm = comm;
	A.local.size[0] = size;
	A.local.size[1] = size;
	A.local.bsize = bsize;
	A.local.rowptr = local_rowptr;
	A.local.colind = local_colind;
	A.local.values = local_values;
	A.exter.size[0] = size;
	A.exter.size[1] = recvptr[nnb];
	A.exter.bsize = bsize;
	A.exter.rowptr = exter_rowptr;
	A.exter.colind = exter_colind;
	A.exter.values = exter_values;
	A.nnb = nnb;
	A.nbrank = nbrank;
	A.recvptr = recvptr;
	A.recvind = recvind;
}

}