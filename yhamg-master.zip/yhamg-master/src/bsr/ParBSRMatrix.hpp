/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef ParBSRMatrix_H
#define ParBSRMatrix_H

#include "BSRMatrix.hpp"
#include "ParOperator.hpp"
#include "ParCSRMatrix.hpp"

namespace YHAMG
{

struct ParBSRMatrix : public ParOperator
{
	BSRMatrix local;
	BSRMatrix exter;

	int nnb;
	int* nbrank;

	int* recvptr;
	int* recvind;

	int* sendptr;
	int* sendind;
	double* sendbuf;
	
	Vector recvx;

	ParBSRMatrix(MPI_Comm comm = MPI_COMM_SELF);
	ParBSRMatrix(MPI_Comm comm, int local_rows, int local_cols, int exter_cols, int bsize, 
	int* local_rowptr, int* local_colind, double* local_values, int local_ref, 
	int* exter_rowptr, int* exter_colind, double* exter_values, int exter_ref,
	int nnb, int* nbrank, int* recvptr, int* recvind);
	ParBSRMatrix(const BSRMatrix& A);
	ParBSRMatrix(const ParBSRMatrix& A);
	ParBSRMatrix(int bsize, const ParCSRMatrix& A);
	ParBSRMatrix(ParBSRMatrix&& A);
	~ParBSRMatrix();
	ParBSRMatrix& operator=(const ParBSRMatrix& A);
	ParBSRMatrix& operator=(ParBSRMatrix&& A);
	
	void Free();
	void Refer(const ParBSRMatrix& A);
	void ExchangeHalo(const ParVector& x) const;
	void SetupHalo();
	int InSize() const;
	int OutSize() const;
	void Apply(const ParVector& x, const ParVector& y) const;
};

void ParCSRToBSR(int bsize, const ParCSRMatrix& A, ParBSRMatrix& B);
void ParBSRDiag(const ParBSRMatrix& A, const ParVector& D);
void ParBSREliminZeros(const ParBSRMatrix& A);
void ParBSRScale(double alpha, const ParBSRMatrix& A);
void ParBSRScaleRows(const ParVector& x, const ParBSRMatrix& A);
void ParBSRScaleCols(const ParVector& x, const ParBSRMatrix& A);
void ParBSRMatAdd(const ParBSRMatrix& A, const ParBSRMatrix& B, ParBSRMatrix& C);
void ParBSRMatMul(const ParBSRMatrix& A, const ParBSRMatrix& B, ParBSRMatrix& C);
void ParBSRMatVec(double alpha, const ParBSRMatrix& A, const ParVector& x, double beta, const ParVector& y);
void ParBSRTrans(const ParBSRMatrix& A, ParBSRMatrix& B);

void ParCSRMultBSR(const ParCSRMatrix& A, const ParBSRMatrix& B, ParBSRMatrix& C);
void ParBSRMultCSR(const ParBSRMatrix& A, const ParCSRMatrix& B, ParBSRMatrix& C);
void ParCSRMatBlockVec(int bsize, double alpha, const ParCSRMatrix& A, const ParVector& x, double beta, const ParVector& y);

}

#endif