/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <map>
#include "BSRMutator.hpp"

namespace YHAMG
{

BSRMutator::BSRMutator(const BSRMatrix& _A)
	: A(_A.size[0], _A.size[1], _A.bsize, _A.rowptr, _A.colind, _A.values, 1),
	marks(new bool[_A.size[0]]),
	data(new std::map<int, double*>[_A.size[0]])
{
	int n = _A.size[0];
	for (int i = 0; i < n; ++i)
		marks[i] = 0;
}

BSRMutator::~BSRMutator()
{
	int n = A.size[0];
	for (int i = 0; i < n; ++i)
		for (std::map<int, double*>::iterator iter = ((std::map<int, double*>*)data)[i].begin(); iter != ((std::map<int, double*>*)data)[i].end(); ++iter)
			if (iter->second) delete[] iter->second;
	if (marks) delete[] marks;
	if (data) delete[] (std::map<int, double*>*)data;
}

double* BSRMutator::Find(int row, int col) const
{
	int bsize = A.bsize;
	int bnnz = bsize * bsize;

	if (!marks[row])
	{
		int* Ap = A.rowptr;
		int* Ai = A.colind;
		double* Av = A.values;
		for (int j = Ap[row]; j < Ap[row + 1]; ++j)
		{
			std::pair<std::map<int, double*>::iterator, bool> ret = ((std::map<int, double*>*)data)[row].insert(std::pair<int, double*>(Ai[j], (double*)0));
			if (!ret.first->second) ret.first->second = new double[bnnz];
			BSRBlockCopy(bsize, Av + j * bnnz, ret.first->second); 
		}
		marks[row] = 1;
	}

	std::map<int, double*>::iterator iter = ((std::map<int, double*>*)data)[row].find(col);
	return iter == ((std::map<int, double*>*)data)[row].end() ? 0 : iter->second;
}

double* BSRMutator::Insert(int row, int col) const
{
	int bsize = A.bsize;
	int bnnz = bsize * bsize;

	if (!marks[row])
	{
		int* Ap = A.rowptr;
		int* Ai = A.colind;
		double* Av = A.values;
		for (int j = Ap[row]; j < Ap[row + 1]; ++j)
		{
			std::pair<std::map<int, double*>::iterator, bool> ret = ((std::map<int, double*>*)data)[row].insert(std::pair<int, double*>(Ai[j], (double*)0));
			if (!ret.first->second) ret.first->second = new double[bnnz];
			BSRBlockCopy(bsize, Av + j * bnnz, ret.first->second); 
		}
		marks[row] = 1;
	}

	std::pair<std::map<int, double*>::iterator, bool> ret = ((std::map<int, double*>*)data)[row].insert(std::pair<int, double*>(col, (double*)0));
	if (!ret.first->second)
	{
		ret.first->second = new double[bnnz];
		BSRBlockFill(bsize, 0.0, ret.first->second); 
	}
	return ret.first->second;
}

void BSRMutator::Erase(int row, int col) const
{
	int bsize = A.bsize;
	int bnnz = bsize * bsize;

	if (!marks[row])
	{
		int* Ap = A.rowptr;
		int* Ai = A.colind;
		double* Av = A.values;
		for (int j = Ap[row]; j < Ap[row + 1]; ++j)
		{
			std::pair<std::map<int, double*>::iterator, bool> ret = ((std::map<int, double*>*)data)[row].insert(std::pair<int, double*>(Ai[j], (double*)0));
			if (!ret.first->second) ret.first->second = new double[bnnz];
			BSRBlockCopy(bsize, Av + j * bnnz, ret.first->second); 
		}
		marks[row] = 1;
	}

	std::map<int, double*>::iterator iter = ((std::map<int, double*>*)data)[row].find(col);
	if (iter != ((std::map<int, double*>*)data)[row].end())
	{
		if (iter->second) delete[] iter->second;
		((std::map<int, double*>*)data)[row].erase(iter);
	}
}

void BSRMutator::operator()(BSRMatrix& _A)
{
	int n = A.size[0];
	int m = A.size[1];
	int bsize = A.bsize;
	int bnnz = bsize * bsize;
	
	int* Ap = A.rowptr;
	int* Ai = A.colind;
	double* Av = A.values;

	int* _Ap = new int[n + 1];

	_Ap[0] = 0;
	for (int i = 0; i < n; ++i)
		_Ap[i + 1] = marks[i] ? ((std::map<int, double*>*)data)[i].size() : Ap[i + 1] - Ap[i];

	for (int i = 0; i < n; ++i)
		_Ap[i + 1] += _Ap[i];

	int* _Ai = new int[_Ap[n]];
	double* _Av = new double[_Ap[n] * bnnz];

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
	for (int i = 0; i < n; ++i)
	{
		if (marks[i])
		{
			std::map<int, double*>::iterator iter = ((std::map<int, double*>*)data)[i].begin();
			for (int j = _Ap[i]; j < _Ap[i + 1]; ++j, ++iter)
			{
				_Ai[j] = iter->first;
				if (iter->second)
					BSRBlockCopy(bsize, iter->second, _Av + j * bnnz);
				else
					BSRBlockFill(bsize, 0.0, _Av + j * bnnz);
			}
		}
		else
		{
			for (int j = _Ap[i], k = Ap[i]; j < _Ap[i + 1]; ++j, ++k)
			{
				_Ai[j] = Ai[k];
				BSRBlockCopy(bsize, Av + k * bnnz, _Av + j * bnnz);
			}
		}
	}

	_A.Free();
	_A.size[0] = n;
	_A.size[1] = m;
	_A.bsize = bsize;
	_A.rowptr = _Ap;
	_A.colind = _Ai;
	_A.values = _Av;

	A.rowptr = _Ap;
	A.colind = _Ai;
	A.values = _Av;
}

}