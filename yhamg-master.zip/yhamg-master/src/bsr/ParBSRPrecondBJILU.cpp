/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "sort.hpp"
#include "BSRUnroll.hpp"
#include "ParBSRPrecondBJILU.hpp"

#ifdef YHAMG_USE_OPENMP
#include <omp.h>
#endif

namespace YHAMG
{

ParBSRPrecondBJILU::ParBSRPrecondBJILU(int maxfil, double droptol)
	: nthd(0),
	D_LU(0),
	L(0),
	U(0),
	MaxFillins(maxfil),
	DropTolerance(droptol)
{
}

ParBSRPrecondBJILU::~ParBSRPrecondBJILU()
{
	if(D_LU) delete[] D_LU;
	if(L) delete[] L;
	if(U) delete[] U;
}

void ParBSRPrecondBJILU::Free()
{
	if(D_LU) delete[] D_LU;
	if(L) delete[] L;
	if(U) delete[] U;
	nthd = 0;
	D_LU = 0;
	L = 0;
	U = 0;
}

#define ABS(x) ((x) > 0 ? (x) : -(x))
#define MIN(a, b) ((a) < (b) ? (a) : (b))

static inline double BSRBlockNormInf(int bsize, const double* A)
{
	double result = 0.0;
	for (int i = 0; i < bsize; ++i)
	{
		double temp = 0.0;
		for (int j = 0; j < bsize; ++j)
			temp += ABS(A[i + j * bsize]);
		if (temp > result)
			result = temp;
	}
	return result;
}

static inline void swap(int& a, int& b)
{
	int temp = a;
	a = b;
	b = temp;
}

static inline void swap(double& a, double& b)
{
	double temp = a;
	a = b;
	b = temp;
}

static void SortAbsDesc(int* a, double* x, int left, int right)
{
	if (left >= right) return;

	swap(a[left], a[(left + right) / 2]);
	swap(x[left], x[(left + right) / 2]);

	int last = left;
	for (int i = left + 1; i <= right; ++i)
	{
		if (ABS(x[i]) > ABS(x[left]))
		{
			swap(a[++last], a[i]);
			swap(x[last], x[i]);
		}
	}

	swap(a[left], a[last]);
	swap(x[left], x[last]);

	SortAbsDesc(a, x, left, last - 1);
	SortAbsDesc(a, x, last + 1, right);
}

void ParBSRPrecondBJILU::Setup(const ParBSRMatrix& A, int REUSE)
{
	int n = A.local.size[0];
	int bsize = A.local.bsize;
	int bnnz = bsize * bsize;
	int* Ap = A.local.rowptr;
	int* Ai = A.local.colind;
	double* Av = A.local.values;

	int maxfil = MIN(MaxFillins, n);
	double droptol = DropTolerance;

	if (!REUSE)
	{
		Free();

		comm = A.comm;

		nthd = 1;
#ifdef USE_ONED_PARTITION
		nthd = omp_get_max_threads();
#endif

		D_LU = new double[n * bnnz];
		L = new BSRMatrix[nthd];
		U = new BSRMatrix[nthd];

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		for (int t = 0; t < nthd; ++t)
		{
			int begin = t * n / nthd;
			int end = (t + 1) * n / nthd;
			int m = end - begin;

			double* Dluv = D_LU + begin * bnnz;

			int* w = new int[m];
			double* g = new double[m];
			double* x = new double[m * bnnz];

			for (int i = 0; i < m; ++i)
				w[i] = -1;

			int lnz = 0, unz = 0;
			for (int i = begin; i < end; ++i)
			{
				for (int j = Ap[i]; j < Ap[i + 1]; ++j)
				{
					if (Ai[j] >= begin && Ai[j] < i)
						++lnz;
					else if (Ai[j] > i && Ai[j] < end)
						++unz;
				}
			}

			int* Lp = new int[m + 1];
			int* Li = new int[lnz + m * maxfil + m];
			double* Lv = new double[(lnz + m * maxfil + m) * bnnz];
			int* Up = new int[m + 1];
			int* Ui = new int[unz + m * maxfil + m];
			double* Uv = new double[(unz + m * maxfil + m) * bnnz];

			Lp[0] = 0;
			Up[0] = 0;

#define BSR_UNROLL_SEGMENT(N) \
	for (int i1 = begin, i = 0; i1 < end; ++i1, ++i) \
	{ \
		int r0 = Lp[i], r1 = r0; \
		int s0 = Up[i], s1 = s0; \
		w[i] = i; \
		BSRBlockFill_UNROLL(N, 0.0, x + i * N * N); \
		double anorm = 0.0; \
		for (int j = Ap[i1]; j < Ap[i1 + 1]; ++j) \
		{ \
			if (Ai[j] < begin || Ai[j] >= end) \
				continue; \
			int jcol = Ai[j] - begin; \
			double jnorm = BSRBlockNormInf(N, Av + j * N * N); \
			if (jnorm > anorm) \
				anorm = jnorm; \
			w[jcol] = i; \
			BSRBlockCopy_UNROLL(N, Av + j * N * N, x + jcol * N * N); \
			if (jcol < i) \
				Li[r1++] = jcol; \
			else if (jcol > i) \
				Ui[s1++] = jcol; \
		} \
		int r = r1, r2 = r1; \
		int s = s1, s2 = s1; \
		sort(Li, r0, r1 - 1); \
		int k1 = r0, k2 = r1; \
		while (k1 < r1 || k2 < r2) \
		{ \
			int k = (k2 == r2 || (k1 < r1 && Li[k1] < Li[k2]) ? k1 : k2)++; \
			int kcol = Li[k]; \
			if (k < r1 || (maxfil && BSRBlockNormInf(N, x + kcol * N * N) > droptol * anorm)) \
			{ \
				BSRBlockMatLUSolve_UNROLL(N, Dluv + kcol * N * N, x + kcol * N * N); \
				if (k >= r1) \
					Li[r++] = kcol; \
				for (int j = Up[kcol]; j < Up[kcol + 1]; ++j) \
				{ \
					int jcol = Ui[j]; \
					if (w[jcol] == i) \
						BSRBlockMatMulSub_UNROLL(N, x + kcol * N * N, Uv + j * N * N, x + jcol * N * N); \
					else \
					{ \
						w[jcol] = i; \
						BSRBlockFill_UNROLL(N, 0.0, x + jcol * N * N); \
						BSRBlockMatMulSub_UNROLL(N, x + kcol * N * N, Uv + j * N * N, x + jcol * N * N); \
						if (jcol < i) \
						{ \
							for (int p = r2++; ; --p) \
							{ \
								if (p == k2 || Li[p - 1] < jcol) \
								{ \
									Li[p] = jcol; \
									break; \
								} \
								Li[p] = Li[p - 1]; \
							} \
						} \
						else \
							Ui[s2++] = jcol; \
					} \
				} \
			} \
		} \
		if (r > r1 + maxfil) \
		{ \
			for (int j = r1; j < r; ++j) \
				g[j - r1] = BSRBlockNormInf(bsize, x + Li[j] * bnnz); \
			SortAbsDesc(Li + r1, g, 0, r - r1 - 1); \
			r = r1 + maxfil; \
		} \
		sort(Li, r0, r - 1); \
		for (int j = r0; j < r; ++j) \
			BSRBlockCopy_UNROLL(N, x + Li[j] * N * N, Lv + j * N * N); \
		for (int j = s1; j < s2; ++j) \
		{ \
			int jcol = Ui[j]; \
			double jnorm = BSRBlockNormInf(N, x + jcol * N * N); \
			if (jnorm > droptol * anorm) \
			{ \
				g[s - s1] = jnorm; \
				Ui[s++] = jcol; \
			} \
		} \
		if (s > s1 + maxfil) \
		{ \
			SortAbsDesc(Ui + s1, g, 0, s - s1 - 1); \
			s = s1 + maxfil; \
		} \
		sort(Ui, s0, s - 1); \
		for (int j = s0; j < s; ++j) \
			BSRBlockCopy_UNROLL(N, x + Ui[j] * N * N, Uv + j * N * N); \
		BSRBlockCopy_UNROLL(N, x + i * N * N, Dluv + i * N * N); \
		BSRBlockLUFactorize_UNROLL(N, Dluv + i * N * N); \
		Lp[i + 1] = r; \
		Up[i + 1] = s; \
	}

#ifdef BSR_UNROLL_1
			if (bsize == 1) { BSR_UNROLL_SEGMENT(1) } else
#endif
#ifdef BSR_UNROLL_2
			if (bsize == 2) { BSR_UNROLL_SEGMENT(2) } else
#endif
#ifdef BSR_UNROLL_3
			if (bsize == 3) { BSR_UNROLL_SEGMENT(3) } else
#endif
#ifdef BSR_UNROLL_4
			if (bsize == 4) { BSR_UNROLL_SEGMENT(4) } else
#endif
#ifdef BSR_UNROLL_5
			if (bsize == 5) { BSR_UNROLL_SEGMENT(5) } else
#endif
#ifdef BSR_UNROLL_6
			if (bsize == 6) { BSR_UNROLL_SEGMENT(6) } else
#endif
#ifdef BSR_UNROLL_7
			if (bsize == 7) { BSR_UNROLL_SEGMENT(7) } else
#endif
#ifdef BSR_UNROLL_8
			if (bsize == 8) { BSR_UNROLL_SEGMENT(8) } else
#endif
#undef BSR_UNROLL_SEGMENT
			{
				for (int i1 = begin, i = 0; i1 < end; ++i1, ++i)
				{
					int r0 = Lp[i], r1 = r0;
					int s0 = Up[i], s1 = s0;

					w[i] = i;
					BSRBlockFill(bsize, 0.0, x + i * bnnz);

					double anorm = 0.0;

					for (int j = Ap[i1]; j < Ap[i1 + 1]; ++j)
					{
						if (Ai[j] < begin || Ai[j] >= end)
							continue;

						int jcol = Ai[j] - begin;

						double jnorm = BSRBlockNormInf(bsize, Av + j * bnnz);
						if (jnorm > anorm)
							anorm = jnorm;

						w[jcol] = i;
						BSRBlockCopy(bsize, Av + j * bnnz, x + jcol * bnnz);

						if (jcol < i)
							Li[r1++] = jcol;
						else if (jcol > i)
							Ui[s1++] = jcol;
					}

					int r = r1, r2 = r1;
					int s = s1, s2 = s1;

					sort(Li, r0, r1 - 1);

					int k1 = r0, k2 = r1;
					while (k1 < r1 || k2 < r2)
					{
						int k = (k2 == r2 || (k1 < r1 && Li[k1] < Li[k2]) ? k1 : k2)++;

						int kcol = Li[k];

						if (k < r1 || BSRBlockNormInf(bsize, x + kcol * bnnz) > droptol * anorm)
						{
							BSRBlockMatLUSolve(bsize, Dluv + kcol * bnnz, x + kcol * bnnz);

							if (k >= r1)
								Li[r++] = kcol;

							for (int j = Up[kcol]; j < Up[kcol + 1]; ++j)
							{
								int jcol = Ui[j];
								if (w[jcol] == i)
									BSRBlockMatMulSub(bsize, x + kcol * bnnz, Uv + j * bnnz, x + jcol * bnnz);
								else
								{
									w[jcol] = i;
									BSRBlockFill(bsize, 0.0, x + jcol * bnnz);
									BSRBlockMatMulSub(bsize, x + kcol * bnnz, Uv + j * bnnz, x + jcol * bnnz);
									if (jcol < i)
									{
										for (int p = r2++; ; --p)
										{
											if (p == k2 || Li[p - 1] < jcol)
											{
												Li[p] = jcol;
												break;
											}
											Li[p] = Li[p - 1];
										}
									}
									else
										Ui[s2++] = jcol;
								}
							}
						}
					}

					if (r > r1 + maxfil)
					{
						for (int j = r1; j < r; ++j)
							g[j - r1] = BSRBlockNormInf(bsize, x + Li[j] * bnnz);
						SortAbsDesc(Li + r1, g, 0, r - r1 - 1);
						r = r1 + maxfil;
					}
					sort(Li, r0, r - 1);
					for (int j = r0; j < r; ++j)
						BSRBlockCopy(bsize, x + Li[j] * bnnz, Lv + j * bnnz);

					for (int j = s1; j < s2; ++j)
					{
						int jcol = Ui[j];
						double jnorm = BSRBlockNormInf(bsize, x + jcol * bnnz);
						if (jnorm > droptol * anorm)
						{
							g[s - s1] = jnorm;
							Ui[s++] = jcol;
						}
					}

					if (s > s1 + maxfil)
					{
						SortAbsDesc(Ui + s1, g, 0, s - s1 - 1);
						s = s1 + maxfil;
					}

					sort(Ui, s0, s - 1);
					for (int j = s0; j < s; ++j)
						BSRBlockCopy(bsize, x + Ui[j] * bnnz, Uv + j * bnnz);

					BSRBlockCopy(bsize, x + i * bnnz, Dluv + i * bnnz);
					BSRBlockLUFactorize(bsize, Dluv + i * bnnz);

					Lp[i + 1] = r;
					Up[i + 1] = s;
				}
			}

			L[t].size[0] = m;
			L[t].size[1] = m;
			L[t].bsize = bsize;
			L[t].rowptr = Lp;
			L[t].colind = Li;
			L[t].values = Lv;
			U[t].size[0] = m;
			U[t].size[1] = m;
			U[t].bsize = bsize;
			U[t].rowptr = Up;
			U[t].colind = Ui;
			U[t].values = Uv;

			delete[] w;
			delete[] g;
			delete[] x;
		}
	}
	else
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		for (int t = 0; t < nthd; ++t)
		{
			int begin = t * n / nthd;
			int end = (t + 1) * n / nthd;
			int m = end - begin;

			double* Dluv = D_LU + begin * bnnz;
			int* Lp = L[t].rowptr;
			int* Li = L[t].colind;
			double* Lv = L[t].values;
			int* Up = U[t].rowptr;
			int* Ui = U[t].colind;
			double* Uv = U[t].values;

			int* w = new int[m];
			double* x = new double[m * bnnz];

			for (int i = 0; i < m; ++i)
				w[i] = -1;

#define BSR_UNROLL_SEGMENT(N) \
	for (int i1 = begin, i = 0; i1 < end; ++i1, ++i) \
	{ \
		w[i] = i; \
		BSRBlockFill_UNROLL(N, 0.0, x + i * N * N); \
		for (int j = Lp[i]; j < Lp[i + 1]; ++j) \
		{ \
			w[Li[j]] = i; \
			BSRBlockFill_UNROLL(N, 0.0, x + Li[j] * N * N); \
		} \
		for (int j = Up[i]; j < Up[i + 1]; ++j) \
		{ \
			w[Ui[j]] = i; \
			BSRBlockFill_UNROLL(N, 0.0, x + Ui[j] * N * N); \
		} \
		for (int j = Ap[i1]; j < Ap[i1 + 1]; ++j) \
			if (Ai[j] >= begin && Ai[j] < end) \
				BSRBlockCopy_UNROLL(N, Av + j * N * N, x + (Ai[j] - begin) * N * N); \
		for (int k = Lp[i]; k < Lp[i + 1]; ++k) \
		{ \
			int kcol = Li[k]; \
			double kval = x[kcol] * D_LU[kcol]; \
			BSRBlockCopy_UNROLL(N, x + kcol * N * N, Lv + k * N * N); \
			BSRBlockMatLUSolve_UNROLL(N, Dluv + kcol * N * N, Lv + k * N * N); \
			for (int j = Up[kcol]; j < Up[kcol + 1]; ++j) \
			{ \
				int jcol = Ui[j]; \
				if (w[jcol] == i) \
					BSRBlockMatMulSub_UNROLL(N, Lv + k * N * N, Uv + j * N * N, x + jcol * N * N); \
			} \
		} \
		BSRBlockCopy_UNROLL(N, x + i * N * N, Dluv + i * N * N); \
		BSRBlockLUFactorize_UNROLL(N, Dluv + i * N * N); \
		for (int j = Up[i]; j < Up[i + 1]; ++j) \
			BSRBlockCopy_UNROLL(N, x + Ui[j] * N * N, Uv + j * N * N); \
	}

#ifdef BSR_UNROLL_1
			if (bsize == 1) { BSR_UNROLL_SEGMENT(1) } else
#endif
#ifdef BSR_UNROLL_2
			if (bsize == 2) { BSR_UNROLL_SEGMENT(2) } else
#endif
#ifdef BSR_UNROLL_3
			if (bsize == 3) { BSR_UNROLL_SEGMENT(3) } else
#endif
#ifdef BSR_UNROLL_4
			if (bsize == 4) { BSR_UNROLL_SEGMENT(4) } else
#endif
#ifdef BSR_UNROLL_5
			if (bsize == 5) { BSR_UNROLL_SEGMENT(5) } else
#endif
#ifdef BSR_UNROLL_6
			if (bsize == 6) { BSR_UNROLL_SEGMENT(6) } else
#endif
#ifdef BSR_UNROLL_7
			if (bsize == 7) { BSR_UNROLL_SEGMENT(7) } else
#endif
#ifdef BSR_UNROLL_8
			if (bsize == 8) { BSR_UNROLL_SEGMENT(8) } else
#endif
#undef BSR_UNROLL_SEGMENT
			{
				for (int i1 = begin, i = 0; i1 < end; ++i1, ++i)
				{
					w[i] = i;
					BSRBlockFill(bsize, 0.0, x + i * bnnz);

					for (int j = Lp[i]; j < Lp[i + 1]; ++j)
					{
						w[Li[j]] = i;
						BSRBlockFill(bsize, 0.0, x + Li[j] * bnnz);
					}

					for (int j = Up[i]; j < Up[i + 1]; ++j)
					{
						w[Ui[j]] = i;
						BSRBlockFill(bsize, 0.0, x + Ui[j] * bnnz);
					}

					for (int j = Ap[i1]; j < Ap[i1 + 1]; ++j)
						if (Ai[j] >= begin && Ai[j] < end)
							BSRBlockCopy(bsize, Av + j * bnnz, x + (Ai[j] - begin) * bnnz);

					for (int k = Lp[i]; k < Lp[i + 1]; ++k)
					{
						int kcol = Li[k];
						double kval = x[kcol] * D_LU[kcol];
						BSRBlockCopy(bsize, x + kcol * bnnz, Lv + k * bnnz);
						BSRBlockMatLUSolve(bsize, Dluv + kcol * bnnz, Lv + k * bnnz);

						for (int j = Up[kcol]; j < Up[kcol + 1]; ++j)
						{
							int jcol = Ui[j];
							if (w[jcol] == i)
								BSRBlockMatMulSub(bsize, Lv + k * bnnz, Uv + j * bnnz, x + jcol * bnnz);
						}
					}

					BSRBlockCopy(bsize, x + i * bnnz, Dluv + i * bnnz);
					BSRBlockLUFactorize(bsize, Dluv + i * bnnz);
					for (int j = Up[i]; j < Up[i + 1]; ++j)
						BSRBlockCopy(bsize, x + Ui[j] * bnnz, Uv + j * bnnz);
				}
			}

			delete[] w;
			delete[] x;
		}
	}
}

int ParBSRPrecondBJILU::InSize() const
{
	int result = 0;
	for (int t = 0; t < nthd; ++t)
		result += L[t].size[0] * L[t].bsize;
	return result;
}

int ParBSRPrecondBJILU::OutSize() const
{
	int result = 0;
	for (int t = 0; t < nthd; ++t)
		result += L[t].size[0] * L[t].bsize;
	return result;
}

void ParBSRPrecondBJILU::Apply(const ParVector& b, const ParVector& x) const
{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
	for (int t = 0; t < nthd; ++t)
	{
		int bsize = L[t].bsize;
		int bnnz = bsize * bsize;

		int begin = 0;
		for (int s = 0; s < t; ++s)
			begin += L[s].size[0];
		int m = L[t].size[0];
		int end = begin + m;

		double* Dluv = D_LU + begin * bnnz;
		int* Lp = L[t].rowptr;
		int* Li = L[t].colind;
		double* Lv = L[t].values;
		int* Up = U[t].rowptr;
		int* Ui = U[t].colind;
		double* Uv = U[t].values;
		double* bv = b.local.values + begin * bsize;
		double* xv = x.local.values + begin * bsize;

#define BSR_UNROLL_SEGMENT(N) \
	for (int i = 0; i < m; ++i) \
	{ \
		VecBlockCopy_UNROLL(N, bv + i * N, xv + i * N); \
		for (int j = Lp[i]; j < Lp[i + 1]; ++j) \
			BSRBlockMatVecSub_UNROLL(N, Lv + j * N * N, xv + Li[j] * N, xv + i * N); \
	} \
	for (int i = m - 1; i >= 0; --i) \
	{ \
		for (int j = Up[i + 1] - 1; j >= Up[i]; --j) \
			BSRBlockMatVecSub_UNROLL(N, Uv + j * N * N, xv + Ui[j] * N, xv + i * N); \
		BSRBlockLUVecSolve_UNROLL(N, Dluv + i * N * N, xv + i * N); \
	}

#ifdef BSR_UNROLL_1
		if (bsize == 1) { BSR_UNROLL_SEGMENT(1) } else
#endif
#ifdef BSR_UNROLL_2
		if (bsize == 2) { BSR_UNROLL_SEGMENT(2) } else
#endif
#ifdef BSR_UNROLL_3
		if (bsize == 3) { BSR_UNROLL_SEGMENT(3) } else
#endif
#ifdef BSR_UNROLL_4
		if (bsize == 4) { BSR_UNROLL_SEGMENT(4) } else
#endif
#ifdef BSR_UNROLL_5
		if (bsize == 5) { BSR_UNROLL_SEGMENT(5) } else
#endif
#ifdef BSR_UNROLL_6
		if (bsize == 6) { BSR_UNROLL_SEGMENT(6) } else
#endif
#ifdef BSR_UNROLL_7
		if (bsize == 7) { BSR_UNROLL_SEGMENT(7) } else
#endif
#ifdef BSR_UNROLL_8
		if (bsize == 8) { BSR_UNROLL_SEGMENT(8) } else
#endif
#undef BSR_UNROLL_SEGMENT
		{
			for (int i = 0; i < m; ++i)
			{
				VecBlockCopy(bsize, bv + i * bsize, xv + i * bsize);
				for (int j = Lp[i]; j < Lp[i + 1]; ++j)
					BSRBlockMatVecSub(bsize, Lv + j * bnnz, xv + Li[j] * bsize, xv + i * bsize);
			}

			for (int i = m - 1; i >= 0; --i)
			{
				for (int j = Up[i + 1] - 1; j >= Up[i]; --j)
					BSRBlockMatVecSub(bsize, Uv + j * bnnz, xv + Ui[j] * bsize, xv + i * bsize);
				BSRBlockLUVecSolve(bsize, Dluv + i * bnnz, xv + i * bsize);
			}
		}
	}
}

}