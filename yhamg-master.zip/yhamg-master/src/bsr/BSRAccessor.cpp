/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "BSRAccessor.hpp"

namespace YHAMG
{

BSRAccessor::BSRAccessor(const BSRMatrix& _A)
	: A(_A.size[0], _A.size[1], _A.bsize, _A.rowptr, _A.colind, _A.values, 1)
{
}

double* BSRAccessor::Find(int row, int col) const
{
	int bsize = A.bsize;
	int bnnz = bsize * bsize;
	int* Ap = A.rowptr;
	int* Ai = A.colind;
	double* Av = A.values;

	for (int j = Ap[row]; j < Ap[row + 1]; ++j)
		if (Ai[j] == col) return Av + j * bnnz;

	return 0;
}

}