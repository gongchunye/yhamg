/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef ParBSRGeneratorIJ_H
#define ParBSRGeneratorIJ_H

#include "global.hpp"
#include "ParBSRGenerator.hpp"

namespace YHAMG
{

class ParBSRGeneratorIJ : public ParBSRGenerator
{
public:
	int size[2];
	int bsize;
	const int* rowptr;
	const global* colind;
	const double* values;
	int pattern_symmetry;

	ParBSRGeneratorIJ(MPI_Comm comm = MPI_COMM_SELF);
	ParBSRGeneratorIJ(MPI_Comm comm, int n, int m, int bsize, const int* rowptr, const global* colind, const double* values, int pattern_symmetry = 0);
	void operator()(ParBSRMatrix& A) const;
};

}

#endif