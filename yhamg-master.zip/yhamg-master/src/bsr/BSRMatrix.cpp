/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "blas.hpp"
#include "BSRUnroll.hpp"
#include "BSRMatrix.hpp"

#ifdef YHAMG_USE_OPENMP
#include <omp.h>
#endif

namespace YHAMG
{

BSRMatrix::BSRMatrix()
	: ref(0),
	size{0, 0},
	bsize(0),
	rowptr(0),
	colind(0),
	values(0)
{
}

BSRMatrix::BSRMatrix(int n, int m, int b, int* _rowptr, int* _colind, double* _values, int _ref)
	: ref(_ref),
	size{n, m},
	bsize(b),
	rowptr(_rowptr),
	colind(_colind),
	values(_values)
{
}

BSRMatrix::BSRMatrix(const BSRMatrix& A)
	: ref(0),
	size{A.size[0], A.size[1]},
	bsize(A.bsize),
	rowptr(new int[A.size[0] + 1]),
	colind(new int[A.rowptr[A.size[0]]]),
	values(new double[A.rowptr[A.size[0]] * A.bsize * A.bsize])
{
	int* Ap = A.rowptr;
	int* Ai = A.colind;
	double* Av = A.values;
	int bnnz = bsize * bsize;

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
	for (int i = 0; i <= size[0]; ++i)
		rowptr[i] = Ap[i];

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
	for (int j = 0; j < Ap[size[0]]; ++j)
	{
		colind[j] = Ai[j];
		BSRBlockCopy(bsize, Av + j * bnnz, values + j * bnnz);
	}
}

BSRMatrix::BSRMatrix(int bsize, const CSRMatrix& A)
	: BSRMatrix()
{
	CSRToBSR(bsize, A, *this);
}

BSRMatrix::BSRMatrix(BSRMatrix&& A)
	: ref(A.ref),
	size{A.size[0], A.size[1]},
	bsize(A.bsize),
	rowptr(A.rowptr),
	colind(A.colind),
	values(A.values)
{
	A.ref = 1;
}

BSRMatrix::~BSRMatrix()
{
	if (!ref)
	{
		if (rowptr) delete[] rowptr;
		if (colind) delete[] colind;
		if (values) delete[] values;
	}
}

BSRMatrix& BSRMatrix::operator=(const BSRMatrix& A)
{
	Free();

	int* Ap = A.rowptr;
	int* Ai = A.colind;
	double* Av = A.values;

	size[0] = A.size[0];
	size[1] = A.size[1];
	bsize = A.bsize;

	int bnnz = bsize * bsize;
	rowptr = new int[size[0] + 1];
	colind = new int[Ap[size[0]]];
	values = new double[Ap[size[0]] * bnnz];

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
	for (int i = 0; i <= size[0]; ++i)
		rowptr[i] = Ap[i];

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
	for (int j = 0; j < Ap[size[0]]; ++j)
	{
		colind[j] = Ai[j];
		BSRBlockCopy(bsize, Av + j * bnnz, values + j * bnnz);
	}

	return *this;
}

BSRMatrix& BSRMatrix::operator=(BSRMatrix&& A)
{
	Free();

	ref = A.ref;
	size[0] = A.size[0];
	size[1] = A.size[1];
	bsize = A.bsize;
	rowptr = A.rowptr;
	colind = A.colind;
	values = A.values;

	A.ref = 1;

	return *this;
}

void BSRMatrix::Free()
{
	if (!ref)
	{
		if (rowptr) delete[] rowptr;
		if (colind) delete[] colind;
		if (values) delete[] values;
	}
	size[0] = 0;
	size[1] = 0;
	bsize = 0;
	rowptr = 0;
	colind = 0;
	values = 0;
	ref = 0;
}

void BSRMatrix::Refer(const BSRMatrix& A)
{
	if (!ref)
	{
		if (rowptr) delete[] rowptr;
		if (colind) delete[] colind;
		if (values) delete[] values;
	}
	size[0] = A.size[0];
	size[1] = A.size[1];
	bsize = A.bsize;
	rowptr = A.rowptr;
	colind = A.colind;
	values = A.values;
	ref = 1;
}

int BSRMatrix::InSize() const
{
	return size[1] * bsize;
}

int BSRMatrix::OutSize() const
{
	return size[0] * bsize;
}

void BSRMatrix::Apply(const Vector& x, const Vector& y) const
{
	BSRMatVec(1.0, *this, x, 0.0, y);
}

void CSRToBSR(int bsize, const CSRMatrix& A, BSRMatrix& B)
{
	int n = A.size[0];
	int m = A.size[1];
	int* Ap = A.rowptr;
	int* Ai = A.colind;
	double* Av = A.values;
	int bnnz = bsize * bsize;

	int nb = (n - 1) / bsize + 1;
	int mb = (m - 1) / bsize + 1;

	int* Bp = new int[nb + 1];

	Bp[0] = 0;
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel
#endif
	{
		int* w = new int[mb];
		for (int i = 0; i < mb; ++i)
			w[i] = -1;
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
		for (int i = 0; i < nb; ++i)
		{
			int cnt = 0;
			for (int ii = 0; ii < bsize; ++ii)
			{
				int ia = i * bsize + ii;
				if (ia >= n) break;
				for (int j = Ap[ia]; j < Ap[ia + 1]; ++j)
				{
					int jcolb = Ai[j] / bsize;
					if (w[jcolb] != i)
					{
						w[jcolb] = i;
						++cnt;
					}
				}
			}
			Bp[i + 1] = cnt;
		}
		delete[] w;
	}
	
	for (int i = 0; i < nb; ++i)
		Bp[i + 1] += Bp[i];

	int* Bi = new int[Bp[nb]];
	double* Bv = new double[Bp[nb] * bnnz];

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel
#endif
	{
		int* w = new int[mb];
		for (int i = 0; i < mb; ++i)
			w[i] = -1;
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
		for (int i = 0; i < nb; ++i)
		{
			for (int ii = 0, r = Bp[i], r0 = Bp[i]; ii < bsize; ++ii)
			{
				int ia = i * bsize + ii;
				if (ia >= n) break;
				for (int j = Ap[ia]; j < Ap[ia + 1]; ++j)
				{
					int jcolb = Ai[j] / bsize;
					int jj = Ai[j] - jcolb * bsize;
					double jval = Av[j];
					if (w[jcolb] < r0)
					{
						w[jcolb] = r;
						Bi[r] = jcolb;
						BSRBlockFill(bsize, 0.0, Bv + r * bnnz);
						++r;
					}
					Bv[w[jcolb] * bnnz + ii + jj * bsize] = jval;
				}
			}
		}
		delete[] w;
	}

	B.Free();
	B.size[0] = nb;
	B.size[1] = mb;
	B.bsize = bsize;
	B.rowptr = Bp;
	B.colind = Bi;
	B.values = Bv;
}

void BSRDiag(const BSRMatrix& A, const Vector& D)
{
	int n = A.size[0];
	int bsize = A.bsize;
	int bnnz = bsize * bsize;

	int* Ap = A.rowptr;
	int* Ai = A.colind;
	double* Av = A.values;
	double* Dv = D.values;

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
	for (int i = 0; i < n; ++i)
	{
		for (int j = Ap[i]; ; ++j)
		{
			if (j == Ap[i + 1])
			{
				VecBlockFill(bsize, 0.0, Dv + i * bsize);
				break;
			}
			if (Ai[j] == i)
			{
				BSRBlockDiagonal(bsize, Av + j * bnnz, Dv + i * bsize);
				break;
			}
		}
	}
}

void BSREliminZeros(const BSRMatrix& A)
{
	int n = A.size[0];
	int bsize = A.bsize;
	int bnnz = bsize * bsize;
	int* Ap = A.rowptr;
	int* Ai = A.colind;
	double* Av = A.values;

	for (int i = 0, j = 0, k = 0; i < n; Ap[++i] = k)
	{
		for ( ; j < Ap[i + 1]; ++j)
		{
			if (BSRBlockAllZero(bsize, Av + j * bnnz)) continue;
			if (k < j)
			{
				Ai[k] = Ai[j];
				BSRBlockCopy(bsize, Av + j * bnnz, Av + k * bnnz);
			}
			++k;
		}
	}
}

void BSRScale(double alpha, const BSRMatrix& A)
{
	int n = A.size[0];
	int bsize = A.bsize;
	int bnnz = bsize * bsize;

	int* Ap = A.rowptr;
	double* Av = A.values;

	blas_dscal(Ap[n] * bnnz, alpha, Av);
}

void BSRScaleRows(const Vector& x, const BSRMatrix& A)
{
	int n = A.size[0];
	int bsize = A.bsize;
	int bnnz = bsize * bsize;

	int* Ap = A.rowptr;
	double* Av = A.values;
	double* xv = x.values;

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
	for (int i = 0; i < n; ++i)
		for (int j = Ap[i]; j < Ap[i + 1]; ++j)
			BSRBlockScaleRows(bsize, xv + i * bsize, Av + j * bnnz);
}

void BSRScaleCols(const Vector& x, const BSRMatrix& A)
{
	int n = A.size[0];
	int bsize = A.bsize;
	int bnnz = bsize * bsize;

	int* Ap = A.rowptr;
	int* Ai = A.colind;
	double* Av = A.values;
	double* xv = x.values;

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
	for (int i = 0; i < n; ++i)
		for (int j = Ap[i]; j < Ap[i + 1]; ++j)
			BSRBlockScaleRows(bsize, xv + Ai[j] * bsize, Av + j * bnnz);
}

void BSRMatAdd(const BSRMatrix& A, const BSRMatrix& B, BSRMatrix& C)
{
	int n = A.size[0];
	int m = B.size[1];
	int bsize = A.bsize;
	int bnnz = bsize * bsize;
	int* Ap = A.rowptr;
	int* Ai = A.colind;
	double* Av = A.values;
	int* Bp = B.rowptr;
	int* Bi = B.colind;
	double* Bv = B.values;

	int* Cp = new int[n + 1];
	Cp[0] = 0;
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel
#endif
	{
		int* w = new int[m];
		for (int i = 0; i < m; ++i)
			w[i] = -1;

#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
		for (int i = 0; i < n; ++i)
		{
			int cnt = Ap[i + 1] - Ap[i];

			for (int j = Ap[i]; j < Ap[i + 1]; ++j)
				w[Ai[j]] = i;

			for (int j = Bp[i]; j < Bp[i + 1]; ++j)
			{
				if (w[Bi[j]] != i)
				{
					w[Bi[j]] = i;
					++cnt;
				}
			}

			Cp[i + 1] = cnt;
		}

		delete[] w;
	}

	for (int i = 0; i < n; ++i)
		Cp[i + 1] += Cp[i];

	int* Ci = new int[Cp[n]];
	double* Cv = new double[Cp[n] * bnnz];

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel
#endif
	{
		int* w = new int[m];
		for (int i = 0; i < m; ++i)
			w[i] = -1;

#define BSR_UNROLL_SEGMENT(N) \
	for (int i = 0; i < n; ++i) \
	{ \
		int r = Cp[i], r0 = Cp[i]; \
		for (int j = Ap[i]; j < Ap[i + 1]; ++j) \
		{ \
			w[Ai[j]] = r; \
			Ci[r] = Ai[j]; \
			BSRBlockCopy_UNROLL(N, Av + j * N * N, Cv + r * N * N); \
			++r; \
		} \
		for (int j = Bp[i]; j < Bp[i + 1]; ++j) \
		{ \
			if (w[Bi[j]] < r0) \
			{ \
				w[Bi[j]] = r; \
				Ci[r] = Bi[j]; \
				BSRBlockCopy_UNROLL(N, Bv + j * N * N, Cv + r * N * N); \
				++r; \
			} \
			else \
				BSRBlockAdd_UNROLL(N, Bv + j * N * N, Cv + w[Bi[j]] * N * N); \
		} \
	}

#ifdef BSR_UNROLL_1
		if (bsize == 1)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
			BSR_UNROLL_SEGMENT(1)
		}
		else
#endif
#ifdef BSR_UNROLL_2
		if (bsize == 2)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
			BSR_UNROLL_SEGMENT(2)
		}
		else
#endif
#ifdef BSR_UNROLL_3
		if (bsize == 3)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
			BSR_UNROLL_SEGMENT(3)
		}
		else
#endif
#ifdef BSR_UNROLL_4
		if (bsize == 4)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
			BSR_UNROLL_SEGMENT(4)
		}
		else
#endif
#ifdef BSR_UNROLL_5
		if (bsize == 5)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
			BSR_UNROLL_SEGMENT(5)
		}
		else
#endif
#ifdef BSR_UNROLL_6
		if (bsize == 6)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
			BSR_UNROLL_SEGMENT(6)
		}
		else
#endif
#ifdef BSR_UNROLL_7
		if (bsize == 7)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
			BSR_UNROLL_SEGMENT(7)
		}
		else
#endif
#ifdef BSR_UNROLL_8
		if (bsize == 8)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
			BSR_UNROLL_SEGMENT(8)
		}
		else
#endif
#undef BSR_UNROLL_SEGMENT
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				int r = Cp[i], r0 = Cp[i];

				for (int j = Ap[i]; j < Ap[i + 1]; ++j)
				{
					w[Ai[j]] = r;
					Ci[r] = Ai[j];
					BSRBlockCopy(bsize, Av + j * bnnz, Cv + r * bnnz);
					++r;
				}

				for (int j = Bp[i]; j < Bp[i + 1]; ++j)
				{
					if (w[Bi[j]] < r0)
					{
						w[Bi[j]] = r;
						Ci[r] = Bi[j];
						BSRBlockCopy(bsize, Bv + j * bnnz, Cv + r * bnnz);
						++r;
					}
					else
						BSRBlockAdd(bsize, Bv + j * bnnz, Cv + w[Bi[j]] * bnnz);
				}
			}
		}

		delete[] w;
	}

	C.Free();

	C.size[0] = n;
	C.size[1] = m;
	C.bsize = bsize;
	C.rowptr = Cp;
	C.colind = Ci;
	C.values = Cv;
}

void BSRMatMul(const BSRMatrix& A, const BSRMatrix& B, BSRMatrix& C)
{
	int n = A.size[0];
	int m = B.size[1];
	int bsize = A.bsize;
	int bnnz = bsize * bsize;

	int* Ap = A.rowptr;
	int* Ai = A.colind;
	double* Av = A.values;
	int* Bp = B.rowptr;
	int* Bi = B.colind;
	double* Bv = B.values;

	int* Cp = new int[n + 1];
	Cp[0] = 0;
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel
#endif
	{
		int* w = new int[m];
		for (int i = 0; i < m; ++i)
			w[i] = -1;

#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
		for (int i = 0; i < n; ++i)
		{
			int cnt = 0;

			for (int k = Ap[i]; k < Ap[i + 1]; ++k)
			{
				int kcol = Ai[k];

				for (int j = Bp[kcol]; j < Bp[kcol + 1]; ++j)
				{
					int jcol = Bi[j];

					if (w[jcol] != i)
					{
						w[jcol] = i;
						++cnt;
					}
				}
			}

			Cp[i + 1] = cnt;
		}

		delete[] w;
	}

	for (int i = 0; i < n; ++i)
		Cp[i + 1] += Cp[i];

	int* Ci = new int[Cp[n]];
	double* Cv = new double[Cp[n] * bnnz];

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel
#endif
	{
		int* w = new int[m];
		for (int i = 0; i < m; ++i)
			w[i] = -1;

#define BSR_UNROLL_SEGMENT(N) \
	for (int i = 0; i < n; ++i) \
	{ \
		for (int k = Ap[i], r = Cp[i], r0 = Cp[i]; k < Ap[i + 1]; ++k) \
		{ \
			int kcol = Ai[k]; \
			for (int j = Bp[kcol]; j < Bp[kcol + 1]; ++j) \
			{ \
				int jcol = Bi[j]; \
				if (w[jcol] < r0) \
				{ \
					w[jcol] = r; \
					Ci[r] = jcol; \
					BSRBlockMatMul_UNROLL(N, Av + k * N * N, Bv + j * N * N, Cv + r * N * N); \
					++r; \
				} \
				else \
					BSRBlockMatMulAdd_UNROLL(N, Av + k * N * N, Bv + j * N * N, Cv + w[jcol] * N * N); \
			} \
		} \
	}

#ifdef BSR_UNROLL_1
		if (bsize == 1)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
			BSR_UNROLL_SEGMENT(1)
		}
		else
#endif
#ifdef BSR_UNROLL_2
		if (bsize == 2)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
			BSR_UNROLL_SEGMENT(2)
		}
		else
#endif
#ifdef BSR_UNROLL_3
		if (bsize == 3)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
			BSR_UNROLL_SEGMENT(3)
		}
		else
#endif
#ifdef BSR_UNROLL_4
		if (bsize == 4)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
			BSR_UNROLL_SEGMENT(4)
		}
		else
#endif
#ifdef BSR_UNROLL_5
		if (bsize == 5)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
			BSR_UNROLL_SEGMENT(5)
		}
		else
#endif
#ifdef BSR_UNROLL_6
		if (bsize == 6)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
			BSR_UNROLL_SEGMENT(6)
		}
		else
#endif
#ifdef BSR_UNROLL_7
		if (bsize == 7)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
			BSR_UNROLL_SEGMENT(7)
		}
		else
#endif
#ifdef BSR_UNROLL_8
		if (bsize == 8)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
			BSR_UNROLL_SEGMENT(8)
		}
		else
#endif
#undef BSR_UNROLL_SEGMENT
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				for (int k = Ap[i], r = Cp[i], r0 = Cp[i]; k < Ap[i + 1]; ++k)
				{
					int kcol = Ai[k];

					for (int j = Bp[kcol]; j < Bp[kcol + 1]; ++j)
					{
						int jcol = Bi[j];

						if (w[jcol] < r0)
						{
							w[jcol] = r;
							Ci[r] = jcol;
							BSRBlockMatMul(bsize, Av + k * bnnz, Bv + j * bnnz, Cv + r * bnnz);
							++r;
						}
						else
							BSRBlockMatMulAdd(bsize, Av + k * bnnz, Bv + j * bnnz, Cv + w[jcol] * bnnz);
					}
				}
			}
		}

		delete[] w;
	}

	C.Free();

	C.size[0] = n;
	C.size[1] = m;
	C.bsize = bsize;
	C.rowptr = Cp;
	C.colind = Ci;
	C.values = Cv;
}

void BSRMatVec(double alpha, const BSRMatrix& A, const Vector& x, double beta, const Vector& y)
{
	int n = A.size[0];
	int bsize = A.bsize;
	int bnnz = bsize * bsize;
	int* Ap = A.rowptr;
	int* Ai = A.colind;
	double* Av = A.values;
	double* xv = x.values;
	double* yv = y.values;

	if (alpha == 0.0)
	{
		y.Scale(beta);
		return;
	}

	y.Scale(beta / alpha);
	
#define BSR_UNROLL_SEGMENT(N) \
	for (int i = 0; i < n; ++i) \
		for (int j = Ap[i]; j < Ap[i + 1]; ++j) \
			BSRBlockMatVecAdd_UNROLL(N, Av + j * N * N, xv + Ai[j] * N, yv + i * N);

#ifdef BSR_UNROLL_1
	if (bsize == 1)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		BSR_UNROLL_SEGMENT(1)
	}
	else
#endif
#ifdef BSR_UNROLL_2
	if (bsize == 2)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		BSR_UNROLL_SEGMENT(2)
	}
	else
#endif
#ifdef BSR_UNROLL_3
	if (bsize == 3)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		BSR_UNROLL_SEGMENT(3)
	}
	else
#endif
#ifdef BSR_UNROLL_4
	if (bsize == 4)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		BSR_UNROLL_SEGMENT(4)
	}
	else
#endif
#ifdef BSR_UNROLL_5
	if (bsize == 5)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		BSR_UNROLL_SEGMENT(5)
	}
	else
#endif
#ifdef BSR_UNROLL_6
	if (bsize == 6)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		BSR_UNROLL_SEGMENT(6)
	}
	else
#endif
#ifdef BSR_UNROLL_7
	if (bsize == 7)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		BSR_UNROLL_SEGMENT(7)
	}
	else
#endif
#ifdef BSR_UNROLL_8
	if (bsize == 8)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		BSR_UNROLL_SEGMENT(8)
	}
	else
#endif
#undef BSR_UNROLL_SEGMENT
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		for (int i = 0; i < n; ++i)
			for (int j = Ap[i]; j < Ap[i + 1]; ++j)
				BSRBlockMatVecAdd(bsize, Av + j * bnnz, xv + Ai[j] * bsize, yv + i * bsize);
	}

	y.Scale(alpha);
}

void BSRTrans(const BSRMatrix& A, BSRMatrix& B)
{
	int n = A.size[0];
	int m = A.size[1];
	int bsize = A.bsize;
	int bnnz = bsize * bsize;

	int* Ap = A.rowptr;
	int* Ai = A.colind;
	double* Av = A.values;

	int* Bp = new int[m + 1];
	int* Bi = new int[Ap[n]];
	double* Bv = new double[Ap[n] * bnnz];

	int nthd = 1;
#ifdef YHAMG_USE_OPENMP
	nthd = omp_get_max_threads();
#endif

	if (nthd == 1)
	{
		for (int i = 0; i <= m; ++i)
		Bp[i] = 0;

		for (int j = Ap[0]; j < Ap[n]; ++j)
			++Bp[Ai[j]];

		for (int i = 0; i < m; ++i)
			Bp[i + 1] += Bp[i];

#define BSR_UNROLL_SEGMENT(N) \
	for (int i = n - 1; i >= 0; --i) \
	{ \
		for (int j = Ap[i + 1] - 1; j >= Ap[i]; --j) \
		{ \
			Bi[--Bp[Ai[j]]] = i; \
			BSRBlockTranspose_UNROLL(N, Av + j * N * N, Bv + Bp[Ai[j]] * N * N); \
		} \
	}

#ifdef BSR_UNROLL_1
		if (bsize == 1) { BSR_UNROLL_SEGMENT(1) } else
#endif
#ifdef BSR_UNROLL_2
		if (bsize == 2) { BSR_UNROLL_SEGMENT(2) } else
#endif
#ifdef BSR_UNROLL_3
		if (bsize == 3) { BSR_UNROLL_SEGMENT(3) } else
#endif
#ifdef BSR_UNROLL_4
		if (bsize == 4) { BSR_UNROLL_SEGMENT(4) } else
#endif
#ifdef BSR_UNROLL_5
		if (bsize == 5) { BSR_UNROLL_SEGMENT(5) } else
#endif
#ifdef BSR_UNROLL_6
		if (bsize == 6) { BSR_UNROLL_SEGMENT(6) } else
#endif
#ifdef BSR_UNROLL_7
		if (bsize == 7) { BSR_UNROLL_SEGMENT(7) } else
#endif
#ifdef BSR_UNROLL_8
		if (bsize == 8) { BSR_UNROLL_SEGMENT(8) } else
#endif
#undef BSR_UNROLL_SEGMENT
		{
			for (int i = n - 1; i >= 0; --i)
			{
				for (int j = Ap[i + 1] - 1; j >= Ap[i]; --j)
				{
					Bi[--Bp[Ai[j]]] = i;
					BSRBlockTranspose(bsize, Av + j * bnnz, Bv + Bp[Ai[j]] * bnnz);
				}
			}
		}
	}
	else
	{
		int*  _offsets = new int[m * nthd];
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		for (int i = 0; i < m * nthd; ++i)
			_offsets[i] = 0;

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		for (int t = 0; t < nthd; ++t)
		{
			int start = n * t / nthd;
			int end = n * (t + 1) / nthd;
			for (int j = Ap[start]; j < Ap[end]; ++j)
				++_offsets[Ai[j] * nthd + t];
		}

		if (nthd > 2)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			for (int t = 0; t < nthd; ++t)
			{
				int start = m * t;
				int end = m * (t + 1);

				for (int i = start + 1; i < end; ++i)
					_offsets[i] += _offsets[i - 1];
			}

			for (int t = 1; t < nthd; ++t)
			{
				int start = m * t;
				int end = m * (t + 1);
				_offsets[end - 1] += _offsets[start - 1];
			}

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			for (int t = 1; t < nthd; ++t)
			{
				int start = m * t;
				int end = m * (t + 1);
				for (int i = start; i < end - 1; ++i)
					_offsets[i] += _offsets[start - 1];
			}
		}
		else
		{
			for (int i = 1; i < m * nthd; ++i)
				_offsets[i] += _offsets[i - 1];
		}

		Bp[0] = 0;
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		for (int i = 1; i <= m; ++i)
			Bp[i] = _offsets[i * nthd - 1];

#define BSR_UNROLL_SEGMENT(N) \
	for (int i = end - 1; i >= start; --i) \
	{ \
		for (int j = Ap[i + 1] - 1; j >= Ap[i]; --j) \
		{ \
			Bi[--_offsets[Ai[j] * nthd + t]] = i; \
			BSRBlockTranspose_UNROLL(N, Av + j * N * N, Bv + _offsets[Ai[j] * nthd + t] * N * N); \
		} \
	}

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		for (int t = 0; t < nthd; ++t)
		{
			int start = n * t / nthd;
			int end = n * (t + 1) / nthd;
	
#ifdef BSR_UNROLL_1
			if (bsize == 1) { BSR_UNROLL_SEGMENT(1) } else
#endif
#ifdef BSR_UNROLL_2
			if (bsize == 2) { BSR_UNROLL_SEGMENT(2) } else
#endif
#ifdef BSR_UNROLL_3
			if (bsize == 3) { BSR_UNROLL_SEGMENT(3) } else
#endif
#ifdef BSR_UNROLL_4
			if (bsize == 4) { BSR_UNROLL_SEGMENT(4) } else
#endif
#ifdef BSR_UNROLL_5
			if (bsize == 5) { BSR_UNROLL_SEGMENT(5) } else
#endif
#ifdef BSR_UNROLL_6
			if (bsize == 6) { BSR_UNROLL_SEGMENT(6) } else
#endif
#ifdef BSR_UNROLL_7
			if (bsize == 7) { BSR_UNROLL_SEGMENT(7) } else
#endif
#ifdef BSR_UNROLL_8
			if (bsize == 8) { BSR_UNROLL_SEGMENT(8) } else
#endif
#undef BSR_UNROLL_SEGMENT
			{
				for (int i = end - 1; i >= start; --i)
				{
					for (int j = Ap[i + 1] - 1; j >= Ap[i]; --j)
					{
						Bi[--_offsets[Ai[j] * nthd + t]] = i;
						BSRBlockTranspose(bsize, Av + j * bnnz, Bv + _offsets[Ai[j] * nthd + t] * bnnz); 
					}
				}
			}
		}

		delete[] _offsets;
	}

	B.Free();
	B.size[0] = m;
	B.size[1] = n;
	B.bsize = bsize;
	B.rowptr = Bp;
	B.colind = Bi;
	B.values = Bv;
}

void CSRMultBSR(const CSRMatrix& A, const BSRMatrix& B, BSRMatrix& C)
{
	int n = A.size[0];
	int m = B.size[1];
	int bsize = B.bsize;
	int bnnz = bsize * bsize;

	int* Ap = A.rowptr;
	int* Ai = A.colind;
	double* Av = A.values;
	int* Bp = B.rowptr;
	int* Bi = B.colind;
	double* Bv = B.values;

	int* Cp = new int[n + 1];
	Cp[0] = 0;
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel
#endif
	{
		int* w = new int[m];
		for (int i = 0; i < m; ++i)
			w[i] = -1;

#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
		for (int i = 0; i < n; ++i)
		{
			int cnt = 0;

			for (int k = Ap[i]; k < Ap[i + 1]; ++k)
			{
				int kcol = Ai[k];

				for (int j = Bp[kcol]; j < Bp[kcol + 1]; ++j)
				{
					int jcol = Bi[j];

					if (w[jcol] != i)
					{
						w[jcol] = i;
						++cnt;
					}
				}
			}

			Cp[i + 1] = cnt;
		}

		delete[] w;
	}

	for (int i = 0; i < n; ++i)
		Cp[i + 1] += Cp[i];

	int* Ci = new int[Cp[n]];
	double* Cv = new double[Cp[n] * bnnz];
	
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel
#endif
	{
		int* w = new int[m];
		for (int i = 0; i < m; ++i)
			w[i] = -1;

#define BSR_UNROLL_SEGMENT(N) \
	for (int i = 0; i < n; ++i) \
	{ \
		int r = Cp[i]; \
		int r0 = Cp[i]; \
		for (int k = Ap[i]; k < Ap[i + 1]; ++k) \
		{ \
			int kcol = Ai[k]; \
			for (int j = Bp[kcol]; j < Bp[kcol + 1]; ++j) \
			{ \
				int jcol = Bi[j]; \
				if (w[jcol] < r0) \
				{ \
					w[jcol] = r; \
					Ci[r] = jcol; \
					BSRBlockCopy_UNROLL(N, Bv + j * N *  N, Cv + r * N *  N); \
					BSRBlockScale_UNROLL(N, Av[k], Cv + r * N *  N); \
					++r; \
				} \
				else \
					BSRBlockScaleAdd_UNROLL(N, Av[k], Bv + j * N *  N, Cv + w[jcol] * N *  N); \
			} \
		} \
	}

#ifdef BSR_UNROLL_1
		if (bsize == 1)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
			BSR_UNROLL_SEGMENT(1)
		}
		else
#endif
#ifdef BSR_UNROLL_2
		if (bsize == 2)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
			BSR_UNROLL_SEGMENT(2)
		}
		else
#endif
#ifdef BSR_UNROLL_3
		if (bsize == 3)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
			BSR_UNROLL_SEGMENT(3)
		}
		else
#endif
#ifdef BSR_UNROLL_4
		if (bsize == 4)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
			BSR_UNROLL_SEGMENT(4)
		}
		else
#endif
#ifdef BSR_UNROLL_5
		if (bsize == 5)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
			BSR_UNROLL_SEGMENT(5)
		}
	else
#endif
#ifdef BSR_UNROLL_6
		if (bsize == 6)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
			BSR_UNROLL_SEGMENT(6)
		}
		else
#endif
#ifdef BSR_UNROLL_7
		if (bsize == 7)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
			BSR_UNROLL_SEGMENT(7)
		}
		else
#endif
#ifdef BSR_UNROLL_8
		if (bsize == 8)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
			BSR_UNROLL_SEGMENT(8)
		}
		else
#endif
#undef BSR_UNROLL_SEGMENT
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				int r = Cp[i];
				int r0 = Cp[i];

				for (int k = Ap[i]; k < Ap[i + 1]; ++k)
				{
					int kcol = Ai[k];

					for (int j = Bp[kcol]; j < Bp[kcol + 1]; ++j)
					{
						int jcol = Bi[j];

						if (w[jcol] < r0)
						{
							w[jcol] = r;
							Ci[r] = jcol;
							BSRBlockCopy(bsize, Bv + j * bnnz, Cv + r * bnnz);
							BSRBlockScale(bsize, Av[k], Cv + r * bnnz);
							++r;
						}
						else
							BSRBlockScaleAdd(bsize, Av[k], Bv + j * bnnz, Cv + w[jcol] * bnnz);
					}
				}
			}
		}

		delete[] w;
	}

	C.Free();

	C.size[0] = n;
	C.size[1] = m;
	C.bsize = bsize;
	C.rowptr = Cp;
	C.colind = Ci;
	C.values = Cv;
}

void BSRMultCSR(const BSRMatrix& A, const CSRMatrix& B, BSRMatrix& C)
{
	int n = A.size[0];
	int m = B.size[1];
	int bsize = A.bsize;
	int bnnz = bsize * bsize;

	int* Ap = A.rowptr;
	int* Ai = A.colind;
	double* Av = A.values;
	int* Bp = B.rowptr;
	int* Bi = B.colind;
	double* Bv = B.values;

	int* Cp = new int[n + 1];
	Cp[0] = 0;
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel
#endif
	{
		int* w = new int[m];
		for (int i = 0; i < m; ++i)
			w[i] = -1;

#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
		for (int i = 0; i < n; ++i)
		{
			int cnt = 0;

			for (int k = Ap[i]; k < Ap[i + 1]; ++k)
			{
				int kcol = Ai[k];

				for (int j = Bp[kcol]; j < Bp[kcol + 1]; ++j)
				{
					int jcol = Bi[j];

					if (w[jcol] != i)
					{
						w[jcol] = i;
						++cnt;
					}
				}
			}

			Cp[i + 1] = cnt;
		}

		delete[] w;
	}

	for (int i = 0; i < n; ++i)
		Cp[i + 1] += Cp[i];

	int* Ci = new int[Cp[n]];
	double* Cv = new double[Cp[n] * bnnz];
	
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel
#endif
	{
		int* w = new int[m];
		for (int i = 0; i < m; ++i)
			w[i] = -1;

#define BSR_UNROLL_SEGMENT(N) \
	for (int i = 0; i < n; ++i) \
	{ \
		int r = Cp[i]; \
		int r0 = Cp[i]; \
		for (int k = Ap[i]; k < Ap[i + 1]; ++k) \
		{ \
			int kcol = Ai[k]; \
			for (int j = Bp[kcol]; j < Bp[kcol + 1]; ++j) \
			{ \
				int jcol = Bi[j]; \
				if (w[jcol] < r0) \
				{ \
					w[jcol] = r; \
					Ci[r] = jcol; \
					BSRBlockCopy_UNROLL(N, Av + j * N *  N, Cv + r * N *  N); \
					BSRBlockScale_UNROLL(N, Bv[k], Cv + r * N *  N); \
					++r; \
				} \
				else \
					BSRBlockScaleAdd_UNROLL(N, Bv[k], Av + j * N *  N, Cv + w[jcol] * N *  N); \
			} \
		} \
	}

#ifdef BSR_UNROLL_1
		if (bsize == 1)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
			BSR_UNROLL_SEGMENT(1)
		}
		else
#endif
#ifdef BSR_UNROLL_2
		if (bsize == 2)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
			BSR_UNROLL_SEGMENT(2)
		}
		else
#endif
#ifdef BSR_UNROLL_3
		if (bsize == 3)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
			BSR_UNROLL_SEGMENT(3)
		}
		else
#endif
#ifdef BSR_UNROLL_4
		if (bsize == 4)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
			BSR_UNROLL_SEGMENT(4)
		}
		else
#endif
#ifdef BSR_UNROLL_5
		if (bsize == 5)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
			BSR_UNROLL_SEGMENT(5)
		}
	else
#endif
#ifdef BSR_UNROLL_6
		if (bsize == 6)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
			BSR_UNROLL_SEGMENT(6)
		}
		else
#endif
#ifdef BSR_UNROLL_7
		if (bsize == 7)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
			BSR_UNROLL_SEGMENT(7)
		}
		else
#endif
#ifdef BSR_UNROLL_8
		if (bsize == 8)
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
			BSR_UNROLL_SEGMENT(8)
		}
		else
#endif
#undef BSR_UNROLL_SEGMENT
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp for schedule(guided)
#endif
			for (int i = 0; i < n; ++i)
			{
				int r = Cp[i];
				int r0 = Cp[i];

				for (int k = Ap[i]; k < Ap[i + 1]; ++k)
				{
					int kcol = Ai[k];

					for (int j = Bp[kcol]; j < Bp[kcol + 1]; ++j)
					{
						int jcol = Bi[j];

						if (w[jcol] < r0)
						{
							w[jcol] = r;
							Ci[r] = jcol;
							BSRBlockCopy(bsize, Av + j * bnnz, Cv + r * bnnz);
							BSRBlockScale(bsize, Bv[k], Cv + r * bnnz);
							++r;
						}
						else
							BSRBlockScaleAdd(bsize, Bv[k], Av + j * bnnz, Cv + w[jcol] * bnnz);
					}
				}
			}
		}

		delete[] w;
	}

	C.Free();

	C.size[0] = n;
	C.size[1] = m;
	C.bsize = bsize;
	C.rowptr = Cp;
	C.colind = Ci;
	C.values = Cv;
}

void CSRMatBlockVec(int bsize, double alpha, const CSRMatrix& A, const Vector& x, double beta, const Vector& y)
{
	int n = A.size[0];

	int* Ap = A.rowptr;
	int* Ai = A.colind;
	double* Av = A.values;

	double* xv = x.values;
	double* yv = y.values;

	if (alpha == 0.0)
	{
		y.Scale(beta);
		return;
	}

	y.Scale(beta / alpha);

#define BSR_UNROLL_SEGMENT(N) \
for (int i = 0; i < n; ++i) \
	for (int j = Ap[i]; j < Ap[i + 1]; ++j) \
		VecBlockScaleAdd_UNROLL(N, Av[j], xv + Ai[j] * N, yv + i * N);

#ifdef BSR_UNROLL_1
	if (bsize == 1)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		BSR_UNROLL_SEGMENT(1)
	}
	else
#endif
#ifdef BSR_UNROLL_2
	if (bsize == 2)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		BSR_UNROLL_SEGMENT(2)
	}
	else
#endif
#ifdef BSR_UNROLL_3
	if (bsize == 3)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		BSR_UNROLL_SEGMENT(3)
	}
	else
#endif
#ifdef BSR_UNROLL_4
	if (bsize == 4)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		BSR_UNROLL_SEGMENT(4)
	}
	else
#endif
#ifdef BSR_UNROLL_5
	if (bsize == 5)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		BSR_UNROLL_SEGMENT(5)
	}
	else
#endif
#ifdef BSR_UNROLL_6
	if (bsize == 6)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		BSR_UNROLL_SEGMENT(6)
	}
	else
#endif
#ifdef BSR_UNROLL_7
	if (bsize == 7)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		BSR_UNROLL_SEGMENT(7)
	}
	else
#endif
#ifdef BSR_UNROLL_8
	if (bsize == 8)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		BSR_UNROLL_SEGMENT(8)
	}
	else
#endif
#undef BSR_UNROLL_SEGMENT
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		for (int i = 0; i < n; ++i)
			for (int j = Ap[i]; j < Ap[i + 1]; ++j)
				VecBlockScaleAdd(bsize, Av[j], xv + Ai[j] * bsize, yv + i * bsize);
	}

	y.Scale(alpha);
}

}