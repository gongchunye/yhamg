/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "ParBSRGenerator7pt.hpp"

namespace YHAMG
{

ParBSRGenerator7pt::ParBSRGenerator7pt(MPI_Comm comm)
	: ParBSRGenerator(comm),
	nx(0),
	ny(0),
	nz(0),
	bx(0),
	by(0),
	bz(0),
	Px(0),
	Py(0),
	Pz(0),
	cx(0.0),
	cy(0.0),
	cz(0.0)
{
}

ParBSRGenerator7pt::ParBSRGenerator7pt(MPI_Comm comm, int _nx, int _ny, int _nz, int _bx, int _by, int _bz, int _Px, int _Py, int _Pz, double _cx, double _cy, double _cz)
	: ParBSRGenerator(comm),
	nx(_nx),
	ny(_ny),
	nz(_nz),
	bx(_bx),
	by(_by),
	bz(_bz),
	Px(_Px),
	Py(_Py),
	Pz(_Pz),
	cx(_cx),
	cy(_cy),
	cz(_cz)
{
}

static inline int sub2ind(int nx, int ny, int nz, int ix, int iy, int iz)
{
	return ix * ny * nz + iy * nz + iz;
}

static inline void ind2sub(int nx, int ny, int nz, int i, int& ix, int& iy, int& iz)
{
	ix = i / (ny * nz);
	iy = i / nz - ix * ny;
	iz = i - ix * ny * nz - iy * nz;
}

void ParBSRGenerator7pt::operator()(ParBSRMatrix& A) const
{
	int comm_rank;
	MPI_Comm_rank(comm, &comm_rank);

	double b = 0.0;
	if (nx * bx * Px > 1) b -= 2 * cx;
	if (ny * bx * Py > 1) b -= 2 * cy;
	if (nz * bx * Pz > 1) b -= 2 * cz;

	int size = nx * ny * nz;
	int bsize = bx * by * bz;
	int bnnz = bsize * bsize;

	int* local_rowptr = new int[size + 1];

	local_rowptr[0] = 0;
	for (int ix = 0; ix < nx; ++ix)
	{
		for (int iy = 0; iy < ny; ++iy)
		{
			for (int iz = 0; iz < nz; ++iz)
			{
				int cnt = 1;
				if (ix > 0) ++cnt;
				if (iy > 0) ++cnt;
				if (iz > 0) ++cnt;
				if (iz < nz - 1) ++cnt;
				if (iy < ny - 1) ++cnt;
				if (ix < nx - 1) ++cnt;
				local_rowptr[sub2ind(nx, ny, nz, ix, iy, iz) + 1] = cnt;
			}
		}
	}

	for (int i = 0; i < size; ++i)
		local_rowptr[i + 1] += local_rowptr[i];

	int* local_colind = new int[local_rowptr[size]];
	double* local_values = new double[local_rowptr[size] * bnnz];

	for (int ix = 0; ix < nx; ++ix)
	{
		for (int iy = 0; iy < ny; ++iy)
		{
			for (int iz = 0; iz < nz; ++iz)
			{
				int r = sub2ind(nx, ny, nz, ix, iy, iz);
				int j = local_rowptr[r];

				if (ix > 0)
				{
					local_colind[j] = sub2ind(nx, ny, nz, ix - 1, iy, iz);
					BSRBlockFill(bsize, 0.0, local_values + j * bnnz);

					for (int jy = 0; jy < by; ++jy)
						for (int jz = 0; jz < bz; ++jz)
							local_values[j * bnnz + sub2ind(bx, by, bz, 0, jy, jz) * bsize + sub2ind(bx, by, bz, bx - 1, jy, jz)] = cx;
					++j;
				}

				if (iy > 0)
				{
					local_colind[j] = sub2ind(nx, ny, nz, ix, iy - 1, iz);
					BSRBlockFill(bsize, 0.0, local_values + j * bnnz);

					for (int jx = 0; jx < bx; ++jx)
						for (int jz = 0; jz < bz; ++jz)
							local_values[j * bnnz + sub2ind(bx, by, bz, jx, 0, jz) * bsize + sub2ind(bx, by, bz, jx, by - 1, jz)] = cy;
					++j;
				}

				if (iz > 0)
				{
					local_colind[j] = sub2ind(nx, ny, nz, ix, iy, iz - 1);
					BSRBlockFill(bsize, 0.0, local_values + j * bnnz);

					for (int jx = 0; jx < bx; ++jx)
						for (int jy = 0; jy < by; ++jy)
							local_values[j * bnnz + sub2ind(bx, by, bz, jx, jy, 0) * bsize + sub2ind(bx, by, bz, jx, jy, bz - 1)] = cz;
					++j;
				}

				local_colind[j] = sub2ind(nx, ny, nz, ix, iy, iz);
				BSRBlockFill(bsize, 0.0, local_values + j * bnnz);
				
				for (int jx = 0; jx < bx; ++jx)
				{
					for (int jy = 0; jy < by; ++jy)
					{
						for (int jz = 0; jz < bz; ++jz)
						{
							if (jx > 0) local_values[j * bnnz + sub2ind(bx, by, bz, jx - 1, jy, jz) * bsize + sub2ind(bx, by, bz, jx, jy, jz)] = cx;
							if (jy > 0) local_values[j * bnnz + sub2ind(bx, by, bz, jx, jy - 1, jz) * bsize + sub2ind(bx, by, bz, jx, jy, jz)] = cy;
							if (jz > 0) local_values[j * bnnz + sub2ind(bx, by, bz, jx, jy, jz - 1) * bsize + sub2ind(bx, by, bz, jx, jy, jz)] = cz;
							local_values[j * bnnz + sub2ind(bx, by, bz, jx, jy, jz) * bsize + sub2ind(bx, by, bz, jx, jy, jz)] = b;
							if (jz < bz - 1) local_values[j * bnnz + sub2ind(bx, by, bz, jx, jy, jz + 1) * bsize + sub2ind(bx, by, bz, jx, jy, jz)] = cz;
							if (jy < by - 1) local_values[j * bnnz + sub2ind(bx, by, bz, jx, jy + 1, jz) * bsize + sub2ind(bx, by, bz, jx, jy, jz)] = cy;
							if (jx < bx - 1) local_values[j * bnnz + sub2ind(bx, by, bz, jx + 1, jy, jz) * bsize + sub2ind(bx, by, bz, jx, jy, jz)] = cx;
						}
					}
				}
				
				++j;

				if (iz < nz - 1)
				{
					local_colind[j] = sub2ind(nx, ny, nz, ix, iy, iz + 1);
					BSRBlockFill(bsize, 0.0, local_values + j * bnnz);

					for (int jx = 0; jx < bx; ++jx)
						for (int jy = 0; jy < by; ++jy)
							local_values[j * bnnz + sub2ind(bx, by, bz, jx, jy, bz - 1) * bsize + sub2ind(bx, by, bz, jx, jy, 0)] = cz;
					++j;
				}

				if (iy < ny - 1)
				{
					local_colind[j] = sub2ind(nx, ny, nz, ix, iy + 1, iz);
					BSRBlockFill(bsize, 0.0, local_values + j * bnnz);

					for (int jx = 0; jx < bx; ++jx)
						for (int jz = 0; jz < bz; ++jz)
							local_values[j * bnnz + sub2ind(bx, by, bz, jx, by - 1, jz) * bsize + sub2ind(bx, by, bz, jx, 0, jz)] = cy;
					++j;
				}

				if (ix < nx - 1)
				{
					local_colind[j] = sub2ind(nx, ny, nz, ix + 1, iy, iz);
					BSRBlockFill(bsize, 0.0, local_values + j * bnnz);

					for (int jy = 0; jy < by; ++jy)
						for (int jz = 0; jz < bz; ++jz)
							local_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, jy, jz) * bsize + sub2ind(bx, by, bz, 0, jy, jz)] = cx;
					++j;
				}
			}
		}
	}

	int rx, ry, rz;
	ind2sub(Px, Py, Pz, comm_rank, rx, ry, rz);

	int* exter_rowptr = new int[size + 1];
	for (int i = 0; i <= size; ++i)
		exter_rowptr[i] = 0;

	int nnb = 0;
	int* nbrank = new int[6];
	int* recvptr = new int[7];

	recvptr[0] = 0;

	if (rx > 0)
	{
		for (int iy = 0; iy < ny; ++iy)
			for (int iz = 0; iz < nz; ++iz)
				++exter_rowptr[sub2ind(nx, ny, nz, 0, iy, iz)];
		nbrank[nnb++] = sub2ind(Px, Py, Pz, rx - 1, ry, rz);
		recvptr[nnb] = ny * nz;
	}

	if (ry > 0)
	{
		for (int ix = 0; ix < nx; ++ix)
			for (int iz = 0; iz < nz; ++iz)
				++exter_rowptr[sub2ind(nx, ny, nz, ix, 0, iz)];
		nbrank[nnb++] = sub2ind(Px, Py, Pz, rx, ry - 1, rz);
		recvptr[nnb] = nx * nz;
	}

	if (rz > 0)
	{
		for (int ix = 0; ix < nx; ++ix)
			for (int iy = 0; iy < ny; ++iy)
				++exter_rowptr[sub2ind(nx, ny, nz, ix, iy, 0)];
		nbrank[nnb++] = sub2ind(Px, Py, Pz, rx, ry, rz - 1);
		recvptr[nnb] = nx * ny;
	}

	if (rz < Pz - 1)
	{
		for (int ix = 0; ix < nx; ++ix)
			for (int iy = 0; iy < ny; ++iy)
				++exter_rowptr[sub2ind(nx, ny, nz, ix, iy, nz - 1)];
		nbrank[nnb++] = sub2ind(Px, Py, Pz, rx, ry, rz + 1);
		recvptr[nnb] = nx * ny;
	}

	if (ry < Py - 1)
	{
		for (int ix = 0; ix < nx; ++ix)
			for (int iz = 0; iz < nz; ++iz)
				++exter_rowptr[sub2ind(nx, ny, nz, ix, ny - 1, iz)];
		nbrank[nnb++] = sub2ind(Px, Py, Pz, rx, ry + 1, rz);
		recvptr[nnb] = nx * nz;
	}

	if (rx < Px - 1)
	{
		for (int iy = 0; iy < ny; ++iy)
			for (int iz = 0; iz < nz; ++iz)
				++exter_rowptr[sub2ind(nx, ny, nz, nx - 1, iy, iz)];
		nbrank[nnb++] = sub2ind(Px, Py, Pz, rx + 1, ry, rz);
		recvptr[nnb] = ny * nz;
	}

	for (int i = 0; i < size; ++i)
		exter_rowptr[i + 1] += exter_rowptr[i];

	int* exter_colind = new int[exter_rowptr[size]];
	double* exter_values = new double[exter_rowptr[size] * bnnz];

	for (int r = 0; r < nnb; ++r)
		recvptr[r + 1] += recvptr[r];

	int* recvind = new int[recvptr[nnb]];

	int nbind = nnb;

	if (rx < Px - 1)
	{
		int t = recvptr[nbind--];
		for (int iy = ny - 1; iy >= 0; --iy)
		{
			for (int iz = nz - 1; iz >= 0; --iz)
			{
				recvind[--t] = sub2ind(nx, ny, nz, 0, iy, iz);
				int j = --exter_rowptr[sub2ind(nx, ny, nz, nx - 1, iy, iz)];
				exter_colind[j] = t;
				BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);

				for (int jy = 0; jy < by; ++jy)
					for (int jz = 0; jz < bz; ++jz)
						exter_values[j * bnnz + sub2ind(bx, by, bz, bx - 1, jy, jz) * bsize + sub2ind(bx, by, bz, 0, jy, jz)] = cx;
			}
		}
	}


	if (ry < Py - 1)
	{
		int t = recvptr[nbind--];
		for (int ix = nx - 1; ix >= 0; --ix)
		{
			for (int iz = nz - 1; iz >= 0; --iz)
			{
				recvind[--t] = sub2ind(nx, ny, nz, ix, 0, iz);
				int j = --exter_rowptr[sub2ind(nx, ny, nz, ix, ny - 1, iz)];
				exter_colind[j] = t;
				BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);

				for (int jx = 0; jx < bx; ++jx)
					for (int jz = 0; jz < bz; ++jz)
						exter_values[j * bnnz + sub2ind(bx, by, bz, jx, by - 1, jz) * bsize + sub2ind(bx, by, bz, jx, 0, jz)] = cy;
			}
		}
	}

	if (rz < Pz - 1)
	{
		int t = recvptr[nbind--];
		for (int ix = nx - 1; ix >= 0; --ix)
		{
			for (int iy = ny - 1; iy >= 0; --iy)
			{
				recvind[--t] = sub2ind(nx, ny, nz, ix, iy, 0);
				int j = --exter_rowptr[sub2ind(nx, ny, nz, ix, iy, nz - 1)];
				exter_colind[j] = t;
				BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);

				for (int jx = 0; jx < bx; ++jx)
					for (int jy = 0; jy < by; ++jy)
						exter_values[j * bnnz + sub2ind(bx, by, bz, jx, jy, bz - 1) * bsize + sub2ind(bx, by, bz, jx, jy, 0)] = cz;
			}
		}
	}

	if (rz > 0)
	{
		int t = recvptr[nbind--];
		for (int ix = nx - 1; ix >= 0; --ix)
		{
			for (int iy = ny - 1; iy >= 0; --iy)
			{
				recvind[--t] = sub2ind(nx, ny, nz, ix, iy, nz - 1);
				int j = --exter_rowptr[sub2ind(nx, ny, nz, ix, iy, 0)];
				exter_colind[j] = t;
				BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);

				for (int jx = 0; jx < bx; ++jx)
					for (int jy = 0; jy < by; ++jy)
						exter_values[j * bnnz + sub2ind(bx, by, bz, jx, jy, 0) * bsize + sub2ind(bx, by, bz, jx, jy, bz - 1)] = cz;
			}
		}
	}

	if (ry > 0)
	{
		int t = recvptr[nbind--];
		for (int ix = nx - 1; ix >= 0; --ix)
		{
			for (int iz = nz - 1; iz >= 0; --iz)
			{
				recvind[--t] = sub2ind(nx, ny, nz, ix, ny - 1, iz);
				int j = --exter_rowptr[sub2ind(nx, ny, nz, ix, 0, iz)];
				exter_colind[j] = t;
				BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);

				for (int jx = 0; jx < bx; ++jx)
					for (int jz = 0; jz < bz; ++jz)
						exter_values[j * bnnz + sub2ind(bx, by, bz, jx, 0, jz) * bsize + sub2ind(bx, by, bz, jx, by - 1, jz)] = cy;
			}
		}
	}

	if (rx > 0)
	{
		int t = recvptr[nbind--];
		for (int iy = ny - 1; iy >= 0; --iy)
		{
			for (int iz = nz - 1; iz >= 0; --iz)
			{
				recvind[--t] = sub2ind(nx, ny, nz, nx - 1, iy, iz);
				int j = --exter_rowptr[sub2ind(nx, ny, nz, 0, iy, iz)];
				exter_colind[j] = t;
				BSRBlockFill(bsize, 0.0, exter_values + j * bnnz);

				for (int jy = 0; jy < by; ++jy)
					for (int jz = 0; jz < bz; ++jz)
						exter_values[j * bnnz + sub2ind(bx, by, bz, 0, jy, jz) * bsize + sub2ind(bx, by, bz, bx - 1, jy, jz)] = cx;
			}
		}
	}

	A.Free();
	A.comm = comm;
	A.local.size[0] = size;
	A.local.size[1] = size;
	A.local.bsize = bsize;
	A.local.rowptr = local_rowptr;
	A.local.colind = local_colind;
	A.local.values = local_values;
	A.exter.size[0] = size;
	A.exter.size[1] = recvptr[nnb];
	A.exter.bsize = bsize;
	A.exter.rowptr = exter_rowptr;
	A.exter.colind = exter_colind;
	A.exter.values = exter_values;
	A.nnb = nnb;
	A.nbrank = nbrank;
	A.recvptr = recvptr;
	A.recvind = recvind;
}

}