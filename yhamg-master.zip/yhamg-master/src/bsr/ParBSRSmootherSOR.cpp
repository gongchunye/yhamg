/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "BSRUnroll.hpp"
#include "ParBSRSmootherSOR.hpp"

#ifdef YHAMG_USE_OPENMP
#include <omp.h>
#endif

namespace YHAMG
{

ParBSRSmootherSOR::ParBSRSmootherSOR(int relaxation_type, double relaxation_factor)
	: nthd(0),
	D_LU(0),
	RelaxationType(relaxation_type),
	RelaxationFactor(relaxation_factor)
{
}

ParBSRSmootherSOR::~ParBSRSmootherSOR()
{
	if (D_LU) delete[] D_LU;
}

void ParBSRSmootherSOR::Setup(const ParBSRMatrix& A, int REUSE)
{
	int n = A.local.size[0];
	int bsize = A.local.bsize;
	int bnnz = bsize * bsize;

	int* Ap = A.local.rowptr;
	int* Ai = A.local.colind;
	double* Av = A.local.values;

	if (!REUSE)
	{
		if (D_LU) delete[] D_LU;
		nthd = 1;
#ifdef USE_ONED_PARTITION
		nthd = omp_get_max_threads();
#endif
		D_LU = new double[n * bnnz];
		z.comm = A.comm;
		z.Resize(n * bsize);
	}

#define BSR_UNROLL_SEGMENT(N) \
	for (int i = 0; i < n; ++i) \
	{ \
		for (int j = Ap[i]; j < Ap[i + 1]; ++j) \
		{ \
			if (Ai[j] == i) \
			{ \
				BSRBlockCopy_UNROLL(N, Av + j * N * N, D_LU + i * N * N); \
				BSRBlockLUFactorize_UNROLL(N, D_LU + i * N * N); \
				break; \
			} \
		} \
	}

#ifdef BSR_UNROLL_1
	if (bsize == 1)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		BSR_UNROLL_SEGMENT(1)
	}
	else
#endif
#ifdef BSR_UNROLL_2
	if (bsize == 2)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		BSR_UNROLL_SEGMENT(2)
	}
	else
#endif
#ifdef BSR_UNROLL_3
	if (bsize == 3)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		BSR_UNROLL_SEGMENT(3)
	}
	else
#endif
#ifdef BSR_UNROLL_4
	if (bsize == 4)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		BSR_UNROLL_SEGMENT(4)
	}
	else
#endif
#ifdef BSR_UNROLL_5
	if (bsize == 5)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		BSR_UNROLL_SEGMENT(5)
	}
	else
#endif
#ifdef BSR_UNROLL_6
	if (bsize == 6)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		BSR_UNROLL_SEGMENT(6)
	}
	else
#endif
#ifdef BSR_UNROLL_7
	if (bsize == 7)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		BSR_UNROLL_SEGMENT(7)
	}
	else
#endif
#ifdef BSR_UNROLL_8
	if (bsize == 8)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		BSR_UNROLL_SEGMENT(8)
	}
	else
#endif
#undef BSR_UNROLL_SEGMENT
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		for (int i = 0; i < n; ++i)
		{
			for (int j = Ap[i]; j < Ap[i + 1]; ++j)
			{
				if (Ai[j] == i)
				{
					BSRBlockCopy(bsize, Av + j * bnnz, D_LU + i * bnnz);
					BSRBlockLUFactorize(bsize, D_LU + i * bnnz);
					break;
				}
			}
		}
	}
}

void ParBSRSmootherSOR::Post(const ParBSRMatrix& A, const ParVector& b, const ParVector& x, int step) const
{
	int n = A.local.size[0];

	int bsize = A.local.bsize;
	int bnnz = bsize * bsize;

	int* local_rowptr = A.local.rowptr;
	int* local_colind = A.local.colind;
	double* local_values = A.local.values;
	int* exter_rowptr = A.exter.rowptr;
	int* exter_colind = A.exter.colind;
	double* exter_values = A.exter.values;

	double* xv_local = x.local.values;
	double* bv_local = b.local.values;
	double* zv_local = z.local.values;

	double* xv_recv = A.recvx.values;

	double omega = RelaxationFactor;

	A.ExchangeHalo(x);

	if (nthd == 1)
	{
		for (int k = 0; k < step; ++k)
		{
			if (RelaxationType == 0 || (RelaxationType == 2 && !(step - k & 1)))
			{
#define BSR_UNROLL_SEGMENT(N) \
for (int i = 0; i < n; ++i) \
{ \
double temp[N]; \
VecBlockCopy_UNROLL(N, bv_local + i * N, temp); \
for (int j = local_rowptr[i]; j < local_rowptr[i + 1]; ++j) \
	BSRBlockMatVecSub_UNROLL(N, local_values + j * N * N, xv_local + local_colind[j] * N, temp); \
for (int j = exter_rowptr[i]; j < exter_rowptr[i + 1]; ++j) \
	BSRBlockMatVecSub_UNROLL(N, exter_values + j * N * N, xv_recv + exter_colind[j] * N, temp); \
BSRBlockLUVecSolve_UNROLL(N, D_LU + i * N * N, temp); \
VecBlockScaleAdd_UNROLL(N, omega, temp, xv_local + i * N); \
}

#ifdef BSR_UNROLL_1
				if (bsize == 1) { BSR_UNROLL_SEGMENT(1) } else
#endif
#ifdef BSR_UNROLL_2
				if (bsize == 2) { BSR_UNROLL_SEGMENT(2) } else
#endif
#ifdef BSR_UNROLL_3
				if (bsize == 3) { BSR_UNROLL_SEGMENT(3) } else
#endif
#ifdef BSR_UNROLL_4
				if (bsize == 4) { BSR_UNROLL_SEGMENT(4) } else
#endif
#ifdef BSR_UNROLL_5
				if (bsize == 5) { BSR_UNROLL_SEGMENT(5) } else
#endif
#ifdef BSR_UNROLL_6
				if (bsize == 6) { BSR_UNROLL_SEGMENT(6) } else
#endif
#ifdef BSR_UNROLL_7
				if (bsize == 7) { BSR_UNROLL_SEGMENT(7) } else
#endif
#ifdef BSR_UNROLL_8
				if (bsize == 8) { BSR_UNROLL_SEGMENT(8) } else
#endif
#undef BSR_UNROLL_SEGMENT
				{
					double* temp = new double[bsize];
					for (int i = 0; i < n; ++i)
					{
						VecBlockCopy(bsize, bv_local + i * bsize, temp);
						for (int j = local_rowptr[i]; j < local_rowptr[i + 1]; ++j)
							BSRBlockMatVecSub(bsize, local_values + j * bnnz, xv_local + local_colind[j] * bsize, temp);
						for (int j = exter_rowptr[i]; j < exter_rowptr[i + 1]; ++j)
							BSRBlockMatVecSub(bsize, exter_values + j * bnnz, xv_recv + exter_colind[j] * bsize, temp);
						BSRBlockLUVecSolve(bsize, D_LU + i * bnnz, temp);
						VecBlockScaleAdd(bsize, omega, temp, xv_local + i * bsize);
					}
					delete[] temp;
				}
			}
			else if (RelaxationType == 1 || (RelaxationType == 2 && step - k & 1))
			{
#define BSR_UNROLL_SEGMENT(N) \
for (int i = n - 1; i >= 0; --i) \
{ \
double temp[N]; \
VecBlockCopy_UNROLL(N, bv_local + i * N, temp); \
for (int j = local_rowptr[i + 1] - 1; j >= local_rowptr[i]; --j) \
	BSRBlockMatVecSub_UNROLL(N, local_values + j * N * N, xv_local + local_colind[j] * N, temp); \
for (int j = exter_rowptr[i + 1] - 1; j >= exter_rowptr[i]; --j) \
	BSRBlockMatVecSub_UNROLL(N, exter_values + j * N * N, xv_recv + exter_colind[j] * N, temp); \
BSRBlockLUVecSolve_UNROLL(N, D_LU + i * N * N, temp); \
VecBlockScaleAdd_UNROLL(N, omega, temp, xv_local + i * N); \
}

#ifdef BSR_UNROLL_1
				if (bsize == 1) { BSR_UNROLL_SEGMENT(1) } else
#endif
#ifdef BSR_UNROLL_2
				if (bsize == 2) { BSR_UNROLL_SEGMENT(2) } else
#endif
#ifdef BSR_UNROLL_3
				if (bsize == 3) { BSR_UNROLL_SEGMENT(3) } else
#endif
#ifdef BSR_UNROLL_4
				if (bsize == 4) { BSR_UNROLL_SEGMENT(4) } else
#endif
#ifdef BSR_UNROLL_5
				if (bsize == 5) { BSR_UNROLL_SEGMENT(5) } else
#endif
#ifdef BSR_UNROLL_6
				if (bsize == 6) { BSR_UNROLL_SEGMENT(6) } else
#endif
#ifdef BSR_UNROLL_7
				if (bsize == 7) { BSR_UNROLL_SEGMENT(7) } else
#endif
#ifdef BSR_UNROLL_8
				if (bsize == 8) { BSR_UNROLL_SEGMENT(8) } else
#endif
#undef BSR_UNROLL_SEGMENT
				{
					double* temp = new double[bsize];
					for (int i = n - 1; i >= 0; --i)
					{
						VecBlockCopy(bsize, bv_local + i * bsize, temp);
						for (int j = local_rowptr[i + 1] - 1; j >= local_rowptr[i]; --j)
							BSRBlockMatVecSub(bsize, local_values + j * bnnz, xv_local + local_colind[j] * bsize, temp);
						for (int j = exter_rowptr[i + 1] - 1; j >= exter_rowptr[i]; --j)
							BSRBlockMatVecSub(bsize, exter_values + j * bnnz, xv_recv + exter_colind[j] * bsize, temp);
						BSRBlockLUVecSolve(bsize, D_LU + i * bnnz, temp);
						VecBlockScaleAdd(bsize, omega, temp, xv_local + i * bsize);
					}
					delete[] temp;
				}
			}
		}
	}
	else
	{
		z.Copy(x);
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
		for (int t = 0; t < nthd; ++t)
		{
			int begin = n * t / nthd;
			int end = n * (t + 1) / nthd;

			for (int k = 0; k < step; ++k)
			{
				if (RelaxationType == 0 || (RelaxationType == 2 && !(step - k & 1)))
				{
#define BSR_UNROLL_SEGMENT(N) \
for (int i = begin; i < end; ++i) \
{ \
double temp[N]; \
VecBlockCopy_UNROLL(N, bv_local + i * N, temp); \
for (int j = local_rowptr[i]; j < local_rowptr[i + 1]; ++j) \
{ \
	if (local_colind[j] < begin || local_colind[j] >= end) \
		BSRBlockMatVecSub_UNROLL(N, local_values + j * N * N, zv_local + local_colind[j] * N, temp); \
	else \
		BSRBlockMatVecSub_UNROLL(N, local_values + j * N * N, xv_local + local_colind[j] * N, temp); \
} \
for (int j = exter_rowptr[i]; j < exter_rowptr[i + 1]; ++j) \
	BSRBlockMatVecSub_UNROLL(N, exter_values + j * N * N, xv_recv + exter_colind[j] * N, temp); \
BSRBlockLUVecSolve_UNROLL(N, D_LU + i * N * N, temp); \
VecBlockScaleAdd_UNROLL(N, omega, temp, xv_local + i * N); \
}

#ifdef BSR_UNROLL_1
					if (bsize == 1) { BSR_UNROLL_SEGMENT(1) } else
#endif
#ifdef BSR_UNROLL_2
					if (bsize == 2) { BSR_UNROLL_SEGMENT(2) } else
#endif
#ifdef BSR_UNROLL_3
					if (bsize == 3) { BSR_UNROLL_SEGMENT(3) } else
#endif
#ifdef BSR_UNROLL_4
					if (bsize == 4) { BSR_UNROLL_SEGMENT(4) } else
#endif
#ifdef BSR_UNROLL_5
					if (bsize == 5) { BSR_UNROLL_SEGMENT(5) } else
#endif
#ifdef BSR_UNROLL_6
					if (bsize == 6) { BSR_UNROLL_SEGMENT(6) } else
#endif
#ifdef BSR_UNROLL_7
					if (bsize == 7) { BSR_UNROLL_SEGMENT(7) } else
#endif
#ifdef BSR_UNROLL_8
					if (bsize == 8) { BSR_UNROLL_SEGMENT(8) } else
#endif
#undef BSR_UNROLL_SEGMENT
					{
						double* temp = new double[bsize];
						for (int i = begin; i < end; ++i)
						{
							VecBlockCopy(bsize, bv_local + i * bsize, temp);
							for (int j = local_rowptr[i]; j < local_rowptr[i + 1]; ++j)
							{
								if (local_colind[j] < begin || local_colind[j] >= end)
									BSRBlockMatVecSub(bsize, local_values + j * bnnz, zv_local + local_colind[j] * bsize, temp);
								else
									BSRBlockMatVecSub(bsize, local_values + j * bnnz, xv_local + local_colind[j] * bsize, temp);
							}
							for (int j = exter_rowptr[i]; j < exter_rowptr[i + 1]; ++j)
								BSRBlockMatVecSub(bsize, exter_values + j * bnnz, xv_recv + exter_colind[j] * bsize, temp);
							BSRBlockLUVecSolve(bsize, D_LU + i * bnnz, temp);
							VecBlockScaleAdd(bsize, omega, temp, xv_local + i * bsize);
						}
						delete[] temp;
					}
				}		
				else if (RelaxationType == 1 || (RelaxationType == 2 && step - k & 1))
				{
#define BSR_UNROLL_SEGMENT(N) \
for (int i = end - 1; i >= begin; --i) \
{ \
double temp[N]; \
VecBlockCopy_UNROLL(N, bv_local + i * N, temp); \
for (int j = local_rowptr[i + 1] - 1; j >= local_rowptr[i]; --j) \
{ \
	if (local_colind[j] < begin || local_colind[j] >= end) \
		BSRBlockMatVecSub_UNROLL(N, local_values + j * N * N, zv_local + local_colind[j] * N, temp); \
	else \
		BSRBlockMatVecSub_UNROLL(N, local_values + j * N * N, xv_local + local_colind[j] * N, temp); \
} \
for (int j = exter_rowptr[i + 1] - 1; j >= exter_rowptr[i]; --j) \
	BSRBlockMatVecSub_UNROLL(N, exter_values + j * N * N, xv_recv + exter_colind[j] * N, temp); \
BSRBlockLUVecSolve_UNROLL(N, D_LU + i * N * N, temp); \
VecBlockScaleAdd_UNROLL(N, omega, temp, xv_local + i * N); \
}

#ifdef BSR_UNROLL_1
					if (bsize == 1) { BSR_UNROLL_SEGMENT(1) } else
#endif
#ifdef BSR_UNROLL_2
					if (bsize == 2) { BSR_UNROLL_SEGMENT(2) } else
#endif
#ifdef BSR_UNROLL_3
					if (bsize == 3) { BSR_UNROLL_SEGMENT(3) } else
#endif
#ifdef BSR_UNROLL_4
					if (bsize == 4) { BSR_UNROLL_SEGMENT(4) } else
#endif
#ifdef BSR_UNROLL_5
					if (bsize == 5) { BSR_UNROLL_SEGMENT(5) } else
#endif
#ifdef BSR_UNROLL_6
					if (bsize == 6) { BSR_UNROLL_SEGMENT(6) } else
#endif
#ifdef BSR_UNROLL_7
					if (bsize == 7) { BSR_UNROLL_SEGMENT(7) } else
#endif
#ifdef BSR_UNROLL_8
					if (bsize == 8) { BSR_UNROLL_SEGMENT(8) } else
#endif
#undef BSR_UNROLL_SEGMENT
					{
						double* temp = new double[bsize];
						for (int i = end - 1; i >= begin; --i)
						{
							VecBlockCopy(bsize, bv_local + i * bsize, temp);
							for (int j = local_rowptr[i + 1] - 1; j >= local_rowptr[i]; --j)
							{
								if (local_colind[j] < begin || local_colind[j] >= end)
									BSRBlockMatVecSub(bsize, local_values + j * bnnz, zv_local + local_colind[j] * bsize, temp);
								else
									BSRBlockMatVecSub(bsize, local_values + j * bnnz, xv_local + local_colind[j] * bsize, temp);
							}
							for (int j = exter_rowptr[i + 1] - 1; j >= exter_rowptr[i]; --j)
								BSRBlockMatVecSub(bsize, exter_values + j * bnnz, xv_recv + exter_colind[j] * bsize, temp);
							BSRBlockLUVecSolve(bsize, D_LU + i * bnnz, temp);
							VecBlockScaleAdd(bsize, omega, temp, xv_local + i * bsize);
						}
						delete[] temp;
					}
				}
			}
		}
	}
}

void ParBSRSmootherSOR::operator()(const ParBSRMatrix& A, const ParVector& b, const ParVector& x, int step, bool x0zero) const
{
	int n = A.local.size[0];

	int bsize = A.local.bsize;
	int bnnz = bsize * bsize;

	int* local_rowptr = A.local.rowptr;
	int* local_colind = A.local.colind;
	double* local_values = A.local.values;
	int* exter_rowptr = A.exter.rowptr;
	int* exter_colind = A.exter.colind;
	double* exter_values = A.exter.values;

	double* xv_local = x.local.values;
	double* bv_local = b.local.values;
	double* zv_local = z.local.values;

	double* xv_recv = A.recvx.values;

	double omega = RelaxationFactor;

	if (!x0zero)
	{
		A.ExchangeHalo(x);

		if (nthd == 1)
		{
			for (int k = 0; k < step; ++k)
			{
				if (RelaxationType == 0 || (RelaxationType == 2 && !(k & 1)))
				{
#define BSR_UNROLL_SEGMENT(N) \
for (int i = 0; i < n; ++i) \
{ \
	double temp[N]; \
	VecBlockCopy_UNROLL(N, bv_local + i * N, temp); \
	for (int j = local_rowptr[i]; j < local_rowptr[i + 1]; ++j) \
		BSRBlockMatVecSub_UNROLL(N, local_values + j * N * N, xv_local + local_colind[j] * N, temp); \
	for (int j = exter_rowptr[i]; j < exter_rowptr[i + 1]; ++j) \
		BSRBlockMatVecSub_UNROLL(N, exter_values + j * N * N, xv_recv + exter_colind[j] * N, temp); \
	BSRBlockLUVecSolve_UNROLL(N, D_LU + i * N * N, temp); \
	VecBlockScaleAdd_UNROLL(N, omega, temp, xv_local + i * N); \
}

#ifdef BSR_UNROLL_1
					if (bsize == 1) { BSR_UNROLL_SEGMENT(1) } else
#endif
#ifdef BSR_UNROLL_2
					if (bsize == 2) { BSR_UNROLL_SEGMENT(2) } else
#endif
#ifdef BSR_UNROLL_3
					if (bsize == 3) { BSR_UNROLL_SEGMENT(3) } else
#endif
#ifdef BSR_UNROLL_4
					if (bsize == 4) { BSR_UNROLL_SEGMENT(4) } else
#endif
#ifdef BSR_UNROLL_5
					if (bsize == 5) { BSR_UNROLL_SEGMENT(5) } else
#endif
#ifdef BSR_UNROLL_6
					if (bsize == 6) { BSR_UNROLL_SEGMENT(6) } else
#endif
#ifdef BSR_UNROLL_7
					if (bsize == 7) { BSR_UNROLL_SEGMENT(7) } else
#endif
#ifdef BSR_UNROLL_8
					if (bsize == 8) { BSR_UNROLL_SEGMENT(8) } else
#endif
#undef BSR_UNROLL_SEGMENT
					{
						double* temp = new double[bsize];
						for (int i = 0; i < n; ++i)
						{
							VecBlockCopy(bsize, bv_local + i * bsize, temp);
							for (int j = local_rowptr[i]; j < local_rowptr[i + 1]; ++j)
								BSRBlockMatVecSub(bsize, local_values + j * bnnz, xv_local + local_colind[j] * bsize, temp);
							for (int j = exter_rowptr[i]; j < exter_rowptr[i + 1]; ++j)
								BSRBlockMatVecSub(bsize, exter_values + j * bnnz, xv_recv + exter_colind[j] * bsize, temp);
							BSRBlockLUVecSolve(bsize, D_LU + i * bnnz, temp);
							VecBlockScaleAdd(bsize, omega, temp, xv_local + i * bsize);
						}
						delete[] temp;
					}
				}
				else if (RelaxationType == 1 || (RelaxationType == 2 && k & 1))
				{
#define BSR_UNROLL_SEGMENT(N) \
for (int i = n - 1; i >= 0; --i) \
{ \
	double temp[N]; \
	VecBlockCopy_UNROLL(N, bv_local + i * N, temp); \
	for (int j = local_rowptr[i + 1] - 1; j >= local_rowptr[i]; --j) \
		BSRBlockMatVecSub_UNROLL(N, local_values + j * N * N, xv_local + local_colind[j] * N, temp); \
	for (int j = exter_rowptr[i + 1] - 1; j >= exter_rowptr[i]; --j) \
		BSRBlockMatVecSub_UNROLL(N, exter_values + j * N * N, xv_recv + exter_colind[j] * N, temp); \
	BSRBlockLUVecSolve_UNROLL(N, D_LU + i * N * N, temp); \
	VecBlockScaleAdd_UNROLL(N, omega, temp, xv_local + i * N); \
}

#ifdef BSR_UNROLL_1
					if (bsize == 1) { BSR_UNROLL_SEGMENT(1) } else
#endif
#ifdef BSR_UNROLL_2
					if (bsize == 2) { BSR_UNROLL_SEGMENT(2) } else
#endif
#ifdef BSR_UNROLL_3
					if (bsize == 3) { BSR_UNROLL_SEGMENT(3) } else
#endif
#ifdef BSR_UNROLL_4
					if (bsize == 4) { BSR_UNROLL_SEGMENT(4) } else
#endif
#ifdef BSR_UNROLL_5
					if (bsize == 5) { BSR_UNROLL_SEGMENT(5) } else
#endif
#ifdef BSR_UNROLL_6
					if (bsize == 6) { BSR_UNROLL_SEGMENT(6) } else
#endif
#ifdef BSR_UNROLL_7
					if (bsize == 7) { BSR_UNROLL_SEGMENT(7) } else
#endif
#ifdef BSR_UNROLL_8
					if (bsize == 8) { BSR_UNROLL_SEGMENT(8) } else
#endif
#undef BSR_UNROLL_SEGMENT
					{
						double* temp = new double[bsize];
						for (int i = n - 1; i >= 0; --i)
						{
							VecBlockCopy(bsize, bv_local + i * bsize, temp);
							for (int j = local_rowptr[i + 1] - 1; j >= local_rowptr[i]; --j)
								BSRBlockMatVecSub(bsize, local_values + j * bnnz, xv_local + local_colind[j] * bsize, temp);
							for (int j = exter_rowptr[i + 1] - 1; j >= exter_rowptr[i]; --j)
								BSRBlockMatVecSub(bsize, exter_values + j * bnnz, xv_recv + exter_colind[j] * bsize, temp);
							BSRBlockLUVecSolve(bsize, D_LU + i * bnnz, temp);
							VecBlockScaleAdd(bsize, omega, temp, xv_local + i * bsize);
						}
						delete[] temp;
					}
				}
			}
		}
		else
		{
			z.Copy(x);
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			for (int t = 0; t < nthd; ++t)
			{
				int begin = n * t / nthd;
				int end = n * (t + 1) / nthd;

				for (int k = 0; k < step; ++k)
				{
					if (RelaxationType == 0 || (RelaxationType == 2 && !(k & 1)))
					{
#define BSR_UNROLL_SEGMENT(N) \
for (int i = begin; i < end; ++i) \
{ \
	double temp[N]; \
	VecBlockCopy_UNROLL(N, bv_local + i * N, temp); \
	for (int j = local_rowptr[i]; j < local_rowptr[i + 1]; ++j) \
	{ \
		if (local_colind[j] < begin || local_colind[j] >= end) \
			BSRBlockMatVecSub_UNROLL(N, local_values + j * N * N, zv_local + local_colind[j] * N, temp); \
		else \
			BSRBlockMatVecSub_UNROLL(N, local_values + j * N * N, xv_local + local_colind[j] * N, temp); \
	} \
	for (int j = exter_rowptr[i]; j < exter_rowptr[i + 1]; ++j) \
		BSRBlockMatVecSub_UNROLL(N, exter_values + j * N * N, xv_recv + exter_colind[j] * N, temp); \
	BSRBlockLUVecSolve_UNROLL(N, D_LU + i * N * N, temp); \
	VecBlockScaleAdd_UNROLL(N, omega, temp, xv_local + i * N); \
}

#ifdef BSR_UNROLL_1
						if (bsize == 1) { BSR_UNROLL_SEGMENT(1) } else
#endif
#ifdef BSR_UNROLL_2
						if (bsize == 2) { BSR_UNROLL_SEGMENT(2) } else
#endif
#ifdef BSR_UNROLL_3
						if (bsize == 3) { BSR_UNROLL_SEGMENT(3) } else
#endif
#ifdef BSR_UNROLL_4
						if (bsize == 4) { BSR_UNROLL_SEGMENT(4) } else
#endif
#ifdef BSR_UNROLL_5
						if (bsize == 5) { BSR_UNROLL_SEGMENT(5) } else
#endif
#ifdef BSR_UNROLL_6
						if (bsize == 6) { BSR_UNROLL_SEGMENT(6) } else
#endif
#ifdef BSR_UNROLL_7
						if (bsize == 7) { BSR_UNROLL_SEGMENT(7) } else
#endif
#ifdef BSR_UNROLL_8
						if (bsize == 8) { BSR_UNROLL_SEGMENT(8) } else
#endif
#undef BSR_UNROLL_SEGMENT
						{
							double* temp = new double[bsize];
							for (int i = begin; i < end; ++i)
							{
								VecBlockCopy(bsize, bv_local + i * bsize, temp);
								for (int j = local_rowptr[i]; j < local_rowptr[i + 1]; ++j)
								{
									if (local_colind[j] < begin || local_colind[j] >= end)
										BSRBlockMatVecSub(bsize, local_values + j * bnnz, zv_local + local_colind[j] * bsize, temp);
									else
										BSRBlockMatVecSub(bsize, local_values + j * bnnz, xv_local + local_colind[j] * bsize, temp);
								}
								for (int j = exter_rowptr[i]; j < exter_rowptr[i + 1]; ++j)
									BSRBlockMatVecSub(bsize, exter_values + j * bnnz, xv_recv + exter_colind[j] * bsize, temp);
								BSRBlockLUVecSolve(bsize, D_LU + i * bnnz, temp);
								VecBlockScaleAdd(bsize, omega, temp, xv_local + i * bsize);
							}
							delete[] temp;
						}
					}		
					else if (RelaxationType == 1 || (RelaxationType == 2 && k & 1))
					{
#define BSR_UNROLL_SEGMENT(N) \
for (int i = end - 1; i >= begin; --i) \
{ \
	double temp[N]; \
	VecBlockCopy_UNROLL(N, bv_local + i * N, temp); \
	for (int j = local_rowptr[i + 1] - 1; j >= local_rowptr[i]; --j) \
	{ \
		if (local_colind[j] < begin || local_colind[j] >= end) \
			BSRBlockMatVecSub_UNROLL(N, local_values + j * N * N, zv_local + local_colind[j] * N, temp); \
		else \
			BSRBlockMatVecSub_UNROLL(N, local_values + j * N * N, xv_local + local_colind[j] * N, temp); \
	} \
	for (int j = exter_rowptr[i + 1] - 1; j >= exter_rowptr[i]; --j) \
		BSRBlockMatVecSub_UNROLL(N, exter_values + j * N * N, xv_recv + exter_colind[j] * N, temp); \
	BSRBlockLUVecSolve_UNROLL(N, D_LU + i * N * N, temp); \
	VecBlockScaleAdd_UNROLL(N, omega, temp, xv_local + i * N); \
}

#ifdef BSR_UNROLL_1
						if (bsize == 1) { BSR_UNROLL_SEGMENT(1) } else
#endif
#ifdef BSR_UNROLL_2
						if (bsize == 2) { BSR_UNROLL_SEGMENT(2) } else
#endif
#ifdef BSR_UNROLL_3
						if (bsize == 3) { BSR_UNROLL_SEGMENT(3) } else
#endif
#ifdef BSR_UNROLL_4
						if (bsize == 4) { BSR_UNROLL_SEGMENT(4) } else
#endif
#ifdef BSR_UNROLL_5
						if (bsize == 5) { BSR_UNROLL_SEGMENT(5) } else
#endif
#ifdef BSR_UNROLL_6
						if (bsize == 6) { BSR_UNROLL_SEGMENT(6) } else
#endif
#ifdef BSR_UNROLL_7
						if (bsize == 7) { BSR_UNROLL_SEGMENT(7) } else
#endif
#ifdef BSR_UNROLL_8
						if (bsize == 8) { BSR_UNROLL_SEGMENT(8) } else
#endif
#undef BSR_UNROLL_SEGMENT
						{
							double* temp = new double[bsize];
							for (int i = end - 1; i >= begin; --i)
							{
								VecBlockCopy(bsize, bv_local + i * bsize, temp);
								for (int j = local_rowptr[i + 1] - 1; j >= local_rowptr[i]; --j)
								{
									if (local_colind[j] < begin || local_colind[j] >= end)
										BSRBlockMatVecSub(bsize, local_values + j * bnnz, zv_local + local_colind[j] * bsize, temp);
									else
										BSRBlockMatVecSub(bsize, local_values + j * bnnz, xv_local + local_colind[j] * bsize, temp);
								}
								for (int j = exter_rowptr[i + 1] - 1; j >= exter_rowptr[i]; --j)
									BSRBlockMatVecSub(bsize, exter_values + j * bnnz, xv_recv + exter_colind[j] * bsize, temp);
								BSRBlockLUVecSolve(bsize, D_LU + i * bnnz, temp);
								VecBlockScaleAdd(bsize, omega, temp, xv_local + i * bsize);
							}
							delete[] temp;
						}
					}
				}
			}
		}
	}
	else
	{
		if (nthd == 1)
		{
			for (int k = 0; k < step; ++k)
			{
				if (RelaxationType == 0 || (RelaxationType == 2 && !(k & 1)))
				{
#define BSR_UNROLL_SEGMENT(N) \
for (int i = 0; i < n; ++i) \
{ \
	double temp[N]; \
	VecBlockCopy_UNROLL(N, bv_local + i * N, temp); \
	for (int j = local_rowptr[i]; j < local_rowptr[i + 1]; ++j) \
		BSRBlockMatVecSub_UNROLL(N, local_values + j * N * N, xv_local + local_colind[j] * N, temp); \
	BSRBlockLUVecSolve_UNROLL(N, D_LU + i * N * N, temp); \
	VecBlockScaleAdd_UNROLL(N, omega, temp, xv_local + i * N); \
}

#ifdef BSR_UNROLL_1
					if (bsize == 1) { BSR_UNROLL_SEGMENT(1) } else
#endif
#ifdef BSR_UNROLL_2
					if (bsize == 2) { BSR_UNROLL_SEGMENT(2) } else
#endif
#ifdef BSR_UNROLL_3
					if (bsize == 3) { BSR_UNROLL_SEGMENT(3) } else
#endif
#ifdef BSR_UNROLL_4
					if (bsize == 4) { BSR_UNROLL_SEGMENT(4) } else
#endif
#ifdef BSR_UNROLL_5
					if (bsize == 5) { BSR_UNROLL_SEGMENT(5) } else
#endif
#ifdef BSR_UNROLL_6
					if (bsize == 6) { BSR_UNROLL_SEGMENT(6) } else
#endif
#ifdef BSR_UNROLL_7
					if (bsize == 7) { BSR_UNROLL_SEGMENT(7) } else
#endif
#ifdef BSR_UNROLL_8
					if (bsize == 8) { BSR_UNROLL_SEGMENT(8) } else
#endif
#undef BSR_UNROLL_SEGMENT
					{
						double* temp = new double[bsize];
						for (int i = 0; i < n; ++i)
						{
							VecBlockCopy(bsize, bv_local + i * bsize, temp);
							for (int j = local_rowptr[i]; j < local_rowptr[i + 1]; ++j)
								BSRBlockMatVecSub(bsize, local_values + j * bnnz, xv_local + local_colind[j] * bsize, temp);
							BSRBlockLUVecSolve(bsize, D_LU + i * bnnz, temp);
							VecBlockScaleAdd(bsize, omega, temp, xv_local + i * bsize);
						}
						delete[] temp;
					}
				}
				else if (RelaxationType == 1 || (RelaxationType == 2 && k & 1))
				{
#define BSR_UNROLL_SEGMENT(N) \
for (int i = n - 1; i >= 0; --i) \
{ \
	double temp[N]; \
	VecBlockCopy_UNROLL(N, bv_local + i * N, temp); \
	for (int j = local_rowptr[i + 1] - 1; j >= local_rowptr[i]; --j) \
		BSRBlockMatVecSub_UNROLL(N, local_values + j * N * N, xv_local + local_colind[j] * N, temp); \
	BSRBlockLUVecSolve_UNROLL(N, D_LU + i * N * N, temp); \
	VecBlockScaleAdd_UNROLL(N, omega, temp, xv_local + i * N); \
}

#ifdef BSR_UNROLL_1
					if (bsize == 1) { BSR_UNROLL_SEGMENT(1) } else
#endif
#ifdef BSR_UNROLL_2
					if (bsize == 2) { BSR_UNROLL_SEGMENT(2) } else
#endif
#ifdef BSR_UNROLL_3
					if (bsize == 3) { BSR_UNROLL_SEGMENT(3) } else
#endif
#ifdef BSR_UNROLL_4
					if (bsize == 4) { BSR_UNROLL_SEGMENT(4) } else
#endif
#ifdef BSR_UNROLL_5
					if (bsize == 5) { BSR_UNROLL_SEGMENT(5) } else
#endif
#ifdef BSR_UNROLL_6
					if (bsize == 6) { BSR_UNROLL_SEGMENT(6) } else
#endif
#ifdef BSR_UNROLL_7
					if (bsize == 7) { BSR_UNROLL_SEGMENT(7) } else
#endif
#ifdef BSR_UNROLL_8
					if (bsize == 8) { BSR_UNROLL_SEGMENT(8) } else
#endif
#undef BSR_UNROLL_SEGMENT
					{
						double* temp = new double[bsize];
						for (int i = n - 1; i >= 0; --i)
						{
							VecBlockCopy(bsize, bv_local + i * bsize, temp);
							for (int j = local_rowptr[i + 1] - 1; j >= local_rowptr[i]; --j)
								BSRBlockMatVecSub(bsize, local_values + j * bnnz, xv_local + local_colind[j] * bsize, temp);
							BSRBlockLUVecSolve(bsize, D_LU + i * bnnz, temp);
							VecBlockScaleAdd(bsize, omega, temp, xv_local + i * bsize);
						}
						delete[] temp;
					}
				}
			}
		}
		else
		{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
			for (int t = 0; t < nthd; ++t)
			{
				int begin = n * t / nthd;
				int end = n * (t + 1) / nthd;

				for (int k = 0; k < step; ++k)
				{
					if (RelaxationType == 0 || (RelaxationType == 2 && !(k & 1)))
					{
#define BSR_UNROLL_SEGMENT(N) \
for (int i = begin; i < end; ++i) \
{ \
	double temp[N]; \
	VecBlockCopy_UNROLL(N, bv_local + i * N, temp); \
	for (int j = local_rowptr[i]; j < local_rowptr[i + 1]; ++j) \
		if (local_colind[j] >= begin && local_colind[j] < end) \
			BSRBlockMatVecSub_UNROLL(N, local_values + j * N * N, xv_local + local_colind[j] * N, temp); \
	BSRBlockLUVecSolve_UNROLL(N, D_LU + i * N * N, temp); \
	VecBlockScaleAdd_UNROLL(N, omega, temp, xv_local + i * N); \
}

#ifdef BSR_UNROLL_1
						if (bsize == 1) { BSR_UNROLL_SEGMENT(1) } else
#endif
#ifdef BSR_UNROLL_2
						if (bsize == 2) { BSR_UNROLL_SEGMENT(2) } else
#endif
#ifdef BSR_UNROLL_3
						if (bsize == 3) { BSR_UNROLL_SEGMENT(3) } else
#endif
#ifdef BSR_UNROLL_4
						if (bsize == 4) { BSR_UNROLL_SEGMENT(4) } else
#endif
#ifdef BSR_UNROLL_5
						if (bsize == 5) { BSR_UNROLL_SEGMENT(5) } else
#endif
#ifdef BSR_UNROLL_6
						if (bsize == 6) { BSR_UNROLL_SEGMENT(6) } else
#endif
#ifdef BSR_UNROLL_7
						if (bsize == 7) { BSR_UNROLL_SEGMENT(7) } else
#endif
#ifdef BSR_UNROLL_8
						if (bsize == 8) { BSR_UNROLL_SEGMENT(8) } else
#endif
#undef BSR_UNROLL_SEGMENT
						{
							double* temp = new double[bsize];
							for (int i = begin; i < end; ++i)
							{
								VecBlockCopy(bsize, bv_local + i * bsize, temp);
								for (int j = local_rowptr[i]; j < local_rowptr[i + 1]; ++j)
									if (local_colind[j] >= begin && local_colind[j] < end)
										BSRBlockMatVecSub(bsize, local_values + j * bnnz, xv_local + local_colind[j] * bsize, temp);
								BSRBlockLUVecSolve(bsize, D_LU + i * bnnz, temp);
								VecBlockScaleAdd(bsize, omega, temp, xv_local + i * bsize);
							}
							delete[] temp;
						}
					}
					else if (RelaxationType == 1 || (RelaxationType == 2 && k & 1))
					{
#define BSR_UNROLL_SEGMENT(N) \
for (int i = end - 1; i >= begin; --i) \
{ \
	double temp[N]; \
	VecBlockCopy_UNROLL(N, bv_local + i * N, temp); \
	for (int j = local_rowptr[i + 1] - 1; j >= local_rowptr[i]; --j) \
		if (local_colind[j] >= begin && local_colind[j] < end) \
			BSRBlockMatVecSub_UNROLL(N, local_values + j * N * N, xv_local + local_colind[j] * N, temp); \
	BSRBlockLUVecSolve_UNROLL(N, D_LU + i * N * N, temp); \
	VecBlockScaleAdd_UNROLL(N, omega, temp, xv_local + i * N); \
}

#ifdef BSR_UNROLL_1
						if (bsize == 1) { BSR_UNROLL_SEGMENT(1) } else
#endif
#ifdef BSR_UNROLL_2
						if (bsize == 2) { BSR_UNROLL_SEGMENT(2) } else
#endif
#ifdef BSR_UNROLL_3
						if (bsize == 3) { BSR_UNROLL_SEGMENT(3) } else
#endif
#ifdef BSR_UNROLL_4
						if (bsize == 4) { BSR_UNROLL_SEGMENT(4) } else
#endif
#ifdef BSR_UNROLL_5
						if (bsize == 5) { BSR_UNROLL_SEGMENT(5) } else
#endif
#ifdef BSR_UNROLL_6
						if (bsize == 6) { BSR_UNROLL_SEGMENT(6) } else
#endif
#ifdef BSR_UNROLL_7
						if (bsize == 7) { BSR_UNROLL_SEGMENT(7) } else
#endif
#ifdef BSR_UNROLL_8
						if (bsize == 8) { BSR_UNROLL_SEGMENT(8) } else
#endif
#undef BSR_UNROLL_SEGMENT
						{
							double* temp = new double[bsize];
							for (int i = end - 1; i >= begin; --i)
							{
								VecBlockCopy(bsize, bv_local + i * bsize, temp);
								for (int j = local_rowptr[i + 1] - 1; j >= local_rowptr[i]; --j)
									if (local_colind[j] >= begin && local_colind[j] < end)
										BSRBlockMatVecSub(bsize, local_values + j * bnnz, xv_local + local_colind[j] * bsize, temp);
								BSRBlockLUVecSolve(bsize, D_LU + i * bnnz, temp);
								VecBlockScaleAdd(bsize, omega, temp, xv_local + i * bsize);
							}
							delete[] temp;
						}
					}
				}
			}
		}
	}
}

}