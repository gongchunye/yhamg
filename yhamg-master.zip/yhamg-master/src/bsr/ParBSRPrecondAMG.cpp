/* Copyright (c) 2021-2022, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <iostream>
#include "BSRUnroll.hpp"
#include "ParBSRSmootherJacobi.hpp"
#include "ParBSRSmootherSOR.hpp"
#include "ParBSRSmootherILU.hpp"
#include "ParBSRSmootherChebyshev.hpp"
#include "ParBSRPrecondAMG.hpp"
#include "RugeStuben.hpp"

#ifdef YHAMG_USE_OPENMP
#include <omp.h>
#endif

namespace YHAMG
{

#define MPI_TAG 400

class ParBSRPrecondAMG::Smoother
{
private:
	ParBSRSmoother* _;

public:
	Smoother()
	: _(0)
	{
	}

	~Smoother()
	{
		if (_) delete _;
	}

	void SetupJacobi(const ParBSRMatrix& A, double RelaxationFactor)
	{
		if (_) delete _;
		_ = new ParBSRSmootherJacobi(RelaxationFactor);
		_->Setup(A, 0);
	}

	void SetupSOR(const ParBSRMatrix& A, int RelaxationType, double RelaxationFactor)
	{
		if (_) delete _;
		_ = new ParBSRSmootherSOR(RelaxationType, RelaxationFactor);
		_->Setup(A, 0);
	}

	void SetupILU(const ParBSRMatrix& A, int MaxFillins, double DropTolerance)
	{
		if (_) delete _;
		_ = new ParBSRSmootherILU(MaxFillins, DropTolerance);
		_->Setup(A, 0);
	}

	void SetupChebyshev(const ParBSRMatrix& A, double EigenRatio)
	{
		if (_) delete _;
		_ = new ParBSRSmootherChebyshev(EigenRatio);
		_->Setup(A, 0);
	}

	void SetupReuse(const ParBSRMatrix& A)
	{
		_->Setup(A, 1);
	}

	void Pre(const ParBSRMatrix& A, const ParVector& b, const ParVector& x, int step, bool x0zero = 0) const
	{
		_->Pre(A, b, x, step, x0zero);
	}

	void Post(const ParBSRMatrix& A, const ParVector& b, const ParVector& x, int step) const
	{
		_->Post(A, b, x, step);
	}

	void Coarse(const ParBSRMatrix& A, const ParVector& b, const ParVector& x, int step, bool x0zero = 0) const
	{
		_->Pre(A, b, x, step, x0zero);
	}
};

#define NODAL(val) BSRBlockSum(bsize, val)

static void ParBSRReduce(const ParBSRMatrix& A, ParCSRMatrix& B)
{
	MPI_Comm comm = A.comm;
	int n = A.local.size[0];
	int recvcnt = A.exter.size[1];

	int bsize = A.local.bsize;
	int bnnz = bsize * bsize;

	int* A_local_rowptr = A.local.rowptr;
	int* A_local_colind = A.local.colind;
	double* A_local_values = A.local.values;

	int* A_exter_rowptr = A.exter.rowptr;
	int* A_exter_colind = A.exter.colind;
	double* A_exter_values = A.exter.values;

	int A_nnb = A.nnb;
	int* A_nbrank = A.nbrank;
	int* A_recvptr = A.recvptr;
	int* A_recvind = A.recvind;

	int* B_local_rowptr = new int[n + 1];
	int* B_local_colind = new int[A_local_rowptr[n]];
	double* B_local_values = new double[A_local_rowptr[n]];
	int* B_exter_rowptr = new int[n + 1];
	int* B_exter_colind = new int[A_exter_rowptr[n]];
	double* B_exter_values = new double[A_exter_rowptr[n]];
	
	int nnb = A.nnb;
	int* B_nbrank = new int[nnb];
	int* B_recvptr = new int[nnb + 1];
	int* B_recvind = new int[recvcnt];

	for (int i = 0; i <= n; ++i)
		B_local_rowptr[i] = A_local_rowptr[i];
	for (int i = 0; i <= n; ++i)
		B_exter_rowptr[i] = A_exter_rowptr[i];

 	for (int j = 0; j < A_local_rowptr[n]; ++j)
	{
		B_local_colind[j] = A_local_colind[j];
		B_local_values[j] = NODAL(A_local_values + j * bnnz);
	}
	for (int j = 0; j < A_exter_rowptr[n]; ++j)
	{
		B_exter_colind[j] = A_exter_colind[j];
		B_exter_values[j] = NODAL(A_exter_values + j * bnnz);
	}
	for (int r = 0; r < nnb; ++r)
		B_nbrank[r] = A_nbrank[r];
	for (int r = 0; r <= nnb; ++r)
		B_recvptr[r] = A_recvptr[r];
	for (int i = 0; i < recvcnt; ++i)
		B_recvind[i] = A_recvind[i];

	B.Free();

	B.comm = comm;

	B.local.size[0] = n;
	B.local.size[1] = n;
	B.local.rowptr = B_local_rowptr;
	B.local.colind = B_local_colind;
	B.local.values = B_local_values;

	B.exter.size[0] = n;
	B.exter.size[1] = recvcnt;
	B.exter.rowptr = B_exter_rowptr;
	B.exter.colind = B_exter_colind;
	B.exter.values = B_exter_values;

	B.nnb = nnb;
	B.nbrank = B_nbrank;
	B.recvptr = B_recvptr;
	B.recvind = B_recvind;
}

void ParBSRPrecondAMG::Strength(const ParCSRMatrix& A, bool* locstg, bool* extstg) const
{
	double threshold = StrengthThreshold;
	RugeStuben::Strength(A, locstg, extstg, threshold);
}

void ParBSRPrecondAMG::Coarsening(const ParCSRMatrix& A, const bool* locstg, const bool* extstg, int* cfmap, int AGGRESSIVE) const
{
	if (AGGRESSIVE)
	{
		if (CoarsenType == 0)
			RugeStuben::AggressiveHMISCoarsening(A, locstg, extstg, cfmap);
		else if (CoarsenType == 1)
			RugeStuben::AggressivePMISCoarsening(A, locstg, extstg, cfmap);
	}
	else
	{
		if (CoarsenType == 0)
			RugeStuben::HMISCoarsening(A, locstg, extstg, cfmap);
		else if (CoarsenType == 1)
			RugeStuben::PMISCoarsening(A, locstg, extstg, cfmap);
	}
}

void ParBSRPrecondAMG::Interpolation(const ParCSRMatrix& A, const bool* locstg, const bool* extstg, int* cfmap, ParCSRMatrix& P, int AGGRESSIVE) const
{
	if (InterpType == 0)
	{
		int min_elements = InterpMinElements;
		int max_elements = InterpMaxElements;
		double truncation_factor = TruncationFactor;
		if (AGGRESSIVE)
			RugeStuben::AggressiveLongRangeInterpolation(A, locstg, extstg, cfmap, P, min_elements, max_elements, truncation_factor);
		else
			RugeStuben::LongRangeInterpolation(A, locstg, extstg, cfmap, P, min_elements, max_elements, truncation_factor);
	}
	else if (InterpType == 1)
	{
		if (AGGRESSIVE)
			RugeStuben::AggressiveSmoothedAggregation(A, locstg, extstg, cfmap, P);
		else
			RugeStuben::SmoothedAggregation(A, locstg, extstg, cfmap, P);
	}
}

void ParBSRPrecondAMG::RAP(const ParCSRMatrix& R, const ParBSRMatrix& A, const ParCSRMatrix& P, ParBSRMatrix& C) const
{
	ParBSRMatrix Z;
	ParBSRMultCSR(A, P, Z);
	ParCSRMultBSR(R, Z, C);
}

#define ABS(x) ((x) > 0 ? (x) : -(x))

void ParBSRPrecondAMG::Sparsification(const ParBSRMatrix& A, ParBSRMatrix& B) const
{
	double threshold = SparsificationThreshold;

	MPI_Comm comm = A.comm;
	int n = A.local.size[0];
	int recvcnt = A.exter.size[1];

	int bsize = A.local.bsize;
	int bnnz = bsize * bsize;

	int* A_local_rowptr = A.local.rowptr;
	int* A_local_colind = A.local.colind;
	double* A_local_values = A.local.values;

	int* A_exter_rowptr = A.exter.rowptr;
	int* A_exter_colind = A.exter.colind;
	double* A_exter_values = A.exter.values;

	int nnb = A.nnb;
	int* A_nbrank = A.nbrank;
	int* A_recvptr = A.recvptr;
	int* A_recvind = A.recvind;
	int* A_sendptr = A.sendptr;
	int* A_sendind = A.sendind;

#ifdef YHAMG_USE_OPENMP
	omp_lock_t lock;
	omp_init_lock(&lock);
#endif

	double* rmax = new double[n];
	double* cmax = new double[n];

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
	for (int i = 0; i < n; ++i)
		rmax[i] = 0.0;
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
	for (int i = 0; i < n; ++i)
		cmax[i] = 0.0;

#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for
#endif
	for (int i = 0; i < n; ++i)
	{
		for (int j = A_local_rowptr[i]; j < A_local_rowptr[i + 1]; ++j)
		{
			int jcol = A_local_colind[j];
			if (jcol == i) continue;
			double abs_jval = ABS(NODAL(A_local_values + j * bnnz));
			if (abs_jval > rmax[i]) rmax[i] = abs_jval;
#ifdef YHAMG_USE_OPENMP
			omp_set_lock(&lock);
#endif
			if (abs_jval > cmax[jcol]) cmax[jcol] = abs_jval;
#ifdef YHAMG_USE_OPENMP
			omp_unset_lock(&lock);
#endif
		}
	}

#ifdef YHAMG_USE_OPENMP
	omp_unset_lock(&lock);
#endif

	double* recvcmax = new double[recvcnt];
	for (int i = 0; i < recvcnt; ++i)
		recvcmax[i] = 0.0;
	for (int i = 0; i < n; ++i)
	{
		for (int j = A_exter_rowptr[i]; j < A_exter_rowptr[i + 1]; ++j)
		{
			int jcol = A_exter_colind[j];
			double abs_jval = ABS(NODAL(A_exter_values + j * bnnz));
			if (abs_jval > rmax[i]) rmax[i] = abs_jval;
			if (abs_jval > recvcmax[jcol]) recvcmax[jcol] = abs_jval;
		}
	}

	double* sendbuf = new double[A_sendptr[nnb]];
	MPI_Request* recvreq = new MPI_Request[nnb];
	MPI_Request* sendreq = new MPI_Request[nnb];
	MPI_Status status;

	for (int r = 0; r < nnb; ++r)
		if (A_sendptr[r + 1] > A_sendptr[r])
			MPI_Irecv(sendbuf + A_sendptr[r], A_sendptr[r + 1] - A_sendptr[r], MPI_DOUBLE, A_nbrank[r], MPI_TAG, comm, recvreq + r);

	for (int r = 0; r < nnb; ++r)
		if (A_recvptr[r + 1] > A_recvptr[r])
			MPI_Isend(recvcmax + A_recvptr[r], A_recvptr[r + 1] - A_recvptr[r], MPI_DOUBLE, A_nbrank[r], MPI_TAG, comm, sendreq + r);

	for (int r = 0; r < nnb; ++r)
	{
		if (A_sendptr[r + 1] > A_sendptr[r])
		{
			MPI_Wait(recvreq + r, &status);
			for (int i = A_sendptr[r]; i < A_sendptr[r + 1]; ++i)
				if (sendbuf[i] > cmax[A_sendind[i]]) cmax[A_sendind[i]] = sendbuf[i];
		}
	}

	for (int r = 0; r < nnb; ++r)
		if (A_recvptr[r + 1] > A_recvptr[r])
			MPI_Wait(sendreq + r, &status);

	for (int r = 0; r < nnb; ++r)
		if (A_recvptr[r + 1] > A_recvptr[r])
			MPI_Irecv(recvcmax + A_recvptr[r], A_recvptr[r + 1] - A_recvptr[r], MPI_DOUBLE, A_nbrank[r], MPI_TAG, comm, recvreq + r);

	for (int r = 0; r < nnb; ++r)
	{
		if (A_sendptr[r + 1] > A_sendptr[r])
		{
			for (int i = A_sendptr[r]; i < A_sendptr[r + 1]; ++i)
				sendbuf[i] = cmax[A_sendind[i]];
			MPI_Isend(sendbuf + A_sendptr[r], A_sendptr[r + 1] - A_sendptr[r], MPI_DOUBLE, A_nbrank[r], MPI_TAG, comm, sendreq + r);
		}
	}
	
	for (int r = 0; r < nnb; ++r)
		if (A_recvptr[r + 1] > A_recvptr[r])
			MPI_Wait(recvreq + r, &status);

	for (int r = 0; r < nnb; ++r)
		if (A_sendptr[r + 1] > A_sendptr[r])
			MPI_Wait(sendreq + r, &status);

	delete[] sendbuf;
	delete[] recvreq;
	delete[] sendreq;

	bool* locstg = new bool[A.local.rowptr[n]];
	bool* extstg = new bool[A.exter.rowptr[n]];

	int* B_local_rowptr = new int[n + 1];
	int* B_exter_rowptr = new int[n + 1];

	B_local_rowptr[0] = 0;
	B_exter_rowptr[0] = 0;
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
	for (int i = 0; i < n; ++i)
	{
		int cntloc = 1;
		int cntext = 0;

		for (int j = A_local_rowptr[i]; j < A_local_rowptr[i + 1]; ++j)
		{
			double abs_jval = ABS(NODAL(A_local_values + j * bnnz));
			locstg[j] = A_local_colind[j] != i && (abs_jval > rmax[i] * threshold || abs_jval > cmax[A_local_colind[j]] * threshold);
			if (locstg[j]) ++cntloc;
		}

		for (int j = A_exter_rowptr[i]; j < A_exter_rowptr[i + 1]; ++j)
		{
			double abs_jval = ABS(NODAL(A_exter_values + j * bnnz));
			extstg[j] = abs_jval > rmax[i] * threshold || abs_jval > recvcmax[A_exter_colind[j]] * threshold;
			if (extstg[j]) ++cntext;
		}

		B_local_rowptr[i + 1] = cntloc;
		B_exter_rowptr[i + 1] = cntext;
	}

	for (int i = 0; i < n; ++i)
		B_local_rowptr[i + 1] += B_local_rowptr[i];
	for (int i = 0; i < n; ++i)
		B_exter_rowptr[i + 1] += B_exter_rowptr[i];

	int* B_local_colind = new int[B_local_rowptr[n]];
	double* B_local_values = new double[B_local_rowptr[n] * bnnz];
	int* B_exter_colind = new int[B_exter_rowptr[n]];
	double* B_exter_values = new double[B_exter_rowptr[n] * bnnz];
	
#define BSR_UNROLL_SEGMENT(N) \
	for (int i = 0; i < n; ++i) \
	{ \
		B_local_colind[B_local_rowptr[i]] = i; \
		BSRBlockFill_UNROLL(N, 0.0, B_local_values + B_local_rowptr[i] * N * N); \
		for (int j = A_local_rowptr[i], k = B_local_rowptr[i] + 1; j < A_local_rowptr[i + 1]; ++j) \
		{ \
			if (locstg[j]) \
			{ \
				B_local_colind[k] = A_local_colind[j]; \
				BSRBlockCopy_UNROLL(N, A_local_values + j * N * N, B_local_values + k * N * N); \
				++k; \
			} \
			else \
				BSRBlockAdd_UNROLL(N, A_local_values + j * N * N, B_local_values + B_local_rowptr[i] * N * N); \
		} \
		for (int j = A_exter_rowptr[i], k = B_exter_rowptr[i]; j < A_exter_rowptr[i + 1]; ++j) \
		{ \
			if (extstg[j]) \
			{ \
				B_exter_colind[k] = A_exter_colind[j]; \
				BSRBlockCopy_UNROLL(N, A_exter_values + j * N * N, B_exter_values + k * N * N); \
				++k; \
			} \
			else \
				BSRBlockAdd_UNROLL(N, A_exter_values + j * N * N, B_local_values + B_local_rowptr[i] * N * N); \
		} \
	}

#ifdef BSR_UNROLL_1
	if (bsize == 1)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		BSR_UNROLL_SEGMENT(1)
	}
	else
#endif
#ifdef BSR_UNROLL_2
	if (bsize == 2)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		BSR_UNROLL_SEGMENT(2)
	}
	else
#endif
#ifdef BSR_UNROLL_3
	if (bsize == 3)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		BSR_UNROLL_SEGMENT(3)
	}
	else
#endif
#ifdef BSR_UNROLL_4
	if (bsize == 4)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		BSR_UNROLL_SEGMENT(4)
	}
	else
#endif
#ifdef BSR_UNROLL_5
	if (bsize == 5)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		BSR_UNROLL_SEGMENT(5)
	}
	else
#endif
#ifdef BSR_UNROLL_6
	if (bsize == 6)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		BSR_UNROLL_SEGMENT(6)
	}
	else
#endif
#ifdef BSR_UNROLL_7
	if (bsize == 7)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		BSR_UNROLL_SEGMENT(7)
	}
	else
#endif
#ifdef BSR_UNROLL_8
	if (bsize == 8)
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		BSR_UNROLL_SEGMENT(8)
	}
	else
#endif
#undef BSR_UNROLL_SEGMENT
	{
#ifdef YHAMG_USE_OPENMP
#pragma omp parallel for schedule(guided)
#endif
		for (int i = 0; i < n; ++i)
		{
			B_local_colind[B_local_rowptr[i]] = i;
			BSRBlockFill(bsize, 0.0, B_local_values + B_local_rowptr[i] * bnnz);

			for (int j = A_local_rowptr[i], k = B_local_rowptr[i] + 1; j < A_local_rowptr[i + 1]; ++j)
			{
				if (locstg[j])
				{
					B_local_colind[k] = A_local_colind[j];
					BSRBlockCopy(bsize, A_local_values + j * bnnz, B_local_values + k * bnnz);
					++k;
				}
				else
					BSRBlockAdd(bsize, A_local_values + j * bnnz, B_local_values + B_local_rowptr[i] * bnnz);
			}

			for (int j = A_exter_rowptr[i], k = B_exter_rowptr[i]; j < A_exter_rowptr[i + 1]; ++j)
			{
				if (extstg[j])
				{
					B_exter_colind[k] = A_exter_colind[j];
					BSRBlockCopy(bsize, A_exter_values + j * bnnz, B_exter_values + k * bnnz);
					++k;
				}
				else
					BSRBlockAdd(bsize, A_exter_values + j * bnnz, B_local_values + B_local_rowptr[i] * bnnz);
			}
		}
	}

	delete[] locstg;
	delete[] extstg;

	int* B_nbrank = new int[nnb];
	for (int r = 0; r < nnb; ++r)
		B_nbrank[r] = A_nbrank[r];

	int* v = new int[A.exter.size[1]];
	for (int i = 0; i < A.exter.size[1]; ++i)
		v[i] = -1;

	for (int j = 0; j < B_exter_rowptr[n]; ++j)
		v[B_exter_colind[j]] = 1;

	int* B_recvind = new int[A.exter.size[1]];
	int* B_recvptr = new int[nnb + 1];

	B_recvptr[0] = 0;
	for (int r = 0, k = 0; r < nnb; B_recvptr[++r] = k)
	{
		for (int i = A_recvptr[r]; i < A_recvptr[r + 1]; ++i)
		{
			if (v[i] == 1)
			{
				v[i] = k;
				B_recvind[k++] = A_recvind[i];
			}
		}
	}

	for (int j = 0; j < B_exter_rowptr[n]; ++j)
		B_exter_colind[j] = v[B_exter_colind[j]];

	delete[] v;

	B.Free();

	B.comm = comm;

	B.local.size[0] = n;
	B.local.size[1] = n;
	B.local.bsize = bsize;
	B.local.rowptr = B_local_rowptr;
	B.local.colind = B_local_colind;
	B.local.values = B_local_values;

	B.exter.size[0] = n;
	B.exter.size[1] = B_recvptr[nnb];
	B.exter.bsize = bsize;
	B.exter.rowptr = B_exter_rowptr;
	B.exter.colind = B_exter_colind;
	B.exter.values = B_exter_values;

	B.nnb = nnb;
	B.nbrank = B_nbrank;
	B.recvptr = B_recvptr;
	B.recvind = B_recvind;
}

void ParBSRPrecondAMG::SetupSmoother(const ParBSRMatrix& A, Smoother& S, int REUSE) const
{
	if (!REUSE)
	{
		if (SmoothType == 0)
			S.SetupJacobi(A, JacobiFactor);
		else if (SmoothType == 1)
			S.SetupSOR(A, SORType, SORFactor);
		else if (SmoothType == 2)
			S.SetupILU(A, ILUMaxFillins, ILUDropTolerance);
		else if (SmoothType == 3)
			S.SetupChebyshev(A, ChebyshevEigenRatio);
	}
	else
		S.SetupReuse(A);
}

void ParBSRPrecondAMG::PreSmooth(int level, const ParVector& b, const ParVector& x, bool x0zero) const
{
	S[level].Pre(A[level], b, x, PreSweeps, x0zero);
}

void ParBSRPrecondAMG::PostSmooth(int level, const ParVector& b, const ParVector& x) const
{
	S[level].Post(A[level], b, x, PostSweeps);
}

void ParBSRPrecondAMG::CoarseSmooth(int level, const ParVector& b, const ParVector& x, bool x0zero) const
{
	S[level].Coarse(A[level], b, x, CoarseSweeps, x0zero);
}

void ParBSRPrecondAMG::Restriction(int level, const ParVector& b, const ParVector& x, const ParVector& g) const
{
	r[level].Copy(b);
	ParBSRMatVec(-1.0, A[level], x, 1.0, r[level]);
	ParCSRMatBlockVec(A[level].local.bsize, 1.0, R[level], r[level], 0.0, g);
}

void ParBSRPrecondAMG::Prolongation(int level, const ParVector& e, const ParVector& x) const
{
	ParCSRMatBlockVec(A[level].local.bsize, 1.0, P[level], e, 1.0, x);
}

void ParBSRPrecondAMG::V_Cycle(int level, const ParVector& b, const ParVector& x, bool x0zero) const
{
	if (level == nlev - 1)
		CoarseSmooth(level, b, x, x0zero);
	else
	{
		PreSmooth(level, b, x, x0zero);

		Restriction(level, b, x, g[level]);

		e[level].Fill(0.0);

		V_Cycle(level + 1, g[level], e[level], 1);

		Prolongation(level, e[level], x);

		PostSmooth(level, b, x);
	}
}

void ParBSRPrecondAMG::W_Cycle(int level, const ParVector& b, const ParVector& x, bool x0zero) const
{
	if (level == nlev - 1)
		CoarseSmooth(level, b, x, x0zero);
	else
	{
		PreSmooth(level, b, x, x0zero);

		Restriction(level, b, x, g[level]);

		e[level].Fill(0.0);

		W_Cycle(level + 1, g[level], e[level], 1);
		W_Cycle(level + 1, g[level], e[level]);

		Prolongation(level, e[level], x);

		PostSmooth(level, b, x);
	}
}

void ParBSRPrecondAMG::F_Cycle(int level, const ParVector& b, const ParVector& x) const
{
	if (level == nlev - 1)
	{
		x.Fill(0.0);
		CoarseSmooth(level, b, x, 1);
	}
	else
	{
		ParCSRMatBlockVec(A[level].local.bsize, 1.0, R[level], b, 0.0, g[level]);

		F_Cycle(level + 1, g[level], e[level]);

		ParCSRMatBlockVec(A[level].local.bsize, 1.0, P[level], e[level], 0.0, x);

		V_Cycle(level, b, x);
	}
}

ParBSRPrecondAMG::ParBSRPrecondAMG(
	int    max_levels,
	int    coarse_size,
	double strength_threshold,
	int    aggressive_levels,
	int    coarsen_type, 
	int    interp_type, 
	int    interp_min_elements,
	int    interp_max_elements,
	double truncation_factor,
	double sparsification_threshold,
	int    cycle_type,
	int    pre_sweeps,
	int    post_sweeps,
	int    coarse_sweeps,
	int    smooth_type,
	int    print_stats)
	: nlev(0),
	A(0),
	P(0),
	R(0),
	S(0),
	r(0),
	e(0),
	g(0),
	MaxLevels(max_levels),
	CoarseSize(coarse_size),
	StrengthThreshold(strength_threshold),
	AggressiveLevels(aggressive_levels),
	CoarsenType(coarsen_type),
	InterpType(interp_type),
	InterpMinElements(interp_min_elements),
	InterpMaxElements(interp_max_elements),
	TruncationFactor(truncation_factor),
	SparsificationThreshold(sparsification_threshold),
	CycleType(cycle_type),
	PreSweeps(pre_sweeps),
	PostSweeps(post_sweeps),
	CoarseSweeps(coarse_sweeps),
	SmoothType(smooth_type),
	JacobiFactor(0.75),
	SORType(2),
	SORFactor(1.0),
	ILUMaxFillins(0),
	ILUDropTolerance(0.01),
	ChebyshevEigenRatio(0.3),
	PrintStats(print_stats)
{
}

ParBSRPrecondAMG::~ParBSRPrecondAMG()
{
	if (A) delete[] A;
	if (P) delete[] P;
	if (R) delete[] R;
	if (S) delete[] S;
	if (r) delete[] r;
	if (e) delete[] e;
	if (g) delete[] g;
}

void ParBSRPrecondAMG::Free()
{
	if (A) delete[] A;
	if (P) delete[] P;
	if (R) delete[] R;
	if (S) delete[] S;
	if (r) delete[] r;
	if (e) delete[] e;
	if (g) delete[] g;
	nlev = 0;
	A = 0;
	P = 0;
	R = 0;
	S = 0;
	r = 0;
	e = 0;
	g = 0;
}

void ParBSRPrecondAMG::Setup(const ParBSRMatrix& _A, int REUSE)
{
	if (!REUSE)
	{
		Free();

		comm = _A.comm;

		int comm_rank;
		MPI_Comm_rank(comm, &comm_rank);

		int bsize = _A.local.bsize;

		A = new ParBSRMatrix[MaxLevels];
		P = new ParCSRMatrix[MaxLevels - 1];
		R = new ParCSRMatrix[MaxLevels - 1];
		r = new ParVector[MaxLevels];
		e = new ParVector[MaxLevels - 1];
		g = new ParVector[MaxLevels - 1];
		S = new Smoother[MaxLevels];

		long global_size0[2];
		double grid_complexity = 0.0;
		double operatoR_complexity = 0.0;

		if (PrintStats && comm_rank == 0)
		{
			std::cout << "Multigrid Hierarchy:\n";
			std::cout << "Level\tRows\tNz\n";
			std::cout << "--------------------------------------------------\n";
		}

		A[0].Refer(_A);
		A[0].SetupHalo();

		int level = 0;

		while (1)
		{
			SetupSmoother(A[level], S[level]);

			int n = A[level].local.size[0];

			long local_size[2];
			long global_size[2];

			local_size[0] = n;
			local_size[1] = A[level].local.rowptr[n] + A[level].exter.rowptr[n];

			MPI_Allreduce(local_size, global_size, 2, MPI_LONG, MPI_SUM, comm);

			if (level == 0)
			{
				global_size0[0] = global_size[0];
				global_size0[1] = global_size[1];
			}

			grid_complexity += (double)global_size[0] / global_size0[0];
			operatoR_complexity += (double)global_size[1] / global_size0[1];

			if (PrintStats && comm_rank == 0)
				std::cout << level << "\t" << global_size[0] << "\t" << global_size[1] << "\n";
			
			r[level].comm = comm;
			r[level].Resize(n * bsize);

			if (level == MaxLevels - 1 || global_size[0] <= (long)CoarseSize) break;

			bool* locstg = new bool[A[level].local.rowptr[n]];
			bool* extstg = new bool[A[level].exter.rowptr[n]];
			int* cfmap = new int[n];

			ParCSRMatrix B;
			ParBSRReduce(A[level], B);
			B.SetupHalo();

			Strength(B, locstg, extstg);
			Coarsening(B, locstg, extstg, cfmap, level < AggressiveLevels);
			Interpolation(B, locstg, extstg, cfmap, P[level], level < AggressiveLevels);

			delete[] cfmap;
			delete[] locstg;
			delete[] extstg;

			P[level].SetupHalo();
			
			ParCSRTrans(P[level], R[level]);

			R[level].SetupHalo();

			ParBSRMatrix C;
			RAP(R[level], A[level], P[level], C);

			C.SetupHalo();

			Sparsification(C, A[level +1]);

			A[level + 1].SetupHalo();
			
			e[level].comm = comm;
			g[level].comm = comm;
			e[level].Resize(A[level + 1].local.size[0] * bsize);
			g[level].Resize(A[level + 1].local.size[0] * bsize);

			++level;
		}

		nlev = level + 1;
		
		if (PrintStats && comm_rank == 0)
		{
			std::cout << "--------------------------------------------------\n";
			std::cout << "Number of Levels: " << nlev << "\n";
			std::cout << "Grid Complexity: " << grid_complexity << "\n";
			std::cout << "Operator Complexity: " << operatoR_complexity << "\n";
		}
	}
	else
	{
		A[0].Refer(_A);
		A[0].SetupHalo();
		SetupSmoother(A[0], S[0], 1);
	}
}

int ParBSRPrecondAMG::InSize() const
{
	return A[0].local.size[0] * A[0].local.bsize;
}

int ParBSRPrecondAMG::OutSize() const
{
	return A[0].local.size[0] * A[0].local.bsize;
}

void ParBSRPrecondAMG::Apply(const ParVector& b, const ParVector& x) const
{
	switch (CycleType)
	{
	case 0:
		x.Fill(0.0);
		V_Cycle(0, b, x, 1);
		break;
	case 1:
		x.Fill(0.0);
		W_Cycle(0, b, x, 1);
		break;
	case 2:
		F_Cycle(0, b, x);
		break;
	}
}

}