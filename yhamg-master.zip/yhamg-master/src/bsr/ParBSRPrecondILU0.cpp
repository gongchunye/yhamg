/* Copyright (c) 2021, National University of Defense Technology. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <set>
#include <map>
#include <stdlib.h>
#include "sort.hpp"
#include "BSRUnroll.hpp"
#include "ParBSRPrecondILU0.hpp"

namespace YHAMG
{

ParBSRPrecondILU0::ParBSRPrecondILU0()
	: D_local_LU(0),
	interior(0),
	label(0),
	nnb(0),
	nblab(0),
	nbrank(0),
	recvptr(0),
	sendptr(0),
	sendind(0),
	sendbuf(0)
{
}

ParBSRPrecondILU0::~ParBSRPrecondILU0()
{
	if (D_local_LU) delete[] D_local_LU;
	if (interior) delete[] interior;
	if (nblab) delete[] nblab;
	if (recvptr) delete[] recvptr;
	if (sendptr) delete[] sendptr;
	if (sendind) delete[] sendind;
	if (sendbuf) delete[] sendbuf;
}

void ParBSRPrecondILU0::Free()
{
	L_local.Free();
	L_exter.Free();
	U_local.Free();
	U_exter.Free();
	recvx.Free();
	if (D_local_LU) delete[] D_local_LU;
	if (interior) delete[] interior;
	if (nblab) delete[] nblab;
	if (recvptr) delete[] recvptr;
	if (sendptr) delete[] sendptr;
	if (sendind) delete[] sendind;
	if (sendbuf) delete[] sendbuf;
	D_local_LU = 0;
	label = 0;
	nnb = 0;
	interior = 0;
	nblab = 0;
	recvptr = 0;
	sendptr = 0;
	sendind = 0;
	sendbuf = 0;
}

#define MPI_TAG 500

static inline void swap(int& a, int& b)
{
	int temp = a;
	a = b;
	b = temp;
}

#define CMPLOC(i, j) (interior[i] != interior[j] ? interior[i] : (i) < (j))
#define CMPEXT(i, j) (from[i] == from[j] ? map[i] < map[j] : label[from[i]] < label[from[j]])

static void SortLoc(int* a, int left, int right, const bool* interior)
{
	if (left >= right) return;

	swap(a[left], a[(left + right) / 2]);

	int last = left;
	for (int i = left + 1; i <= right; ++i)
		if (CMPLOC(a[i], a[left]))
			swap(a[++last], a[i]);

	swap(a[left], a[last]);

	SortLoc(a, left, last - 1, interior);
	SortLoc(a, last + 1, right, interior);
}

static void SortExt(int* a, int left, int right, const int* map, const int* from, const int* label)
{
	if (left >= right) return;

	swap(a[left], a[(left + right) / 2]);

	int last = left;
	for (int i = left + 1; i <= right; ++i)
		if (CMPEXT(a[i], a[left]))
			swap(a[++last], a[i]);

	swap(a[left], a[last]);

	SortExt(a, left, last - 1, map, from, label);
	SortExt(a, last + 1, right, map, from, label);
}

void ParBSRPrecondILU0::Setup(const ParBSRMatrix& A, int REUSE)
{
	int n = A.local.size[0];
	int recvcnt = A.exter.size[1];

	int bsize = A.local.bsize;
	int bnnz = bsize * bsize;

	int* A_local_rowptr = A.local.rowptr;
	int* A_local_colind = A.local.colind;
	double* A_local_values = A.local.values;
	int* A_exter_rowptr = A.exter.rowptr;
	int* A_exter_colind = A.exter.colind;
	double* A_exter_values = A.exter.values;

	int* recvind = A.recvind;

	if (!REUSE)
	{
		Free();

		comm = A.comm;

		int comm_rank;
		MPI_Comm_rank(comm, &comm_rank);

		nnb = A.nnb;
		nbrank = new int[nnb];
		recvptr = new int[nnb + 1];
		sendptr = new int[nnb + 1];
		sendind = new int[A.sendptr[nnb]];
		sendbuf = new double[A.sendptr[nnb] * bsize];

		for (int r = 0; r < nnb; ++r)
			nbrank[r] = A.nbrank[r];
		for (int r = 0; r <= nnb; ++r)
			recvptr[r] = A.recvptr[r];
		for (int r = 0; r <= nnb; ++r)
			sendptr[r] = A.sendptr[r];
		for (int i = 0; i < A.sendptr[nnb]; ++i)
			sendind[i] = A.sendind[i];

		int* w = new int[n];
		double* x = new double[n * bnnz];

		for (int i = 0; i < n; ++i)
			w[i] = -1;

		interior = new bool[n];
		for (int i = 0; i < n; ++i)
			interior[i] = A_exter_rowptr[i + 1] == A_exter_rowptr[i];
		for (int i = 0; i < sendptr[nnb]; ++i)
			interior[sendind[i]] = 0;

		MPI_Request* recvreq = new MPI_Request[nnb];
		MPI_Request* sendreq = new MPI_Request[nnb];
		MPI_Status status;

		label = 0;
		nblab = new int[nnb];

		std::set<int> label_set;

		for (int r = 0; r < nnb; ++r)
			MPI_Irecv(nblab + r, 1, MPI_INT, nbrank[r], MPI_TAG, comm, recvreq + r);

		for (int r = 0; r < nnb; ++r)
		{
			if (comm_rank > nbrank[r])
			{
				MPI_Wait(recvreq + r, &status);
				label_set.insert(nblab[r]);
			}
		}

		for (std::set<int>::iterator iter = label_set.begin(); iter != label_set.end(); ++iter, ++label)
			if (*iter != label) break;

		for (int r = 0; r < nnb; ++r)
			MPI_Send(&label, 1, MPI_INT, nbrank[r], MPI_TAG, comm);

		for (int r = 0; r < nnb; ++r)
			if (comm_rank < nbrank[r])
				MPI_Wait(recvreq + r, &status);

		std::map<int, int> nbmap;
		std::map<int, int>* recvmap = new std::map<int, int>[nnb];

		for (int r = 0; r < nnb; ++r)
		{
			nbmap.insert(std::pair<int, int>(nbrank[r], r));
			for (int i = recvptr[r]; i < recvptr[r + 1]; ++i)
				recvmap[r].insert(std::pair<int, int>(recvind[i], i));
		}

		int* recvfrom = new int[recvcnt];
		for (int r = 0; r < nnb; ++r)
			for (int i = recvptr[r]; i < recvptr[r + 1]; ++i)
				recvfrom[i] = r;

		D_local_LU = new double[n * bnnz];

		int* L_local_rowptr = new int[n + 1];
		int* U_local_rowptr = new int[n + 1];
		int* L_exter_rowptr = new int[n + 1];
		int* U_exter_rowptr = new int[n + 1];

		L_local_rowptr[0] = 0;
		U_local_rowptr[0] = 0;
		L_exter_rowptr[0] = 0;
		U_exter_rowptr[0] = 0;

		for (int i = 0, cntlocl = 0, cntlocu = 0, cntextl = 0, cntextu = 0; i < n; L_local_rowptr[++i] = cntlocl, U_local_rowptr[i] = cntlocu, L_exter_rowptr[i] = cntextl, U_exter_rowptr[i] = cntextu)
		{
			if (interior[i])
			{
				for (int j = A_local_rowptr[i]; j < A_local_rowptr[i + 1]; ++j)
				{
					int jcol = A_local_colind[j];

					if (jcol < i && interior[jcol])
						++cntlocl;
					else if (jcol != i)
						++cntlocu;
				}
			}
			else
			{
				for (int j = A_local_rowptr[i]; j < A_local_rowptr[i + 1]; ++j)
				{
					int jcol = A_local_colind[j];

					if (jcol < i || interior[jcol])
						++cntlocl;
					else if (jcol != i)
						++cntlocu;
				}

				for (int j = A_exter_rowptr[i]; j < A_exter_rowptr[i + 1]; ++j)
				{
					int jcol = A_exter_colind[j];
					int jfrom = recvfrom[jcol];

					if (label > nblab[jfrom])
						++cntextl;
					else
						++cntextu;
				}
			}
		}

		int* L_local_colind = new int[L_local_rowptr[n]];
		double* L_local_values = new double[L_local_rowptr[n] * bnnz];
		int* U_local_colind = new int[U_local_rowptr[n]];
		double* U_local_values = new double[U_local_rowptr[n] * bnnz];
		int* L_exter_colind = new int[L_exter_rowptr[n]];
		double* L_exter_values = new double[L_exter_rowptr[n] * bnnz];
		int* U_exter_colind = new int[U_exter_rowptr[n]];
		double* U_exter_values = new double[U_exter_rowptr[n] * bnnz];

#define BSR_UNROLL_SEGMENT(N) \
	for (int i = 0; i < n; ++i) \
	{ \
		if (interior[i]) \
		{ \
			w[i] = i; \
			BSRBlockFill_UNROLL(N, 0.0, x + i * N * N); \
			for (int j = A_local_rowptr[i], k = L_local_rowptr[i], r = U_local_rowptr[i]; j < A_local_rowptr[i + 1]; ++j) \
			{ \
				int jcol = A_local_colind[j]; \
				w[jcol] = i; \
				BSRBlockCopy_UNROLL(N, A_local_values + j * N * N, x + jcol * N * N); \
				if (jcol < i && interior[jcol]) \
					L_local_colind[k++] = jcol; \
				else if (jcol != i) \
					U_local_colind[r++] = jcol; \
			} \
			sort(L_local_colind, L_local_rowptr[i], L_local_rowptr[i + 1] - 1); \
			for (int k = L_local_rowptr[i]; k < L_local_rowptr[i + 1]; ++k) \
			{ \
				int kcol = L_local_colind[k]; \
				BSRBlockCopy_UNROLL(N, x + kcol * N * N, L_local_values + k * N * N); \
				BSRBlockMatLUSolve_UNROLL(N, D_local_LU + kcol * N * N, L_local_values + k * N * N); \
				for (int j = U_local_rowptr[kcol]; j < U_local_rowptr[kcol + 1]; ++j) \
				{ \
					int jcol = U_local_colind[j]; \
					if (w[jcol] == i) \
						BSRBlockMatMulSub_UNROLL(N, L_local_values + k * N * N, U_local_values + j * N * N, x + jcol * N * N); \
				} \
			} \
			BSRBlockCopy_UNROLL(N, x + i * N * N, D_local_LU + i * N * N); \
			BSRBlockLUFactorize_UNROLL(N, D_local_LU + i * N * N); \
			for (int j = U_local_rowptr[i]; j < U_local_rowptr[i + 1]; ++j) \
				BSRBlockCopy_UNROLL(N, x + U_local_colind[j] * N * N, U_local_values + j * N * N); \
		} \
	}

#ifdef BSR_UNROLL_1
		if (bsize == 1) { BSR_UNROLL_SEGMENT(1) } else
#endif
#ifdef BSR_UNROLL_2
		if (bsize == 2) { BSR_UNROLL_SEGMENT(2) } else
#endif
#ifdef BSR_UNROLL_3
		if (bsize == 3) { BSR_UNROLL_SEGMENT(3) } else
#endif
#ifdef BSR_UNROLL_4
		if (bsize == 4) { BSR_UNROLL_SEGMENT(4) } else
#endif
#ifdef BSR_UNROLL_5
		if (bsize == 5) { BSR_UNROLL_SEGMENT(5) } else
#endif
#ifdef BSR_UNROLL_6
		if (bsize == 6) { BSR_UNROLL_SEGMENT(6) } else
#endif
#ifdef BSR_UNROLL_7
		if (bsize == 7) { BSR_UNROLL_SEGMENT(7) } else
#endif
#ifdef BSR_UNROLL_8
		if (bsize == 8) { BSR_UNROLL_SEGMENT(8) } else
#endif
#undef BSR_UNROLL_SEGMENT
		{
			for (int i = 0; i < n; ++i)
			{
				if (interior[i])
				{
					w[i] = i;
					BSRBlockFill(bsize, 0.0, x + i * bnnz);

					for (int j = A_local_rowptr[i], k = L_local_rowptr[i], r = U_local_rowptr[i]; j < A_local_rowptr[i + 1]; ++j)
					{
						int jcol = A_local_colind[j];

						w[jcol] = i;
						BSRBlockCopy(bsize, A_local_values + j * bnnz, x + jcol * bnnz);

						if (jcol < i && interior[jcol])
							L_local_colind[k++] = jcol;
						else if (jcol != i)
							U_local_colind[r++] = jcol;
					}

					sort(L_local_colind, L_local_rowptr[i], L_local_rowptr[i + 1] - 1);

					for (int k = L_local_rowptr[i]; k < L_local_rowptr[i + 1]; ++k)
					{
						int kcol = L_local_colind[k];
						BSRBlockCopy(bsize, x + kcol * bnnz, L_local_values + k * bnnz);
						BSRBlockMatLUSolve(bsize, D_local_LU + kcol * bnnz, L_local_values + k * bnnz);

						for (int j = U_local_rowptr[kcol]; j < U_local_rowptr[kcol + 1]; ++j)
						{
							int jcol = U_local_colind[j];
							if (w[jcol] == i)
								BSRBlockMatMulSub(bsize, L_local_values + k * bnnz, U_local_values + j * bnnz, x + jcol * bnnz);
						}
					}

					BSRBlockCopy(bsize, x + i * bnnz, D_local_LU + i * bnnz);
					BSRBlockLUFactorize(bsize, D_local_LU + i * bnnz);
					for (int j = U_local_rowptr[i]; j < U_local_rowptr[i + 1]; ++j)
						BSRBlockCopy(bsize, x + U_local_colind[j] * bnnz, U_local_values + j * bnnz);
				}
			}
		}

		char** recvbuf = new char* [nnb];
		char** sendbuf = new char* [nnb];

		int recvnnz = 0;

		for (int r = 0; r < nnb; ++r)
		{
			if (label > nblab[r] && recvptr[r + 1] > recvptr[r])
			{
				int bufsize;
				MPI_Probe(nbrank[r], MPI_TAG, comm, &status);
				MPI_Get_count(&status, MPI_PACKED, &bufsize);
				recvbuf[r] = (char*)malloc(bufsize);
				MPI_Irecv(recvbuf[r], bufsize, MPI_PACKED, nbrank[r], MPI_TAG, comm, recvreq + r);

				int nrow = recvptr[r + 1] - recvptr[r];
				int nnz = (bufsize - nrow * (sizeof(int) + bnnz * sizeof(double))) / (2 * sizeof(int) + bnnz * sizeof(double));
				recvnnz += nnz;
			}
		}

		double* D_recv_lu = new double[recvcnt * bnnz];
		int* U_recvloc_rowptr = new int[recvcnt + 1];
		int* U_recvloc_colind = new int[recvnnz];
		double* U_recvloc_values = new double[recvnnz * bnnz];
		int* U_recvext_rowptr = new int[recvcnt + 1];
		int* U_recvext_colind = new int[recvnnz];
		double* U_recvext_values = new double[recvnnz * bnnz];

		U_recvloc_rowptr[0] = 0;
		U_recvext_rowptr[0] = 0;

		for (int r = 0; r < nnb; ++r)
		{
			if (label > nblab[r] && recvptr[r + 1] > recvptr[r])
			{
				MPI_Wait(recvreq + r, &status);

				int bufsize;
				MPI_Get_count(&status, MPI_PACKED, &bufsize);

				int position = 0;

				MPI_Unpack(recvbuf[r], bufsize, &position, D_recv_lu + recvptr[r] * bnnz, (recvptr[r + 1] - recvptr[r]) * bnnz, MPI_DOUBLE, comm);

				for (int i = recvptr[r], k = U_recvloc_rowptr[i], t = U_recvext_rowptr[i]; i < recvptr[r + 1]; U_recvloc_rowptr[++i] = k, U_recvext_rowptr[i] = t)
				{
					int length;
					MPI_Unpack(recvbuf[r], bufsize, &position, &length, 1, MPI_INT, comm);

					int* ranks = new int[length];
					int* colind = new int[length];
					double* values = new double[length * bnnz];

					MPI_Unpack(recvbuf[r], bufsize, &position, ranks, length, MPI_INT, comm);
					MPI_Unpack(recvbuf[r], bufsize, &position, colind, length, MPI_INT, comm);
					MPI_Unpack(recvbuf[r], bufsize, &position, values, length * bnnz, MPI_DOUBLE, comm);

					for (int j = 0; j < length; ++j)
					{
						if (ranks[j] == comm_rank)
						{
							U_recvloc_colind[k] = colind[j];
							BSRBlockCopy(bsize, values + j * bnnz, U_recvloc_values + k * bnnz);
							++k;
						}
						else
						{
							std::map<int, int>::iterator ret1 = nbmap.find(ranks[j]);
							if (ret1 == nbmap.end()) continue;
							std::map<int, int>::iterator ret2 = recvmap[ret1->second].find(colind[j]);
							if (ret2 == recvmap[ret1->second].end()) continue;
							U_recvext_colind[t] = ret2->second;
							BSRBlockCopy(bsize, values + j * bnnz, U_recvext_values + t * bnnz);
							++t;
						}
					}

					delete[] ranks;
					delete[] colind;
					delete[] values;
				}

				free(recvbuf[r]);
			}
			else if (recvptr[r + 1] > recvptr[r])
			{
				for (int i = recvptr[r], k = U_recvloc_rowptr[i], t = U_recvext_rowptr[i]; i < recvptr[r + 1]; U_recvloc_rowptr[++i] = k, U_recvext_rowptr[i] = t)
					;
			}
		}

		delete[] recvmap;

		int* v = new int[recvcnt];
		double* y = new double[recvcnt * bnnz];

		for (int i = 0; i < recvcnt; ++i)
			v[i] = -1;

#define BSR_UNROLL_SEGMENT(N) \
	for (int i = 0; i < n; ++i) \
	{ \
		if (interior[i]) continue; \
		w[i] = i; \
		BSRBlockFill_UNROLL(N, 0.0, x + i * N * N); \
		for (int j = A_local_rowptr[i], k = L_local_rowptr[i], r = U_local_rowptr[i]; j < A_local_rowptr[i + 1]; ++j) \
		{ \
			int jcol = A_local_colind[j]; \
			w[jcol] = i; \
			BSRBlockCopy_UNROLL(N, A_local_values + j * N * N, x + jcol * N * N); \
			if (jcol < i || interior[jcol]) \
				L_local_colind[k++] = jcol; \
			else if (jcol != i) \
				U_local_colind[r++] = jcol; \
		} \
		SortLoc(L_local_colind, L_local_rowptr[i], L_local_rowptr[i + 1] - 1, interior); \
		for (int j = A_exter_rowptr[i], k = L_exter_rowptr[i], r = U_exter_rowptr[i]; j < A_exter_rowptr[i + 1]; ++j) \
		{ \
			int jcol = A_exter_colind[j]; \
			int jfrom = recvfrom[jcol]; \
			v[jcol] = i; \
			BSRBlockCopy_UNROLL(N, A_exter_values + j * N * N, y + jcol * N * N); \
			if (label > nblab[jfrom]) \
				L_exter_colind[k++] = jcol; \
			else \
				U_exter_colind[r++] = jcol; \
		} \
		SortExt(L_exter_colind, L_exter_rowptr[i], L_exter_rowptr[i + 1] - 1, recvind, recvfrom, nblab); \
		for (int k = L_exter_rowptr[i]; k < L_exter_rowptr[i + 1]; ++k) \
		{ \
			int kcol = L_exter_colind[k]; \
			BSRBlockCopy_UNROLL(N, y + kcol * N * N, L_exter_values + k * N * N); \
			BSRBlockMatLUSolve_UNROLL(N, D_recv_lu + kcol * N * N, L_exter_values + k * N * N); \
			for (int j = U_recvext_rowptr[kcol]; j < U_recvext_rowptr[kcol + 1]; ++j) \
			{ \
				int jcol = U_recvext_colind[j]; \
				if (v[jcol] == i) \
					BSRBlockMatMulSub_UNROLL(N, L_exter_values + k * N * N, U_recvext_values + j * N * N, y + jcol * N * N); \
			} \
			for (int j = U_recvloc_rowptr[kcol]; j < U_recvloc_rowptr[kcol + 1]; ++j) \
			{ \
				int jcol = U_recvloc_colind[j]; \
				if (w[jcol] == i) \
					BSRBlockMatMulSub_UNROLL(N, L_exter_values + k * N * N, U_recvloc_values + j * N * N, x + jcol * N * N); \
			} \
		} \
		for (int k = L_local_rowptr[i]; k < L_local_rowptr[i + 1]; ++k) \
		{ \
			int kcol = L_local_colind[k]; \
			BSRBlockCopy_UNROLL(N, x + kcol * N * N, L_local_values + k * N * N); \
			BSRBlockMatLUSolve_UNROLL(N, D_local_LU + kcol * N * N, L_local_values + k * N * N); \
			for (int j = U_local_rowptr[kcol]; j < U_local_rowptr[kcol + 1]; ++j) \
			{ \
				int jcol = U_local_colind[j]; \
				if (w[jcol] == i) \
					BSRBlockMatMulSub_UNROLL(N, L_local_values + k * N * N, U_local_values + j * N * N, x + jcol * N * N); \
			} \
		} \
		BSRBlockCopy_UNROLL(N, x + i * N * N, D_local_LU + i * N * N); \
		BSRBlockLUFactorize_UNROLL(N, D_local_LU + i * N * N); \
		for (int j = U_local_rowptr[i]; j < U_local_rowptr[i + 1]; ++j) \
			BSRBlockCopy_UNROLL(N, x + U_local_colind[j] * N * N, U_local_values + j * N * N); \
		for (int j = U_exter_rowptr[i]; j < U_exter_rowptr[i + 1]; ++j) \
			BSRBlockCopy_UNROLL(N, y + U_exter_colind[j] * N * N, U_exter_values + j * N * N); \
	}

#ifdef BSR_UNROLL_1
		if (bsize == 1) { BSR_UNROLL_SEGMENT(1) } else
#endif
#ifdef BSR_UNROLL_2
		if (bsize == 2) { BSR_UNROLL_SEGMENT(2) } else
#endif
#ifdef BSR_UNROLL_3
		if (bsize == 3) { BSR_UNROLL_SEGMENT(3) } else
#endif
#ifdef BSR_UNROLL_4
		if (bsize == 4) { BSR_UNROLL_SEGMENT(4) } else
#endif
#ifdef BSR_UNROLL_5
		if (bsize == 5) { BSR_UNROLL_SEGMENT(5) } else
#endif
#ifdef BSR_UNROLL_6
		if (bsize == 6) { BSR_UNROLL_SEGMENT(6) } else
#endif
#ifdef BSR_UNROLL_7
		if (bsize == 7) { BSR_UNROLL_SEGMENT(7) } else
#endif
#ifdef BSR_UNROLL_8
		if (bsize == 8) { BSR_UNROLL_SEGMENT(8) } else
#endif
#undef BSR_UNROLL_SEGMENT
		{
			for (int i = 0; i < n; ++i)
			{
				if (interior[i]) continue;

				w[i] = i;
				BSRBlockFill(bsize, 0.0, x + i * bnnz);

				for (int j = A_local_rowptr[i], k = L_local_rowptr[i], r = U_local_rowptr[i]; j < A_local_rowptr[i + 1]; ++j)
				{
					int jcol = A_local_colind[j];

					w[jcol] = i;
					BSRBlockCopy(bsize, A_local_values + j * bnnz, x + jcol * bnnz);

					if (jcol < i || interior[jcol])
						L_local_colind[k++] = jcol;
					else if (jcol != i)
						U_local_colind[r++] = jcol;
				}

				SortLoc(L_local_colind, L_local_rowptr[i], L_local_rowptr[i + 1] - 1, interior);

				for (int j = A_exter_rowptr[i], k = L_exter_rowptr[i], r = U_exter_rowptr[i]; j < A_exter_rowptr[i + 1]; ++j)
				{
					int jcol = A_exter_colind[j];
					int jfrom = recvfrom[jcol];

					v[jcol] = i;
					BSRBlockCopy(bsize, A_exter_values + j * bnnz, y + jcol * bnnz);

					if (label > nblab[jfrom])
						L_exter_colind[k++] = jcol;
					else
						U_exter_colind[r++] = jcol;
				}

				SortExt(L_exter_colind, L_exter_rowptr[i], L_exter_rowptr[i + 1] - 1, recvind, recvfrom, nblab);

				for (int k = L_exter_rowptr[i]; k < L_exter_rowptr[i + 1]; ++k)
				{
					int kcol = L_exter_colind[k];
					BSRBlockCopy(bsize, y + kcol * bnnz, L_exter_values + k * bnnz);
					BSRBlockMatLUSolve(bsize, D_recv_lu + kcol * bnnz, L_exter_values + k * bnnz);

					for (int j = U_recvext_rowptr[kcol]; j < U_recvext_rowptr[kcol + 1]; ++j)
					{
						int jcol = U_recvext_colind[j];
						if (v[jcol] == i)
							BSRBlockMatMulSub(bsize, L_exter_values + k * bnnz, U_recvext_values + j * bnnz, y + jcol * bnnz);
					}

					for (int j = U_recvloc_rowptr[kcol]; j < U_recvloc_rowptr[kcol + 1]; ++j)
					{
						int jcol = U_recvloc_colind[j];
						if (w[jcol] == i)
							BSRBlockMatMulSub(bsize, L_exter_values + k * bnnz, U_recvloc_values + j * bnnz, x + jcol * bnnz);
					}
				}

				for (int k = L_local_rowptr[i]; k < L_local_rowptr[i + 1]; ++k)
				{
					int kcol = L_local_colind[k];
					BSRBlockCopy(bsize, x + kcol * bnnz, L_local_values + k * bnnz);
					BSRBlockMatLUSolve(bsize, D_local_LU + kcol * bnnz, L_local_values + k * bnnz);

					for (int j = U_local_rowptr[kcol]; j < U_local_rowptr[kcol + 1]; ++j)
					{
						int jcol = U_local_colind[j];
						if (w[jcol] == i)
							BSRBlockMatMulSub(bsize, L_local_values + k * bnnz, U_local_values + j * bnnz, x + jcol * bnnz);
					}
				}

				BSRBlockCopy(bsize, x + i * bnnz, D_local_LU + i * bnnz);
				BSRBlockLUFactorize(bsize, D_local_LU + i * bnnz);
				for (int j = U_local_rowptr[i]; j < U_local_rowptr[i + 1]; ++j)
					BSRBlockCopy(bsize, x + U_local_colind[j] * bnnz, U_local_values + j * bnnz);
				for (int j = U_exter_rowptr[i]; j < U_exter_rowptr[i + 1]; ++j)
					BSRBlockCopy(bsize, y + U_exter_colind[j] * bnnz, U_exter_values + j * bnnz);
			}
		}

		delete[] w;
		delete[] x;
		delete[] v;
		delete[] y;

		delete[] D_recv_lu;
		delete[] U_recvloc_rowptr;
		delete[] U_recvloc_colind;
		delete[] U_recvloc_values;
		delete[] U_recvext_rowptr;
		delete[] U_recvext_colind;
		delete[] U_recvext_values;

		double* D_LU_Send = new double[sendptr[nnb] * bnnz];

		for (int r = 0; r < nnb; ++r)
		{
			if (label < nblab[r] && sendptr[r + 1] > sendptr[r])
			{
				int nrow = sendptr[r + 1] - sendptr[r];
				int nnz = 0;
				for (int i = sendptr[r]; i < sendptr[r + 1]; ++i)
					nnz += U_local_rowptr[sendind[i] + 1] - U_local_rowptr[sendind[i]] + U_exter_rowptr[sendind[i] + 1] - U_exter_rowptr[sendind[i]];

				int bufsize = (nrow + 2 * nnz * bnnz) * sizeof(int) + (nrow + nnz * bnnz) * sizeof(double);
				sendbuf[r] = (char*)malloc(bufsize);

				int position = 0;

				for (int i = sendptr[r]; i < sendptr[r + 1]; ++i)
					BSRBlockCopy(bsize, D_local_LU + sendind[i] * bnnz, D_LU_Send + i * bnnz);

				MPI_Pack(D_LU_Send + sendptr[r] * bnnz, (sendptr[r + 1] - sendptr[r]) * bnnz, MPI_DOUBLE, sendbuf[r], bufsize, &position, comm);

				for (int i = sendptr[r]; i < sendptr[r + 1]; ++i)
				{
					int irow = sendind[i];
					int length = U_local_rowptr[irow + 1] - U_local_rowptr[irow] + U_exter_rowptr[irow + 1] - U_exter_rowptr[irow];

					int* ranks = new int[length];
					int* colind = new int[length];
					double* values = new double[length * bnnz];

					int j = 0;
					for (int k = U_local_rowptr[irow]; k < U_local_rowptr[irow + 1]; ++k)
					{
						ranks[j] = comm_rank;
						colind[j] = U_local_colind[k];
						BSRBlockCopy(bsize, U_local_values + k * bnnz, values + j * bnnz);
						++j;
					}
					for (int k = U_exter_rowptr[irow]; k < U_exter_rowptr[irow + 1]; ++k)
					{
						int kcol = U_exter_colind[k];
						ranks[j] = nbrank[recvfrom[kcol]];
						colind[j] = recvind[kcol];
						BSRBlockCopy(bsize, U_exter_values + k * bnnz, values + j * bnnz);
						++j;
					}

					MPI_Pack(&length, 1, MPI_INT, sendbuf[r], bufsize, &position, comm);
					MPI_Pack(ranks, length, MPI_INT, sendbuf[r], bufsize, &position, comm);
					MPI_Pack(colind, length, MPI_INT, sendbuf[r], bufsize, &position, comm);
					MPI_Pack(values, length * bnnz, MPI_DOUBLE, sendbuf[r], bufsize, &position, comm);

					delete[] ranks;
					delete[] colind;
					delete[] values;
				}

				MPI_Isend(sendbuf[r], bufsize, MPI_PACKED, nbrank[r], MPI_TAG, comm, sendreq + r);
			}
		}

		for (int r = 0; r < nnb; ++r)
		{
			if (label < nblab[r] && sendptr[r + 1] > sendptr[r])
			{
				MPI_Wait(sendreq + r, &status);
				free(sendbuf[r]);
			}
		}

		delete[] recvbuf;
		delete[] recvreq;
		delete[] sendbuf;
		delete[] sendreq;
		delete[] D_LU_Send;
		delete[] recvfrom;

		L_local.size[0] = n;
		L_local.size[1] = n;
		L_local.bsize = bsize;
		L_local.rowptr = L_local_rowptr;
		L_local.colind = L_local_colind;
		L_local.values = L_local_values;

		L_exter.size[0] = n;
		L_exter.size[1] = recvcnt;
		L_exter.bsize = bsize;
		L_exter.rowptr = L_exter_rowptr;
		L_exter.colind = L_exter_colind;
		L_exter.values = L_exter_values;

		U_local.size[0] = n;
		U_local.size[1] = n;
		U_local.bsize = bsize;
		U_local.rowptr = U_local_rowptr;
		U_local.colind = U_local_colind;
		U_local.values = U_local_values;

		U_exter.size[0] = n;
		U_exter.size[1] = recvcnt;
		U_exter.bsize = bsize;
		U_exter.rowptr = U_exter_rowptr;
		U_exter.colind = U_exter_colind;
		U_exter.values = U_exter_values;

		recvx.Resize(recvcnt * bnnz);
	}
	else
	{
		int comm_rank;
		MPI_Comm_rank(comm, &comm_rank);

		int* L_local_rowptr = L_local.rowptr;
		int* L_local_colind = L_local.colind;
		double* L_local_values = L_local.values;
		int* U_local_rowptr = U_local.rowptr;
		int* U_local_colind = U_local.colind;
		double* U_local_values = U_local.values;
		int* L_exter_rowptr = L_exter.rowptr;
		int* L_exter_colind = L_exter.colind;
		double* L_exter_values = L_exter.values;
		int* U_exter_rowptr = U_exter.rowptr;
		int* U_exter_colind = U_exter.colind;
		double* U_exter_values = U_exter.values;

		int* w = new int[n];
		double* x = new double[n * bnnz];

		for (int i = 0; i < n; ++i)
			w[i] = -1;

#define BSR_UNROLL_SEGMENT(N) \
	for (int i = 0; i < n; ++i) \
	{ \
		if (interior[i]) \
		{ \
			w[i] = i; \
			BSRBlockFill_UNROLL(N, 0.0, x + i * N * N); \
			for (int j = A_local_rowptr[i], k = L_local_rowptr[i], r = U_local_rowptr[i]; j < A_local_rowptr[i + 1]; ++j) \
			{ \
				int jcol = A_local_colind[j]; \
				w[jcol] = i; \
				BSRBlockCopy_UNROLL(N, A_local_values + j * N * N, x + jcol * N * N); \
			} \
			for (int k = L_local_rowptr[i]; k < L_local_rowptr[i + 1]; ++k) \
			{ \
				int kcol = L_local_colind[k]; \
				BSRBlockCopy_UNROLL(N, x + kcol * N * N, L_local_values + k * N * N); \
				BSRBlockMatLUSolve_UNROLL(N, D_local_LU + kcol * N * N, L_local_values + k * N * N); \
				for (int j = U_local_rowptr[kcol]; j < U_local_rowptr[kcol + 1]; ++j) \
				{ \
					int jcol = U_local_colind[j]; \
					if (w[jcol] == i) \
						BSRBlockMatMulSub_UNROLL(N, L_local_values + k * N * N, U_local_values + j * N * N, x + jcol * N * N); \
				} \
			} \
			BSRBlockCopy_UNROLL(N, x + i * N * N, D_local_LU + i * N * N); \
			BSRBlockLUFactorize_UNROLL(N, D_local_LU + i * N * N); \
			for (int j = U_local_rowptr[i]; j < U_local_rowptr[i + 1]; ++j) \
				BSRBlockCopy_UNROLL(N, x + U_local_colind[j] * N * N, U_local_values + j * N * N); \
		} \
	}

#ifdef BSR_UNROLL_1
		if (bsize == 1) { BSR_UNROLL_SEGMENT(1) } else
#endif
#ifdef BSR_UNROLL_2
		if (bsize == 2) { BSR_UNROLL_SEGMENT(2) } else
#endif
#ifdef BSR_UNROLL_3
		if (bsize == 3) { BSR_UNROLL_SEGMENT(3) } else
#endif
#ifdef BSR_UNROLL_4
		if (bsize == 4) { BSR_UNROLL_SEGMENT(4) } else
#endif
#ifdef BSR_UNROLL_5
		if (bsize == 5) { BSR_UNROLL_SEGMENT(5) } else
#endif
#ifdef BSR_UNROLL_6
		if (bsize == 6) { BSR_UNROLL_SEGMENT(6) } else
#endif
#ifdef BSR_UNROLL_7
		if (bsize == 7) { BSR_UNROLL_SEGMENT(7) } else
#endif
#ifdef BSR_UNROLL_8
		if (bsize == 8) { BSR_UNROLL_SEGMENT(8) } else
#endif
#undef BSR_UNROLL_SEGMENT
		{
			for (int i = 0; i < n; ++i)
			{
				if (interior[i])
				{
					w[i] = i;
					BSRBlockFill(bsize, 0.0, x + i * bnnz);

					for (int j = A_local_rowptr[i], k = L_local_rowptr[i], r = U_local_rowptr[i]; j < A_local_rowptr[i + 1]; ++j)
					{
						int jcol = A_local_colind[j];
						w[jcol] = i;
						BSRBlockCopy(bsize, A_local_values + j * bnnz, x + jcol * bnnz);
					}

					for (int k = L_local_rowptr[i]; k < L_local_rowptr[i + 1]; ++k)
					{
						int kcol = L_local_colind[k];
						BSRBlockCopy(bsize, x + kcol * bnnz, L_local_values + k * bnnz);
						BSRBlockMatLUSolve(bsize, D_local_LU + kcol * bnnz, L_local_values + k * bnnz);

						for (int j = U_local_rowptr[kcol]; j < U_local_rowptr[kcol + 1]; ++j)
						{
							int jcol = U_local_colind[j];
							if (w[jcol] == i)
								BSRBlockMatMulSub(bsize, L_local_values + k * bnnz, U_local_values + j * bnnz, x + jcol * bnnz);
						}
					}

					BSRBlockCopy(bsize, x + i * bnnz, D_local_LU + i * bnnz);
					BSRBlockLUFactorize(bsize, D_local_LU + i * bnnz);
					for (int j = U_local_rowptr[i]; j < U_local_rowptr[i + 1]; ++j)
						BSRBlockCopy(bsize, x + U_local_colind[j] * bnnz, U_local_values + j * bnnz);
				}
			}
		}

		MPI_Request* recvreq = new MPI_Request[nnb];
		MPI_Request* sendreq = new MPI_Request[nnb];
		MPI_Status status;

		std::map<int, int> nbmap;
		std::map<int, int>* recvmap = new std::map<int, int>[nnb];

		for (int r = 0; r < nnb; ++r)
		{
			nbmap.insert(std::pair<int, int>(nbrank[r], r));
			for (int i = recvptr[r]; i < recvptr[r + 1]; ++i)
				recvmap[r].insert(std::pair<int, int>(recvind[i], i));
		}

		int* recvrank = new int[recvcnt];
		for (int r = 0; r < nnb; ++r)
			for (int i = recvptr[r]; i < recvptr[r + 1]; ++i)
				recvrank[i] = nbrank[r];

		char** recvbuf = new char* [nnb];
		char** sendbuf = new char* [nnb];

		int recvnnz = 0;

		for (int r = 0; r < nnb; ++r)
		{
			if (label > nblab[r] && recvptr[r + 1] > recvptr[r])
			{
				int bufsize;
				MPI_Probe(nbrank[r], MPI_TAG, comm, &status);
				MPI_Get_count(&status, MPI_PACKED, &bufsize);
				recvbuf[r] = (char*)malloc(bufsize);
				MPI_Irecv(recvbuf[r], bufsize, MPI_PACKED, nbrank[r], MPI_TAG, comm, recvreq + r);

				int nrow = recvptr[r + 1] - recvptr[r];
				int nnz = (bufsize - nrow * (sizeof(int) + bnnz * sizeof(double))) / (2 * sizeof(int) + bnnz * sizeof(double));
				recvnnz += nnz;
			}
		}

		double* D_recv_lu = new double[recvcnt * bnnz];
		int* U_recvloc_rowptr = new int[recvcnt + 1];
		int* U_recvloc_colind = new int[recvnnz];
		double* U_recvloc_values = new double[recvnnz * bnnz];
		int* U_recvext_rowptr = new int[recvcnt + 1];
		int* U_recvext_colind = new int[recvnnz];
		double* U_recvext_values = new double[recvnnz * bnnz];

		U_recvloc_rowptr[0] = 0;
		U_recvext_rowptr[0] = 0;

		for (int r = 0; r < nnb; ++r)
		{
			if (label > nblab[r] && recvptr[r + 1] > recvptr[r])
			{
				MPI_Wait(recvreq + r, &status);

				int bufsize;
				MPI_Get_count(&status, MPI_PACKED, &bufsize);

				int position = 0;

				MPI_Unpack(recvbuf[r], bufsize, &position, D_recv_lu + recvptr[r] * bnnz, (recvptr[r + 1] - recvptr[r]) * bnnz, MPI_DOUBLE, comm);

				for (int i = recvptr[r], k = U_recvloc_rowptr[i], t = U_recvext_rowptr[i]; i < recvptr[r + 1]; U_recvloc_rowptr[++i] = k, U_recvext_rowptr[i] = t)
				{
					int length;
					MPI_Unpack(recvbuf[r], bufsize, &position, &length, 1, MPI_INT, comm);

					int* ranks = new int[length];
					int* colind = new int[length];
					double* values = new double[length * bnnz];

					MPI_Unpack(recvbuf[r], bufsize, &position, ranks, length, MPI_INT, comm);
					MPI_Unpack(recvbuf[r], bufsize, &position, colind, length, MPI_INT, comm);
					MPI_Unpack(recvbuf[r], bufsize, &position, values, length * bnnz, MPI_DOUBLE, comm);

					for (int j = 0; j < length; ++j)
					{
						if (ranks[j] == comm_rank)
						{
							U_recvloc_colind[k] = colind[j];
							BSRBlockCopy(bsize, values + j * bnnz, U_recvloc_values + k * bnnz);
							++k;
						}
						else
						{
							std::map<int, int>::iterator ret1 = nbmap.find(ranks[j]);
							if (ret1 == nbmap.end()) continue;
							std::map<int, int>::iterator ret2 = recvmap[ret1->second].find(colind[j]);
							if (ret2 == recvmap[ret1->second].end()) continue;
							U_recvext_colind[t] = ret2->second;
							BSRBlockCopy(bsize, values + j * bnnz, U_recvext_values + t * bnnz);
							++t;
						}
					}

					delete[] ranks;
					delete[] colind;
					delete[] values;
				}

				free(recvbuf[r]);
			}
			else if (recvptr[r + 1] > recvptr[r])
			{
				for (int i = recvptr[r], k = U_recvloc_rowptr[i], t = U_recvext_rowptr[i]; i < recvptr[r + 1]; U_recvloc_rowptr[++i] = k, U_recvext_rowptr[i] = t)
					;
			}
		}

		delete[] recvmap;

		int* v = new int[recvcnt];
		double* y = new double[recvcnt * bnnz];

		for (int i = 0; i < recvcnt; ++i)
			v[i] = -1;

#define BSR_UNROLL_SEGMENT(N) \
	for (int i = 0; i < n; ++i) \
	{ \
		if (interior[i]) continue; \
		w[i] = i; \
		BSRBlockFill_UNROLL(N, 0.0, x + i * N * N); \
		for (int j = A_local_rowptr[i], k = L_local_rowptr[i], r = U_local_rowptr[i]; j < A_local_rowptr[i + 1]; ++j) \
		{ \
			int jcol = A_local_colind[j]; \
			w[jcol] = i; \
			BSRBlockCopy_UNROLL(N, A_local_values + j * N * N, x + jcol * N * N); \
		} \
		for (int j = A_exter_rowptr[i], k = L_exter_rowptr[i], r = U_exter_rowptr[i]; j < A_exter_rowptr[i + 1]; ++j) \
		{ \
			int jcol = A_exter_colind[j]; \
			v[jcol] = i; \
			BSRBlockCopy_UNROLL(N, A_exter_values + j * N * N, y + jcol * N * N); \
		} \
		for (int k = L_exter_rowptr[i]; k < L_exter_rowptr[i + 1]; ++k) \
		{ \
			int kcol = L_exter_colind[k]; \
			BSRBlockCopy_UNROLL(N, y + kcol * N * N, L_exter_values + k * N * N); \
			BSRBlockMatLUSolve_UNROLL(N, D_recv_lu + kcol * N * N, L_exter_values + k * N * N); \
			for (int j = U_recvext_rowptr[kcol]; j < U_recvext_rowptr[kcol + 1]; ++j) \
			{ \
				int jcol = U_recvext_colind[j]; \
				if (v[jcol] == i) \
					BSRBlockMatMulSub_UNROLL(N, L_exter_values + k * N * N, U_recvext_values + j * N * N, y + jcol * N * N); \
			} \
			for (int j = U_recvloc_rowptr[kcol]; j < U_recvloc_rowptr[kcol + 1]; ++j) \
			{ \
				int jcol = U_recvloc_colind[j]; \
				if (w[jcol] == i) \
					BSRBlockMatMulSub_UNROLL(N, L_exter_values + k * N * N, U_recvloc_values + j * N * N, x + jcol * N * N); \
			} \
		} \
		for (int k = L_local_rowptr[i]; k < L_local_rowptr[i + 1]; ++k) \
		{ \
			int kcol = L_local_colind[k]; \
			BSRBlockCopy_UNROLL(N, x + kcol * N * N, L_local_values + k * N * N); \
			BSRBlockMatLUSolve_UNROLL(N, D_local_LU + kcol * N * N, L_local_values + k * N * N); \
			for (int j = U_local_rowptr[kcol]; j < U_local_rowptr[kcol + 1]; ++j) \
			{ \
				int jcol = U_local_colind[j]; \
				if (w[jcol] == i) \
					BSRBlockMatMulSub_UNROLL(N, L_local_values + k * N * N, U_local_values + j * N * N, x + jcol * N * N); \
			} \
		} \
		BSRBlockCopy_UNROLL(N, x + i * N * N, D_local_LU + i * N * N); \
		BSRBlockLUFactorize_UNROLL(N, D_local_LU + i * N * N); \
		for (int j = U_local_rowptr[i]; j < U_local_rowptr[i + 1]; ++j) \
			BSRBlockCopy_UNROLL(N, x + U_local_colind[j] * N * N, U_local_values + j * N * N); \
		for (int j = U_exter_rowptr[i]; j < U_exter_rowptr[i + 1]; ++j) \
			BSRBlockCopy_UNROLL(N, y + U_exter_colind[j] * N * N, U_exter_values + j * N * N); \
	}

#ifdef BSR_UNROLL_1
		if (bsize == 1) { BSR_UNROLL_SEGMENT(1) } else
#endif
#ifdef BSR_UNROLL_2
		if (bsize == 2) { BSR_UNROLL_SEGMENT(2) } else
#endif
#ifdef BSR_UNROLL_3
		if (bsize == 3) { BSR_UNROLL_SEGMENT(3) } else
#endif
#ifdef BSR_UNROLL_4
		if (bsize == 4) { BSR_UNROLL_SEGMENT(4) } else
#endif
#ifdef BSR_UNROLL_5
		if (bsize == 5) { BSR_UNROLL_SEGMENT(5) } else
#endif
#ifdef BSR_UNROLL_6
		if (bsize == 6) { BSR_UNROLL_SEGMENT(6) } else
#endif
#ifdef BSR_UNROLL_7
		if (bsize == 7) { BSR_UNROLL_SEGMENT(7) } else
#endif
#ifdef BSR_UNROLL_8
		if (bsize == 8) { BSR_UNROLL_SEGMENT(8) } else
#endif
#undef BSR_UNROLL_SEGMENT
		{
			for (int i = 0; i < n; ++i)
			{
				if (interior[i]) continue;

				w[i] = i;
				BSRBlockFill(bsize, 0.0, x + i * bnnz);

				for (int j = A_local_rowptr[i], k = L_local_rowptr[i], r = U_local_rowptr[i]; j < A_local_rowptr[i + 1]; ++j)
				{
					int jcol = A_local_colind[j];
					w[jcol] = i;
					BSRBlockCopy(bsize, A_local_values + j * bnnz, x + jcol * bnnz);
				}

				for (int j = A_exter_rowptr[i], k = L_exter_rowptr[i], r = U_exter_rowptr[i]; j < A_exter_rowptr[i + 1]; ++j)
				{
					int jcol = A_exter_colind[j];
					v[jcol] = i;
					BSRBlockCopy(bsize, A_exter_values + j * bnnz, y + jcol * bnnz);
				}

				for (int k = L_exter_rowptr[i]; k < L_exter_rowptr[i + 1]; ++k)
				{
					int kcol = L_exter_colind[k];
					BSRBlockCopy(bsize, y + kcol * bnnz, L_exter_values + k * bnnz);
					BSRBlockMatLUSolve(bsize, D_recv_lu + kcol * bnnz, L_exter_values + k * bnnz);

					for (int j = U_recvext_rowptr[kcol]; j < U_recvext_rowptr[kcol + 1]; ++j)
					{
						int jcol = U_recvext_colind[j];
						if (v[jcol] == i)
							BSRBlockMatMulSub(bsize, L_exter_values + k * bnnz, U_recvext_values + j * bnnz, y + jcol * bnnz);
							
					}

					for (int j = U_recvloc_rowptr[kcol]; j < U_recvloc_rowptr[kcol + 1]; ++j)
					{
						int jcol = U_recvloc_colind[j];
						if (w[jcol] == i)
							BSRBlockMatMulSub(bsize, L_exter_values + k * bnnz, U_recvloc_values + j * bnnz, x + jcol * bnnz);
					}
				}

				for (int k = L_local_rowptr[i]; k < L_local_rowptr[i + 1]; ++k)
				{
					int kcol = L_local_colind[k];
					BSRBlockCopy(bsize, x + kcol * bnnz, L_local_values + k * bnnz);
					BSRBlockMatLUSolve(bsize, D_local_LU + kcol * bnnz, L_local_values + k * bnnz);

					for (int j = U_local_rowptr[kcol]; j < U_local_rowptr[kcol + 1]; ++j)
					{
						int jcol = U_local_colind[j];
						if (w[jcol] == i)
							BSRBlockMatMulSub(bsize, L_local_values + k * bnnz, U_local_values + j * bnnz, x + jcol * bnnz);
					}
				}

				BSRBlockCopy(bsize, x + i * bnnz, D_local_LU + i * bnnz);
				BSRBlockLUFactorize(bsize, D_local_LU + i * bnnz);
				for (int j = U_local_rowptr[i]; j < U_local_rowptr[i + 1]; ++j)
					BSRBlockCopy(bsize, x + U_local_colind[j] * bnnz, U_local_values + j * bnnz);
				for (int j = U_exter_rowptr[i]; j < U_exter_rowptr[i + 1]; ++j)
					BSRBlockCopy(bsize, y + U_exter_colind[j] * bnnz, U_exter_values + j * bnnz);
			}
		}

		delete[] w;
		delete[] x;
		delete[] v;
		delete[] y;

		delete[] D_recv_lu;
		delete[] U_recvloc_rowptr;
		delete[] U_recvloc_colind;
		delete[] U_recvloc_values;
		delete[] U_recvext_rowptr;
		delete[] U_recvext_colind;
		delete[] U_recvext_values;

		double* D_LU_Send = new double[sendptr[nnb] * bnnz];

		for (int r = 0; r < nnb; ++r)
		{
			if (label < nblab[r] && sendptr[r + 1] > sendptr[r])
			{
				int nrow = sendptr[r + 1] - sendptr[r];
				int nnz = 0;
				for (int i = sendptr[r]; i < sendptr[r + 1]; ++i)
					nnz += U_local_rowptr[sendind[i] + 1] - U_local_rowptr[sendind[i]] + U_exter_rowptr[sendind[i] + 1] - U_exter_rowptr[sendind[i]];

				int bufsize = (nrow + 2 * nnz * bnnz) * sizeof(int) + (nrow + nnz * bnnz) * sizeof(double);
				sendbuf[r] = (char*)malloc(bufsize);

				int position = 0;

				for (int i = sendptr[r]; i < sendptr[r + 1]; ++i)
					BSRBlockCopy(bsize, D_local_LU + sendind[i] * bnnz, D_LU_Send + i * bnnz);

				MPI_Pack(D_LU_Send + sendptr[r] * bnnz, (sendptr[r + 1] - sendptr[r]) * bnnz, MPI_DOUBLE, sendbuf[r], bufsize, &position, comm);

				for (int i = sendptr[r]; i < sendptr[r + 1]; ++i)
				{
					int irow = sendind[i];
					int length = U_local_rowptr[irow + 1] - U_local_rowptr[irow] + U_exter_rowptr[irow + 1] - U_exter_rowptr[irow];

					int* ranks = new int[length];
					int* colind = new int[length];
					double* values = new double[length * bnnz];

					int j = 0;
					for (int k = U_local_rowptr[irow]; k < U_local_rowptr[irow + 1]; ++k)
					{
						ranks[j] = comm_rank;
						colind[j] = U_local_colind[k];
						BSRBlockCopy(bsize, U_local_values + k * bnnz, values + j * bnnz);
						++j;
					}
					for (int k = U_exter_rowptr[irow]; k < U_exter_rowptr[irow + 1]; ++k)
					{
						int kcol = U_exter_colind[k];
						ranks[j] = recvrank[kcol];
						colind[j] = recvind[kcol];
						BSRBlockCopy(bsize, U_exter_values + k * bnnz, values + j * bnnz);
						++j;
					}

					MPI_Pack(&length, 1, MPI_INT, sendbuf[r], bufsize, &position, comm);
					MPI_Pack(ranks, length, MPI_INT, sendbuf[r], bufsize, &position, comm);
					MPI_Pack(colind, length, MPI_INT, sendbuf[r], bufsize, &position, comm);
					MPI_Pack(values, length * bnnz, MPI_DOUBLE, sendbuf[r], bufsize, &position, comm);

					delete[] ranks;
					delete[] colind;
					delete[] values;
				}

				MPI_Isend(sendbuf[r], bufsize, MPI_PACKED, nbrank[r], MPI_TAG, comm, sendreq + r);
			}
		}

		for (int r = 0; r < nnb; ++r)
		{
			if (label < nblab[r] && sendptr[r + 1] > sendptr[r])
			{
				MPI_Wait(sendreq + r, &status);
				free(sendbuf[r]);
			}
		}

		delete[] recvbuf;
		delete[] recvreq;
		delete[] sendbuf;
		delete[] sendreq;
		delete[] D_LU_Send;
		delete[] recvrank;
	}
}

int ParBSRPrecondILU0::InSize() const
{
	return L_local.size[0] * L_local.bsize;
}

int ParBSRPrecondILU0::OutSize() const
{
	return L_local.size[0] * L_local.bsize;
}

void ParBSRPrecondILU0::Apply(const ParVector& b, const ParVector& x) const
{
	int n = L_local.size[0];
	int bsize = L_local.bsize;
	int bnnz = bsize * bsize;
	int* L_local_rowptr = L_local.rowptr;
	int* L_local_colind = L_local.colind;
	double* L_local_values = L_local.values;
	int* L_exter_rowptr = L_exter.rowptr;
	int* L_exter_colind = L_exter.colind;
	double* L_exter_values = L_exter.values;
	int* U_local_rowptr = U_local.rowptr;
	int* U_local_colind = U_local.colind;
	double* U_local_values = U_local.values;
	int* U_exter_rowptr = U_exter.rowptr;
	int* U_exter_colind = U_exter.colind;
	double* U_exter_values = U_exter.values;

	double* b_local_values = b.local.values;
	double* x_local_values = x.local.values;
	double* x_recv_values = recvx.values;

	MPI_Request* recvreq = new MPI_Request[nnb];
	MPI_Request* sendreq = new MPI_Request[nnb];
	MPI_Status status;

#define BSR_UNROLL_SEGMENT(N) \
	for (int i = 0; i < n; ++i) \
	{ \
		if (!interior[i]) continue; \
		VecBlockCopy_UNROLL(N, b_local_values + i * N, x_local_values + i * N); \
		for (int j = L_local_rowptr[i]; j < L_local_rowptr[i + 1]; ++j) \
			BSRBlockMatVecSub_UNROLL(N, L_local_values + j * N * N, x_local_values + L_local_colind[j] * N, x_local_values + i * N); \
	} \
	for (int r = 0; r < nnb; ++r) \
		if (label > nblab[r] && recvptr[r + 1] > recvptr[r]) \
			MPI_Irecv(x_recv_values + recvptr[r] * N, (recvptr[r + 1] - recvptr[r]) * N, MPI_DOUBLE, nbrank[r], MPI_TAG, comm, recvreq + r); \
	for (int r = 0; r < nnb; ++r) \
		if (label > nblab[r] && recvptr[r + 1] > recvptr[r]) \
			MPI_Wait(recvreq + r, &status); \
	for (int i = 0; i < n; ++i) \
	{ \
		if (interior[i]) continue; \
		VecBlockCopy_UNROLL(N, b_local_values + i * N, x_local_values + i * N); \
		for (int j = L_exter_rowptr[i]; j < L_exter_rowptr[i + 1]; ++j) \
			BSRBlockMatVecSub_UNROLL(N, L_exter_values + j * N * N, x_recv_values + L_exter_colind[j] * N, x_local_values + i * N); \
		for (int j = L_local_rowptr[i]; j < L_local_rowptr[i + 1]; ++j) \
			BSRBlockMatVecSub_UNROLL(N, L_local_values + j * N * N, x_local_values + L_local_colind[j] * N, x_local_values + i * N); \
	} \
	for (int r = 0; r < nnb; ++r) \
	{ \
		if (label < nblab[r] && sendptr[r + 1] > sendptr[r]) \
		{ \
			for (int i = sendptr[r]; i < sendptr[r + 1]; ++i) \
				VecBlockCopy_UNROLL(N, x_local_values + sendind[i] * N, sendbuf + i * N); \
			MPI_Isend(sendbuf + sendptr[r] * N, (sendptr[r + 1] - sendptr[r]) * N, MPI_DOUBLE, nbrank[r], MPI_TAG, comm, sendreq + r); \
		} \
	} \
	for (int r = 0; r < nnb; ++r) \
		if (label < nblab[r] && sendptr[r + 1] > sendptr[r]) \
			MPI_Wait(sendreq + r, &status); \
	for (int r = 0; r < nnb; ++r) \
		if (label < nblab[r] && recvptr[r + 1] > recvptr[r]) \
			MPI_Irecv(x_recv_values + recvptr[r] * N, (recvptr[r + 1] - recvptr[r]) * N, MPI_DOUBLE, nbrank[r], MPI_TAG, comm, recvreq + r); \
	for (int r = 0; r < nnb; ++r) \
		if (label < nblab[r] && recvptr[r + 1] > recvptr[r]) \
			MPI_Wait(recvreq + r, &status); \
	for (int i = n - 1; i >= 0; --i) \
	{ \
		if (interior[i]) continue; \
		for (int j = U_exter_rowptr[i + 1] - 1; j >= U_exter_rowptr[i]; --j) \
			BSRBlockMatVecSub_UNROLL(N, U_exter_values + j * N * N, x_recv_values + U_exter_colind[j] * N, x_local_values + i * N); \
		for (int j = U_local_rowptr[i + 1] - 1; j >= U_local_rowptr[i]; --j) \
			BSRBlockMatVecSub_UNROLL(N, U_local_values + j * N * N, x_local_values + U_local_colind[j] * N, x_local_values + i * N); \
		BSRBlockLUVecSolve_UNROLL(N, D_local_LU + i * N * N, x_local_values + i * N); \
	} \
	for (int r = 0; r < nnb; ++r) \
	{ \
		if (label > nblab[r] && sendptr[r + 1] > sendptr[r]) \
		{ \
			for (int i = sendptr[r]; i < sendptr[r + 1]; ++i) \
				VecBlockCopy_UNROLL(N, x_local_values + sendind[i] * N, sendbuf + i * N); \
			MPI_Isend(sendbuf + sendptr[r] * N, (sendptr[r + 1] - sendptr[r]) * N, MPI_DOUBLE, nbrank[r], MPI_TAG, comm, sendreq + r); \
		} \
	} \
	for (int r = 0; r < nnb; ++r) \
		if (label > nblab[r] && sendptr[r + 1] > sendptr[r]) \
			MPI_Wait(sendreq + r, &status); \
	for (int i = n - 1; i >= 0; --i) \
	{ \
		if (!interior[i]) continue; \
		for (int j = U_local_rowptr[i + 1] - 1; j >= U_local_rowptr[i]; --j) \
			BSRBlockMatVecSub_UNROLL(N, U_local_values + j * N * N, x_local_values + U_local_colind[j] * N, x_local_values + i * N); \
		BSRBlockLUVecSolve_UNROLL(N, D_local_LU + i * N * N, x_local_values + i * N); \
	}

#ifdef BSR_UNROLL_1
	if (bsize == 1) { BSR_UNROLL_SEGMENT(1) } else
#endif
#ifdef BSR_UNROLL_2
	if (bsize == 2) { BSR_UNROLL_SEGMENT(2) } else
#endif
#ifdef BSR_UNROLL_3
	if (bsize == 3) { BSR_UNROLL_SEGMENT(3) } else
#endif
#ifdef BSR_UNROLL_4
	if (bsize == 4) { BSR_UNROLL_SEGMENT(4) } else
#endif
#ifdef BSR_UNROLL_5
	if (bsize == 5) { BSR_UNROLL_SEGMENT(5) } else
#endif
#ifdef BSR_UNROLL_6
	if (bsize == 6) { BSR_UNROLL_SEGMENT(6) } else
#endif
#ifdef BSR_UNROLL_7
	if (bsize == 7) { BSR_UNROLL_SEGMENT(7) } else
#endif
#ifdef BSR_UNROLL_8
	if (bsize == 8) { BSR_UNROLL_SEGMENT(8) } else
#endif
#undef BSR_UNROLL_SEGMENT
	{
		for (int i = 0; i < n; ++i)
		{
			if (!interior[i]) continue;
			VecBlockCopy(bsize, b_local_values + i * bsize, x_local_values + i * bsize);
			for (int j = L_local_rowptr[i]; j < L_local_rowptr[i + 1]; ++j)
				BSRBlockMatVecSub(bsize, L_local_values + j * bnnz, x_local_values + L_local_colind[j] * bsize, x_local_values + i * bsize);
		}

		for (int r = 0; r < nnb; ++r)
			if (label > nblab[r] && recvptr[r + 1] > recvptr[r])
				MPI_Irecv(x_recv_values + recvptr[r] * bsize, (recvptr[r + 1] - recvptr[r]) * bsize, MPI_DOUBLE, nbrank[r], MPI_TAG, comm, recvreq + r);

		for (int r = 0; r < nnb; ++r)
			if (label > nblab[r] && recvptr[r + 1] > recvptr[r])
				MPI_Wait(recvreq + r, &status);

		for (int i = 0; i < n; ++i)
		{
			if (interior[i]) continue;
			VecBlockCopy(bsize, b_local_values + i * bsize, x_local_values + i * bsize);
			for (int j = L_exter_rowptr[i]; j < L_exter_rowptr[i + 1]; ++j)
				BSRBlockMatVecSub(bsize, L_exter_values + j * bnnz, x_recv_values + L_exter_colind[j] * bsize, x_local_values + i * bsize);
			for (int j = L_local_rowptr[i]; j < L_local_rowptr[i + 1]; ++j)
				BSRBlockMatVecSub(bsize, L_local_values + j * bnnz, x_local_values + L_local_colind[j] * bsize, x_local_values + i * bsize);
		}

		for (int r = 0; r < nnb; ++r)
		{
			if (label < nblab[r] && sendptr[r + 1] > sendptr[r])
			{
				for (int i = sendptr[r]; i < sendptr[r + 1]; ++i)
					VecBlockCopy(bsize, x_local_values + sendind[i] * bsize, sendbuf + i * bsize);
				MPI_Isend(sendbuf + sendptr[r] * bsize, (sendptr[r + 1] - sendptr[r]) * bsize, MPI_DOUBLE, nbrank[r], MPI_TAG, comm, sendreq + r);
			}
		}

		for (int r = 0; r < nnb; ++r)
			if (label < nblab[r] && sendptr[r + 1] > sendptr[r])
				MPI_Wait(sendreq + r, &status);

		for (int r = 0; r < nnb; ++r)
			if (label < nblab[r] && recvptr[r + 1] > recvptr[r])
				MPI_Irecv(x_recv_values + recvptr[r] * bsize, (recvptr[r + 1] - recvptr[r]) * bsize, MPI_DOUBLE, nbrank[r], MPI_TAG, comm, recvreq + r);

		for (int r = 0; r < nnb; ++r)
			if (label < nblab[r] && recvptr[r + 1] > recvptr[r])
				MPI_Wait(recvreq + r, &status);

		for (int i = n - 1; i >= 0; --i)
		{
			if (interior[i]) continue;
			for (int j = U_exter_rowptr[i + 1] - 1; j >= U_exter_rowptr[i]; --j)
				BSRBlockMatVecSub(bsize, U_exter_values + j * bnnz, x_recv_values + U_exter_colind[j] * bsize, x_local_values + i * bsize);
			for (int j = U_local_rowptr[i + 1] - 1; j >= U_local_rowptr[i]; --j)
				BSRBlockMatVecSub(bsize, U_local_values + j * bnnz, x_local_values + U_local_colind[j] * bsize, x_local_values + i * bsize);
			BSRBlockLUVecSolve(bsize, D_local_LU + i * bnnz, x_local_values + i * bsize);
		}

		for (int r = 0; r < nnb; ++r)
		{
			if (label > nblab[r] && sendptr[r + 1] > sendptr[r])
			{
				for (int i = sendptr[r]; i < sendptr[r + 1]; ++i)
					VecBlockCopy(bsize, x_local_values + sendind[i] * bsize, sendbuf + i * bsize);
				MPI_Isend(sendbuf + sendptr[r] * bsize, (sendptr[r + 1] - sendptr[r]) * bsize, MPI_DOUBLE, nbrank[r], MPI_TAG, comm, sendreq + r);
			}
		}

		for (int r = 0; r < nnb; ++r)
			if (label > nblab[r] && sendptr[r + 1] > sendptr[r])
				MPI_Wait(sendreq + r, &status);

		for (int i = n - 1; i >= 0; --i)
		{
			if (!interior[i]) continue;
			for (int j = U_local_rowptr[i + 1] - 1; j >= U_local_rowptr[i]; --j)
				BSRBlockMatVecSub(bsize, U_local_values + j * bnnz, x_local_values + U_local_colind[j] * bsize, x_local_values + i * bsize);
			BSRBlockLUVecSolve(bsize, D_local_LU + i * bnnz, x_local_values + i * bsize);
		}
	}

	delete[] recvreq;
	delete[] sendreq;
}

}